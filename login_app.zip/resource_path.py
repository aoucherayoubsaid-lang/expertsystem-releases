# -*- coding: utf-8 -*-
"""يحل مشكلة شائعة جداً بعد تحويل برامج PyQt إلى .exe عبر PyInstaller:
الملفات المرفقة (أيقونة، قوالب HTML...) تُستخرَج مؤقتاً عند التشغيل في
مجلد مختلف (sys._MEIPASS) وليس بجانب الملف .py الأصلي، فإذا استمر الكود
في البحث عنها بجانب __file__ فقط، لن يجدها بعد التحويل رغم أنها "مرفقة".

استعمل resource_path(...) لبناء أي مسار لملف مرفق مع البرنامج (أيقونة،
قالب، صورة...) بدل بنائه يدوياً، ليعمل صحيحاً في الحالتين.
"""
import os
import sys


def resource_path(*parts):
    """يبني مساراً كاملاً لملف مرفق مع البرنامج، صالحاً في كل الحالات:
    تشغيل كسكربت بايثون عادي، أو بعد تحويله لملف .exe (onefile أو onedir).

    مثال:
        icon_path = resource_path("app_icon.ico")
        template_dir = resource_path("templates")
    """
    if getattr(sys, "frozen", False):
        base_dir = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(sys.executable)))
    else:
        base_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_dir, *parts)
