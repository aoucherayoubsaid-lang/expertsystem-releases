# -*- coding: utf-8 -*-
"""Backup/restore utilities for the local application data.

Backups are ZIP snapshots plus a SHA-256 manifest. This is intentionally
separate from the UI so it can later be connected to Settings.
"""
import json
import os
import shutil
import tempfile
import zipfile
from datetime import datetime

import secure_storage


def create_backup(source_root, destination_dir):
    source_root = os.path.abspath(source_root)
    os.makedirs(destination_dir, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    tmp_root = tempfile.mkdtemp(prefix="expert_backup_")
    try:
        manifest = secure_storage.build_manifest(source_root)
        manifest_path = os.path.join(tmp_root, "MANIFEST.json")
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, ensure_ascii=False, indent=2)
        zip_path = os.path.join(destination_dir, "ExpertJudicial_Backup_%s.zip" % stamp)
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.write(manifest_path, "MANIFEST.json")
            for base, dirs, files in os.walk(source_root):
                dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git")]
                for name in files:
                    path = os.path.join(base, name)
                    if os.path.abspath(path) == os.path.abspath(zip_path):
                        continue
                    arc = os.path.relpath(path, source_root)
                    zf.write(path, arc)
        return zip_path
    finally:
        shutil.rmtree(tmp_root, ignore_errors=True)
