# -*- coding: utf-8 -*-
"""قوالب الرسائل المرسلة للمطوّر (اقتراح/مشكلة/طلب تفعيل): منظمة وعربية الاتجاه.

الأنماط:
  wa    : واتساب/لصق — رموز تعبيرية + خط عريض *...*
  mail  : Gmail في المتصفح — رموز تعبيرية بدون عريض
  plain : برنامج البريد والملف النصي — بلا رموز (تتوافق مع ويندوز 7 وأوتلوك)
كل سطر يبدأ بعلامة RLM كي يبقى اتجاهه من اليمين حتى لو احتوى أرقاماً أو إنجليزية.
"""
import platform
from datetime import datetime

import app_info

RLM = "\u200f"
LRM = "\u200e"

_ICON = {"title": "📩", "type": "🔖", "subject": "📝", "details": "📄", "from": "👤",
         "contact": "📞", "tech": "⚙️", "date": "🗓", "key": "🔑", "code": "🖥"}
_TYPE_ICON = {"اقتراح": "💡", "مشكلة": "🐞", "سؤال": "❓"}


def _line(text=""):
    return (RLM + text) if text else ""


def _fmt(style):
    sep = "━━━━━━━━━━━━━━━━" if style != "plain" else "────────────────"

    def label(key, text):
        if style == "plain":
            return text + ":"
        icon = _ICON.get(key, "")
        if key == "type":
            pass
        return ("%s *%s:*" % (icon, text)) if style == "wa" else ("%s %s:" % (icon, text))

    def heading(key, text):
        if style == "plain":
            return text
        icon = _ICON.get(key, "")
        return ("%s *%s*" % (icon, text)) if style == "wa" else ("%s %s" % (icon, text))

    return sep, label, heading


def windows_name():
    try:
        if platform.system() == "Windows":
            rel = platform.release()
            return "ويندوز " + rel if rel else "ويندوز"
        return platform.platform()
    except Exception:
        return "غير معروف"


def tech_lines():
    try:
        import license_manager
        lic = license_manager.status_text()
    except Exception:
        lic = "—"
    return [("الإصدار", LRM + app_info.APP_VERSION + LRM), ("النظام", windows_name()), ("الترخيص", lic)]


def feedback_message(style, word, subject, desc, name="", contact="", include_tech=True):
    sep, label, heading = _fmt(style)
    out = [_line(sep),
           _line(heading("title", "رسالة من " + app_info.APP_NAME_AR)),
           _line(sep)]
    type_label = label("type", "النوع")
    if style != "plain":
        type_label = type_label.replace(_ICON["type"], _TYPE_ICON.get(word, _ICON["type"]))
    out += [_line("%s %s" % (type_label, word)),
            _line("%s %s" % (label("subject", "العنوان"), subject or "بدون عنوان")),
            "", _line(label("details", "التفاصيل"))]
    out += [_line(l) for l in (desc or "").strip().splitlines()]
    if name or contact:
        out.append("")
        if name:
            out.append(_line("%s %s" % (label("from", "المرسل"), name)))
        if contact:
            out.append(_line("%s %s" % (label("contact", "للتواصل"), LRM + contact + LRM)))
    if include_tech:
        out += ["", _line(label("tech", "معلومات تقنية"))]
        out += [_line("• %s: %s" % (k, v)) for k, v in tech_lines()]
    out += [_line(sep), _line("%s %s" % (label("date", "التاريخ"), LRM + datetime.now().strftime("%Y/%m/%d  %H:%M") + LRM))]
    return "\n".join(out)


def feedback_subject(word, subject):
    return "%s: %s — نظام الخبير القضائي" % (word, subject or "بدون عنوان")


def license_request(style, machine_code, name=""):
    sep, label, heading = _fmt(style)
    out = [_line(sep),
           _line(heading("key", "طلب تفعيل البرنامج")),
           _line(sep),
           _line("السلام عليكم، أرغب في تفعيل برنامج " + app_info.APP_NAME_AR + "."),
           "",
           _line("%s %s" % (label("from", "الاسم"), name or "..........")),
           _line("%s %s" % (label("contact", "هاتفي"), "..........")),
           _line("%s %s" % (label("code", "رمز الجهاز"), LRM + machine_code + LRM)),
           _line("• الإصدار: " + LRM + app_info.APP_VERSION + LRM),
           _line(sep)]
    return "\n".join(out)


def license_subject():
    return "طلب تفعيل — نظام الخبير القضائي"
