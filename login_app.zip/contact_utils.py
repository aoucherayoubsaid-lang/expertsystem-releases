# -*- coding: utf-8 -*-
"""روابط التواصل مع المطوّر (واتساب / بريد) — تُفتح في المتصفح أو برنامج البريد."""
from urllib.parse import quote

from PyQt5.QtCore import QUrl
from PyQt5.QtGui import QDesktopServices

import app_info


def open_whatsapp(text):
    url = "https://wa.me/%s?text=%s" % (app_info.DEVELOPER_WHATSAPP, quote(text, safe=""))
    return QDesktopServices.openUrl(QUrl(url))


def open_gmail(subject, body):
    url = "https://mail.google.com/mail/?view=cm&fs=1&to=%s&su=%s&body=%s" % (
        quote(app_info.DEVELOPER_EMAIL), quote(subject, safe=""), quote(body, safe=""))
    return QDesktopServices.openUrl(QUrl(url))


def open_mail_client(subject, body, limit=1500):
    # روابط mailto محدودة الطول في ويندوز: نقتطع النص الطويل
    if len(body) > limit:
        body = body[:limit] + "\n...(اختُصر النص — استعمل زر «نسخ» لإرساله كاملاً)"
    url = "mailto:%s?subject=%s&body=%s" % (
        app_info.DEVELOPER_EMAIL, quote(subject, safe=""), quote(body, safe=""))
    return QDesktopServices.openUrl(QUrl(url))
