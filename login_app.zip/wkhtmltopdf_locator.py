# -*- coding: utf-8 -*-
"""يبحث عن الملف التنفيذي wkhtmltopdf.exe المُضمَّن مع توزيعة البرنامج،
بدل الاعتماد على مسار ثابت مكتوب في الكود (مثل D:\\Program Files\\...)
والذي يختلف من جهاز لآخر ويفشل عند أي عميل لا يملك نفس المسار بالضبط.

كيف تُضمِّن wkhtmltopdf مع برنامجك (مرة واحدة فقط، عند التحضير للتوزيع):
------------------------------------------------------------------
1) نزّل النسخة "portable / minimal" (بدون مثبِّت Installer) من الموقع الرسمي:
   https://wkhtmltopdf.org/downloads.html
   اختر إصدار Windows، وابحث عن نسخة .zip أو استخرج wkhtmltopdf.exe من
   المثبِّت العادي بعد تثبيته مرة واحدة على أي جهاز (هو ملف تنفيذي مستقل
   لا يحتاج لأي تسجيل في النظام ليعمل).

2) انسخ الملف بحيث يصبح المسار داخل مجلد مشروعك:
       <مجلد المشروع>/vendor/wkhtmltopdf/wkhtmltopdf.exe

3) عند تحويل البرنامج إلى .exe عبر PyInstaller، أضف هذا المجلد كملف بيانات
   إضافي (data) حتى يُنسَخ داخل التوزيعة النهائية. مثال سطر أوامر (Windows):

       pyinstaller main_app.py --add-data "vendor\\wkhtmltopdf;vendor\\wkhtmltopdf"

   أو داخل ملف .spec (إن كنت تستعمل واحداً):

       a = Analysis(
           ...,
           datas=[('vendor/wkhtmltopdf', 'vendor/wkhtmltopdf')],
           ...
       )

هذه الوحدة تبحث عن الملف بالترتيب التالي، وتستعمل أول نسخة تجدها:
    1) بجانب البرنامج نفسه بعد تحويله لـ .exe (vendor/wkhtmltopdf/wkhtmltopdf.exe)
    2) بجانب سكربتات المشروع أثناء التطوير العادي (قبل التحويل لـ .exe)
    3) أي مسار تثبيت شائع على ويندوز (لو كان الجهاز يملك نسخة مثبَّتة أصلاً)
    4) أي نسخة موجودة في PATH النظام
"""
import os
import shutil
import sys

_EXE_NAME = "wkhtmltopdf.exe" if os.name == "nt" else "wkhtmltopdf"

_COMMON_INSTALL_PATHS = [
    r"C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe",
    r"C:\Program Files (x86)\wkhtmltopdf\bin\wkhtmltopdf.exe",
    "/usr/local/bin/wkhtmltopdf",
    "/usr/bin/wkhtmltopdf",
]


def _bundled_candidates():
    """أماكن البحث عن النسخة المضمَّنة مع توزيعة البرنامج نفسها.

    نتحقق من احتمالين لبنية المجلد داخل vendor/wkhtmltopdf، لأن نسخ مجلد
    التثبيت كاملاً (كما يفعله كثير من المستخدمين بسحب وإفلات المجلد الأصلي)
    يُبقي الملف التنفيذي داخل مجلد فرعي اسمه bin، بينما البعض ينسخ الملف
    التنفيذي وحده مباشرة:
        vendor/wkhtmltopdf/wkhtmltopdf.exe           (نسخ الملف وحده)
        vendor/wkhtmltopdf/bin/wkhtmltopdf.exe       (نسخ مجلد التثبيت كاملاً)
    """
    candidates = []

    if getattr(sys, "frozen", False):
        # البرنامج يعمل كملف .exe مبني بـ PyInstaller (أو مشابه)
        roots = []
        meipass = getattr(sys, "_MEIPASS", None)
        if meipass:
            # وضع --onefile: الملفات المرفقة تُستخرَج مؤقتاً هنا عند التشغيل
            roots.append(meipass)
        # وضع --onedir: الملفات المرفقة تبقى بجانب الملف التنفيذي مباشرة
        roots.append(os.path.dirname(os.path.abspath(sys.executable)))
    else:
        # تشغيل عادي كسكربت بايثون أثناء التطوير
        roots = [os.path.dirname(os.path.abspath(__file__))]

    for root in roots:
        candidates.append(os.path.join(root, "vendor", "wkhtmltopdf", _EXE_NAME))
        candidates.append(os.path.join(root, "vendor", "wkhtmltopdf", "bin", _EXE_NAME))

    return candidates


def find_wkhtmltopdf():
    """يُرجع المسار الكامل لأول نسخة صالحة من wkhtmltopdf يجدها، أو None."""
    for path in _bundled_candidates():
        if path and os.path.isfile(path):
            return path

    for path in _COMMON_INSTALL_PATHS:
        if os.path.isfile(path):
            return path

    found_in_path = shutil.which("wkhtmltopdf")
    if found_in_path:
        return found_in_path

    return None


def require_wkhtmltopdf():
    """مثل find_wkhtmltopdf لكن يرمي خطأ واضحاً بدل إرجاع None، مفيد عند
    نقطة الاستخدام الفعلية لإعطاء المستخدم رسالة مفهومة بدل انهيار مبهم."""
    path = find_wkhtmltopdf()
    if not path:
        raise RuntimeError(
            "تعذّر العثور على wkhtmltopdf.exe.\n"
            "تأكد من وجود الملف ضمن vendor/wkhtmltopdf/ المرفق مع البرنامج، "
            "أو ثبّته يدوياً وتأكد أنه ضمن PATH النظام."
        )
    return path
