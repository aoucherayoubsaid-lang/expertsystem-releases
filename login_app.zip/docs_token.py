# -*- coding: utf-8 -*-
"""رمز وصول خادم الوثائق: بدل مفتاح مشترك في كل جهاز، يطلب البرنامج من خادم التراخيص رمزًا
موقَّعًا خاصًا بهذا الجهاز صالحًا 24 ساعة، ولا يُصدَر إلا لترخيص فعّال أو تجربة سارية.
يتحقق خادم الوثائق من التوقيع بالمفتاح العام فقط، فلا يوجد سر يمكن استخراجه من البرنامج."""
import base64
import threading
import time

import license_manager as lm
import trial_online

_lock = threading.Lock()
_cache = {"token": None, "exp": 0.0}


def _license_key():
    try:
        states, _bad = lm._read_all()
        for s in states:
            if s.get("lic"):
                return s["lic"]
    except Exception:
        pass
    return ""


def get_token(force=False):
    """يرجع الرمز (من الذاكرة إن كان صالحًا). يرفع RuntimeError برسالة عربية واضحة عند الفشل."""
    with _lock:
        if not force and _cache["token"] and time.time() < _cache["exp"] - 600:
            return _cache["token"]
        machine = lm.machine_code()
        body = {"machine_id": machine}
        key = _license_key()
        if key:
            body["key"] = key
        st, d, resp = trial_online._ask("/token", body, machine)
        if st == "offline":
            raise RuntimeError("لا يوجد اتصال بالإنترنت (مطلوب لتسجيل الوثائق).")
        if st == "no_access":
            raise RuntimeError("خدمة الوثائق تتطلب تجربة سارية أو ترخيصًا فعّالًا.")
        if st != "ok" or d.get("t") != "docs" or not trial_online.server_clock_ok(d):
            raise RuntimeError("تعذّر التحقق من الترخيص لخدمة الوثائق.")
        _cache["token"] = base64.b64encode(resp["data"].encode("utf-8")).decode("ascii") + "." + resp["sig"]
        _cache["exp"] = trial_online._parse_time(d["exp"]).timestamp()
        return _cache["token"]


def auth_headers(force=False):
    return {"Authorization": "Bearer " + get_token(force), "X-Machine-Id": lm.machine_code()}
