# storage.py
"""
طبقة التخزين الموحّدة للتطبيق.

يوجد نوعان من البيانات:
1) بيانات عامة (Global) خاصة بالتطبيق ككل: المستخدمون، قائمة الملفات (Dossiers)،
   معلومات الخبير، الإعدادات العامة  -> تُحفظ داخل مجلد app_data/
2) بيانات خاصة بكل ملف (Dossier) على حدة: القضايا، الأطراف، الوثائق، الأتعاب،
   التسديدات، محاضر الحضور، محاضر الانتقال، ملفات التقارير
   -> تُحفظ داخل  dossiers_data/<اسم_مجلد_الملف>/

يجب دائماً استدعاء set_current_dossier(folder_name) بعد اختيار المستخدم
لملف (Dossier) معيّن، قبل استخدام أي دالة من دوال البيانات الخاصة بالملف.
"""

import json
import os
import re
import hashlib
import hmac
import secrets
import sys
import shutil

from app_paths import app_base_dir
import local_protect
import password_policy

# ---------------------------------------------------------------------------
# المسارات الأساسية (مسارات مطلقة ثابتة: تعمل نفسها أثناء التطوير وبعد تحويل .exe)
# ---------------------------------------------------------------------------
APP_DATA_DIR = os.path.join(app_base_dir(), "app_data")      # في الوضع المشترك: داخل المجلد المشترك
DOSSIERS_DATA_DIR = os.path.join(app_base_dir(), "dossiers_data")

USERS_FILE = os.path.join(APP_DATA_DIR, "users.json")
DOSSIERS_FILE = os.path.join(APP_DATA_DIR, "dossiers.json")
EXPERT_INFO_FILE = os.path.join(APP_DATA_DIR, "expert_info.json")
SETTINGS_FILE = os.path.join(APP_DATA_DIR, "settings.json")

_current_dossier_folder = None
_current_dossier_name = None
_current_year = None
_current_court = None


# ---------------------------------------------------------------------------
# أدوات مساعدة عامة لقراءة/كتابة JSON
# ---------------------------------------------------------------------------
def _ensure_dirs():
    os.makedirs(APP_DATA_DIR, exist_ok=True)
    os.makedirs(DOSSIERS_DATA_DIR, exist_ok=True)


def _read_json(path, default):
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            content = f.read().strip()
            if not content:
                return default
            return json.loads(content)
    except (json.JSONDecodeError, OSError):
        return default


# ملفات الأمان الموقَّعة (local_protect): أي تعديل خارج التطبيق يُرفض
_PROTECTED = ("users.json", "settings.json")


def _read_protected_json(path, default):
    """يقرأ ملفاً موقَّعاً. عند العبث: يسجّل الحادثة ويرجع الافتراضي، وتبقى local_protect.tamper_detected()
    صحيحة فتمنع الواجهة الدخول وتمنع أي كتابة تُخفي الأثر."""
    try:
        raw = local_protect.read_verified(path)
    except local_protect.IntegrityError:
        return default
    if raw is None:
        return default
    try:
        text = raw.decode("utf-8").strip()
        return json.loads(text) if text else default
    except (ValueError, UnicodeDecodeError):
        return default


_READONLY_WRITABLE = ("settings.json", "users.json")   # لغة/مظهر وتجزئات الدخول فقط في وضع القراءة


def _write_json(path, data):
    """كل حفظ للبيانات يمر من هنا: في وضع القراءة فقط (تجربة/ترخيص منتهٍ أو تلاعب) لا يُكتب شيء،
    فلا يكفي إخفاء الأزرار أو تعديل user_can لتجاوز الحماية."""
    try:
        import license_manager
        if license_manager.is_read_only() and os.path.basename(path) not in _READONLY_WRITABLE:
            return
    except Exception:
        if getattr(sys, "frozen", False) and os.path.basename(path) not in _READONLY_WRITABLE:
            return                                   # نسخة exe: تعذّر فحص الترخيص = لا كتابة (فشل مغلق)
    try:
        import data_lock
        if data_lock.is_read_only():
            return                                   # مجلد مشترك وجهاز آخر هو الكاتب: لا نكتب (يمنع تضارب التعديلات)
    except ImportError:
        pass
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    if os.path.basename(path) in _PROTECTED:
        if local_protect.tamper_detected():
            raise local_protect.IntegrityError("refusing to overwrite a tampered security file")
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
        local_protect.sign_file(path)
        return
    tmp = path + ".tmp"                              # كتابة ذرّية: انقطاع التيار/الشبكة لا يترك ملفاً مبتوراً
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


# ---------------------------------------------------------------------------
# اختيار / تحديد "الملف" (Dossier) الحالي
# ---------------------------------------------------------------------------
def slugify(name: str) -> str:
    """تحويل اسم الملف (قد يكون بالعربية) إلى اسم مجلد صالح."""
    s = re.sub(r"[^\w\u0600-\u06FF\- ]", "", name, flags=re.UNICODE)
    s = s.strip().replace(" ", "_")
    return s or "dossier"


def set_current_dossier(folder_name: str, display_name: str = None):
    """تفعيل ملف (Dossier) معيّن ليتم استخدام بياناته الخاصة."""
    global _current_dossier_folder, _current_dossier_name
    global _current_court
    _current_dossier_folder = folder_name
    _current_dossier_name = display_name or folder_name
    _current_court = None
    os.makedirs(os.path.join(DOSSIERS_DATA_DIR, folder_name), exist_ok=True)
    # ترحيل بيانات النسخ القديمة (قبل عزل البيانات حسب المحكمة) مرة واحدة
    try:
        migrate_legacy_dossier()
    except Exception as exc:  # لا نمنع فتح الملف بسبب فشل الترحيل
        print("تعذّر ترحيل البيانات القديمة:", exc)


def get_current_dossier_folder():
    return _current_dossier_folder


def get_current_dossier_name():
    return _current_dossier_name


def clear_current_dossier():
    global _current_dossier_folder, _current_dossier_name, _current_court
    _current_dossier_folder = None
    _current_dossier_name = None
    _current_court = None


def _dossier_path(filename):
    if not _current_dossier_folder:
        raise RuntimeError(
            "لم يتم اختيار أي ملف (Dossier) بعد. الرجاء استخدام set_current_dossier() أولاً."
        )
    return os.path.join(DOSSIERS_DATA_DIR, _current_dossier_folder, filename)


# ---------------------------------------------------------------------------
# السنوات (كل ملف/Dossier يقسّم عمله إلى سنوات، كل سنة تُقفل على حدة)
# ---------------------------------------------------------------------------
def _years_registry_path():
    if not _current_dossier_folder:
        raise RuntimeError("لم يتم اختيار أي ملف (Dossier) بعد.")
    return os.path.join(DOSSIERS_DATA_DIR, _current_dossier_folder, "years.json")


def load_years():
    """قائمة السنوات المسجّلة للملف الحالي: [{"year": "2026", "closed": false}, ...]"""
    return _read_json(_years_registry_path(), [])


def save_years(years):
    _write_json(_years_registry_path(), years)


def add_year(year: str):
    years = load_years()
    if not any(y["year"] == year for y in years):
        years.append({"year": year, "closed": False})
        save_years(years)
    _ensure_year_dir(year)
    return year


def close_year(year: str, closed: bool = True):
    years = load_years()
    for y in years:
        if y["year"] == year:
            y["closed"] = closed
    save_years(years)


def is_year_closed(year: str) -> bool:
    years = load_years()
    for y in years:
        if y["year"] == year:
            return y.get("closed", False)
    return False


def _ensure_year_dir(year: str):
    if not _current_dossier_folder:
        return
    os.makedirs(os.path.join(DOSSIERS_DATA_DIR, _current_dossier_folder, "years", year), exist_ok=True)


def set_current_year(year: str):
    global _current_year
    _current_year = year
    if year:
        _ensure_year_dir(year)


def get_current_year():
    return _current_year


def clear_current_year():
    global _current_year
    _current_year = None


def _court_dir_in_year(year: str, court: str) -> str:
    return os.path.join(DOSSIERS_DATA_DIR, _current_dossier_folder, "years", year,
                        "courts", court_slug(court))


def _year_path(filename):
    """مسار ملف بيانات مرتبط بسنة ومحكمة معيّنتين داخل الملف (Dossier) الحالي.

    كل محكمة لها مجلد مستقل داخل كل سنة، لذلك لا تختلط قضايا محكمة دلس
    بقضايا محكمة برج منايل (القضايا، الأتعاب، التسديدات، المحاضر، الوثائق...).
    """
    if not _current_dossier_folder:
        raise RuntimeError("لم يتم اختيار أي ملف (Dossier) بعد.")
    if not _current_year:
        raise RuntimeError("لم يتم اختيار سنة العمل بعد. الرجاء اختيار السنة من الصفحة الرئيسية.")
    if not _current_court:
        raise RuntimeError("لم يتم اختيار المحكمة بعد. الرجاء اختيار المحكمة من الصفحة الرئيسية.")
    path = _court_dir_in_year(_current_year, _current_court)
    os.makedirs(path, exist_ok=True)
    return os.path.join(path, filename)


# ---------------------------------------------------------------------------
# المحاكم: كل محكمة "مساحة عمل" مستقلة داخل الملف (Dossier)
# ---------------------------------------------------------------------------
UNASSIGNED_COURT = "محكمة غير محددة"


def court_slug(name: str) -> str:
    """اسم مجلد صالح للمحكمة (قد يكون عربياً)."""
    return slugify(name or "")


def _courts_path():
    if not _current_dossier_folder:
        raise RuntimeError("لم يتم اختيار أي ملف (Dossier) بعد.")
    return os.path.join(DOSSIERS_DATA_DIR, _current_dossier_folder, "courts.json")


def _dossier_context_path():
    if not _current_dossier_folder:
        raise RuntimeError("لم يتم اختيار أي ملف (Dossier) بعد.")
    return os.path.join(DOSSIERS_DATA_DIR, _current_dossier_folder, "context.json")


def load_courts():
    return _read_json(_courts_path(), [])


def add_court(name: str):
    name = (name or "").strip()
    if not name:
        return
    courts = load_courts()
    if name not in courts:
        courts.append(name)
        _write_json(_courts_path(), courts)


def set_current_court(court: str):
    """تفعيل محكمة: كل دوال load_* / save_* تعمل بعدها على بياناتها فقط."""
    global _current_court
    court = (court or "").strip()
    _current_court = court or None
    if court:
        add_court(court)
        ctx = _read_json(_dossier_context_path(), {})
        ctx["default_court"] = court
        _write_json(_dossier_context_path(), ctx)


def get_current_court():
    return _current_court


def clear_current_court():
    global _current_court
    _current_court = None


def get_default_court():
    """المحكمة النشطة حالياً، وإلا آخر محكمة اختارها المستخدم في هذا الملف."""
    if _current_court:
        return _current_court
    try:
        return _read_json(_dossier_context_path(), {}).get("default_court", "")
    except RuntimeError:
        return ""


def set_default_court(court: str):
    """للتوافق مع الكود القديم: تعادل تفعيل المحكمة."""
    set_current_court(court)


def delete_court(name: str):
    """يحذف المحكمة من القائمة فقط. بياناتها تبقى محفوظة على القرص، وتعود
    كما كانت إذا أعيدت إضافة نفس الاسم."""
    global _current_court
    name = (name or "").strip()
    if not name:
        return
    courts = load_courts()
    if name in courts:
        courts.remove(name)
        _write_json(_courts_path(), courts)
    if _current_court == name:
        _current_court = None
    ctx = _read_json(_dossier_context_path(), {})
    if ctx.get("default_court") == name:
        ctx["default_court"] = ""
        _write_json(_dossier_context_path(), ctx)


def rename_court(old_name: str, new_name: str):
    """يعدّل اسم محكمة مع نقل مجلدات بياناتها في كل السنوات."""
    global _current_court
    old_name = (old_name or "").strip()
    new_name = (new_name or "").strip()
    if not old_name or not new_name or old_name == new_name:
        return False
    courts = load_courts()
    if old_name not in courts or new_name in courts:
        return False
    base = os.path.join(DOSSIERS_DATA_DIR, _current_dossier_folder)
    old_slug, new_slug = court_slug(old_name), court_slug(new_name)
    if old_slug != new_slug:
        years_dir = os.path.join(base, "years")
        if os.path.isdir(years_dir):
            for y in os.listdir(years_dir):
                src = os.path.join(years_dir, y, "courts", old_slug)
                dst = os.path.join(years_dir, y, "courts", new_slug)
                if os.path.isdir(src) and not os.path.exists(dst):
                    os.rename(src, dst)
                    # نحدّث حقل المحكمة داخل القضايا
                    cp = os.path.join(dst, "cases.json")
                    cases = _read_json(cp, [])
                    for c in cases:
                        if (c.get("court") or "").strip() == old_name:
                            c["court"] = new_name
                    if cases:
                        _write_json(cp, cases)
        src = os.path.join(base, "courts_data", old_slug)
        dst = os.path.join(base, "courts_data", new_slug)
        if os.path.isdir(src) and not os.path.exists(dst):
            os.rename(src, dst)
    courts[courts.index(old_name)] = new_name
    _write_json(_courts_path(), courts)
    ctx = _read_json(_dossier_context_path(), {})
    if ctx.get("default_court") == old_name:
        ctx["default_court"] = new_name
        _write_json(_dossier_context_path(), ctx)
    if _current_court == old_name:
        _current_court = new_name
    return True


def with_court(court: str, func, *args, **kwargs):
    """ينفّذ دالة أثناء تفعيل محكمة أخرى مؤقتاً (للإحصائيات المجمّعة)."""
    global _current_court
    previous = _current_court
    _current_court = (court or "").strip() or None
    try:
        return func(*args, **kwargs)
    finally:
        _current_court = previous


# ---------------------------------------------------------------------------
# أقسام القضايا (مدني / اجتماعي / تجاري ...) - قابلة للإضافة من المستخدم،
# بنفس منطق المحاكم أعلاه تمامًا.
# ---------------------------------------------------------------------------
LEGACY_DEFAULT_SECTIONS = ["القسم المدني", "القسم الاجتماعي", "القسم التجاري"]
# أقسام المحكمة (قابلة للإضافة من المستخدم)
COURT_DEFAULT_SECTIONS = [
    "القسم المدني", "القسم الاجتماعي", "القسم التجاري", "القسم العقاري",
]
# قائمة سبق أن أُنشئت تلقائياً في نسخة سابقة (تُستبدل بالقائمة الحالية)
_PREV_AUTO_COURT_SECTIONS = [
    "القسم المدني", "القسم الاجتماعي", "القسم التجاري",
    "القسم العقاري", "قسم شؤون الأسرة",
]
# غرف المجلس القضائي (قابلة للإضافة من المستخدم)
COUNCIL_DEFAULT_SECTIONS = [
    "الغرفة المدنية", "الغرفة الاجتماعية", "الغرفة الجزائية", "الغرفة التجارية",
]
DEFAULT_SECTIONS = COURT_DEFAULT_SECTIONS


def dossier_kind(name=None):
    """نوع الملف يُستنتج تلقائياً من اسمه: اسم فيه \"مجلس\" = مجلس قضائي، وإلا محكمة."""
    name = (name if name is not None else _current_dossier_name) or ""
    return "council" if "مجلس" in name else "court"


def unit_words(name=None):
    """مصطلحات الواجهة حسب نوع الملف (مجلس قضائي / محكمة)."""
    if dossier_kind(name) == "council":
        return {
            "kind": "council",
            "unit": "المجلس القضائي",     # الجهة نفسها
            "units": "المجالس القضائية",
            "the_unit": "المجلس القضائي",
            "section": "الغرفة",          # التقسيم الداخلي
            "sections": COUNCIL_DEFAULT_SECTIONS,
        }
    return {
        "kind": "court",
        "unit": "المحكمة",
        "units": "المحاكم",
        "the_unit": "المحكمة",
        "section": "القسم",
        "sections": COURT_DEFAULT_SECTIONS,
    }


def _sections_path():
    if not _current_dossier_folder:
        raise RuntimeError("لم يتم اختيار أي ملف (Dossier) بعد.")
    return os.path.join(DOSSIERS_DATA_DIR, _current_dossier_folder, "sections.json")


def load_sections():
    defaults = list(unit_words()["sections"])
    sections = _read_json(_sections_path(), None)
    # ملف جديد، أو ملف ما زال يحمل القائمة الافتراضية القديمة (3 أقسام) -> نحدّثه
    if sections is None or list(sections) in (LEGACY_DEFAULT_SECTIONS, _PREV_AUTO_COURT_SECTIONS):
        sections = defaults
        _write_json(_sections_path(), sections)
    return sections


def add_section(name: str):
    name = (name or "").strip()
    if not name:
        return
    sections = load_sections()
    if name not in sections:
        sections.append(name)
        _write_json(_sections_path(), sections)


def save_sections(sections):
    """يحفظ قائمة الأقسام/الغرف كاملة (بعد تنظيفها من الفراغات والتكرار)."""
    clean = []
    for name in sections or []:
        name = (name or "").strip()
        if name and name not in clean:
            clean.append(name)
    _write_json(_sections_path(), clean)
    return clean


def remove_section(name: str):
    """يحذف قسماً/غرفة من قائمة الاقتراحات فقط (القضايا المسجلة لا تتأثر)."""
    name = (name or "").strip()
    sections = load_sections()
    if name in sections:
        sections.remove(name)
        _write_json(_sections_path(), sections)


def rename_section(old_name: str, new_name: str):
    """يعدّل اسم قسم/غرفة في القائمة. يرجع False إن كان الاسم الجديد فارغاً أو مكرراً."""
    old_name = (old_name or "").strip()
    new_name = (new_name or "").strip()
    sections = load_sections()
    if not new_name or old_name not in sections:
        return False
    if new_name != old_name and new_name in sections:
        return False
    sections[sections.index(old_name)] = new_name
    _write_json(_sections_path(), sections)
    return True


# ---------------------------------------------------------------------------
# إدارة الملفات (Dossiers) - قائمة عامة
# ---------------------------------------------------------------------------
def load_dossiers():
    _ensure_dirs()
    return _read_json(DOSSIERS_FILE, [])


def save_dossiers(dossiers):
    _ensure_dirs()
    _write_json(DOSSIERS_FILE, dossiers)


def add_dossier(name: str):
    """إضافة ملف (Dossier) جديد وإرجاع اسم مجلده."""
    dossiers = load_dossiers()
    base_folder = slugify(name)
    folder = base_folder
    existing_folders = {d["folder"] for d in dossiers}
    i = 1
    while folder in existing_folders:
        i += 1
        folder = f"{base_folder}_{i}"
    dossiers.append({"name": name, "folder": folder})
    save_dossiers(dossiers)
    os.makedirs(os.path.join(DOSSIERS_DATA_DIR, folder), exist_ok=True)
    return folder


def update_dossier(folder: str, new_name: str):
    dossiers = load_dossiers()
    for d in dossiers:
        if d["folder"] == folder:
            d["name"] = new_name
            break
    save_dossiers(dossiers)


def delete_dossier(folder: str):
    dossiers = load_dossiers()
    dossiers = [d for d in dossiers if d["folder"] != folder]
    save_dossiers(dossiers)
    # ملاحظة: لا يتم حذف مجلد بيانات الملف فعلياً حفاظاً على البيانات،
    # يمكن حذفه يدوياً من dossiers_data إذا رغب المستخدم بذلك نهائياً.


# ---------------------------------------------------------------------------
# المستخدمون (تسجيل الدخول)
# ---------------------------------------------------------------------------
PBKDF2_ITERATIONS = 600_000   # التجزئات القديمة تحمل عدد تكرارها وتبقى صالحة


def _hash_password(password: str) -> str:
    """يولّد تجزئة آمنة (PBKDF2-HMAC-SHA256) مع ملح عشوائي لكل كلمة مرور.

    الصيغة المخزَّنة: pbkdf2_sha256$<iterations>$<salt_hex>$<hash_hex>
    """
    salt = secrets.token_bytes(16)
    derived = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS
    )
    return "pbkdf2_sha256$%d$%s$%s" % (
        PBKDF2_ITERATIONS, salt.hex(), derived.hex()
    )


def _verify_password(password: str, stored_hash: str) -> bool:
    """يتحقق من كلمة المرور مقابل تجزئة مخزَّنة.

    يدعم كلا الصيغتين: التجزئة الجديدة (PBKDF2 المُملّحة) والتجزئة القديمة
    (SHA-256 بلا ملح) للتوافق مع الحسابات المُنشأة قبل هذا التحديث.
    """
    if not stored_hash:
        return False
    if stored_hash.startswith("pbkdf2_sha256$"):
        try:
            _, iterations_str, salt_hex, hash_hex = stored_hash.split("$", 3)
            iterations = int(iterations_str)
            salt = bytes.fromhex(salt_hex)
            expected = bytes.fromhex(hash_hex)
        except (ValueError, IndexError):
            return False
        derived = hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), salt, iterations
        )
        return hmac.compare_digest(derived, expected)
    # صيغة قديمة: SHA-256 عادي بلا ملح (نسخ تم إنشاؤها قبل هذا التحديث)
    legacy_hash = hashlib.sha256(password.encode("utf-8")).hexdigest()
    return hmac.compare_digest(legacy_hash, stored_hash)


def _is_legacy_hash(stored_hash: str) -> bool:
    return bool(stored_hash) and not stored_hash.startswith("pbkdf2_sha256$")


def _audit(action, username="", result="success", extra=None):
    """تسجيل في سجل التدقيق دون أن يعطّل فشلُه العملية."""
    try:
        import security_manager
        security_manager.audit(action, username, result, extra)
    except Exception:
        pass


# إجابات/كلمات افتراضية كانت تُشحن مع نسخ سابقة: تُبطَل تلقائياً عند أول تحميل
_SHIPPED_DEFAULT_ANSWERS = ("مكتب",)
_SHIPPED_DEFAULT_PASSWORDS = ("admin123",)
# تجزئة وهمية لتساوي زمن الفحص عند اسم مستخدم غير موجود (لا تكشف الأسماء بالتوقيت)
_DUMMY_HASH = None


def _dummy_verify(secret):
    global _DUMMY_HASH
    if _DUMMY_HASH is None:
        _DUMMY_HASH = _hash_password("dummy-" + secrets.token_hex(8))
    _verify_password(secret or "", _DUMMY_HASH)


def _norm_answer(answer: str) -> str:
    return (answer or "").strip().lower()


def _migrate_users(users):
    """مرة واحدة لكل حساب (علامة recovery_v2): يبطل أي إجابة أمان افتراضية سبق شحنها،
    ويُجبر على تغيير كلمة المرور الافتراضية إن بقيت."""
    changed = False
    for u in users:
        if u.get("recovery_v2"):
            continue
        changed = True
        u["recovery_v2"] = True
        h = u.get("security_answer_hash", "")
        if h and any(_verify_password(a, h) for a in _SHIPPED_DEFAULT_ANSWERS):
            u["security_answer_hash"] = ""
            u["security_question"] = ""
            u["force_recovery_setup"] = True
            _audit("DEFAULT_RECOVERY_REVOKED", u.get("username", ""), "success")
        ph = u.get("password_hash", "")
        if ph and any(_verify_password(p, ph) for p in _SHIPPED_DEFAULT_PASSWORDS):
            u["force_password_change"] = True
    if changed:
        save_users(users)
    return users


def load_users():
    _ensure_dirs()
    users = _read_protected_json(USERS_FILE, None)
    if local_protect.tamper_detected():
        return []                                  # فشل مغلق: لا حسابات ولا إنشاء admin افتراضي فوق ملف معبوث به
    if users is None:
        # أول تشغيل للتطبيق: حساب admin بكلمة مرور مؤقتة تُغيَّر إجبارياً عند أول دخول.
        # لا إجابة أمان افتراضية إطلاقاً: يضبط المدير السؤال والإجابة عند أول دخول،
        # وإلى ذلك الحين لا يعمل الاسترجاع لهذا الحساب.
        users = [{
            "username": "admin",
            "password_hash": _hash_password("admin123"),
            "role": "admin",
            "active": True,
            "security_question": "",
            "security_answer_hash": "",
            "force_password_change": True,
            "force_recovery_setup": True,
            "recovery_v2": True,
        }]
        save_users(users)
        return users
    return _migrate_users(users)


def save_users(users):
    _ensure_dirs()
    _write_json(USERS_FILE, users)


def verify_login(username: str, password: str):
    """التحقق من بيانات الدخول. يرجع بيانات المستخدم عند النجاح أو None عند الفشل/التعطيل."""
    users = load_users()
    for u in users:
        if u.get("username") == username and _verify_password(password, u.get("password_hash", "")):
            if not u.get("active", True):
                return "disabled"
            dirty = False
            # ترحيل تلقائي: التجزئة القديمة (SHA-256 بلا ملح) تُستبدل بـ PBKDF2 المُملَّح فور نجاح الدخول.
            if _is_legacy_hash(u.get("password_hash", "")):
                u["password_hash"] = _hash_password(password)
                dirty = True
            # كلمة مرور لا تطابق السياسة (قصيرة/ضعيفة): يُجبر صاحبها على استبدالها قبل المتابعة
            if not u.get("force_password_change") and not password_policy.check(password, username)[0]:
                u["force_password_change"] = True
                dirty = True
            if dirty:
                save_users(users)
            return u
    if not any(u.get("username") == username for u in users):
        _dummy_verify(password)
    return None


def add_user(username: str, password: str, role: str = "assistant",
             security_question: str = "", security_answer: str = ""):
    ok, problems = password_policy.check(password, username)
    if not ok:
        raise password_policy.WeakPassword(problems)
    if security_answer:
        ok, problems = password_policy.check_answer(security_answer)
        if not ok:
            raise ValueError("؛ ".join(problems))
    users = load_users()
    if any(u.get("username") == username for u in users):
        raise ValueError("اسم المستخدم موجود بالفعل")
    users.append({
        "username": username,
        "password_hash": _hash_password(password),
        "role": role,
        "active": True,
        "security_question": security_question if security_answer else "",
        "security_answer_hash": _hash_password(_norm_answer(security_answer)) if security_answer else "",
        "recovery_v2": True,
    })
    save_users(users)
    _audit("USER_ADDED", username, "success", {"role": role})


def update_user(username: str, role: str = None, active: bool = None):
    """تعديل دور/تفعيل مستخدم موجود (لا تُستعمل لكلمة المرور، انظر change_password)."""
    users = load_users()
    for u in users:
        if u.get("username") == username:
            if role is not None:
                u["role"] = role
            if active is not None:
                u["active"] = active
            save_users(users)
            _audit("USER_UPDATED", username, "success", {"role": role, "active": active})
            return True
    return False


def delete_user(username: str):
    users = load_users()
    new_users = [u for u in users if u.get("username") != username]
    if len(new_users) == len(users):
        return False
    save_users(new_users)
    _audit("USER_DELETED", username, "success")
    return True


def change_password(username: str, new_password: str):
    ok, problems = password_policy.check(new_password, username)
    if not ok:
        raise password_policy.WeakPassword(problems)
    users = load_users()
    for u in users:
        if u.get("username") == username:
            u["password_hash"] = _hash_password(new_password)
            u.pop("force_password_change", None)
            save_users(users)
            _audit("PASSWORD_CHANGED", username, "success")
            return True
    return False


def must_change_password(username: str) -> bool:
    """يُستعمل من شاشة الدخول لمعرفة هل يجب إجبار المستخدم على تغيير كلمة مروره
    (حساب admin الافتراضي، أو كلمة مرور لا تطابق السياسة)."""
    for u in load_users():
        if u.get("username") == username:
            return bool(u.get("force_password_change"))
    return False


def needs_recovery_setup(username: str) -> bool:
    """هل يجب أن يضبط هذا الحساب سؤال/إجابة الاسترجاع قبل المتابعة (admin عند أول دخول)؟"""
    for u in load_users():
        if u.get("username") == username:
            return bool(u.get("force_recovery_setup")) or (
                u.get("role") == "admin" and not u.get("security_answer_hash"))
    return False


def set_recovery(username: str, question: str, answer: str):
    """يضبط سؤال الأمان وإجابته (إجابة قوية، لا افتراضية). يرفع ValueError عند رفض الإجابة."""
    question = (question or "").strip()
    if len(question) < 8:
        raise ValueError("اكتب سؤال أمان واضحاً (8 أحرف على الأقل).")
    ok, problems = password_policy.check_answer(answer)
    if not ok:
        raise ValueError("؛ ".join(problems))
    if _norm_answer(answer) in _norm_answer(question):
        raise ValueError("لا تجعل الإجابة جزءاً من السؤال.")
    users = load_users()
    for u in users:
        if u.get("username") == username:
            u["security_question"] = question
            u["security_answer_hash"] = _hash_password(_norm_answer(answer))
            u.pop("force_recovery_setup", None)
            save_users(users)
            _audit("RECOVERY_CONFIGURED", username, "success")
            return True
    return False


_FAKE_QUESTIONS = (
    "ما اسم أول مدرسة التحقت بها؟",
    "ما اسم المدينة التي وُلد فيها والدك؟",
    "ما اسم أقرب صديق في طفولتك؟",
    "ما هو أول مكتب عملت فيه؟",
    "ما اسم أول سيارة امتلكتها؟",
    "ما هو كتابك المفضل؟",
)


def _fake_question(username: str) -> str:
    try:
        key = local_protect.derived_key("fakeq")
    except local_protect.IntegrityError:
        key = b"fakeq"
    idx = hmac.new(key, (username or "").strip().casefold().encode("utf-8"), hashlib.sha256).digest()[0]
    return _FAKE_QUESTIONS[idx % len(_FAKE_QUESTIONS)]


def get_security_question(username: str):
    """السؤال الحقيقي إن كان الحساب موجوداً ومفعّلاً ومهيّأً للاسترجاع، وإلا None.
    الواجهة يجب أن تستعمل recovery_question_for_display حتى لا تكشف وجود الحساب."""
    for u in load_users():
        if u.get("username") == username:
            if u.get("active", True) and u.get("security_answer_hash") and u.get("security_question"):
                return u.get("security_question")
            return None
    return None


def recovery_question_for_display(username: str) -> str:
    """نفس الشكل دائماً: سؤال حقيقي أو سؤال وهمي ثابت لنفس الاسم، فلا يُعرف أيّ الأسماء موجود."""
    return get_security_question(username) or _fake_question(username)


def reset_password_with_security_answer(username: str, answer: str, new_password: str):
    """استرجاع كلمة المرور عبر الإجابة الصحيحة على سؤال الأمان.
    يرجع False بلا تفصيل لكل أسباب الفشل (حساب غير موجود/معطّل/بلا إجابة/إجابة خاطئة).
    القفل والتدقيق مسؤولية المستدعي (انظر login_app.ForgotPasswordDialog)؛ سياسة كلمة المرور تُفرض هنا."""
    ok, problems = password_policy.check(new_password, username)
    if not ok:
        raise password_policy.WeakPassword(problems)
    users = load_users()
    normalized_answer = _norm_answer(answer)
    for u in users:
        if u.get("username") == username:
            stored_hash = u.get("security_answer_hash", "")
            if not u.get("active", True) or not stored_hash or not _verify_password(normalized_answer, stored_hash):
                if not stored_hash:
                    _dummy_verify(normalized_answer)
                return False
            u["password_hash"] = _hash_password(new_password)
            u.pop("force_password_change", None)
            save_users(users)
            return True
    _dummy_verify(normalized_answer)
    return False


# ---------------------------------------------------------------------------
# الصلاحيات: كل الأدوار الممكنة ومفاتيح الصلاحيات المرتبطة بكل دور.
# نضيف صلاحية جديدة هنا مرة واحدة بدل نثر شروط "if role == ..." في كل ملف.
# ---------------------------------------------------------------------------
ROLES = {
    "admin":      "المدير (الخبير)",
    "assistant":  "مساعد",
    "accountant": "محاسب",
}

ROLE_DESCRIPTIONS = {
    "admin": "الخبير: صلاحيات كاملة، بما فيها المستخدمون والإعدادات وإدارة الملفات.",
    "assistant": "مساعد/كاتب الخبير: يدير ملف القضية (القضايا، الأطراف، الوثائق، المحاضر، "
                 "مسودات التقرير) دون أي اطّلاع على الشؤون المالية أو الإعدادات.",
    "accountant": "محاسب: يدير الأتعاب والتسديدات والوصولات فقط، ويطّلع على القضايا للقراءة "
                  "دون تعديل أي بيان فيها.",
}

# مفاتيح الصلاحيات (view_* = اطّلاع/ظهور التبويب، manage_*/edit_* = إنشاء وتعديل وحذف)
ROLE_PERMISSIONS = {
    # الخبير: كل شيء
    "admin": {
        "manage_dossiers", "manage_users", "manage_settings",
        "view_cases", "edit_cases",
        "view_parties", "manage_parties",
        "view_documents", "manage_documents",
        "view_minutes", "manage_attendance",
        "view_fees", "manage_fees",
        "view_payments", "manage_payments",
        "view_receipts", "manage_receipts",
        "view_reports", "manage_reports",
    },
    # المساعد: ملف القضية كاملاً، بلا مالية ولا إعدادات ولا مستخدمين
    "assistant": {
        "view_cases", "edit_cases",
        "view_parties", "manage_parties",
        "view_documents", "manage_documents",
        "view_minutes", "manage_attendance",
        "view_reports", "manage_reports",
    },
    # المحاسب: المالية فقط + قراءة القضايا (فصل المهام: لا يعدّل بيانات القضية)
    "accountant": {
        "view_cases",
        "view_fees", "manage_fees",
        "view_payments", "manage_payments",
        "view_receipts", "manage_receipts",
    },
}


def user_can(user, permission: str) -> bool:
    """نقطة التحقق المركزية الوحيدة من الصلاحيات في كل التطبيق."""
    if not user:
        return False
    role = user.get("role", "assistant")
    if permission.startswith(("manage_", "edit_")) and permission != "manage_settings":
        # بعد انتهاء النسخة التجريبية (وضع القراءة فقط): لا إضافة ولا تعديل ولا حذف
        try:
            import license_manager
            if license_manager.is_read_only():
                return False
        except Exception:
            if getattr(sys, "frozen", False):
                return False                         # فشل مغلق في نسخة exe
    return permission in ROLE_PERMISSIONS.get(role, set())


# ---------------------------------------------------------------------------
# معلومات الخبير و الإعدادات العامة
# ---------------------------------------------------------------------------
def load_expert_info():
    _ensure_dirs()
    return _read_json(EXPERT_INFO_FILE, {})


def save_expert_info(data):
    _ensure_dirs()
    _write_json(EXPERT_INFO_FILE, data)


def load_settings(default=None):
    _ensure_dirs()
    return _read_protected_json(SETTINGS_FILE, default or {})


def get_font_family():
    """الخط الذي اختاره المستخدم من الإعدادات، ليُستعمل في التقارير
    المولَّدة (PDF/HTML) بنفس خط واجهة البرنامج. Arial افتراضياً إن لم
    يُحدَّد المستخدم شيئاً بعد."""
    return load_settings().get("font_family") or "Arial"


def save_settings(data):
    _ensure_dirs()
    _write_json(SETTINGS_FILE, data)


# ---------------------------------------------------------------------------
# بيانات خاصة بكل ملف (Dossier) - لا ترتبط بسنة معيّنة (تبقى كما هي عبر السنوات)
# ---------------------------------------------------------------------------
def _load_scoped(filename, default=None):
    return _read_json(_dossier_path(filename), default if default is not None else [])


def _save_scoped(filename, data):
    _write_json(_dossier_path(filename), data)


# --- الأطراف (خاصة بكل محكمة، وتتكرر عبر سنواتها) ---
def _parties_path():
    if not _current_dossier_folder:
        raise RuntimeError("لم يتم اختيار أي ملف (Dossier) بعد.")
    if not _current_court:
        raise RuntimeError("لم يتم اختيار المحكمة بعد.")
    return os.path.join(DOSSIERS_DATA_DIR, _current_dossier_folder,
                        "courts_data", court_slug(_current_court), "parties.json")


def load_parties():
    """أطراف المحكمة الحالية فقط (مشتركة بين سنوات نفس المحكمة)."""
    return _read_json(_parties_path(), [])


def save_parties(parties):
    _write_json(_parties_path(), parties)


# ---------------------------------------------------------------------------
# بيانات خاصة بسنة عمل معيّنة داخل الملف الحالي (تُقفل السنة فتبقى بياناتها محفوظة بمعزل)
# ---------------------------------------------------------------------------
def _load_year_scoped(filename, default=None):
    return _read_json(_year_path(filename), default if default is not None else [])


def _save_year_scoped(filename, data):
    _write_json(_year_path(filename), data)


# --- القضايا ---
def load_cases():
    return _load_year_scoped("cases.json")


def save_cases(cases):
    _save_year_scoped("cases.json", cases)


# --- ملاحظات القضايا (المهام + نبذة عن القضية) مفهرسة برقم القضية ---
def load_case_notes():
    data = _load_year_scoped("case_notes.json", {})
    return data if isinstance(data, dict) else {}


def save_case_notes(notes):
    _save_year_scoped("case_notes.json", notes)


def get_case_note(case_number):
    return load_case_notes().get(str(case_number).strip(), {"tasks": "", "summary": ""})


def set_case_note(case_number, tasks, summary):
    notes = load_case_notes()
    notes[str(case_number).strip()] = {"tasks": tasks, "summary": summary}
    save_case_notes(notes)


def rename_case_note(old_number, new_number):
    old_number, new_number = str(old_number).strip(), str(new_number).strip()
    if old_number == new_number:
        return
    notes = load_case_notes()
    if old_number in notes:
        notes[new_number] = notes.pop(old_number)
        save_case_notes(notes)


def delete_case_note(case_number):
    notes = load_case_notes()
    if str(case_number).strip() in notes:
        notes.pop(str(case_number).strip())
        save_case_notes(notes)


# --- الوثائق ---
def load_documents():
    return _load_year_scoped("documents.json")


def save_documents(documents):
    _save_year_scoped("documents.json", documents)


# --- حالة الأتعاب ---
def load_fees_status():
    return _load_year_scoped("fees_status.json")


def save_fees_status(data):
    _save_year_scoped("fees_status.json", data)


# --- التسديدات ---
def load_payments():
    return _load_year_scoped("payments.json")


def save_payments(data):
    _save_year_scoped("payments.json", data)


# --- محاضر الحضور ---
def load_attendance():
    return _load_year_scoped("attendance.json")


def save_attendance(data):
    _save_year_scoped("attendance.json", data)


# --- محاضر الانتقال (المعاينة) ---
def load_visits():
    return _load_year_scoped("visits.json")


def save_visits(data):
    _save_year_scoped("visits.json", data)


# --- ملفات التقرير النهائي ---
def load_reports():
    return _load_year_scoped("reports.json")


def save_reports(data):
    _save_year_scoped("reports.json", data)


# --- وصولات الإيداع (كشف الأتعاب / التسديد) ---
def load_receipts():
    return _load_year_scoped("receipts.json")


def save_receipts(data):
    _save_year_scoped("receipts.json", data)


# ---------------------------------------------------------------------------
# مرفقات الوصولات/التسديدات (سكانر، صورة أو PDF للوصل الفعلي)
# تُخزَّن نسخة من الملف داخل بيانات السنة الحالية حتى لا تُفقد لو حُرِّك
# الملف الأصلي على جهاز المستخدم.
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# مجلدات التقارير (PDF/Excel): مجلد لكل نوع، داخل مساحة عمل السنة والمحكمة
# ---------------------------------------------------------------------------
REPORTS_ROOT_NAME = "التقارير"
REPORT_FOLDERS = {
    "attendance": "محاضر_الحضور",
    "visit":      "محاضر_الانتقال",
    "fees":       "كشوف_الأتعاب",
    "status":     "الوضعية_العامة",
    "payments":   "تسديد_الأتعاب",
    "receipt":    "وصولات_الإيداع",
}


def reports_dir(kind: str) -> str:
    """مجلد حفظ نوع معيّن من التقارير داخل الملف (Dossier) الحالي (يُنشأ تلقائياً)."""
    sub = REPORT_FOLDERS.get(kind, kind)
    try:
        base = os.path.dirname(_year_path("_"))
    except RuntimeError:
        # لا سنة/محكمة محددة: نحفظ داخل مجلد الملف إن وُجد، وإلا في مجلد عام
        if _current_dossier_folder:
            base = os.path.join(DOSSIERS_DATA_DIR, _current_dossier_folder)
        else:
            base = os.path.join(app_base_dir(), "reports_unassigned")
    path = os.path.join(base, REPORTS_ROOT_NAME, sub)
    os.makedirs(path, exist_ok=True)
    return path


def _attachments_dir(subfolder: str) -> str:
    if not _current_dossier_folder:
        raise RuntimeError("لم يتم اختيار أي ملف (Dossier) بعد.")
    path = os.path.join(os.path.dirname(_year_path("_")), subfolder)
    os.makedirs(path, exist_ok=True)
    return path


def save_attachment_file(source_path: str, subfolder: str, desired_filename: str) -> str:
    """ينسخ ملف مرفق (صورة/PDF) إلى مجلد مرفقات خاص بالسنة الحالية، ويعيد المسار الكامل للنسخة المحفوظة.
    يُعيد سلسلة فارغة إذا كان الملف المصدر غير موجود."""
    if not source_path or not os.path.isfile(source_path):
        return ""

    target_dir = _attachments_dir(subfolder)
    ext = os.path.splitext(source_path)[1]
    safe_name = re.sub(r"[^\w\-\u0600-\u06FF]", "_", desired_filename).strip("_") or "attachment"
    target_path = os.path.join(target_dir, safe_name + ext)

    counter = 1
    while os.path.exists(target_path):
        target_path = os.path.join(target_dir, f"{safe_name}_{counter}{ext}")
        counter += 1

    shutil.copy2(source_path, target_path)
    return target_path


def next_receipt_number(receipt_type: str) -> str:
    """يقترح رقم الوصل التالي (تسلسلي) بناءً على أعلى رقم وصل رقمي مُستخدَم سابقاً لنفس نوع الوصل.
    إن لم توجد أرقام سابقة صالحة، يُعيد سلسلة فارغة (يترك الحقل للمستخدم)."""
    records = load_receipts()
    max_num = 0
    found = False
    for rec in records:
        if rec.get("type") != receipt_type:
            continue
        raw = (rec.get("receipt_number") or "").strip()
        if raw.isdigit():
            found = True
            max_num = max(max_num, int(raw))
    if not found:
        return ""
    return str(max_num + 1)


def receipt_number_exists(receipt_type: str, receipt_number: str) -> bool:
    """يتحقق مما إذا كان رقم الوصل مستعملاً سابقاً لنفس النوع (لتفادي التكرار)."""
    receipt_number = (receipt_number or "").strip()
    if not receipt_number:
        return False
    for rec in load_receipts():
        if rec.get("type") == receipt_type and (rec.get("receipt_number") or "").strip() == receipt_number:
            return True
    return False


# ---------------------------------------------------------------------------
# ترحيل بيانات النسخ القديمة: كانت بيانات السنة مخزّنة مباشرة في
#   years/<السنة>/cases.json ...   أما الآن فهي في
#   years/<السنة>/courts/<المحكمة>/cases.json ...
# يُوزَّع كل شيء حسب حقل "المحكمة" في كل قضية، وتُنقل الأتعاب/التسديدات/
# المحاضر/الوثائق... حسب رقم القضية. الملفات القديمة تُحفظ بامتداد
# .legacy_backup ولا تُحذف.
# ---------------------------------------------------------------------------
_LEGACY_YEAR_FILES = {
    "cases.json": None,
    "payments.json": "case_number",
    "fees_status.json": "case_number",
    "receipts.json": "case_number",
    "attendance.json": "case",
    "visits.json": "case",
    "reports.json": "case",
    "documents.json": "case",
}


def _merge_write(path, records):
    existing = _read_json(path, [])
    if isinstance(existing, list):
        _write_json(path, existing + records)
    else:
        _write_json(path, records)


def migrate_legacy_dossier():
    if not _current_dossier_folder:
        return
    base = os.path.join(DOSSIERS_DATA_DIR, _current_dossier_folder)
    years_dir = os.path.join(base, "years")
    touched_courts = []

    if os.path.isdir(years_dir):
        for year in sorted(os.listdir(years_dir)):
            ydir = os.path.join(years_dir, year)
            if not os.path.isdir(ydir):
                continue
            if not any(os.path.isfile(os.path.join(ydir, f)) for f in _LEGACY_YEAR_FILES):
                continue

            legacy_cases = _read_json(os.path.join(ydir, "cases.json"), [])
            number_to_court = {}
            for c in legacy_cases:
                court = (c.get("court") or "").strip() or UNASSIGNED_COURT
                c["court"] = court
                num = str(c.get("case_number", "") or "").strip()
                if num:
                    number_to_court[num] = court

            for fname, key in _LEGACY_YEAR_FILES.items():
                fpath = os.path.join(ydir, fname)
                if not os.path.isfile(fpath):
                    continue
                records = legacy_cases if fname == "cases.json" else _read_json(fpath, [])
                if not isinstance(records, list):
                    continue
                grouped = {}
                for rec in records:
                    if fname == "cases.json":
                        court = rec["court"]
                    else:
                        num = str(rec.get(key, "") or "").strip()
                        court = number_to_court.get(num, UNASSIGNED_COURT)
                    grouped.setdefault(court, []).append(rec)
                for court, recs in grouped.items():
                    cdir = _court_dir_in_year(year, court)
                    os.makedirs(cdir, exist_ok=True)
                    _merge_write(os.path.join(cdir, fname), recs)
                    if court not in touched_courts:
                        touched_courts.append(court)
                os.replace(fpath, fpath + ".legacy_backup")

            # سياق السنة القديم (المحكمة الافتراضية)
            old_ctx = os.path.join(ydir, "context.json")
            if os.path.isfile(old_ctx):
                os.replace(old_ctx, old_ctx + ".legacy_backup")

    for court in touched_courts:
        add_court(court)

    # الأطراف القديمة كانت مشتركة على مستوى الملف؛ نوزّعها على المحاكم
    # حسب ارتباطها بالقضايا ({"year","number"})
    legacy_parties_path = os.path.join(base, "parties.json")
    if os.path.isfile(legacy_parties_path):
        parties = _read_json(legacy_parties_path, [])
        courts = load_courts()
        if isinstance(parties, list) and courts:
            index = {}
            for court in courts:
                for y in (os.listdir(years_dir) if os.path.isdir(years_dir) else []):
                    cp = os.path.join(_court_dir_in_year(y, court), "cases.json")
                    for c in _read_json(cp, []):
                        num = str(c.get("case_number", "") or "").strip()
                        if num:
                            index[(str(y), num)] = court
            per_court = {}
            for p in parties:
                links = p.get("cases", []) if isinstance(p.get("cases", []), list) else []
                by_court = {}
                for l in links:
                    if isinstance(l, dict):
                        court = index.get((str(l.get("year", "")), str(l.get("number", "")).strip()))
                        if court:
                            by_court.setdefault(court, []).append(l)
                if not by_court:
                    by_court = {courts[0]: links}
                for court, ls in by_court.items():
                    q = dict(p)
                    q["cases"] = ls
                    per_court.setdefault(court, []).append(q)
            for court, plist in per_court.items():
                pdir = os.path.join(base, "courts_data", court_slug(court))
                os.makedirs(pdir, exist_ok=True)
                _merge_write(os.path.join(pdir, "parties.json"), plist)
            os.replace(legacy_parties_path, legacy_parties_path + ".legacy_backup")
