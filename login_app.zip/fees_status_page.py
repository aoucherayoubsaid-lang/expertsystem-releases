from msgbox_ltr import show_info, show_warning, show_question
import sys
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QPushButton, QDialog, QFormLayout, QLabel, QFrame, QHeaderView, QLineEdit, QMessageBox,
    QComboBox, QFileDialog, QTabWidget, QStyledItemDelegate, QAbstractItemView
)
from PyQt5.QtCore import Qt, QSize, QVariantAnimation, QEasingCurve
from PyQt5.QtGui import QColor, QPalette
from modern_theme import style_button, style_soft_button, show_toast
import json
import os
import storage
import qtawesome as qta
from table_actions import build_action_bar


class CaseDetailsWindow(QDialog):
    """نافذة عرض تفاصيل القضية - منظمة ومرتبة"""
    def __init__(self, case_data):
        super().__init__()
        self.setWindowTitle("تفاصيل القضية")
        self.resize(450, 500)
        
        # اتجاه النافذة عربي (من اليمين لليسار) لتظهر العناوين بشكل صحيح
        self.setLayoutDirection(Qt.RightToLeft)
        
        layout = QFormLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(30, 30, 30, 30)

        # تنسيق النصوص
        label_style = "font-weight: bold; font-size: 14px; color: #1f2347;"
        value_style = "font-size: 14px; color: #000; border-bottom: 1px solid #cdd3ee; padding-bottom: 2px;"

        fields = [
            ("رقم الفهرس", "index_number"),
            ("رقم الغرفة", "room_number"),
            ("تاريخ الجلسة", "session_date"),
            (storage.unit_words()["unit"], "court"),
            ("المدعي", "plaintiff"),
            ("المدعى عليه", "defendant"),
            ("تاريخ استلام القضية", "receive_date"),
            ("مدة إنجاز الخبرة (بالأشهر)", "duration_months"),
            ("تاريخ إيداع التقرير", "submission_date")
        ]

        for label_text, key in fields:
            value = case_data.get(key, "---")
            
            lbl = QLabel(f"{label_text}:")
            lbl.setStyleSheet(label_style)
            
            val = QLabel(str(value))
            val.setStyleSheet(value_style)
            
            layout.addRow(lbl, val)

        self.close_btn = QPushButton("إغلاق")
        self.close_btn.setFixedWidth(120)
        style_button(self.close_btn, "primary", radius=8, padding="8px 16px")
        self.close_btn.clicked.connect(self.close)
        layout.addRow("", self.close_btn)
        


def _num(text):
    """يحوّل نص خلية (مثل 24300.00 أو -2000.0 أو 1,200) إلى رقم؛ صفر إن تعذّر."""
    try:
        return float(str(text).replace(",", "").replace(" ", "").replace("\u200e", "") or 0)
    except ValueError:
        return 0.0


class _FeesDelegate(QStyledItemDelegate):
    """عرض فقط (لا يغيّر القيم المخزَّنة): توسيط، أرقام LTR سليمة (بدل \"-2000.0-\")،
    وألوان للحالة والباقي."""

    def __init__(self, kind, parent=None):
        super().__init__(parent)
        self.kind = kind   # "case" | "number" | "remaining" | "status"

    def displayText(self, value, locale):
        text = super().displayText(value, locale)
        if self.kind in ("number", "remaining") and text:
            return "\u200e" + text      # LRM: يمنع انقلاب علامة السالب داخل واجهة RTL
        return text

    def initStyleOption(self, option, index):
        super().initStyleOption(option, index)
        option.displayAlignment = Qt.AlignCenter
        color = None
        text = str(index.data() or "")
        if self.kind == "status":
            if "بالكامل" in text:
                color = "#0f7a52"
            elif "غير" in text:
                color = "#d03a50"
            elif text:
                color = "#8a4b00"
        elif self.kind == "remaining":
            v = _num(text)
            color = "#8a4b00" if v < 0 else ("#0f7a52" if v == 0 else "#d03a50")
        elif self.kind == "case":
            color = "#4338ca"
        if color:
            option.palette.setColor(QPalette.Text, QColor(color))
            option.palette.setColor(QPalette.HighlightedText, QColor(color))
            f = option.font
            f.setBold(True)
            option.font = f


class _StatCard(QFrame):
    """بطاقة إحصاء صغيرة بقيمة تعدّ تصاعدياً (count-up) عند التغيّر."""

    def __init__(self, title, color, icon_name):
        super().__init__()
        self.setObjectName("statCard")
        self.setStyleSheet(
            f"QFrame#statCard {{ background: white; border: 1px solid #eef0ff;"
            f" border-right: 5px solid {color}; border-radius: 10px; }}"
            "QFrame#statCard QLabel { background: transparent; border: none; }")
        row = QHBoxLayout(self)
        row.setContentsMargins(14, 8, 14, 8)
        row.setSpacing(10)
        ic = QLabel()
        ic.setPixmap(qta.icon(icon_name, color=color).pixmap(26, 26))
        row.addWidget(ic)
        col = QVBoxLayout()
        col.setSpacing(0)
        self.title = QLabel(title)
        self.title.setStyleSheet("color:#6b7399; font-size:11px;")
        self.value = QLabel("0.00")
        self.value.setProperty("_auto_i18n_skip", True)
        self.value.setStyleSheet(f"color:{color}; font-size:17px; font-weight:bold;")
        col.addWidget(self.title)
        col.addWidget(self.value)
        row.addLayout(col)
        row.addStretch()
        self._current = 0.0
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(250)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._anim.valueChanged.connect(self._show)

    def _show(self, v):
        self.value.setText(f"{float(v):,.2f}")

    def set_value(self, target):
        self._anim.stop()
        self._anim.setStartValue(float(self._current))
        self._anim.setEndValue(float(target))
        self._current = float(target)
        self._anim.start()


class FeesStatusPage(QWidget):
    ALL_STATUSES = "كل الحالات"

    def __init__(self, case_management_page):
        super().__init__()
        self.case_management_page = case_management_page

        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        title = QLabel("كشف الأتعاب — الوضعية العامة")
        title.setStyleSheet("font-size:16px; font-weight:bold; color:#4338ca;")
        layout.addWidget(title)

        # بطاقات ملخّص (تتبع التصفية الحالية)
        cards = QHBoxLayout()
        cards.setSpacing(10)
        self.card_total = _StatCard("إجمالي الأتعاب", "#4338ca", "fa5s.coins")
        self.card_paid = _StatCard("المدفوع", "#0f7a52", "fa5s.check-circle")
        self.card_remaining = _StatCard("الباقي", "#d03a50", "fa5s.hourglass-half")
        for c in (self.card_total, self.card_paid, self.card_remaining):
            cards.addWidget(c, 1)
        layout.addLayout(cards)

        # شريط الأدوات: بحث + تصفية بالحالة + أزرار
        tools = QHBoxLayout()
        tools.setSpacing(8)
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("ابحث برقم القضية...")
        self.search_input.setMinimumHeight(36)
        self.search_input.textChanged.connect(self.filter_table)
        tools.addWidget(self.search_input, 1)

        self.status_filter = QComboBox()
        self.status_filter.setMinimumHeight(36)
        self.status_filter.setMinimumWidth(170)
        self.status_filter.addItem(self.ALL_STATUSES)
        self.status_filter.currentIndexChanged.connect(self.filter_table)
        tools.addWidget(self.status_filter)

        self.btn_payments = QPushButton("تسديدات القضية")
        self.btn_payments.setIcon(qta.icon("fa5s.money-check-alt", color="#5a4ee3"))
        self.btn_payments.setToolTip("عرض تسديدات القضية المحددة في تبويب تسديد الأتعاب")
        style_soft_button(self.btn_payments, "info", padding="7px 14px")
        self.btn_payments.clicked.connect(self.show_case_payments)
        tools.addWidget(self.btn_payments)

        self.btn_export = QPushButton("تصدير Excel")
        self.btn_export.setIcon(qta.icon("fa5s.file-excel", color="#0f7a52"))
        self.btn_export.setToolTip("تصدير الصفوف الظاهرة إلى ملف Excel")
        style_soft_button(self.btn_export, "success", padding="7px 14px")
        self.btn_export.clicked.connect(self.export_excel)
        tools.addWidget(self.btn_export)

        self.btn_refresh = QPushButton("تحديث")
        self.btn_refresh.setIcon(qta.icon("fa5s.sync-alt", color="#5b6485"))
        self.btn_refresh.setToolTip("إعادة تحميل الوضعية العامة")
        style_soft_button(self.btn_refresh, "secondary", padding="7px 14px")
        self.btn_refresh.clicked.connect(self.refresh_clicked)
        tools.addWidget(self.btn_refresh)
        layout.addLayout(tools)

        # إنشاء الجدول
        self.table = QTableWidget()

        # اتجاه الجدول يتبع لغة البرنامج: عربي = رقم القضية أول عمود من اليمين،
        # وعند تغيير اللغة ينقلب الجدول تلقائياً ليبدأ من اليسار.
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels([
            "رقم القضية", "الإجمالي", "المدفوع", "الباقي", "الحالة", "ملاحظات"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(5, QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(40)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setShowGrid(False)
        self.table.setStyleSheet("QTableWidget { border: 1px solid #eef0ff; border-radius: 8px; }")
        for col, kind in ((0, "case"), (1, "number"), (2, "number"), (3, "remaining"), (4, "status")):
            self.table.setItemDelegateForColumn(col, _FeesDelegate(kind, self.table))

        layout.addWidget(self.table, 1)

        # شريط الأزرار: حفظ | تعديل | حذف (للسطر المحدد)
        action_bar, self._action_buttons = build_action_bar(
            on_save=self.save_clicked,
            on_edit=self.edit_selected_fee,
            on_delete=self.delete_selected_fee,
            parent=self,
        )
        layout.addLayout(action_bar)

        self.btn_print = QPushButton("طباعة الوضعية العامة")
        self.btn_print.setIcon(qta.icon("fa5s.print", color="white"))
        self.btn_print.setIconSize(QSize(18, 18))
        self.btn_print.setFixedHeight(44)
        style_button(self.btn_print, "primary", radius=10, padding="9px 18px")
        self.btn_print.clicked.connect(self.print_general_status)
        layout.addWidget(self.btn_print)

        self.table.cellDoubleClicked.connect(self.open_details)
        self.load_fees_from_json()
        self.table.itemChanged.connect(self.save_fees_to_json)
        self.table.itemChanged.connect(lambda *_: self._refresh_view())
        self.setLayout(layout)
        self._refresh_view()

    # ---------------- الملخّص والتصفية ----------------
    def _refresh_view(self):
        """يحدّث قائمة الحالات (مما هو موجود فعلاً في الجدول) ثم التصفية والملخص."""
        current = self.status_filter.currentText()
        statuses = []
        for r in range(self.table.rowCount()):
            it = self.table.item(r, 4)
            txt = it.text().strip() if it else ""
            if txt and txt not in statuses:
                statuses.append(txt)
        self.status_filter.blockSignals(True)
        self.status_filter.clear()
        self.status_filter.addItem(self.ALL_STATUSES)
        self.status_filter.addItems(statuses)
        idx = self.status_filter.findText(current)
        self.status_filter.setCurrentIndex(idx if idx >= 0 else 0)
        self.status_filter.blockSignals(False)
        self.filter_table()

    def _update_summary(self):
        total = paid = remaining = 0.0
        for r in range(self.table.rowCount()):
            if self.table.isRowHidden(r):
                continue
            total += _num(self.table.item(r, 1).text() if self.table.item(r, 1) else 0)
            paid += _num(self.table.item(r, 2).text() if self.table.item(r, 2) else 0)
            remaining += _num(self.table.item(r, 3).text() if self.table.item(r, 3) else 0)
        self.card_total.set_value(total)
        self.card_paid.set_value(paid)
        self.card_remaining.set_value(remaining)

    def refresh_clicked(self):
        self.load_fees_from_json()
        self._refresh_view()
        show_toast(self, "تم تحديث الوضعية العامة", "info")

    def _selected_case(self):
        row = self.table.currentRow()
        item = self.table.item(row, 0) if row >= 0 else None
        return item.text().strip() if item else ""

    def show_case_payments(self):
        case_number = self._selected_case()
        if not case_number:
            show_warning(self, "تنبيه", "اختر قضية من الجدول أولاً.")
            return
        tab = self.parentWidget()
        while tab is not None and not isinstance(tab, QTabWidget):
            tab = tab.parentWidget()
        if tab is None:
            return
        from payments_page import PaymentsPage
        for i in range(tab.count()):
            w = tab.widget(i)
            if isinstance(w, PaymentsPage):
                w.case_input.setText(case_number)
                tab.setCurrentIndex(i)
                return

    def export_excel(self):
        rows = [r for r in range(self.table.rowCount()) if not self.table.isRowHidden(r)]
        if not rows:
            show_warning(self, "تنبيه", "لا توجد بيانات لتصديرها.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "تصدير الوضعية العامة", "الوضعية_العامة.xlsx", "Excel (*.xlsx)")
        if not path:
            return
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Font, PatternFill, Alignment
            wb = Workbook()
            ws = wb.active
            ws.title = "الوضعية العامة"
            ws.sheet_view.rightToLeft = True
            headers = [self.table.horizontalHeaderItem(c).text() for c in range(self.table.columnCount())]
            ws.append(headers)
            for c in range(1, len(headers) + 1):
                cell = ws.cell(row=1, column=c)
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = PatternFill("solid", fgColor="0E2D4E")
                cell.alignment = Alignment(horizontal="center", vertical="center")
            for r in rows:
                values = []
                for c in range(self.table.columnCount()):
                    it = self.table.item(r, c)
                    txt = it.text() if it else ""
                    values.append(_num(txt) if c in (1, 2, 3) and txt.strip() else txt)
                ws.append(values)
            for col, width in zip("ABCDEF", (18, 16, 16, 16, 20, 40)):
                ws.column_dimensions[col].width = width
            wb.save(path)
        except Exception as e:
            show_warning(self, "خطأ", f"تعذر تصدير الملف:\n{e}")
            return
        show_toast(self, "تم تصدير الملف بنجاح ✓", "success")

    def filter_table(self):
        query = self.search_input.text().strip().lower()
        status = self.status_filter.currentText()
        use_status = status and status != self.ALL_STATUSES
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            st_item = self.table.item(row, 4)
            ok_query = (not query) or (item and query in item.text().lower())
            ok_status = (not use_status) or (st_item and st_item.text().strip() == status)
            self.table.setRowHidden(row, not (ok_query and ok_status))
        self._update_summary()

    def print_general_status(self):
        rows = []
        for row in range(self.table.rowCount()):
            if self.table.isRowHidden(row):
                continue
            rows.append({
                "case_number": self.table.item(row, 0).text() if self.table.item(row, 0) else "",
                "total": self.table.item(row, 1).text() if self.table.item(row, 1) else "",
                "paid": self.table.item(row, 2).text() if self.table.item(row, 2) else "",
                "remaining": self.table.item(row, 3).text() if self.table.item(row, 3) else "",
                "status": self.table.item(row, 4).text() if self.table.item(row, 4) else "",
            })

        if not rows:
            show_warning(self, "تنبيه", "لا توجد بيانات لطباعتها.")
            return

        try:
            from generate_status_reports import generate_fees_status_report
            html_file, pdf_file = generate_fees_status_report(rows)
        except Exception as e:
            show_warning(self, "خطأ", f"تعذر توليد التقرير:\n{e}")
            return

        from report_viewer import ReportViewer
        self.status_viewer = ReportViewer(html_file, pdf_file=pdf_file, title="معاينة تقرير الوضعية العامة")
        self.status_viewer.show()
        show_info(self, "تم", f"تم إنشاء تقرير الوضعية العامة:\n{pdf_file}")

    def open_details(self, row, column):
        """جلب البيانات وفتح النافذة"""
        item = self.table.item(row, 0) # العمود 0 هو رقم القضية (في أقصى اليسار)
        if not item: return

        case_number = item.text()
        case_data = {}
        case_table = self.case_management_page.table 

        for r in range(case_table.rowCount()):
            cell_item = case_table.item(r, 0)
            if cell_item and cell_item.text() == case_number:
                case_data = {
                    "index_number": case_table.item(r, 1).text() if case_table.item(r,1) else "",
                    "room_number": case_table.item(r, 2).text() if case_table.item(r,2) else "",
                    "session_date": case_table.item(r, 3).text() if case_table.item(r,3) else "",
                    "court": case_table.item(r, 4).text() if case_table.item(r,4) else "",
                    "plaintiff": case_table.item(r, 5).text() if case_table.item(r,5) else "",
                    "defendant": case_table.item(r, 6).text() if case_table.item(r,6) else "",
                }
                break

        if case_data:
            details_window = CaseDetailsWindow(case_data)
            details_window.exec_()
    def save_fees_to_json(self):
        """حفظ بيانات الجدول في ملف JSON الخاص بالملف (Dossier) الحالي"""
        fees_list = []
        for row in range(self.table.rowCount()):
            row_data = {}
            for col, key in enumerate(["case_number", "total", "paid", "remaining", "status", "notes"]):
              item = self.table.item(row, col)
              row_data[key] = item.text() if item else ""
            fees_list.append(row_data)

        storage.save_fees_status(fees_list)

    def load_fees_from_json(self):
        """تحميل بيانات الجدول من تخزين الملف (Dossier) الحالي"""
        fees_list = storage.load_fees_status()
        if not fees_list:
            self.table.blockSignals(True)
            self.table.setRowCount(0)
            self.table.blockSignals(False)
            return

        self.table.blockSignals(True)
        self.table.setRowCount(0)
        for row_data in fees_list:
            row = self.table.rowCount()
            self.table.insertRow(row)
            for col, key in enumerate(["case_number", "total", "paid", "remaining", "status", "notes"]):
                item = QTableWidgetItem(row_data.get(key, ""))
                self.table.setItem(row, col, item)
        self.table.blockSignals(False)

    # ---------------- حفظ / تعديل / حذف ----------------
    def save_clicked(self):
        self.save_fees_to_json()
        show_toast(self, "تم حفظ كشف الأتعاب ✓", "success")

    def _selected_row(self, purpose):
        row = self.table.currentRow()
        if row < 0 or row >= self.table.rowCount() or self.table.isRowHidden(row):
            show_warning(self, "تنبيه", f"اختر سطراً من الجدول أولاً {purpose}.")
            return -1
        return row

    def _cell_text(self, row, col):
        it = self.table.item(row, col)
        return it.text().strip() if it else ""

    def edit_selected_fee(self):
        row = self._selected_row("لتعديله")
        if row < 0:
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("تعديل كشف الأتعاب")
        dialog.resize(420, 320)
        form = QFormLayout(dialog)

        case_input = QLineEdit(self._cell_text(row, 0))
        total_input = QLineEdit(self._cell_text(row, 1))
        paid_input = QLineEdit(self._cell_text(row, 2))
        notes_input = QLineEdit(self._cell_text(row, 5))
        remaining_label = QLabel()
        status_label = QLabel()

        def recalc():
            total, paid = _num(total_input.text()), _num(paid_input.text())
            remaining = total - paid
            remaining_label.setText(f"{remaining:.2f}")
            if paid <= 0:
                status_label.setText("غير مدفوع")
            elif remaining <= 0:
                status_label.setText("مدفوع بالكامل")
            else:
                status_label.setText("مدفوع جزئي")

        total_input.textChanged.connect(recalc)
        paid_input.textChanged.connect(recalc)
        recalc()

        form.addRow("رقم القضية:", case_input)
        form.addRow("الإجمالي:", total_input)
        form.addRow("المدفوع:", paid_input)
        form.addRow("الباقي (تلقائي):", remaining_label)
        form.addRow("الحالة (تلقائية):", status_label)
        form.addRow("ملاحظات:", notes_input)

        btns = QHBoxLayout()
        save_btn = QPushButton("حفظ التعديلات")
        save_btn.setStyleSheet("background:#128456;color:white;padding:8px 16px;border-radius:6px;font-weight:bold;")
        save_btn.clicked.connect(dialog.accept)
        cancel_btn = QPushButton("إلغاء")
        cancel_btn.clicked.connect(dialog.reject)
        btns.addWidget(save_btn)
        btns.addWidget(cancel_btn)
        form.addRow(btns)

        if dialog.exec_() != QDialog.Accepted:
            return

        case_number = case_input.text().strip()
        if not case_number:
            show_warning(self, "تنبيه", "رقم القضية مطلوب.")
            return

        self.table.blockSignals(True)
        self.table.setItem(row, 0, QTableWidgetItem(case_number))
        self.table.setItem(row, 1, QTableWidgetItem(total_input.text().strip()))
        self.table.setItem(row, 2, QTableWidgetItem(paid_input.text().strip()))
        self.table.setItem(row, 3, QTableWidgetItem(remaining_label.text()))
        self.table.setItem(row, 4, QTableWidgetItem(status_label.text()))
        self.table.setItem(row, 5, QTableWidgetItem(notes_input.text().strip()))
        self.table.blockSignals(False)
        self.save_fees_to_json()
        self._refresh_view()
        show_toast(self, "تم حفظ التعديلات ✓", "success")

    def delete_selected_fee(self):
        row = self._selected_row("لحذفه")
        if row < 0:
            return
        case_number = self._cell_text(row, 0)
        reply = show_question(
            self, "تأكيد الحذف",
            f"هل أنت متأكد من حذف سطر كشف الأتعاب للقضية «{case_number}»؟\n"
            "لن تُحذف التسديدات ولا الوصولات المرتبطة بها.")
        if reply != QMessageBox.Yes:
            return
        self.table.blockSignals(True)
        self.table.removeRow(row)
        self.table.blockSignals(False)
        self.save_fees_to_json()
        self._refresh_view()
        show_toast(self, "تم حذف السطر", "success")

    def reload(self):
        """تُستدعى عند تفعيل التبويب: تحديث التصفية والملخص بما في الجدول حالياً."""
        self._refresh_view()
        self.load_fees_from_json()