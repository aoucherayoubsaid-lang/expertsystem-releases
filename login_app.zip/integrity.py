# -*- coding: utf-8 -*-
"""فحص سلامة ملفات البرنامج المثبَّت (يعمل فقط في نسخة exe المبنية، وفقط إن ضُبط مفتاح التحديثات).

يوقّع tools/release_tool.py manifest ملف integrity.json بمفتاح التحديثات الخاص عند كل بناء: بصمات
SHA-256 لـ ExpertSystem.exe ومكتبة بايثون وملفات .pyd. عند التشغيل يتحقق البرنامج من التوقيع ومن
مطابقة الملفات. تعديل الـ exe (حقن/ترقيع) أو استبدال مكتبة يكسر الفحص.
حدّه: من يملك تعديل البرنامج قد يعطّل الفحص نفسه؛ لذلك يُدمج مع تعتيم الكود (انظر packaging/PROTECTION_AR.md).
"""
import base64
import hashlib
import json
import os
import sys
import time

import ed25519_verify

MANIFEST_NAME = "integrity.json"
_CACHE = {"t": 0.0, "r": (True, "")}
_CORE_SUFFIX = (".exe", ".pyd", "base_library.zip")


def _is_core(rel):
    low = rel.lower()
    return low.endswith(_CORE_SUFFIX) or (os.path.basename(low).startswith("python") and low.endswith(".dll"))


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_dir(root, manifest_path, public_b64):
    """(سليم؟، رسالة). مفصولة عن المنطق العام ليسهل اختبارها."""
    try:
        with open(manifest_path, "r", encoding="utf-8") as f:
            env = json.load(f)
        pub = base64.b64decode(public_b64)
        if not ed25519_verify.verify(pub, env["data"].encode("utf-8"), base64.b64decode(env["sig"])):
            return False, "bad_signature"
        files = json.loads(env["data"]).get("files") or {}
    except FileNotFoundError:
        return False, "manifest_missing"
    except Exception:
        return False, "manifest_invalid"
    exe_name = os.path.basename(sys.executable).lower()
    seen_exe = False
    for rel, want in files.items():
        if not _is_core(rel):
            continue
        full = os.path.join(root, *rel.split("/"))
        if not os.path.isfile(full):
            return False, "missing:" + rel
        if os.path.basename(rel).lower() == exe_name:
            seen_exe = True
        try:
            if _sha256(full) != want:
                return False, "modified:" + rel
        except OSError:
            return False, "unreadable:" + rel
    if not seen_exe:
        return False, "exe_not_in_manifest"
    return True, ""


def check(force=False):
    """يرجع (سليم؟، سبب). في وضع التطوير (غير exe) أو بلا مفتاح مضبوط: دائماً سليم."""
    if not getattr(sys, "frozen", False):
        return True, ""
    import updater
    if not updater.is_configured():
        return True, "unconfigured"
    if not force and time.monotonic() - _CACHE["t"] < 3600 and _CACHE["t"]:
        return _CACHE["r"]
    root = os.path.dirname(os.path.abspath(sys.executable))
    r = verify_dir(root, os.path.join(root, MANIFEST_NAME), updater.UPDATE_PUBLIC_B64)
    _CACHE["t"], _CACHE["r"] = time.monotonic(), r
    return r
