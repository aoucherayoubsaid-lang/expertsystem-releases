# -*- coding: utf-8 -*-
"""الاتصال بخادم الحماية (Cloudflare Worker: server/guard_worker.js).

* كل رد موقَّع بـ Ed25519 ومربوط بجهازك وبقيمة عشوائية (nonce) أرسلها هذا الطلب بالذات،
  فلا يمكن تزويره ولا إعادة تشغيل رد قديم. التحقق بلغة بايثون الصرفة (يعمل على ويندوز 7).
* وقت الخادم هو المرجع: رد بتاريخ بعيد عن ساعة الجهاز يُعتبر تلاعبًا بالساعة.
* غير مضبوط (الرابط/المفتاح ما زالا نموذجيين) => is_configured() = False والبرنامج يعمل كما كان.
"""
import base64
import json
import os
import time
import urllib.error
import urllib.request
from datetime import date, datetime, timedelta, timezone

import ed25519_verify
import trial_online

GUARD_URL = "https://expert-guard.aoucher-ayoubsaid.workers.dev"           # رابط Worker الحماية بدون / في الآخر
GUARD_PUBLIC_B64 = "sRHZMyJlhKvVlxgE1SVBM4JVitMD+L7azcalZ7hE3q4="             # المفتاح العام فقط (من tools/guard_keygen.py)
CLOCK_SKEW_DAYS = 2


def is_configured():
    return "YOUR-GUARD" not in GUARD_URL and not GUARD_PUBLIC_B64.startswith("PASTE")


def _post(path, body, timeout=10):
    """يرجع (http_status, dict) أو (None, None) عند انقطاع الاتصال."""
    req = urllib.request.Request(
        GUARD_URL.rstrip("/") + path, data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json", "User-Agent": "ExpertSystem/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=trial_online._ssl_context()) as r:
            return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode("utf-8"))
        except Exception:
            return e.code, {}
    except Exception:
        return None, None


def _verify(resp, machine, nonce):
    try:
        pub = base64.b64decode(GUARD_PUBLIC_B64)
        if not ed25519_verify.verify(pub, resp["data"].encode("utf-8"), base64.b64decode(resp["sig"])):
            return None
        d = json.loads(resp["data"])
        if d.get("m") != machine or d.get("n") != nonce or d.get("t") != "guard":
            return None
        return d
    except Exception:
        return None


def verify_stored(resp, machine):
    """يتحقق من رد حماية محفوظ محلياً (توقيع + جهاز + نوع + حالة ok) دون nonce. يرجع dict أو None.
    يُستعمل ليستند البرنامج إلى وقت وتاريخ بدء موقَّعين من الخادم لا إلى ملفات يمكن العبث بها."""
    try:
        pub = base64.b64decode(GUARD_PUBLIC_B64)
        if not ed25519_verify.verify(pub, resp["data"].encode("utf-8"), base64.b64decode(resp["sig"])):
            return None
        d = json.loads(resp["data"])
        if d.get("m") != machine or d.get("t") != "guard" or str(d.get("status")) != "ok":
            return None
        return d
    except Exception:
        return None


def _clock_ok(d):
    try:
        iat = trial_online._parse_time(d["iat"])
        return abs(datetime.now(timezone.utc) - iat) <= timedelta(days=CLOCK_SKEW_DAYS)
    except Exception:
        return False


def _ask(path, body, machine):
    """يرجع (status, data). status: 'offline' | 'error' | 'bad' (توقيع خاطئ) | 'clock' | حالة الخادم
    ('ok','unknown','banned','otp_required','otp_invalid','rate_limited','sent',...)."""
    nonce = os.urandom(16).hex()
    body = dict(body, machine=machine, nonce=nonce, client_ts=int(time.time()))
    code, resp = _post(path, body)
    if code is None:
        return "offline", None
    if code != 200:
        return "error", None                      # أخطاء غير موقَّعة لا تقرّر شيئًا: نعاود لاحقًا
    d = _verify(resp, machine, nonce)
    if d is None:
        return "bad", None
    if not _clock_ok(d):
        return "clock", d
    if d.get("start"):
        try:
            d["start_date"] = date.fromisoformat(d["start"])
        except Exception:
            return "bad", None
    d["_resp"] = resp                              # الرد الموقَّع الخام: يُخزَّن محلياً ويُعاد التحقق منه
    return str(d.get("status") or "bad"), d


def first_run(machine, comps, email=None, otp=None, local_start=None):
    body = {"comps": comps}
    if email:
        body["email"] = email
    if otp:
        body["otp"] = otp
    if local_start:
        body["local_start"] = local_start.isoformat()
    return _ask("/g/trial", body, machine)


def heartbeat(machine, comps):
    return _ask("/g/beat", {"comps": comps}, machine)


def request_otp(machine, email):
    return _ask("/g/otp", {"email": email}, machine)
