from msgbox_ltr import show_info, show_warning
# login_app.py
import os
import sys
import tempfile
import faulthandler

# ---------------------------------------------------------------------------
# تسجيل تفصيلي للانهيار (Crash log)
# ---------------------------------------------------------------------------
# انهيار "Python has stopped working" لا يترك أي Traceback عادي لأنه استثناء
# win32 غير معالَج (انهيار داخل طبقة C++ للـ Qt)، وليس خطأ بايثون. faulthandler
# يستطيع مع ذلك كتابة "الخيط/السطر الذي كان قيد التنفيذ لحظة الانهيار" إلى ملف،
# وهذا كفيل بتحديد أي سطر بالضبط تسبّب في الانهيار.
# بعد إعادة إنتاج الخطأ، الملف يكون هنا:
#   %TEMP%\expertise_crash_log.txt   (عادة: C:\Users\<اسمك>\AppData\Local\Temp)
_CRASH_LOG_PATH = os.path.join(tempfile.gettempdir(), "expertise_crash_log.txt")
_crash_log_file = open(_CRASH_LOG_PATH, "w", encoding="utf-8", buffering=1)
faulthandler.enable(file=_crash_log_file, all_threads=True)

# ---------------------------------------------------------------------------
# سجل الأخطاء البايثونية غير الممسوكة (Unhandled exceptions) + منع الانهيار
# ---------------------------------------------------------------------------
# هذا هو السبب الأشيع لـ "Python has stopped working" في تطبيقات PyQt5 (أشيع
# حتى من انهيارات C++ الحقيقية): إن حدث استثناء بايثون عادي (مثل ملف PDF غير
# موجود، أو wkhtmltopdf غير موجود في هذا الجهاز) داخل دالة مربوطة بزر
# (clicked.connect)، فإن PyQt5 منذ الإصدار 5.5 يستدعي afunc abort() على طبقة
# C++ فور خروج الاستثناء من الـ slot دون معالجة - فيظهر للمستخدم كانهيار كامل
# صامت، رغم أنه استثناء بايثون عادي تماماً كان يمكن الإمساك به.
# الحل: نُسجِّل كل استثناء غير مُمسوك هنا في ملف نصي (بدل تركه يُسقِط البرنامج)،
# ونعرض للمستخدم رسالة عادية بدل الانهيار الكامل.
import datetime
import traceback

_ERROR_LOG_PATH = os.path.join(tempfile.gettempdir(), "expertise_error_log.txt")


def _handle_uncaught_exception(exc_type, exc_value, exc_tb):
    try:
        with open(_ERROR_LOG_PATH, "a", encoding="utf-8") as f:
            f.write("\n" + "=" * 70 + "\n")
            f.write(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + "\n")
            traceback.print_exception(exc_type, exc_value, exc_tb, file=f)
    except Exception:
        pass
    try:
        from PyQt5.QtWidgets import QApplication, QMessageBox
        if QApplication.instance() is not None:
            QMessageBox.critical(
                None, "حدث خطأ",
                "حدث خطأ غير متوقع، لكن البرنامج لن يتوقف.\n\n"
                f"تفاصيل الخطأ:\n{exc_value}\n\n"
                f"سُجِّل الخطأ كاملاً في هذا الملف (أرسله للدعم الفني عند الحاجة):\n{_ERROR_LOG_PATH}"
            )
    except Exception:
        pass


sys.excepthook = _handle_uncaught_exception

# إجبار Qt على استعمال محرّك رسوميات برمجي (Software OpenGL) بدل ANGLE/OpenGL الفعلي.
# ضروري جداً على أجهزة قديمة ببطاقة Intel HD Graphics 3000/2000 (مثل هذا الجهاز:
# i3-2370M) تحت Windows 7: عند إضافة تأثيرات مثل QGraphicsDropShadowEffect أو
# حركات النوافذ (fade/slide) فإن Qt يحاول تفعيل تسريع رسوميات عبر OpenGL، وتعريف
# القرص الرسومي القديم/الناقص على هذا الجهاز يتسبب في "استثناء win32 غير معالَج"
# (Access Violation) يظهر كـ "Python has stopped working" - وهذا لا يمكن التقاطه
# بـ try/except لأنه انهيار في طبقة C++ الأصلية للـ Qt، وليس استثناء بايثون.
os.environ.setdefault("QT_OPENGL", "software")
os.environ.setdefault("QT_QUICK_BACKEND", "software")
os.environ.setdefault("QTWEBENGINE_CHROMIUM_FLAGS", "--disable-gpu")
from PyQt5.QtCore import (Qt, QCoreApplication, QTimer, QElapsedTimer, QVariantAnimation,
                          QEasingCurve, QRectF, QPointF, QSize)
QCoreApplication.setAttribute(Qt.AA_UseSoftwareOpenGL, True)
QCoreApplication.setAttribute(Qt.AA_ShareOpenGLContexts)
# ✅ إصلاح مشكلة عدم ظهور أيقونات الأزرار إلا بعد تصغير/تكبير النافذة
# (مشكلة معروفة مع qtawesome على الشاشات عالية الدقة في PyQt5 على Windows)
QCoreApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
QCoreApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)

from PyQt5.QtGui import (QFont, QPalette, QLinearGradient, QColor, QBrush, QIcon,
                         QPainter, QPixmap, QRadialGradient, QPainterPath, QPen)
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QLineEdit, QPushButton, QBoxLayout,
    QVBoxLayout, QHBoxLayout, QCheckBox, QMessageBox, QComboBox,
    QDialog, QFormLayout, QFrame
)
import sys
import math
import qtawesome as qta
from modern_theme import style_button, style_hero_button

import app_paths


def _fatal_data_location(path):
    """المجلد المشترك غير متاح: نتوقف برسالة واضحة بدل العمل على مكان بديل بصمت (كانت البيانات ستبدو «مفقودة»)."""
    msg = ("تعذّر الوصول إلى مجلد البيانات المشترك:\n%s\n\nتأكّد من اتصال الشبكة ومن أن المجلد موجود ويمكن "
           "الكتابة فيه، ثم أعد تشغيل البرنامج." % path)
    try:
        if os.name == "nt":
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, msg, "نظام الخبير", 0x10)
        else:
            print(msg)
    finally:
        sys.exit(1)


try:
    app_paths.app_base_dir()
except app_paths.DataLocationError as _exc:
    _fatal_data_location(str(_exc))

import storage
import security_manager
import local_protect
import data_lock
import data_location
import password_policy
from i18n import tr, is_rtl, current_language_code
import theme_tokens as T
from resource_path import resource_path


_FEATURES = {
    "ar": ["إدارة القضايا والأطراف والوثائق", "الأتعاب والوصولات والتقارير", "التخطيط وتنبيهات آجال الإيداع"],
    "fr": ["Affaires, parties et documents", "Honoraires, reçus et rapports", "Planning et alertes d'échéances"],
    "en": ["Cases, parties and documents", "Fees, receipts and reports", "Planning and deadline alerts"],
}
_TAGLINE = {
    "ar": "منصّتك المتكاملة لعمل الخبير القضائي",
    "fr": "Votre plateforme complète d'expertise judiciaire",
    "en": "Your complete judicial-expertise workspace",
}


class _BrandPanel(QFrame):
    """لوحة الهوية: تدرّج بنفسجي ناعم بحواف مستديرة من الجهة الخارجية فقط،
    وأشكال زخرفية شفافة. تُرسم يدوياً بلا مؤثرات رسومية (خفيفة على الأجهزة القديمة)."""

    def __init__(self, outer_right, parent=None):
        super().__init__(parent)
        self.setObjectName("brandPanel")
        self._outer_right = outer_right

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect())
        path = QPainterPath()
        path.setFillRule(Qt.WindingFill)
        path.addRoundedRect(r, 26, 26)
        inner = QRectF(r)
        if self._outer_right:
            inner.setRight(r.center().x())
        else:
            inner.setLeft(r.center().x())
        path.addRect(inner)
        g = QLinearGradient(r.topLeft(), r.bottomRight())
        g.setColorAt(0.0, QColor(T.GRAD_A))
        g.setColorAt(0.55, QColor(T.GRAD_B))
        g.setColorAt(1.0, QColor(T.GRAD_C))
        p.fillPath(path, g)
        p.setClipPath(path)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(255, 255, 255, 28))
        p.drawEllipse(QPointF(r.center().x(), r.bottom() + 20), 170, 170)
        p.setBrush(QColor(255, 255, 255, 20))
        p.drawEllipse(QPointF(r.right() - 20 if not self._outer_right else r.left() + 20, r.top() + 40), 120, 120)
        p.setBrush(QColor(255, 200, 87, 235))
        p.drawEllipse(QPointF(r.center().x() + (70 if self._outer_right else -70), r.top() + 130), 7, 7)
        p.setBrush(QColor(249, 168, 212, 210))
        p.drawEllipse(QPointF(r.center().x() + (-90 if self._outer_right else 90), r.bottom() - 150), 5, 5)
        p.setBrush(Qt.NoBrush)
        p.setPen(QPen(QColor(255, 255, 255, 60), 2))
        p.drawEllipse(QPointF(r.center().x(), r.bottom() + 20), 235, 235)
        p.end()


class LoginWindow(QWidget):
    """نافذة تسجيل الدخول: خلفية فاتحة بألوان باستيل، بطاقة بيضاء كبيرة، لوحة هوية بنفسجية،
    حقول بأيقونات، زر بتدرّج، ظهور منزلق واهتزاز عند خطأ كلمة المرور."""

    MARGIN = 40

    def __init__(self):
        super().__init__()
        self.setWindowTitle(tr("login_window_title"))
        screen = QApplication.primaryScreen().availableGeometry()
        # حجم ثابت: التكبير يجعل البطاقة تبدو فارغة وغير جذابة، لذلك نلغيه
        self.setWindowFlags(Qt.Window | Qt.WindowTitleHint | Qt.WindowSystemMenuHint
                            | Qt.WindowMinimizeButtonHint | Qt.WindowCloseButtonHint)
        self.setFixedSize(960, min(620, int(screen.height() * 0.95)))
        self.move(screen.center().x() - self.width() // 2,
                  max(screen.top() + 10, screen.center().y() - self.height() // 2))
        self._clock = QElapsedTimer()
        self._clock.start()
        self._bg_cache = None          # الخلفية تُرسم مرة واحدة فقط (توفير للمعالج)
        self._entered = False
        self.setup_ui()

    # ---------------- الخلفية ----------------
    def paintEvent(self, _):
        p = QPainter(self)
        w, h = self.width(), self.height()
        if self._bg_cache is None or self._bg_cache.size() != self.size():
            self._bg_cache = self._render_background(w, h)
        p.drawPixmap(0, 0, self._bg_cache)
        p.setRenderHint(QPainter.Antialiasing)
        # ظل ناعم مائل للبنفسجي تحت البطاقة (يُرسم يدوياً حتى لا نضع مؤثّراً على حاوية فيها أزرار)
        geo = self.card.geometry()
        p.setPen(Qt.NoPen)
        for i in range(1, 15):
            p.setBrush(QColor(67, 56, 202, max(2, 11 - i)))
            p.drawRoundedRect(QRectF(geo.adjusted(-i, -i + 10, i, i + 10)), 28 + i, 28 + i)
        p.end()

    def _render_background(self, w, h):
        pm = QPixmap(w, h)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing)
        g = QLinearGradient(0, 0, w, h)
        g.setColorAt(0.0, QColor(T.BG_GRAD[0]))
        g.setColorAt(0.5, QColor(T.BG_GRAD[1]))
        g.setColorAt(1.0, QColor(T.BG_GRAD[2]))
        p.fillRect(pm.rect(), g)
        p.setPen(Qt.NoPen)
        for cx, cy, rad, col in ((90, 80, 150, QColor(124, 58, 237, 34)),
                                 (w - 60, 120, 120, QColor(14, 165, 233, 30)),
                                 (w - 160, h - 40, 170, QColor(236, 72, 153, 26)),
                                 (140, h - 20, 110, QColor(255, 200, 87, 44))):
            p.setBrush(col)
            p.drawEllipse(QPointF(cx, cy), rad, rad)
        p.end()
        return pm

    def showEvent(self, event):
        super().showEvent(event)
        if not self._entered:
            self._entered = True
            if T.ANIMATIONS:
                self._play_entrance()

    def hideEvent(self, event):
        super().hideEvent(event)

    def _play_entrance(self):
        """البطاقة تنزلق من الأسفل مرة واحدة (حجمها ثابت: نزيح الهوامش فقط)."""
        anim = QVariantAnimation(self)
        anim.setDuration(620)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        m = self.MARGIN

        def step(v):
            off = int(30 * (1.0 - float(v)))
            self._root.setContentsMargins(m, m + off, m, m - off)

        def done():
            self._root.setContentsMargins(m, m, m, m)

        anim.valueChanged.connect(step)
        anim.finished.connect(done)
        self._entrance = anim
        anim.start()

    def _shake(self):
        anim = QVariantAnimation(self)
        anim.setDuration(460)
        for pos, val in ((0.0, 0.0), (0.10, -14.0), (0.25, 14.0), (0.40, -10.0),
                         (0.55, 10.0), (0.70, -6.0), (0.85, 6.0), (1.0, 0.0)):
            anim.setKeyValueAt(pos, val)
        m = self.MARGIN
        anim.valueChanged.connect(
            lambda v: self._root.setContentsMargins(max(0, m + int(v)), m, max(0, m - int(v)), m))
        self._shake_anim = anim
        anim.start()

    def _flag_error(self):
        fields = (self.username_input, self.password_input)
        for f in fields:
            f.setProperty("error", True)
            f.style().unpolish(f)
            f.style().polish(f)

        def clear():
            for f in fields:
                f.setProperty("error", False)
                f.style().unpolish(f)
                f.style().polish(f)

        QTimer.singleShot(1400, clear)

    # ---------------- بناء الواجهة ----------------
    def _logo_pixmap(self, size=76):
        dpr = self.devicePixelRatioF()
        pm = QPixmap(int(size * dpr), int(size * dpr))
        pm.setDevicePixelRatio(dpr)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(255, 255, 255, 52))
        p.drawEllipse(1, 1, size - 2, size - 2)
        p.setBrush(QColor(255, 255, 255))
        inner = size - 16
        p.drawEllipse(8, 8, inner, inner)
        icon_px = qta.icon("fa5s.balance-scale", color=T.ACCENT).pixmap(int(size * 0.42), int(size * 0.42))
        p.drawPixmap(int((size - icon_px.width() / dpr) / 2), int((size - icon_px.height() / dpr) / 2), icon_px)
        p.end()
        return pm

    def setup_ui(self):
        rtl = is_rtl()
        lang = current_language_code()
        self._root = QVBoxLayout(self)
        m = self.MARGIN
        self._root.setContentsMargins(m, m, m, m)

        self.card = QFrame()
        self.card.setObjectName("loginCard")
        self.card.setStyleSheet(f"""
            QFrame#loginCard {{ background: white; border-radius: 26px; }}
            QFrame#loginCard QLabel {{ background: transparent; }}
            QFrame#loginCard QLineEdit, QFrame#loginCard QComboBox {{
                background: {T.SURFACE_ALT}; border: 2px solid {T.BORDER}; border-radius: 13px;
                padding: 11px 14px; color: {T.TEXT}; min-height: 24px; font-size: 11pt;
            }}
            QFrame#loginCard QLineEdit:hover, QFrame#loginCard QComboBox:hover {{
                border: 2px solid {T.BORDER_STRONG};
            }}
            QFrame#loginCard QLineEdit:focus, QFrame#loginCard QComboBox:focus {{
                border: 2px solid {T.ACCENT}; background: white;
            }}
            QFrame#loginCard QLineEdit[error="true"], QFrame#loginCard QComboBox[error="true"] {{
                border: 2px solid {T.DANGER}; background: {T.BAD_BG};
            }}
            QFrame#loginCard QComboBox QLineEdit {{
                border: none; background: transparent; padding: 0; min-height: 0;
            }}
            QFrame#loginCard QCheckBox {{ color: {T.TEXT_MUTED}; }}
        """)
        card_row = QHBoxLayout(self.card)
        card_row.setContentsMargins(0, 0, 0, 0)
        card_row.setSpacing(0)
        # ترتيب فيزيائي ثابت: لوحة الهوية يميناً بالعربية ويساراً في غيرها
        card_row.setDirection(QBoxLayout.RightToLeft if rtl else QBoxLayout.LeftToRight)

        # ---------- لوحة الهوية ----------
        brand = _BrandPanel(outer_right=rtl)
        brand.setFixedWidth(350)
        bl = QVBoxLayout(brand)
        bl.setContentsMargins(34, 40, 34, 26)
        bl.setSpacing(10)
        logo = QLabel()
        logo.setPixmap(self._logo_pixmap(76))
        logo.setStyleSheet("background: transparent;")
        bl.addWidget(logo, 0, Qt.AlignLeading)
        bl.addSpacing(8)
        title = QLabel(tr("login_app_title"))
        title.setWordWrap(True)
        title.setStyleSheet("font-size: 25px; font-weight: bold; color: white; background: transparent;")
        bl.addWidget(title)
        tagline = QLabel(_TAGLINE.get(lang, _TAGLINE["ar"]))
        tagline.setProperty("_auto_i18n_skip", True)
        tagline.setWordWrap(True)
        tagline.setStyleSheet(f"font-size: 12px; color: {T.TEXT_ON_DARK_MUTED}; background: transparent;")
        bl.addWidget(tagline)
        rule = QFrame()
        rule.setFixedSize(46, 4)
        rule.setStyleSheet(f"background: {T.ACCENT_LIGHT}; border: none; border-radius: 2px;")
        bl.addWidget(rule, 0, Qt.AlignLeading)
        bl.addSpacing(14)

        for text in _FEATURES.get(lang, _FEATURES["ar"]):
            pill = QFrame()
            pill.setObjectName("featPill")
            pill.setStyleSheet(
                "QFrame#featPill { background: rgba(255,255,255,38); border: none; border-radius: 14px; }"
                "QFrame#featPill QLabel { background: transparent; border: none; }")
            pl = QHBoxLayout(pill)
            pl.setContentsMargins(12, 9, 14, 9)
            pl.setSpacing(10)
            dot = QLabel()
            dot.setFixedSize(24, 24)
            dot.setAlignment(Qt.AlignCenter)
            dot.setStyleSheet("background: white; border-radius: 12px;")
            dot.setPixmap(qta.icon("fa5s.check", color=T.ACCENT).pixmap(11, 11))
            lab = QLabel(text)
            lab.setProperty("_auto_i18n_skip", True)
            lab.setWordWrap(True)
            lab.setStyleSheet("color: white; font-size: 12px; font-weight: 600;")
            pl.addWidget(dot)
            pl.addWidget(lab, 1)
            bl.addWidget(pill)
        bl.addStretch(1)

        import app_info, license_manager
        try:
            _lic = license_manager.status_text()
        except Exception:
            _lic = ""
        version = QLabel("v%s%s" % (app_info.APP_VERSION, ("\n" + _lic) if _lic else ""))
        version.setWordWrap(True)
        version.setStyleSheet(f"font-size: 11px; color: {T.TEXT_ON_DARK_FAINT}; background: transparent;")
        bl.addWidget(version)
        card_row.addWidget(brand)

        # ---------- نموذج الدخول ----------
        form = QFrame()
        form.setObjectName("formPanel")
        form.setStyleSheet("QFrame#formPanel { background: transparent; }")
        lay = QVBoxLayout(form)
        lay.setContentsMargins(52, 36, 52, 32)
        lay.setSpacing(14)
        from theme_manager import make_theme_button
        theme_row = QHBoxLayout()
        theme_row.addStretch(1)
        theme_row.addWidget(make_theme_button(self))
        lay.addLayout(theme_row)
        lay.addStretch(1)

        hello = QLabel({"ar": "👋  أهلاً بعودتك", "fr": "👋  Bon retour", "en": "👋  Welcome back"}.get(lang, "👋  أهلاً بعودتك"))
        hello.setProperty("_auto_i18n_skip", True)
        hello.setStyleSheet(
            f"font-size: 12px; font-weight: 600; color: {T.ACCENT}; background: {T.INFO_BG};"
            " border-radius: 12px; padding: 4px 14px;")
        lay.addWidget(hello, 0, Qt.AlignLeading)

        heading = QLabel({"ar": "تسجيل الدخول", "fr": "Connexion", "en": "Sign in"}.get(lang, "تسجيل الدخول"))
        heading.setProperty("_auto_i18n_skip", True)
        heading.setStyleSheet(f"font-size: 28px; font-weight: bold; color: {T.INK};")
        lay.addWidget(heading)

        subtitle = QLabel(tr("login_subtitle"))
        subtitle.setWordWrap(True)
        subtitle.setStyleSheet(f"font-size: 13px; color: {T.TEXT_MUTED};")
        lay.addWidget(subtitle)
        lay.addSpacing(8)

        self.username_input = QComboBox()
        self.username_input.setEditable(True)  # يبقى بإمكانه كتابة اسم غير موجود في القائمة عند الحاجة
        self.username_input.lineEdit().setPlaceholderText(tr("login_username_placeholder"))
        self.username_input.lineEdit().addAction(
            qta.icon("fa5s.user", color=T.ACCENT), QLineEdit.TrailingPosition)
        self.username_input.lineEdit().returnPressed.connect(
            lambda: self.password_input.setFocus())
        self.populate_accounts()
        lay.addWidget(self.username_input)

        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText(tr("login_password_placeholder"))
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.addAction(qta.icon("fa5s.lock", color=T.ACCENT), QLineEdit.LeadingPosition)
        self._eye_action = self.password_input.addAction(
            qta.icon("fa5s.eye", color="#8a92b5"), QLineEdit.TrailingPosition)
        self._eye_action.setToolTip(tr("login_show_password"))
        self._eye_action.triggered.connect(self._toggle_password)
        self.password_input.returnPressed.connect(self.handle_login)
        lay.addWidget(self.password_input)

        if is_rtl():
            # عربي: الكتابة (والنص التوضيحي) من اليمين إلى اليسار في الحقلين.
            # AlignAbsolute ضروري: بدونه ينعكس الـ placeholder إلى اليسار في واجهة RTL.
            for field in (self.username_input.lineEdit(), self.password_input):
                field.setLayoutDirection(Qt.RightToLeft)
                field.setAlignment(Qt.AlignRight | Qt.AlignAbsolute | Qt.AlignVCenter)
            # سهم القائمة المنسدلة جهة اليمين: القائمة نفسها LTR وحقل الكتابة داخلها RTL
            self.username_input.setLayoutDirection(Qt.LeftToRight)
            self.username_input.view().setLayoutDirection(Qt.RightToLeft)
            self.username_input.lineEdit().setTextMargins(0, 0, 6, 0)

        self.remember_checkbox = QCheckBox(tr("login_remember_me"))

        forgot_link = QPushButton(tr("login_forgot_password"))
        forgot_link.setFlat(True)
        forgot_link.setCursor(Qt.PointingHandCursor)
        forgot_link.setStyleSheet(
            f"QPushButton {{ border: none; color: {T.ACCENT}; background: transparent; padding: 2px; font-weight: 600; }}"
            f"QPushButton:hover {{ color: {T.PRIMARY_DARK}; text-decoration: underline; }}"
        )
        forgot_link.clicked.connect(self.open_forgot_password)

        options_layout = QHBoxLayout()
        # ترتيب فيزيائي ثابت: تذكّرني يساراً ورابط الاسترجاع أقصى اليمين،
        # بما في ذلك عند تشغيل الواجهة العربية RTL.
        options_layout.setDirection(QBoxLayout.LeftToRight)
        options_layout.addWidget(self.remember_checkbox)
        options_layout.addStretch(1)
        options_layout.addWidget(forgot_link, 0, Qt.AlignRight)
        lay.addLayout(options_layout)

        login_btn = QPushButton(tr("login_button"))
        login_btn.setIcon(qta.icon("fa5s.sign-in-alt", color="white"))
        login_btn.setIconSize(QSize(18, 18))
        login_btn.setMinimumHeight(52)
        login_btn.setDefault(True)
        style_hero_button(login_btn, radius=14, padding="13px 22px")
        login_btn.clicked.connect(self.handle_login)
        lay.addSpacing(6)
        lay.addWidget(login_btn)
        lay.addStretch(1)
        card_row.addWidget(form, 1)

        self._root.addWidget(self.card)

    def _toggle_password(self):
        hidden = self.password_input.echoMode() == QLineEdit.Password
        self.password_input.setEchoMode(QLineEdit.Normal if hidden else QLineEdit.Password)
        self._eye_action.setIcon(qta.icon("fa5s.eye-slash" if hidden else "fa5s.eye", color="#8a92b5"))

    def populate_accounts(self):
        """يملأ القائمة بالحسابات المفعّلة فقط، كل حساب مع دوره، حتى يختار
        المستخدم حسابه مباشرة بدل كتابة اسمه يدوياً في كل مرة."""
        try:
            users = storage.load_users()
        except Exception:
            users = []
        self.username_input.clear()
        self.username_input.addItem("", "")  # اختيار فارغ افتراضي
        role_labels = getattr(storage, "ROLES", {})
        for u in users:
            if not u.get("active", True):
                continue
            username = u.get("username", "")
            role_label = role_labels.get(u.get("role", ""), u.get("role", ""))
            label = f"{username}  —  {role_label}"
            if is_rtl():
                label = "\u200f" + label  # علامة RTL: يبدأ العرض من اليمين حتى لو بدأ النص بحروف لاتينية
            self.username_input.addItem(label, username)
            if is_rtl():
                self.username_input.setItemData(
                    self.username_input.count() - 1,
                    Qt.AlignRight | Qt.AlignVCenter, Qt.TextAlignmentRole)
        self.username_input.setCurrentIndex(0)
        self.username_input.currentIndexChanged.connect(self._on_account_picked)

    def _on_account_picked(self, index):
        # عند اختيار حساب من القائمة، ننتقل مباشرة لحقل كلمة المرور
        if self.username_input.itemData(index):
            self.password_input.setFocus()

    def current_username(self):
        """يرجع اسم المستخدم الفعلي، سواء اختير من القائمة أو كُتب يدوياً."""
        index = self.username_input.currentIndex()
        data = self.username_input.itemData(index)
        if data:
            return data
        return self.username_input.currentText().strip()

    def open_forgot_password(self):
        dialog = ForgotPasswordDialog(self, username=self.current_username())
        dialog.exec_()

    def handle_login(self):
        username = self.current_username()
        password = self.password_input.text()

        if local_protect.tamper_detected():
            show_warning(self, tr("login_error_title"), tr("tamper_blocked_message"))
            return
        if security_manager.is_locked(username):
            if local_protect.tamper_detected():
                show_warning(self, tr("login_error_title"), tr("tamper_blocked_message"))
                return
            show_warning(self, tr("login_error_title"),
                         tr("login_locked_message").replace("{m}", str(max(1, security_manager.lock_remaining_minutes(username)))))
            security_manager.audit("LOGIN_BLOCKED", username, "locked")
            return
        user = storage.verify_login(username, password)
        if local_protect.tamper_detected():
            show_warning(self, tr("login_error_title"), tr("tamper_blocked_message"))
            return
        if user == "disabled":
            show_warning(
                self, tr("login_disabled_title"),
                tr("login_disabled_message"))
        elif user:
            security_manager.ensure_device_approved()
            security_manager.record_success(username)
            need_pw = storage.must_change_password(username)
            need_rec = storage.needs_recovery_setup(username)
            if need_pw or need_rec:
                dialog = ForceChangePasswordDialog(username, self, need_password=need_pw, need_recovery=need_rec)
                if dialog.exec_() != QDialog.Accepted:
                    # المستخدم أغلق نافذة الإعداد الإلزامية دون إكمالها
                    return
                user = next((u for u in storage.load_users() if u.get("username") == username), user)
            # ننتقل إلى شاشة اختيار الملف (Dossier) بدلاً من فتح البرنامج مباشرة
            from dossier_page import DossierPage
            self.dossier_page = DossierPage(current_user=user)
            self.dossier_page.show()
            self.close()
        else:
            security_manager.record_failure(username)
            # اهتزاز البطاقة + تمييز الحقول بالأحمر ثم رسالة الخطأ
            self._shake()
            self._flag_error()
            QTimer.singleShot(
                420, lambda: show_warning(
                    self, tr("login_error_title"), tr("login_error_message")))


class ForgotPasswordDialog(QDialog):
    """استرجاع كلمة المرور عبر سؤال الأمان الذي حدَّده صاحب الحساب مسبقاً
    (يُضبط من الإعدادات ← المستخدمون ← تعديل، أو عند أول دخول للمدير).

    نفس حماية الدخول: قفل بعد محاولات فاشلة (مفتاح مستقل لكل اسم + قفل عام للجهاز)، كل المحاولات
    في سجل التدقيق، رسائل الخطأ عامة (لا تكشف وجود الحساب)، وكلمة المرور الجديدة تطابق السياسة."""

    def __init__(self, parent=None, username=""):
        super().__init__(parent)
        self.setWindowTitle(tr("forgot_dialog_title"))
        self.setMinimumWidth(340)

        layout = QVBoxLayout(self)
        form = QFormLayout()

        # حقل نصي لا قائمة: لا نعرض أسماء الحسابات في هذه النافذة
        self.username_input = QLineEdit(username or "")
        form.addRow(tr("forgot_username_label"), self.username_input)
        layout.addLayout(form)

        show_question_btn = QPushButton(tr("forgot_show_question"))
        show_question_btn.clicked.connect(self.show_question)
        layout.addWidget(show_question_btn)

        self.question_label = QLabel("")
        self.question_label.setWordWrap(True)
        self.question_label.setStyleSheet("color:#1f2347; font-weight:bold;")
        layout.addWidget(self.question_label)

        self.answer_form = QFormLayout()
        self.answer_input = QLineEdit()
        self.answer_form.addRow(tr("forgot_answer_label"), self.answer_input)

        self.new_password_input = QLineEdit()
        self.new_password_input.setEchoMode(QLineEdit.Password)
        self.answer_form.addRow(tr("forgot_new_password_label"), self.new_password_input)

        self.confirm_password_input = QLineEdit()
        self.confirm_password_input.setEchoMode(QLineEdit.Password)
        self.answer_form.addRow(tr("forgot_confirm_password_label"), self.confirm_password_input)
        layout.addLayout(self.answer_form)

        hint = QLabel(password_policy.requirements_text())
        hint.setWordWrap(True)
        hint.setStyleSheet("color:#555; font-size:11px;")
        layout.addWidget(hint)

        reset_btn = QPushButton(tr("forgot_reset_button"))
        reset_btn.setStyleSheet("background:#128456;color:white;padding:8px;border-radius:6px;")
        reset_btn.clicked.connect(self.do_reset)
        layout.addWidget(reset_btn)

    @staticmethod
    def _lock_key(username):
        return "reset:" + (username or "").strip()

    def _blocked(self, username):
        if local_protect.tamper_detected():
            show_warning(self, tr("forgot_warning_title"), tr("tamper_blocked_message"))
            return True
        key = self._lock_key(username)
        if security_manager.is_locked(key):
            security_manager.audit("RESET_BLOCKED", username, "locked")
            show_warning(self, tr("forgot_warning_title"),
                         tr("login_locked_message").replace("{m}", str(max(1, security_manager.lock_remaining_minutes(key)))))
            return True
        return False

    def show_question(self):
        username = self.username_input.text().strip()
        if not username:
            show_warning(self, tr("forgot_warning_title"), tr("forgot_enter_username_first"))
            return
        if self._blocked(username):
            self.question_label.setText("")
            return
        security_manager.audit("RESET_REQUESTED", username, "success")
        # سؤال حقيقي إن وُجد الحساب وكان مهيّأً، وإلا سؤال وهمي ثابت: لا فرق ظاهر بين الحالتين
        question = storage.recovery_question_for_display(username)
        self.question_label.setText(f"{tr('forgot_question_prefix')} {question}")

    def do_reset(self):
        username = self.username_input.text().strip()
        answer = self.answer_input.text().strip()
        new_password = self.new_password_input.text()
        confirm_password = self.confirm_password_input.text()

        if not username or not answer or not new_password:
            show_warning(self, tr("forgot_warning_title"), tr("forgot_fill_all_fields"))
            return
        if new_password != confirm_password:
            show_warning(self, tr("forgot_warning_title"), tr("forgot_passwords_mismatch"))
            return
        ok_pw, problems = password_policy.check(new_password, username)
        if not ok_pw:
            show_warning(self, tr("forgot_warning_title"), password_policy.explain(problems))
            return
        if self._blocked(username):
            return

        try:
            ok = storage.reset_password_with_security_answer(username, answer, new_password)
        except password_policy.WeakPassword as exc:
            show_warning(self, tr("forgot_warning_title"), password_policy.explain(exc.problems))
            return
        except local_protect.IntegrityError:
            show_warning(self, tr("forgot_warning_title"), tr("tamper_blocked_message"))
            return
        key = self._lock_key(username)
        if ok:
            security_manager.record_success(key, action="PASSWORD_RESET")
            show_info(self, tr("forgot_success_title"), tr("forgot_success_message"))
            self.accept()
        else:
            security_manager.record_failure(key, action="RESET_FAILED")
            show_warning(self, tr("login_error_title"), tr("forgot_wrong_answer"))


class ForceChangePasswordDialog(QDialog):
    """نافذة إلزامية (لا يمكن تجاوزها بدون إغلاق البرنامج) تظهر عند أول دخول بحساب كلمة مروره
    افتراضية أو لا تطابق السياسة، وعندما لا يكون للحساب سؤال/إجابة استرجاع خاصة به.
    لا تُقبل كلمة مرور ضعيفة ولا إجابة تافهة."""

    def __init__(self, username, parent=None, need_password=True, need_recovery=False):
        super().__init__(parent)
        self.username = username
        self.need_password = need_password
        self.need_recovery = need_recovery
        self.setWindowTitle(tr("force_change_title"))
        self.setMinimumWidth(380)

        layout = QVBoxLayout(self)

        message = QLabel(tr("force_change_message") if need_password else tr("recovery_setup_message"))
        message.setWordWrap(True)
        layout.addWidget(message)

        form = QFormLayout()
        self.new_password_input = QLineEdit()
        self.new_password_input.setEchoMode(QLineEdit.Password)
        self.confirm_password_input = QLineEdit()
        self.confirm_password_input.setEchoMode(QLineEdit.Password)
        if need_password:
            form.addRow(tr("force_change_new_password_label"), self.new_password_input)
            form.addRow(tr("force_change_confirm_password_label"), self.confirm_password_input)

        self.question_input = QLineEdit()
        self.answer_input = QLineEdit()
        if need_recovery:
            self.question_input.setPlaceholderText(tr("recovery_question_placeholder"))
            form.addRow(tr("recovery_question_label"), self.question_input)
            form.addRow(tr("recovery_answer_label"), self.answer_input)
        layout.addLayout(form)

        hint = QLabel(password_policy.requirements_text() if need_password else tr("recovery_answer_hint"))
        hint.setWordWrap(True)
        hint.setStyleSheet("color:#555; font-size:11px;")
        layout.addWidget(hint)

        confirm_btn = QPushButton(tr("force_change_button"))
        confirm_btn.setStyleSheet("background:#128456;color:white;padding:8px;border-radius:6px;")
        confirm_btn.clicked.connect(self.do_change)
        layout.addWidget(confirm_btn)

    def do_change(self):
        # نتحقق من كل شيء قبل أي حفظ، كي لا يُحفظ نصف الإعداد
        if self.need_password:
            new_password = self.new_password_input.text()
            if new_password != self.confirm_password_input.text():
                show_warning(self, tr("login_error_title"), tr("force_change_mismatch"))
                return
            ok, problems = password_policy.check(new_password, self.username)
            if not ok:
                show_warning(self, tr("login_error_title"), password_policy.explain(problems))
                return
        if self.need_recovery:
            question = self.question_input.text().strip()
            answer = self.answer_input.text()
            if len(question) < 8:
                show_warning(self, tr("login_error_title"), tr("recovery_question_too_short"))
                return
            ok, problems = password_policy.check_answer(answer)
            if not ok:
                show_warning(self, tr("login_error_title"), "؛ ".join(problems))
                return
        try:
            if self.need_password:
                storage.change_password(self.username, new_password)
            if self.need_recovery:
                storage.set_recovery(self.username, question, answer)
        except (ValueError, local_protect.IntegrityError) as exc:
            show_warning(self, tr("login_error_title"), str(exc))
            return
        show_info(self, tr("login_button"), tr("force_change_success"))
        self.accept()


def _ensure_shared_unlocked(app):
    """وضع المجلد المشترك: إن لم يملك هذا الجهاز المفتاح يطلب عبارة المرور (5 محاولات)."""
    from PyQt5.QtWidgets import QInputDialog
    state = local_protect.shared_state()
    if state == "ready" or state == "local":
        return
    if state == "need_setup":
        QMessageBox.warning(None, "المجلد المشترك غير مهيّأ",
                            "المجلد المشترك لم يُهيَّأ بعد. شغّل البرنامج بالخيار --use-shared-folder لتهيئته.")
        sys.exit()
    for _ in range(5):
        text, ok = QInputDialog.getText(None, "عبارة مرور المجلد المشترك",
                                        "أدخل عبارة المرور التي حدّدها صاحب المجلد المشترك\n(تُطلب مرة واحدة على هذا الجهاز):",
                                        QLineEdit.Password)
        if not ok:
            sys.exit()
        try:
            local_protect.unlock_shared(text)
            return
        except ValueError as exc:
            QMessageBox.warning(None, "عبارة المرور", str(exc))
    sys.exit()


def _acquire_writer_or_exit(app):
    """جهاز واحد يكتب في المجلد المشترك؛ الباقي للقراءة فقط."""
    import atexit
    res = data_lock.acquire()
    atexit.register(data_lock.release)
    if res["role"] == "writer":
        return
    box = QMessageBox(QMessageBox.Question, "البيانات قيد الاستعمال",
                      "جهاز آخر يعمل الآن على هذه البيانات: %s.\n\nيمكنك فتحها للقراءة فقط (لن تُحفظ أي تعديلات)، "
                      "أو الخروج وإعادة المحاولة بعد أن يُغلق الجهاز الآخر برنامجه.\n"
                      "إن كان البرنامج مغلقاً على الجهاز الآخر فسيُفرَج عن القفل تلقائياً بعد دقيقة ونصف تقريباً."
                      % (data_lock.holder_text() or "؟"))
    ro = box.addButton("فتح للقراءة فقط", QMessageBox.AcceptRole)
    box.addButton("خروج", QMessageBox.RejectRole)
    box.exec_()
    if box.clickedButton() is not ro:
        sys.exit()


def _run_location_switch(app):
    from PyQt5.QtWidgets import QFileDialog, QInputDialog
    try:
        if "--use-local-data" in sys.argv:
            if app_paths.data_mode() != "shared":
                QMessageBox.information(None, "وضع البيانات", "هذا الجهاز يعمل أصلاً على بيانات محلية.")
                return
            _a = QMessageBox.question(
                None, "العودة إلى بيانات محلية",
                "ستُنسخ البيانات المشتركة إلى هذا الجهاز بعد التحقق منها، ويبقى المجلد المشترك كما هو للأجهزة الأخرى.\n\nمتابعة؟",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if _a == QMessageBox.Yes:
                r = data_location.switch_to_local()
                QMessageBox.information(None, "تم", "نُسخت البيانات إلى:\n" + r["target"])
            return
        folder = QFileDialog.getExistingDirectory(None, "اختر المجلد المشترك (على الشبكة أو الخادم)")
        if not folder:
            return
        text, ok = QInputDialog.getText(
            None, "عبارة المرور",
            "عبارة مرور المجلد المشترك (12 حرفاً فأكثر).\nمجلد جديد: اختر عبارة جديدة واحفظها. مجلد قائم: أدخل عبارته.\n"
            "لا يمكن استرجاعها إن نُسيت.", QLineEdit.Password)
        if not ok:
            return
        r = data_location.switch_to_shared(folder, text)
        QMessageBox.information(
            None, "تم",
            "أُنشئ المجلد المشترك ونُقلت إليه بياناتك." if r["created"] else "انضم هذا الجهاز إلى المجلد المشترك.")
    except (data_location.SwitchError, ValueError) as exc:
        QMessageBox.warning(None, "تعذّر التحويل", str(exc))


if __name__ == "__main__":
    app = QApplication(sys.argv)
    # أيقونة موحّدة لكل نوافذ البرنامج (تظهر في شريط العنوان وشريط المهام)
    app.setWindowIcon(QIcon(resource_path("app_icon.ico")))

    from auto_translation import get_auto_translation_manager
    auto_i18n = get_auto_translation_manager(app)

    # مسار استرداد صريح بعد نقل التطبيق لجهاز جديد أو بعد تحقق المالك من سلامة الملفات
    if "--reseal-integrity" in sys.argv:
        _ans = QMessageBox.question(
            None, "إعادة ختم ملفات الأمان",
            "سيتبنّى البرنامج ملفات المستخدمين والإعدادات الحالية كما هي ويصدر لها توقيعاً جديداً.\n"
            "افعل هذا فقط إن كنت واثقاً أن الملفات لم تُعدَّل (مثلاً بعد نقل البرنامج لجهاز جديد).\n"
            "إن شككت بعبث فاسترجع نسخة احتياطية أولاً.\n\nمتابعة؟",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if _ans == QMessageBox.Yes:
            _done = local_protect.reseal_all()
            security_manager.audit("INTEGRITY_RESEALED", "", "success", {"files": _done})
            show_info(None, "تم", "أُعيد ختم الملفات: " + "، ".join(_done))
        sys.exit()

    # تبديل موقع البيانات (يُشغَّل من اختصار أو سطر أوامر عند الحاجة)
    if "--use-shared-folder" in sys.argv or "--use-local-data" in sys.argv:
        _run_location_switch(app)
        sys.exit()

    # المجلد المشترك: عبارة المرور (مرة واحدة لكل جهاز) ثم عقد الكتابة
    _ensure_shared_unlocked(app)
    _acquire_writer_or_exit(app)

    from settings_page import AppSettings
    settings = AppSettings()
    if local_protect.tamper_detected():
        show_warning(None, tr("login_error_title"), tr("tamper_blocked_message"))
        sys.exit()

    # نطبّق الخط الذي اختاره المستخدم (أو Arial افتراضياً) على واجهة
    # البرنامج بأكملها، منذ أول نافذة تُفتح.
    from ui_style import apply_global_font
    apply_global_font(app, settings.get("font_family") or "Arial", int(settings.get("font_size") or 13))

    # التصميم العصري: أزرار متحركة + انتقالات ناعمة + تنسيق موحّد
    from modern_theme import install_modern_theme
    install_modern_theme(app)

    auto_i18n.set_language("ar" if is_rtl() else settings.get_language_code())
    app.setLayoutDirection(Qt.RightToLeft if is_rtl() else Qt.LeftToRight)
    # تُركَّب دائماً: المرشّحات تفحص اتجاه التطبيق عند كل إظهار، فتعمل بالعربية
    # وتتوقف تلقائياً إذا غيّر المستخدم اللغة إلى الفرنسية/الإنجليزية أثناء التشغيل.
    # الجملة في وسط الزر ثم الأيقونة بعدها (بدل نص ملتصق بالحافة وأيقونة وسطى)
    from ui_style import (install_rtl_button_style, install_rtl_field_alignment,
                          install_rtl_text_alignment)
    install_rtl_button_style(app)
    # محاذاة يمين لكل حقول الإدخال في البرنامج كله دفعة واحدة
    install_rtl_field_alignment(app)
    # مؤشر الكتابة في مربعات الملاحظات (QTextEdit) من أقصى اليمين
    install_rtl_text_alignment(app)

    # النسخة التجريبية (30 يوماً) والتفعيل: يظهر طلب التفعيل هنا عند الانتهاء
    from license_dialog import startup_check
    if not startup_check():
        sys.exit()

    # الحارس المتقدّم (نقاط توقف المعالج، بيئة افتراضية، تجميد التنفيذ، أدوات هندسة عكسية):
    # يبدأ فوراً بعد نجاح الترخيص وقبل أي استيراد آخر -- أبكر نقطة ممكنة لحماية بقية التشغيل.
    import advanced_guard
    advanced_guard.start()

    # حزمة منطق العمل المشفّرة (إن كانت مضبوطة في هذه النسخة): يجب أن يحدث هذا قبل أي
    # استيراد لوحدة من tools/build_bundle.py (BUNDLE_MODULES)، ولذلك هو هنا مباشرة بعد
    # التحقق من الترخيص وقبل أي سطر قد يستورد main_app أو dossier_page أو ما شابه.
    import app_info
    import bundle_loader
    import license_manager as _lm
    _bundle_ok, _bundle_msg = bundle_loader.unlock(
        _lm.machine_code(), _lm.current_license_key(), app_info.APP_VERSION)
    if not _bundle_ok and bundle_loader.is_configured():
        show_warning(None, "تعذّر التشغيل",
                     "تعذّر تحميل وحدات البرنامج من الخادم (%s). تأكّد من الاتصال بالإنترنت "
                     "ثم أعد المحاولة." % _bundle_msg)
        sys.exit()

    if settings.get("require_password_on_start"):
        from main_app import LoginDialog
        login_dialog = LoginDialog(settings)
        login_dialog.show()
        app.processEvents()
        while login_dialog.isVisible():
            app.processEvents()
        if not getattr(login_dialog, 'accepted', False):
            sys.exit()

    login_window = LoginWindow()
    login_window.show()

    # تحقق دوري من خادم الحماية في الخلفية (الموعد يحدده الخادم عشوائياً بين 2 و5 أيام)
    from PyQt5.QtCore import QTimer
    from PyQt5.QtWidgets import QApplication as _QApp
    from license_dialog import guard_tick
    app._guard_timer = QTimer(app)
    app._guard_timer.timeout.connect(lambda: guard_tick(_QApp.activeWindow()))
    app._guard_timer.start(30 * 60 * 1000)

    sys.exit(app.exec_())