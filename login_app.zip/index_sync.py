# -*- coding: utf-8 -*-
"""فهرسة وثائق القضايا في الخلفية بعد كل حفظ في صفحة الوثائق.

مهم: الفهرسة ترسل نصوص الوثائق إلى خدمة الذكاء الاصطناعي، لذلك هي **معطّلة افتراضياً**
ولا تعمل إلا إذا فعّلها الخبير بنفسه (get/set_auto_index). يمكنه أيضاً فهرسة يدوية: schedule(force=True).
"""
import json
import os
import threading

_lock = threading.Lock()
_state = {"running": False, "dirty": False, "last": None, "error": ""}


def _cfg_path():
    import storage
    return os.path.join(storage.APP_DATA_DIR, "ai_settings.json")


def get_auto_index():
    try:
        with open(_cfg_path(), "r", encoding="utf-8") as f:
            return bool(json.load(f).get("auto_index", False))
    except Exception:
        return False


def set_auto_index(value):
    path = _cfg_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    try:
        with open(path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception:
        cfg = {}
    cfg["auto_index"] = bool(value)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False)


def _run():
    import rag_index
    while True:
        with _lock:
            _state["dirty"] = False
        try:
            report = rag_index.sync_case_documents()
            errs = [r.get("error", "") for _, r in report if r["status"] == "error"]
            _state["error"] = errs[0] if errs else ""
            _state["last"] = {"files": len(report), "errors": len(errs)}
        except Exception as e:                      # لا نُسقط البرنامج أبداً بسبب الفهرسة
            _state["error"] = str(e)
        with _lock:
            if not _state["dirty"]:
                _state["running"] = False
                return


def schedule(force=False):
    """استدعِه بعد حفظ الوثائق. يرجع True إن بدأت (أو ستُعاد) المزامنة."""
    if not force and not get_auto_index():
        return False
    with _lock:
        if _state["running"]:
            _state["dirty"] = True
            return True
        _state["running"] = True
    threading.Thread(target=_run, daemon=True).start()
    return True


def is_running():
    return _state["running"]


def status():
    return dict(_state)
