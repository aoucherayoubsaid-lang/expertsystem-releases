# -*- coding: utf-8 -*-
"""تحميل وحدات منطق العمل (المدرجة في packaging/bundle_modules.txt) من حزمة مشفّرة
(packaging\\bundle.bin → bundle.bin بجانب الـ exe)، بمفتاح يسلّمه خادم Cloudflare بعد التحقق
من الترخيص، ومُغلَّف (wrapped) خصيصاً لهذا الجهاز عبر تبادل مفاتيح X25519 (ECDH). تُنفَّذ
الوحدات من الذاكرة مباشرة (sys.meta_path + marshal.loads) بلا كتابة أي ملف .py أو .pyc وسيط
على القرص إطلاقاً.

طبقتان لرفع كلفة تفريغ الذاكرة:

1) **فك بالطلب، وحدة بوحدة، لا دفعة واحدة.** كل وحدة مشفّرة بمفتاحها الخاص المشتقّ من
   content_key (انظر tools/build_bundle.py)، وهذا الملف لا يفك إلا الوحدة التي يطلبها
   مُفسِّر بايثون في لحظة استيرادها الفعلية (lazy import، وكل وحدات هذا المشروع تُستورَد
   كسولاً أصلاً بعد تسجيل الدخول). تفريغ ذاكرة في لحظة واحدة لا يكشف إلا الشاشات التي
   فتحها المستخدم فعلاً حتى تلك اللحظة، لا الـ25 وحدة دفعة واحدة؛ لكشف كل الكود يحتاج
   المهاجم فتح كل شاشة وميزة في البرنامج وتفريغ الذاكرة عند كل واحدة على حدة.

2) **علامة مائية لكل زبون.** الخادم يرسل مع كل رد قيمة wm (اشتقاق من مفتاح الترخيص أو
   رمز الجهاز، لا يكشف أيّاً منهما بذاته) تُحقَن في كل وحدة بعد فكها كمتغيّر
   `__license_watermark__`. إن تسرّب كود مفكوك (من تفريغ ذاكرة أو غيره) تستطيع مطابقة هذه
   القيمة مع سجلّك عند الخادم (جدول bundle_devices) لمعرفة أي جهاز/ترخيص كان مصدره.

لماذا X25519 لا مجرد مطابقة رمز الجهاز: كل جهاز يولّد زوج مفاتيح X25519 عند أول تشغيل
ويُثبَّت مفتاحه العام عند الخادم. الخادم لا يرسل content_key مباشرة، بل مُغلَّفاً (AES-GCM)
بمفتاح يُشتقّ من تبادل Diffie-Hellman بين مفتاحه العام المثبَّت ومفتاح عابر (ephemeral)
يولّده الخادم مع كل طلب. فك هذا الغلاف يتطلب المفتاح الخاص المحلي الذي لا يغادر الجهاز
أبداً، فرد مُلتقَط على جهاز آخر عديم الفائدة رياضياً، لا بفحص برمجي يمكن تجاوزه بترقيع الكود.

شرط هذا الادّعاء: أن يبقى المفتاح الخاص غير قابل للنسخ. لذلك يُحفظ ملف .es_dk مغلَّفاً بـ DPAPI على
ويندوز (local_protect.protect)، فنسخه إلى جهاز أو حساب ويندوز آخر لا يُفك هناك، ويولّد ذلك الجهاز زوجاً
جديداً ويُسجَّل جهازاً جديداً عند الخادم (فيظهر في مراقبة bundle_devices). خارج ويندوز (تطوير فقط)
يبقى الملف نصاً عادياً بصلاحية 600 ولا ينطبق الادّعاء. ومن يملك حساب ويندوز نفسه يستطيع استدعاء DPAPI.

الترتيب الإلزامي: استدعِ unlock() بعد نجاح license_dialog.startup_check() وقبل أي استيراد
لوحدة من BUNDLE_MODULES من أي مكان في البرنامج (نقطة الاستدعاء هنا: __main__ في
login_app.py مباشرة بعد startup_check()).

حدود هذا الملف (اقرأها قبل الاعتماد عليه): content_key يبقى في ذاكرة العملية طوال مدة
التشغيل (ضروري لفك أي وحدة تُستورَد لاحقاً)، ومحفوظ داخل هذا الملف نفسه الذي يُجمَّع إلى
.pyd بـ Nuitka (انظر tools/protect_build.py)، فلا يظهر كمتغيّر بايثون عادي قابل للقراءة
المباشرة عبر أدوات فحص كائنات بايثون، لكنه يبقى فعلياً في ذاكرة العملية الخام ولا يمكن
إخفاؤه عن تفريغ ذاكرة كامل للعملية. هذا لا يمنع مشتركاً شرعياً من تفريغ الذاكرة أثناء
التشغيل الفعلي؛ يمنع فقط الوصول من القرص ومن أي جهاز آخر، ويجبر من يريد كل الكود على تفريغ
الذاكرة مرات متكررة بدل مرة واحدة. انظر packaging/PROTECTION_AR.md لبقية الطبقات
(hardening.py، Nuitka لوحدات الترخيص، المراقبة السلوكية في الخادم).
"""
import base64
import hashlib
import hmac
import importlib.abc
import importlib.util
import io
import json
import marshal
import os
import sys
import urllib.error
import urllib.request
import zipfile

import ed25519_verify
import local_protect
from app_paths import app_base_dir

BUNDLE_URL = "https://expert-bundle.aoucher-ayoubsaid.workers.dev"   # رابط Worker الحزمة بدون / في الآخر
BUNDLE_PUBLIC_B64 = "cLH8HXqUQgmMG67NGklfRpAb8ZmlM0xhBWG4rEVr4FY="                        # من tools/bundle_keygen.py (المفتاح العام فقط)
BUNDLE_FILE = "bundle.bin"
_KEYPAIR_FILE = ".es_dk"           # المفتاح الخاص لهذا الجهاز (X25519)، محلي فقط، لا يغادره أبداً

_STATE = {"unlocked": False, "watermark": ""}


def is_configured():
    return "YOUR-BUNDLE" not in BUNDLE_URL and not BUNDLE_PUBLIC_B64.startswith("PASTE")


def is_unlocked():
    return _STATE["unlocked"]


def watermark():
    """العلامة المائية التي أرسلها الخادم لهذا الجهاز/الترخيص (نص فارغ إن لم تُفتَح الحزمة)."""
    return _STATE["watermark"]


def _bundle_path():
    base = os.path.dirname(os.path.abspath(sys.executable)) if getattr(sys, "frozen", False) \
        else os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, BUNDLE_FILE)


def _ssl_context():
    try:
        import certifi
        import ssl
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        import ssl
        return ssl.create_default_context()


# ----------------------------------------------------------------------
# زوج مفاتيح الجهاز (X25519): يُولَّد مرة واحدة ويبقى محلياً دوماً
# ----------------------------------------------------------------------
def _keypair_path():
    import app_paths
    return os.path.join(app_paths.machine_dir(), _KEYPAIR_FILE)      # خاص بالجهاز: لا يُشارَك أبداً


def _write_keypair_file(path, raw):
    """يكتب المفتاح الخاص محميّاً بـ DPAPI على ويندوز (مرتبط بحساب ويندوز والجهاز)؛
    خارج ويندوز يبقى base64 بصلاحية 600 (بيئة تطوير فقط)."""
    blob = local_protect.protect(raw)
    if blob is None:
        blob = base64.b64encode(raw)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(blob)
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    os.replace(tmp, path)


def _load_or_create_keypair():
    from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
    from cryptography.hazmat.primitives import serialization
    path = _keypair_path()
    try:
        with open(path, "rb") as f:
            blob = f.read().strip()
        if local_protect.is_protected_blob(blob):
            raw = local_protect.unprotect(blob)       # يفشل إن نُسخ الملف لجهاز/حساب آخر
        else:
            raw = base64.b64decode(blob)              # نسخة قديمة غير محمية
            if len(raw) == 32 and local_protect.dpapi_available():
                try:
                    _write_keypair_file(path, raw)    # ترحيل تلقائي إلى صيغة DPAPI
                except Exception:
                    pass
        if len(raw) == 32:
            return X25519PrivateKey.from_private_bytes(raw)
    except Exception:
        pass
    # لا ملف، أو تالف، أو من جهاز آخر (غير قابل للفك): نولّد زوجاً جديداً لهذا الجهاز
    sk = X25519PrivateKey.generate()
    raw = sk.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw,
                           serialization.NoEncryption())
    try:
        _write_keypair_file(path, raw)
    except Exception:
        pass            # تعذّر الحفظ: سيُعاد توليد زوج جديد في المرة القادمة (يُعيد التثبيت عند الخادم)
    return sk


def _public_key_b64(sk):
    from cryptography.hazmat.primitives import serialization
    pub = sk.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return base64.b64encode(pub).decode("ascii")


# ----------------------------------------------------------------------
# طلب مفتاح الحزمة (مُغلَّف خصيصاً لهذا الجهاز) من الخادم
# ----------------------------------------------------------------------
def _fetch_wrapped_key(machine, license_key, version, device_pub_b64):
    nonce = os.urandom(16).hex()
    body = {"machine_id": machine, "key": license_key or "", "version": version,
            "nonce": nonce, "pubkey": device_pub_b64}
    req = urllib.request.Request(
        BUNDLE_URL.rstrip("/") + "/bundle", data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json", "User-Agent": "ExpertSystem/" + version})
    try:
        with urllib.request.urlopen(req, timeout=10, context=_ssl_context()) as r:
            resp = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            return None, json.loads(e.read().decode("utf-8")).get("error", "bad")
        except Exception:
            return None, "bad"
    except Exception:
        return None, "offline"
    try:
        pub = base64.b64decode(BUNDLE_PUBLIC_B64)
        if not ed25519_verify.verify(pub, resp["data"].encode("utf-8"), base64.b64decode(resp["sig"])):
            return None, "bad_signature"
        d = json.loads(resp["data"])
        if d.get("t") != "bundle" or d.get("m") != machine or d.get("n") != nonce or d.get("v") != version:
            return None, "bad_response"
        return d, None
    except Exception:
        return None, "bad_response"


def _unwrap_content_key(d, device_sk, version):
    """يحسب سر ECDH مع المفتاح العابر للخادم، يشتق منه مفتاح تغليف، ويفك به content_key."""
    from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PublicKey
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    server_ephemeral_pub = X25519PublicKey.from_public_bytes(base64.b64decode(d["ek"]))
    shared = device_sk.exchange(server_ephemeral_pub)
    kek = hmac.new(shared, b"ExpertSystem-bundle-wrap-v1", hashlib.sha256).digest()
    wn = base64.b64decode(d["wn"])
    wk = base64.b64decode(d["wk"])
    aad = ("ExpertSystem-bundle|" + version).encode("utf-8")
    return AESGCM(kek).decrypt(wn, wk, aad)


def _module_key(content_key, name):
    """نفس حساب tools/build_bundle.py بالضبط: مفتاح مستقل لكل وحدة."""
    return hmac.new(content_key, ("module|" + name).encode("utf-8"), hashlib.sha256).digest()


# ----------------------------------------------------------------------
# مستورِد يفك كل وحدة عند طلبها فقط (lazy)؛ لا يُفك شيء دفعة واحدة، ولا يُكتب شيء على القرص
# ----------------------------------------------------------------------
class _BundleImporter(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    def __init__(self, zip_bytes, content_key, version, wm):
        self._zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
        self._names = set(n[:-4] for n in self._zf.namelist() if n.endswith(".enc"))
        self._content_key = content_key
        self._version = version
        self._wm = wm

    def find_spec(self, name, path, target=None):
        if name not in self._names:
            return None
        return importlib.util.spec_from_loader(name, self, origin="<bundle:%s>" % name)

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        name = module.__name__
        blob = self._zf.read(name + ".enc")
        nonce, ct = blob[:12], blob[12:]
        mkey = _module_key(self._content_key, name)
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        aad = ("ExpertSystem-bundle|" + self._version + "|" + name).encode("utf-8")
        plain = AESGCM(mkey).decrypt(nonce, ct, aad)   # تُفَك هذه الوحدة فقط، الآن، لا غيرها
        code = marshal.loads(plain)
        module.__license_watermark__ = self._wm
        exec(code, module.__dict__)
        plain = code = None   # إسقاط المرجع فور التنفيذ (لا يضمن محو الذاكرة فوراً، لكن يقلّل بقاءه)


def unlock(machine, license_key, version):
    """يفتح الحزمة ويسجّل مستورِداً كسولاً في sys.meta_path. يرجع (نجح؟، رسالة). استدعِه مرة
    واحدة فقط، بعد ترخيص صالح وقبل أي استيراد لوحدة من BUNDLE_MODULES."""
    if _STATE["unlocked"]:
        return True, ""
    if not is_configured():
        return True, "unconfigured"     # وضع التطوير بلا حزمة: الاستيراد العادي من ملفات .py يعمل
    path = _bundle_path()
    if not os.path.isfile(path):
        return False, "bundle_missing"

    device_sk = _load_or_create_keypair()
    d, err = _fetch_wrapped_key(machine, license_key, version, _public_key_b64(device_sk))
    if d is None:
        return False, err or "offline"

    try:
        content_key = _unwrap_content_key(d, device_sk, version)
    except Exception:
        return False, "unwrap_failed"
    device_sk = None

    with open(path, "rb") as f:
        zip_bytes = f.read()
    try:
        importer = _BundleImporter(zip_bytes, content_key, version, str(d.get("wm") or ""))
    except Exception:
        return False, "bad_bundle"

    sys.meta_path.insert(0, importer)
    _STATE["unlocked"] = True
    _STATE["watermark"] = importer._wm
    return True, ""
