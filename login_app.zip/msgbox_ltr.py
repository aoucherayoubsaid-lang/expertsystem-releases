# -*- coding: utf-8 -*-
"""نوافذ رسائل (QMessageBox) بديلة لدوال Qt الجاهزة (information/warning/...).

مشكلة 1: عندما تُستدعى QMessageBox.information(self, ...) من نافذة اتجاهها
RightToLeft، يعكس Qt أيضاً موضع الأزرار (Mirroring) فيضعها في أقصى اليسار.
الحل: إنشاء صندوق الرسالة يدوياً، وإجباره على اتجاه LeftToRight من أجل موضع
الأزرار فقط (فيبقى الزر في أقصى اليمين كما هو مألوف).

مشكلة 2: نص الرسالة غالباً يخلط سطراً عربياً (مثل "تم إنشاء التقرير:") مع
سطر آخر لاتيني بالكامل (مسار ملف مثل D:\\...\\report.pdf). محاذاة الكتلة
كلها لليمين كخيار واحد تجعل حتى المسار اللاتيني يظهر ملتصقاً باليمين، وهو
غير مقروء/غير مألوف لمحتوى لاتيني (يجب أن يبدأ من أقصى اليسار).

الحل: كل سطر من النص يُفحَص على حدة (هل يحتوي حرفاً عربياً أم لا)، ويُغلَّف
بوسم HTML <div dir="rtl"|"ltr"> يفرض عليه اتجاهه ومحاذاته الخاصة به، بغض
النظر عن باقي الأسطر. فيظهر السطر العربي من اليمين، والسطر اللاتيني (مسار/
رقم/نص فرنسي) من اليسار، كل حسب لغته الفعلية.

الاستعمال: بدّل فقط سطر الاستيراد:
    from PyQt5.QtWidgets import QMessageBox
    QMessageBox.information(self, "تم", "...")
إلى:
    from msgbox_ltr import show_info
    show_info(self, "تم", "...")
(ونظائرها: show_warning, show_critical, show_question)
"""
import re
import html as _html

from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtCore import Qt

_ARABIC_RE = re.compile(r'[\u0600-\u06FF\u0750-\u077F]')


def _format_mixed_direction_text(text):
    """يغلّف كل سطر من النص بوسم HTML يفرض اتجاهه الخاص (RTL للعربية،
    LTR لأي سطر آخر لا يحتوي حرفاً عربياً إطلاقاً، كمسارات الملفات
    والأرقام والنصوص الفرنسية/الإنجليزية)."""
    lines = text.split("\n")
    parts = []
    for line in lines:
        stripped = line.strip()
        if not stripped:
            parts.append("<div>&nbsp;</div>")
            continue
        escaped = _html.escape(stripped)
        if _ARABIC_RE.search(stripped):
            parts.append(f'<div dir="rtl" style="text-align:right;">{escaped}</div>')
        else:
            parts.append(f'<div dir="ltr" style="text-align:left;">{escaped}</div>')
    return "".join(parts)


def _build_box(parent, title, text, icon):
    box = QMessageBox(parent)
    box.setWindowTitle(title)
    box.setText(_format_mixed_direction_text(text))
    box.setIcon(icon)
    # اتجاه LeftToRight خاص بصندوق الحوار نفسه فقط، ليبقى الزر على اليمين
    # بصرياً (الشكل المعتاد)، بغض النظر عن اتجاه النافذة الأصلية المستدعية.
    # اتجاه كل سطر نفسه يُضبَط بالفعل عبر وسم <div dir="..."> أعلاه.
    box.setLayoutDirection(Qt.LeftToRight)
    return box


def show_info(parent, title, text):
    box = _build_box(parent, title, text, QMessageBox.Information)
    box.setStandardButtons(QMessageBox.Ok)
    return box.exec_()


def show_warning(parent, title, text):
    box = _build_box(parent, title, text, QMessageBox.Warning)
    box.setStandardButtons(QMessageBox.Ok)
    return box.exec_()


def show_critical(parent, title, text):
    box = _build_box(parent, title, text, QMessageBox.Critical)
    box.setStandardButtons(QMessageBox.Ok)
    return box.exec_()


def show_question(parent, title, text, default_yes=False):
    box = _build_box(parent, title, text, QMessageBox.Question)
    box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
    box.setDefaultButton(QMessageBox.Yes if default_yes else QMessageBox.No)
    return box.exec_()

def show_confirm(parent, title, text, danger=False, yes_text=None, no_text=None):
    """تأكيد موحّد يُرجع True/False. danger=True يُلوّن زر التأكيد بالأحمر (للحذف ونحوه)
    ويجعل الافتراضي \"لا\" دائماً لتفادي الحذف بضغطة Enter خاطئة."""
    box = _build_box(parent, title, text, QMessageBox.Warning if danger else QMessageBox.Question)
    box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
    box.setDefaultButton(QMessageBox.No)
    if yes_text:
        box.button(QMessageBox.Yes).setText(yes_text)
    if no_text:
        box.button(QMessageBox.No).setText(no_text)
    if danger:
        from modern_theme import style_button
        style_button(box.button(QMessageBox.Yes), "danger")
    return box.exec_() == QMessageBox.Yes
