# -*- coding: utf-8 -*-
"""الاتصال بخادم الترخيص (Cloudflare Worker): التجربة المجانية + تفعيل/تجديد مفتاح الاشتراك.
كل رد موقَّع بـ Ed25519 بمفتاح الخادم الخاص ومربوط بجهاز واحد وبقيمة عشوائية (nonce)،
فلا يمكن تزويره ولا إعادة استعماله. التحقق بلغة بايثون الصرفة (يعمل على ويندوز 7)."""
import base64
import json
import os
import ssl
import urllib.error
import urllib.request
from datetime import date, datetime, timedelta, timezone

import ed25519_verify

SERVER_URL = "https://expert-license.aoucher-ayoubsaid.workers.dev"      # رابط الـ Worker بدون / في الآخر
SERVER_PUBLIC_B64 = "rU37WnDOCmWqxNGLsS7SkCXJjCihlJ3e4eCiOpSoBtU="            # سطر PUBLIC من الخطوة 7 (المفتاح العام فقط)
TRIAL_DAYS_SERVER = 30                                 # يجب أن يطابق مدة التجربة في worker.js


def _ssl_context():
    """شهادات certifi المرفقة بدل مخزن ويندوز: ويندوز 7 القديم قد تنقصه الشهادات الجذرية الحديثة."""
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def is_configured():
    return "YOUR-SUBDOMAIN" not in SERVER_URL and not SERVER_PUBLIC_B64.startswith("PASTE")


def _post(path, body, timeout=8):
    """يرجع (http_status, dict) أو (None, None) عند انقطاع الاتصال."""
    req = urllib.request.Request(
        SERVER_URL.rstrip("/") + path,
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json", "User-Agent": "ExpertSystem/1.0"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl_context()) as r:
            return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode("utf-8"))
        except Exception:
            return e.code, {}
    except Exception:
        return None, None


def _parse_time(s):
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


def verify_resp(resp, machine, nonce=None):
    """يتحقق من توقيع الخادم ومن أن الرد لهذا الجهاز (ولنفس الـ nonce إن مُرِّر). يرجع dict أو None."""
    try:
        pub = base64.b64decode(SERVER_PUBLIC_B64)
        if not ed25519_verify.verify(pub, resp["data"].encode("utf-8"), base64.b64decode(resp["sig"])):
            return None
        d = json.loads(resp["data"])
        if d.get("m") != machine:
            return None
        if nonce is not None and d.get("n") != nonce:
            return None
        return d
    except Exception:
        return None


def _ask(path, body, machine):
    """يرسل طلبًا ويتحقق من الرد. يرجع (status, dict_data, resp_raw)
    status: 'ok' | 'offline' | 'bad' (رد غير موقَّع/مزوَّر) | رمز خطأ الخادم ('invalid','expired','other_device'...)"""
    nonce = os.urandom(16).hex()
    body = dict(body, nonce=nonce)
    code, resp = _post(path, body)
    if code is None:
        return "offline", None, None
    if code != 200:
        return (resp or {}).get("error", "bad"), None, None
    d = verify_resp(resp, machine, nonce)
    if d is None:
        return "bad", None, None
    return "ok", d, resp


def fetch_trial_start(machine):
    """تاريخ أول ظهور لهذا الجهاز عند الخادم (date)، أو None إن تعذّر الاتصال/التحقق."""
    st, d, _ = _ask("/trial", {"machine_id": machine}, machine)
    if st != "ok" or d.get("t") != "trial":
        return None
    try:
        return (_parse_time(d["exp"]) - timedelta(days=TRIAL_DAYS_SERVER)).date()
    except Exception:
        return None


def activate_online(key, machine):
    """يرجع (status, dict_data, resp_raw) — انظر _ask. النجاح يتطلب t == 'license'."""
    try:                              # بصمة العتاد: يربط الخادم الاشتراك بالعتاد لا بـ MachineGuid وحده
        import device_fingerprint
        comps = device_fingerprint.collect()
    except Exception:
        comps = {}
    st, d, resp = _ask("/activate", {"key": key, "machine_id": machine, "comps": comps}, machine)
    if st == "ok" and d.get("t") != "license":
        return "bad", None, None
    return st, d, resp


def server_clock_ok(d, max_skew_days=2):
    """هل ساعة الجهاز قريبة من وقت الخادم وقت إصدار الرد؟ (كشف تزوير التاريخ عند التحقق)"""
    try:
        iat = _parse_time(d["iat"])
        return abs(datetime.now(timezone.utc) - iat) <= timedelta(days=max_skew_days)
    except Exception:
        return False
