# -*- coding: utf-8 -*-
"""معلومات التطبيق والمطوّر في مكان واحد (غيّر هنا فقط وتتحدث كل النوافذ)."""

APP_NAME_AR = "نظام إدارة أعمال الخبير القضائي"
APP_NAME_EN = "Expert System"
APP_VERSION = "1.0.0"

DEVELOPER_NAME = "أيوب سعيد أوشر"
DEVELOPER_EMAIL = "aoucher.ayoubsaid@gmail.com"
DEVELOPER_PHONE = "0674841338"
# رقم واتساب بالصيغة الدولية بدون + أو أصفار (الجزائر 213)
DEVELOPER_WHATSAPP = "213674841338"

# أدلة الاستخدام (PDF) بجانب البرنامج. يظهر في «مساعدة ← دليل الاستخدام» كل لغة
# يوجد ملفها فقط. (رمز اللغة، الاسم الظاهر، أسماء الملف المقبولة بالترتيب)
USER_GUIDES = [
    ("ar", "العربية", ("UserGuide_AR.pdf", "UserGuide.pdf", "دليل_الاستخدام.pdf")),
    ("fr", "Français", ("Guide_Utilisateur_FR.pdf", "UserGuide_FR.pdf")),
    ("en", "English", ("User_Guide_EN.pdf", "UserGuide_EN.pdf")),
]
