# -*- coding: utf-8 -*-
"""تحقق توقيع Ed25519 بلغة بايثون الصرفة (RFC 8032) — بلا أي مكتبة خارجية،
فيعمل على Windows 7 وفي ملف exe بدون مشاكل DLL. للتحقق فقط؛ التوقيع يتم في
أداة tools/keygen.py عند المطوّر."""
import hashlib

_p = 2 ** 255 - 19
_q = 2 ** 252 + 27742317777372353535851937790883648493
_d = -121665 * pow(121666, _p - 2, _p) % _p
_I = pow(2, (_p - 1) // 4, _p)


def _H(m):
    return hashlib.sha512(m).digest()


def _inv(x):
    return pow(x, _p - 2, _p)


def _xrecover(y):
    xx = (y * y - 1) * _inv(_d * y * y + 1)
    x = pow(xx, (_p + 3) // 8, _p)
    if (x * x - xx) % _p != 0:
        x = (x * _I) % _p
    if x % 2 != 0:
        x = _p - x
    return x


_By = 4 * _inv(5) % _p
_Bx = _xrecover(_By)
_B = (_Bx % _p, _By % _p, 1, (_Bx * _By) % _p)


def _add(P, Q):
    A = (P[1] - P[0]) * (Q[1] - Q[0]) % _p
    B = (P[1] + P[0]) * (Q[1] + Q[0]) % _p
    C = 2 * P[3] * Q[3] * _d % _p
    D = 2 * P[2] * Q[2] % _p
    E, F, G, Hh = B - A, D - C, D + C, B + A
    return (E * F % _p, G * Hh % _p, F * G % _p, E * Hh % _p)


def _mul(s, P):
    Q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            Q = _add(Q, P)
        P = _add(P, P)
        s >>= 1
    return Q


def _equal(P, Q):
    if (P[0] * Q[2] - Q[0] * P[2]) % _p != 0:
        return False
    return (P[1] * Q[2] - Q[1] * P[2]) % _p == 0


def _decompress(s):
    if len(s) != 32:
        raise ValueError("bad length")
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _xrecover(y)
    if (x & 1) != sign:
        x = _p - x
    P = (x, y, 1, (x * y) % _p)
    return P


def verify(public_key: bytes, message: bytes, signature: bytes) -> bool:
    """True فقط إذا كان التوقيع صحيحاً لهذه الرسالة وهذا المفتاح العام."""
    try:
        if len(public_key) != 32 or len(signature) != 64:
            return False
        A = _decompress(public_key)
        R = _decompress(signature[:32])
        S = int.from_bytes(signature[32:], "little")
        if S >= _q:
            return False
        h = int.from_bytes(_H(signature[:32] + public_key + message), "little") % _q
        return _equal(_mul(S, _B), _add(R, _mul(h, A)))
    except Exception:
        return False
