# -*- coding: utf-8 -*-
"""قفل الكتابة للمجلد المشترك (يعمل فقط في وضع shared).

الفكرة: جهاز واحد فقط «يكتب» في كل لحظة، وبقية الأجهزة تفتح البيانات للقراءة فقط. هذا يمنع
فساد الملفات وضياع التعديلات حين يعمل أكثر من جهاز على المجلد نفسه.

الآلية: ملف عقد (.writer.lease) في app_data المشترك يحمل هوية الجهاز، وخيط نبض يجدّد وقته كل 20 ثانية.
العقد يُعدّ منتهياً إن مرّت 90 ثانية بلا تجديد (انهيار البرنامج أو انقطاع الجهاز)، فيستولي عليه جهاز آخر.
الوقت يُقاس بساعة الخادم الذي يحمل المجلد (وقت تعديل الملفات) لا بساعات الأجهزة، فلا يضرّ اختلاف ساعاتها.

حدود صريحة: هذا قفل تعاوني مبني على ملفات؛ على مشاركات SMB الاعتيادية يفي بالغرض لكنه ليس ضماناً
مطلقاً كقفل قاعدة بيانات خادم. وضع القراءة فقط يُطبَّق في مسار الحفظ المركزي (storage._write_json).
"""
import json
import os
import platform
import secrets
import threading
import time

import app_paths

LEASE_NAME = ".writer.lease"
HEARTBEAT_SECONDS = 20
STALE_SECONDS = 90

_state = {"role": "writer", "token": None, "holder": None, "thread": None, "stop": None}


def _lease_path():
    return os.path.join(app_paths.shared_app_data_dir(), LEASE_NAME)


def _me():
    try:
        user = os.environ.get("USERNAME") or os.environ.get("USER") or ""
    except Exception:
        user = ""
    return {"host": platform.node(), "user": user, "pid": os.getpid()}


def _server_now(folder):
    """ساعة الخادم الحاملة للمجلد: وقت تعديل ملف نكتبه الآن."""
    probe = os.path.join(folder, ".clock_probe_" + secrets.token_hex(4))
    try:
        with open(probe, "w") as f:
            f.write("x")
        return os.path.getmtime(probe)
    finally:
        try:
            os.remove(probe)
        except OSError:
            pass


def _read_lease():
    try:
        with open(_lease_path(), "r", encoding="utf-8") as f:
            d = json.load(f)
        d["_mtime"] = os.path.getmtime(_lease_path())
        return d
    except (OSError, ValueError):
        return None


def _write_lease(token):
    d = dict(_me(), token=token)
    tmp = _lease_path() + "." + secrets.token_hex(3) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, _lease_path())


def _is_stale(lease):
    folder = os.path.dirname(_lease_path())
    try:
        return (_server_now(folder) - lease["_mtime"]) > STALE_SECONDS
    except OSError:
        return False        # لا نستولي على عقد لا نستطيع قياس عمره


def acquire():
    """يحاول أن يصير الجهاز «كاتباً». يرجع {"role": "writer"|"reader", "holder": {...}|None}.

    خارج وضع shared يرجع writer دائماً بلا أي ملفات."""
    if app_paths.data_mode() != "shared":
        _state.update(role="writer", holder=None)
        return {"role": "writer", "holder": None}
    os.makedirs(os.path.dirname(_lease_path()), exist_ok=True)
    token = secrets.token_hex(8)
    for _ in range(3):
        lease = _read_lease()
        if lease is None or _is_stale(lease):
            _write_lease(token)
            time.sleep(0.4)                        # يمنح منافساً متزامناً فرصة لكتابة عقده فنرى الفائز الحقيقي
            now = _read_lease()
            if now and now.get("token") == token:
                _state.update(role="writer", token=token, holder=None)
                _start_heartbeat()
                return {"role": "writer", "holder": None}
            continue
        if lease.get("token") == _state.get("token"):
            _state.update(role="writer")
            return {"role": "writer", "holder": None}
        break
    holder = _read_lease()
    _state.update(role="reader", token=None, holder=holder)
    return {"role": "reader", "holder": holder}


def _start_heartbeat():
    stop = threading.Event()
    _state["stop"] = stop

    def run():
        while not stop.wait(HEARTBEAT_SECONDS):
            try:
                lease = _read_lease()
                if lease is None or lease.get("token") != _state["token"]:
                    if lease is None or _is_stale(lease):
                        _write_lease(_state["token"])
                        continue
                    _state["role"] = "reader"            # فقدنا العقد (استولى عليه جهاز آخر)
                    _state["holder"] = lease
                    return
                _write_lease(_state["token"])
            except OSError:
                pass                                       # انقطاع شبكة مؤقت: نحاول في النبضة التالية

    t = threading.Thread(target=run, name="writer-lease", daemon=True)
    _state["thread"] = t
    t.start()


def release():
    stop = _state.get("stop")
    if stop:
        stop.set()
    if app_paths.data_mode() == "shared" and _state.get("token"):
        try:
            lease = _read_lease()
            if lease and lease.get("token") == _state["token"]:
                os.remove(_lease_path())
        except OSError:
            pass
    _state.update(role="writer", token=None, holder=None, stop=None, thread=None)


def is_read_only():
    """صحيح إن كانت البيانات مشتركة وجهاز آخر هو الكاتب. يُفحص عند كل حفظ."""
    if app_paths.data_mode() != "shared":
        return False
    if _state["role"] != "writer":
        return True
    # لو فُقد العقد بين نبضتين لا نكتب
    lease = _read_lease()
    return not (lease and lease.get("token") == _state["token"])


def holder_text():
    h = _state.get("holder") or {}
    if not h:
        return ""
    return "%s (%s)" % (h.get("host", "?"), h.get("user", "?"))
