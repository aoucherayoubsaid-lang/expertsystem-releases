# -*- coding: utf-8 -*-
"""شاشة «تدقيق الوثائق وتأكيد المبالغ».

لكل وثيقة مالية في القضية: الأرقام التي استخرجها البرنامج، ونتيجة الفحص الحسابي، وخلاف قراءتَي الصورة إن وُجد.
الخبير يفتح الوثيقة الأصلية بزر واحد، ويقارن، ثم يؤكّد كل رقم أو يصحّحه. المؤكَّد يصبح أقوى دليل في التحقق،
والمصحَّح يُعاد فحصه حسابياً فوراً (مع حفظ القيمة المقروءة الأصلية).
"""
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import (
    QAbstractItemView, QDialog, QHBoxLayout, QHeaderView, QLabel, QListWidget, QListWidgetItem, QSplitter,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

import theme_tokens as T
from msgbox_ltr import show_info, show_warning
from ai_report_page import _section_head, make_button, muted

COL_FIELD, COL_VALUE, COL_STATE, COL_OK = 0, 1, 2, 3


def _plain(x):
    return str(int(round(x))) if abs(x - round(x)) < 1e-9 else "%.2f" % x


class AuditDialog(QDialog):
    def __init__(self, case_number, parent=None):
        super().__init__(parent)
        self.case_number = str(case_number)
        self._key = None
        self._loading = False
        self._orig = {}                       # مسار الحقل -> القيمة المقروءة عند عرض الوثيقة
        self.setWindowTitle("تدقيق الوثائق وتأكيد المبالغ — قضية %s" % self.case_number)
        self.setLayoutDirection(Qt.RightToLeft)
        self.setMinimumSize(1020, 640)
        self.resize(1180, 740)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 18, 24, 16)
        lay.setSpacing(10)
        lay.addWidget(_section_head("تدقيق الوثائق وتأكيد المبالغ", "fa5s.file-invoice-dollar", 1.4))
        lay.addWidget(muted(
            "اختر وثيقة، افتح أصلها وقارن كل رقم بما هو مطبوع فيها، ثم علّم «تأكيد» على ما صحّ وصحّح ما أخطأت قراءته "
            "(عدّل القيمة في العمود الثاني ثم علّم تأكيد). الأرقام المؤكَّدة هي التي يثق بها البرنامج في التقرير، "
            "وكل تصحيح يُعاد فحصه حسابياً في الحال."))

        split = QSplitter(Qt.Horizontal)
        self.docs = QListWidget()
        self.docs.setMinimumWidth(280)
        self.docs.currentRowChanged.connect(self._on_doc)
        split.addWidget(self.docs)

        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(0, 0, 0, 0)
        rl.setSpacing(8)
        self.issues = QLabel("")
        self.issues.setWordWrap(True)
        self.issues.setTextFormat(Qt.RichText)
        self.issues.setStyleSheet("background:%s; border:1px solid %s; border-radius:10px; padding:10px 14px;"
                                  % (T.TINT_AMBER, T.BORDER))
        rl.addWidget(self.issues)
        self.tbl = QTableWidget(0, 4)
        self.tbl.setHorizontalHeaderLabels(["الحقل", "القيمة المقروءة (قابلة للتعديل)", "الحالة", "تأكيد"])
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setAlternatingRowColors(True)
        self.tbl.setWordWrap(True)
        self.tbl.setEditTriggers(QAbstractItemView.DoubleClicked | QAbstractItemView.EditKeyPressed |
                                 QAbstractItemView.AnyKeyPressed)
        self.tbl.setStyleSheet("QTableWidget::item { padding: 6px 10px; }")
        hh = self.tbl.horizontalHeader()
        hh.setSectionResizeMode(COL_FIELD, QHeaderView.Stretch)
        hh.setSectionResizeMode(COL_VALUE, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(COL_STATE, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(COL_OK, QHeaderView.ResizeToContents)
        self.tbl.itemChanged.connect(self._on_item_changed)
        rl.addWidget(self.tbl, 1)
        split.addWidget(right)
        split.setStretchFactor(0, 0)
        split.setStretchFactor(1, 1)
        lay.addWidget(split, 1)

        bar = QHBoxLayout()
        bar.setSpacing(10)
        b_open = make_button("فتح الوثيقة الأصلية", "info", "fa5s.external-link-alt", soft=True)
        b_all = make_button("تأكيد كل أرقام الوثيقة كما هي", "secondary", "fa5s.check-double", soft=True)
        b_save = make_button("حفظ التأكيد والتصحيحات", "success", "fa5s.save")
        b_close = make_button("إغلاق", "primary")
        b_open.clicked.connect(self._open_original)
        b_all.clicked.connect(self._check_all)
        b_save.clicked.connect(self._save)
        b_close.clicked.connect(self.accept)
        bar.addWidget(b_open)
        bar.addWidget(b_all)
        bar.addStretch(1)
        bar.addWidget(b_save)
        bar.addWidget(b_close)
        lay.addLayout(bar)
        self._reload(select=0)

    # ------------------------------------------------------------------ تحميل
    def _reload(self, select=None):
        import doc_audit
        self._data = doc_audit.load(self.case_number)
        keep = self._key
        entries = sorted(self._data["docs"].items(), key=lambda kv: kv[1]["title"])
        self._keys = [k for k, _v in entries]
        self.docs.blockSignals(True)
        self.docs.clear()
        for k, v in entries:
            errs = sum(1 for i in v.get("issues", []) if i["sev"] == "error")
            warns = sum(1 for i in v.get("issues", []) if i["sev"] == "warn")
            conf = len(v.get("confirmed", {}))
            total = len(doc_audit.doc_fields(v["doc"]))
            mark = "❌ " if errs else ("⚠ " if warns else "✔ ")
            it = QListWidgetItem("%s%s\n   مؤكَّد %d من %d%s" % (
                mark, v["title"], conf, total, ("   |   أخطاء %d" % errs) if errs else ""))
            it.setForeground(QColor(T.DANGER if errs else (T.WARNING if warns else T.SUCCESS)))
            self.docs.addItem(it)
        if not entries:
            self.docs.blockSignals(False)
            self.issues.setText("لا توجد وثائق مالية مدقَّقة بعد. افتح تبويب «المراجعة والتحقق» واضغط «تدقيق الوثائق».")
            self.tbl.setRowCount(0)
            return
        row = self._keys.index(keep) if keep in self._keys else (select or 0)
        self.docs.setCurrentRow(row)
        self.docs.blockSignals(False)
        self._on_doc(row)

    def _on_doc(self, row):
        if row < 0 or row >= len(self._keys):
            return
        import doc_audit
        self._key = self._keys[row]
        v = self._data["docs"][self._key]
        doc, conf = v["doc"], v.get("confirmed", {})
        flagged = set()
        lines = []
        for it in v.get("issues", []):
            icon = "❌" if it["sev"] == "error" else "⚠"
            lines.append("%s %s" % (icon, it["msg"]))
            if it["sev"] == "error":
                flagged.update(it["fields"])
        d = doc
        head = "<b>%s</b> — النوع: %s | الرقم: %s | التاريخ: %s | العملة: %s" % (
            v["title"], d.get("doc_type") or "-", d.get("number") or "-", d.get("date") or "-", d.get("currency") or "-")
        body = "<br>".join(lines) if lines else "✔ الفحص الحسابي سليم."
        self.issues.setText(head + "<br>" + body)
        self.issues.setStyleSheet("background:%s; border:1px solid %s; border-radius:10px; padding:10px 14px;" % (
            T.TINT_ROSE if any(i["sev"] == "error" for i in v.get("issues", [])) else T.TINT_GREEN, T.BORDER))

        fields = doc_audit.doc_fields(doc)
        self._loading = True
        self._orig = {}
        self.tbl.setRowCount(len(fields))
        for r, (path, label, val) in enumerate(fields):
            self._orig[path] = val
            a = QTableWidgetItem(label)
            a.setFlags(Qt.ItemIsEnabled)
            a.setData(Qt.UserRole, path)
            b = QTableWidgetItem(_plain(val))
            b.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
            if path in v.get("original", {}):
                b.setToolTip("القيمة المقروءة أصلاً: %s" % _plain(v["original"][path]))
            c = QTableWidgetItem("")
            c.setFlags(Qt.ItemIsEnabled)
            d_ = QTableWidgetItem("")
            d_.setFlags(Qt.ItemIsEnabled | Qt.ItemIsUserCheckable)
            d_.setCheckState(Qt.Checked if path in conf else Qt.Unchecked)
            for col, it in enumerate((a, b, c, d_)):
                self.tbl.setItem(r, col, it)
            self._paint(r, path in conf, path in flagged, path in v.get("original", {}))
        self._loading = False
        self.tbl.resizeRowsToContents()

    def _paint(self, r, confirmed, flagged, corrected):
        if corrected:
            text, bg = "مصحَّح بيدك", T.TINT_VIOLET
        elif confirmed:
            text, bg = "✔ مؤكَّد", T.TINT_GREEN
        elif flagged:
            text, bg = "❌ مشتبه (يتعارض حسابياً)", T.TINT_ROSE
        else:
            text, bg = "غير مؤكَّد", T.TINT_AMBER
        it = self.tbl.item(r, COL_STATE)
        it.setText(text)
        for col in range(4):
            self.tbl.item(r, col).setBackground(QColor(bg))

    def _on_item_changed(self, item):
        """تعديل القيمة يعلّم «تأكيد» تلقائياً (الخبير يقرّ بما كتبه)."""
        if self._loading or item.column() != COL_VALUE:
            return
        chk = self.tbl.item(item.row(), COL_OK)
        if chk.checkState() != Qt.Checked:
            chk.setCheckState(Qt.Checked)

    # ------------------------------------------------------------------ أفعال
    def _check_all(self):
        for r in range(self.tbl.rowCount()):
            self.tbl.item(r, COL_OK).setCheckState(Qt.Checked)

    def _open_original(self):
        if not self._key:
            return
        try:
            import rag_index
            import safe_open
            import storage
            for d in storage.load_documents():
                if rag_index._doc_key(d) == self._key and d.get("full_path"):
                    safe_open.open_path(d["full_path"])
                    return
            show_warning(self, "فتح الوثيقة", "لم أجد الملف الأصلي في صفحة الوثائق (ربما حُذف أو نُقل).")
        except Exception as e:
            show_warning(self, "فتح الوثيقة", "تعذّر فتح الملف: %s" % e)

    def _save(self):
        if not self._key:
            return
        import doc_audit
        import report_engine
        changes = {}
        for r in range(self.tbl.rowCount()):
            if self.tbl.item(r, COL_OK).checkState() != Qt.Checked:
                continue
            path = self.tbl.item(r, COL_FIELD).data(Qt.UserRole)
            text = self.tbl.item(r, COL_VALUE).text().strip()
            try:
                new = report_engine.to_number(text)
            except ValueError as e:
                show_warning(self, "قيمة غير صالحة", "الحقل «%s»: %s" % (self.tbl.item(r, COL_FIELD).text(), e))
                return
            changes[path] = None if abs(new - self._orig[path]) < 1e-9 else new
        if not changes:
            show_info(self, "التأكيد", "لم تعلّم أي رقم بـ «تأكيد».")
            return
        fixed = doc_audit.set_confirmed(self.case_number, self._key, changes)
        self._reload()
        show_info(self, "التأكيد", "حُفظ تأكيد %d رقم%s. أعيد فحص الوثيقة حسابياً؛ راجع نتيجتها أعلى الجدول." % (
            len(changes), ("، منها %d مصحَّحة" % fixed) if fixed else ""))
