# -*- coding: utf-8 -*-
"""يُدرج مسودة التقرير (بعد مراجعة الخبير) داخل نموذج Word الخاص به.

- مكان المحتوى: فقرة في النموذج فيها العلامة {{report_body}} وحدها.
- العناوين والفقرات والجداول تُكتب بأنماط Word الموجودة في نموذج الخبير نفسه،
  فتأخذ خطوطه وألوانه. إن لم يوجد النمط يُستعمل الافتراضي.
- باقي العلامات ({{case_number}} وغيرها) تُملأ بـ word_cover.
"""
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt

import report_engine
import word_cover

_H1 = ("Heading 1", "العنوان 1", "Titre 1")
_H2 = ("Heading 2", "العنوان 2", "Titre 2")
_BODY = ("Normal", "عادي", "Normal (Web)", "Corps de texte")
_TABLE = ("Table Grid", "شبكة جدول", "Grille du tableau", "Normal Table")


def _style(doc, names):
    existing = {s.name for s in doc.styles}
    for n in names:
        if n in existing:
            return n
    return None


def _rtl_paragraph(p):
    pPr = p._p.get_or_add_pPr()
    pPr.append(OxmlElement("w:bidi"))     # أول ما يُضاف بعد pStyle فالترتيب سليم
    for r in p.runs:
        r.font.rtl = True


def _par(doc, anchor, text, style_names, rtl=True, italic=False, size=None, bold=None):
    p = doc.add_paragraph(style=_style(doc, style_names))
    if text:
        run = p.add_run(text)
        if italic:
            run.italic = True
        if bold is not None:
            run.bold = bold
        if size:
            run.font.size = Pt(size)
    if rtl:
        _rtl_paragraph(p)
    anchor._p.addprevious(p._p)
    return p


def _table(doc, anchor, rows, header=True, rtl=True):
    t = doc.add_table(rows=len(rows), cols=len(rows[0]))
    st = _style(doc, _TABLE)
    if st:
        t.style = st
    for i, row in enumerate(rows):
        for j, val in enumerate(row):
            cell = t.cell(i, j)
            cell.text = ""
            par = cell.paragraphs[0]
            run = par.add_run(str(val))
            if header and i == 0:
                run.bold = True
            if rtl:
                _rtl_paragraph(par)
    if rtl:
        tblPr = t._tbl.tblPr
        bidi = OxmlElement("w:bidiVisual")
        tblW = tblPr.find(qn("w:tblW"))
        if tblW is not None:
            tblW.addprevious(bidi)
        else:
            tblPr.append(bidi)
    try:
        from docx.enum.table import WD_TABLE_ALIGNMENT
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
    except Exception:
        pass
    anchor._p.addprevious(t._tbl)
    return t


def _find_anchor(doc, key="{{report_body}}"):
    def scan(paragraphs):
        for p in paragraphs:
            if key in "".join(r.text for r in p.runs).replace(" ", ""):
                return p
        return None
    p = scan(doc.paragraphs)
    if p is not None:
        return p
    for t in doc.tables:
        for row in t.rows:
            for cell in row.cells:
                p = scan(cell.paragraphs)
                if p is not None:
                    return p
    return None


def render_report(template_path, output_path, ctx, draft, rtl=True):
    """يكتب التقرير النهائي. يستعمل draft['results'] (استدعِ compute_all قبله)."""
    doc = Document(template_path)
    word_cover.fill_document(doc, ctx)             # أولاً، قبل إدراج نص الذكاء الاصطناعي
    anchor = _find_anchor(doc)
    if anchor is None:
        raise ValueError("لم أجد العلامة {{report_body}} في نموذج التقرير. ضعها في فقرة مستقلة.")
    for r in anchor.runs:
        r.text = ""

    report_engine.ensure_ids(draft)
    results = draft.get("results") or [report_engine.compute_calc(c) for c in draft.get("calculations", [])]
    res_of = {c["id"]: r for c, r in zip(draft.get("calculations", []), results)}
    done = set()

    def emit_calc(calc):
        res = res_of.get(calc["id"]) or report_engine.compute_calc(calc)
        _par(doc, anchor, calc["title"], _H2, rtl)
        if calc.get("method"):
            _par(doc, anchor, calc["method"], _BODY, rtl)
        rows = [["البند", "القيمة", "المصدر"]]
        details = res.get("inputs_detail") or []
        for k, i in enumerate(calc["inputs"]):
            shown = details[k] if k < len(details) else report_engine.fmt_num(i["value"])
            rows.append([i.get("label") or i["name"], shown,
                         report_engine.source_label(draft, i["source"]) if i.get("source") else "—"])
        if res["error"]:
            rows.append(["النتيجة", "تعذّر الحساب: " + res["error"], "—"])
        else:
            rows.append(["المعادلة", res["steps"], "؛ ".join(report_engine.source_label(draft, x)
                                                           for x in calc.get("method_sources", [])) or "—"])
            rows.append(["النتيجة", report_engine.fmt_num(res["result"]), "—"])
        _table(doc, anchor, rows, rtl=rtl)
        if calc.get("note"):
            _par(doc, anchor, calc["note"], _BODY, rtl, italic=True, size=9)
        _par(doc, anchor, "", _BODY, rtl)
        done.add(calc["id"])

    def emit_table(t):
        ev = report_engine.evaluate_table(t)          # الخلايا التي تبدأ بـ = تُحسب بالكود
        _par(doc, anchor, t["title"], _H2, rtl)
        _table(doc, anchor, [ev["columns"]] + (ev["rows"] or [[""] * len(ev["columns"])]), rtl=rtl)
        if t.get("note"):
            _par(doc, anchor, t["note"], _BODY, rtl, italic=True, size=9)
        for msg in ev["errors"]:
            _par(doc, anchor, "تعذّر حساب خلية: " + msg, _BODY, rtl, italic=True, size=9)
        _par(doc, anchor, "", _BODY, rtl)
        done.add(t["id"])

    for s_ in draft.get("sections", []):
        if s_.get("status") == "suggested":            # عنوان لم يعتمده الخبير لا يدخل التقرير
            continue
        _par(doc, anchor, s_["title"], _H1, rtl)
        for line in [l.strip() for l in s_.get("body", "").split("\n") if l.strip()]:
            _par(doc, anchor, line, _BODY, rtl)
        if s_.get("sources"):
            labels = "؛ ".join(report_engine.source_label(draft, x) for x in s_["sources"])
            _par(doc, anchor, "المصادر: " + labels, _BODY, rtl, italic=True, size=9)
        for c in draft.get("calculations", []):
            if c.get("section") == s_["id"]:
                emit_calc(c)
        for t in draft.get("tables", []):
            if t.get("section") == s_["id"]:
                emit_table(t)

    rest_c = [c for c in draft.get("calculations", []) if c["id"] not in done]
    rest_t = [t for t in draft.get("tables", []) if t["id"] not in done]
    if rest_c or rest_t:
        _par(doc, anchor, "الحسابات والجداول", _H1, rtl)
        for c in rest_c:
            emit_calc(c)
        for t in rest_t:
            emit_table(t)

    anchor._p.getparent().remove(anchor._p)
    doc.save(output_path)


def render_html_preview(ctx, draft):
    """معاينة التقرير كاملاً (غلاف + عناوين معتمدة + جداولها) كـ HTML لعرضها داخل البرنامج قبل التصدير."""
    from html import escape as e
    report_engine.ensure_ids(draft)
    results = draft.get("results") or [report_engine.compute_calc(c) for c in draft.get("calculations", [])]
    res_of = {c["id"]: r for c, r in zip(draft.get("calculations", []), results)}
    css = ("<style>body{font-family:Arial;color:#1f2347} h1{color:#3730a3;font-size:17pt;border-bottom:2px solid #e4e7f7;"
           "padding-bottom:4px} h2{color:#4338ca;font-size:13pt} table{border-collapse:collapse;margin:8px 0}"
           "th{background:#4338ca;color:white;padding:6px} td{border:1px solid #cdd3ee;padding:6px}"
           ".src{color:#5b6485;font-size:9pt} .cover{text-align:center;padding:30px 0;border:1px solid #e4e7f7;"
           "background:#f8f9ff} .err{color:#b1243c}</style>")
    out = ['<html><body dir="rtl">', css]
    out.append('<div class="cover"><h1 style="border:none">تقرير خبرة قضائية</h1><p>القضية رقم: %s</p><p>%s</p><p>%s / %s</p></div>' % (
        e(str(ctx.get("case_number", ""))), e(str(ctx.get("court", "") or "")), e(str(ctx.get("plaintiff", ""))), e(str(ctx.get("defendant", "")))))
    done = set()

    def calc_html(c):
        r = res_of.get(c["id"]) or report_engine.compute_calc(c)
        h = ["<h2>%s</h2>" % e(c["title"])]
        if c.get("method"):
            h.append("<p>%s</p>" % e(c["method"]))
        rows = "".join("<tr><td>%s</td><td>%s</td></tr>" % (e(str(i.get("label") or i["name"])), e(str((r.get("inputs_detail") or [""] * 99)[k] or report_engine.fmt_num(i["value"]))))
                       for k, i in enumerate(c["inputs"]))
        res = ('<tr><td><b>النتيجة</b></td><td class="err">%s</td></tr>' % e(r["error"]) if r["error"] else
               "<tr><td>المعادلة</td><td>%s</td></tr><tr><td><b>النتيجة</b></td><td><b>%s</b></td></tr>" % (e(r["steps"]), e(report_engine.fmt_num(r["result"]))))
        h.append("<table><tr><th>البند</th><th>القيمة</th></tr>%s%s</table>" % (rows, res))
        done.add(c["id"])
        return "".join(h)

    def table_html(t):
        ev = report_engine.evaluate_table(t)
        head = "".join("<th>%s</th>" % e(x) for x in ev["columns"])
        body = "".join("<tr>%s</tr>" % "".join("<td>%s</td>" % e(v) for v in r) for r in ev["rows"])
        errs = "".join('<p class="err">تعذّر حساب خلية %s</p>' % e(m) for m in ev["errors"])
        done.add(t["id"])
        return "<h2>%s</h2><table><tr>%s</tr>%s</table>%s" % (e(t["title"]), head, body, errs)

    for s_ in draft.get("sections", []):
        if s_.get("status") == "suggested":
            continue
        out.append("<h1>%s</h1>" % e(s_["title"]))
        out.extend("<p>%s</p>" % e(l) for l in s_.get("body", "").split("\n") if l.strip())
        out.extend(calc_html(c) for c in draft.get("calculations", []) if c.get("section") == s_["id"])
        out.extend(table_html(t) for t in draft.get("tables", []) if t.get("section") == s_["id"])
    rest = [calc_html(c) for c in draft.get("calculations", []) if c["id"] not in done]
    rest += [table_html(t) for t in draft.get("tables", []) if t["id"] not in done]
    if rest:
        out.append("<h1>الحسابات والجداول</h1>" + "".join(rest))
    out.append("</body></html>")
    page = "".join(out)
    # توسيط الجداول وعناوينها وخلاياها (الحساب: جدول أضيق، والجداول العامة أعرض)
    page = page.replace("<table><tr><th>البند</th>", "<table align='center' width='62%' cellpadding='7'><tr><th>البند</th>")
    page = page.replace("<table>", "<table align='center' width='90%' cellpadding='7'>")
    page = page.replace("<h2>", "<h2 align='center'>")
    page = page.replace("<th>", "<th align='center'>").replace("<td>", "<td align='center'>")
    page = page.replace("<td class=\"err\">", "<td align='center' class=\"err\">")
    return page
