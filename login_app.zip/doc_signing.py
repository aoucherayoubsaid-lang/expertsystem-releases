# -*- coding: utf-8 -*-
"""Réf + QR لكل وثيقة (صادرة من البرنامج أو واردة/ممسوحة ضوئياً) مع سجل في Cloudflare.

Réf = السنة-رقم القضية-التسلسل  (مثال 2026-123-1 ثم 2026-123-2 ...) ويبدأ من 1 لكل قضية.
الـ QR يحمل رابطاً برمز سرّي منفصل، فمعرفة الـ Réf وحدها لا تكشف بيانات القضية.

الإعداد: DOCS_API_URL (متغير بيئة) أو ملف docs_api.json بجانب البرنامج:
    {"url": "https://....workers.dev"}
المصادقة برمز خاص بالجهاز يصدره خادم التراخيص (docs_token.py)، لا مفتاح مشترك.
لا يُرسل إلى الخادم: بطاقات التعريف، هواتف/عناوين الأطراف، ولا محتوى الملفات (اسم + بصمة SHA-256 فقط).
"""
import base64
import datetime
import hashlib
import html
import io
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request

try:
    import qrcode
    from qrcode.constants import ERROR_CORRECT_M
except ImportError:  # pragma: no cover
    qrcode = None

_SPLIT = re.compile(r"[،,;؛/\\|\n\r]+")
_REF_TEXT = re.compile(r"R[ée]f\s*[:：]?\s*(\d{4}/[^\s<>|/]{1,80}/\d/\d{1,5})(?=\s|$|[<|])", re.I)
# رمز الطرف داخل Réf:  0 = صادرة عن الخبير
ROLE_CODES = {"مدعي": 1, "مدعى عليه": 2, "مدخل في الخصام": 3, "متدخل في الخصام": 4, "شاهد": 5, "أخرى": 6}
_TOKEN_URL = re.compile(r"/v/([A-Z2-9]{12})\b")
STAMPABLE = {".pdf", ".png", ".jpg", ".jpeg"}
# مكان سطر Réf في أعلى الصفحة: "left" أو "right"
REF_SIDE = "left"


LAST_ERROR = ""


def _log(msg):
    """يسجّل الخطأ في docs_log.txt بجانب البرنامج (لأن print لا يظهر في نسخة exe)."""
    global LAST_ERROR
    LAST_ERROR = str(msg)
    try:
        from app_paths import app_base_dir
        with open(os.path.join(app_base_dir(), "docs_log.txt"), "a", encoding="utf-8") as f:
            f.write(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + "  " + str(msg) + "\n")
    except Exception:
        pass


# ----------------------------------------------------------------- الاتصال
def _config():
    """رابط خادم الوثائق فقط. لم يعد هناك مفتاح مشترك: المصادقة برمز الجهاز (docs_token.py)."""
    url = os.environ.get("DOCS_API_URL", "").strip()
    if not url:
        try:
            import app_paths
            # الإعداد يُشحن بجانب البرنامج؛ ونقبله أيضاً في مجلد البيانات للنسخ القديمة
            for folder in (app_paths.install_dir(), app_paths.app_base_dir()):
                p = os.path.join(folder, "docs_api.json")
                if os.path.exists(p):
                    with open(p, encoding="utf-8-sig") as f:
                        url = str(json.load(f).get("url", "")).strip()
                    break
        except Exception:
            pass
    url = url.rstrip("/")
    if not url:
        raise RuntimeError("لم يتم إعداد خادم التحقق (DOCS_API_URL).")
    if not url.startswith("https://"):
        raise RuntimeError("يجب أن يبدأ رابط خادم التحقق بـ https://")
    return url


def _call(path, payload=None):
    import docs_token
    base = _config()
    data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
    for attempt in (0, 1):
        headers = {"Content-Type": "application/json", "Accept": "application/json",
                   "User-Agent": "ExpertDocs/1.0 (+Windows)"}
        headers.update(docs_token.auth_headers(force=bool(attempt)))
        req = urllib.request.Request(base + path, data=data, method="GET" if data is None else "POST",
                                     headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=20, context=_ssl_ctx()) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            if exc.code == 401 and attempt == 0:      # رمز منتهٍ/مرفوض: نجدّده مرة واحدة ثم نعيد المحاولة
                continue
            raise RuntimeError(f"رفض الخادم الطلب ({exc.code}): {exc.read().decode('utf-8', 'replace')[:200]}") from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise RuntimeError(f"تعذر الاتصال بخادم التحقق: {exc}") from exc


def _ssl_ctx():
    try:
        import trial_online
        return trial_online._ssl_context()      # شهادات certifi (مهم لويندوز 7)
    except Exception:
        return None


# ------------------------------------------------- لقطة القضية من البرنامج
def case_key(case_number):
    """رقم القضية كما يُرسل للخادم ويظهر في Réf: كل / أو \\ يصير - (مثل 25/000125 -> 25-000125)،
    حتى لا يتعارض مع / الفاصلة بين أجزاء Réf."""
    return re.sub(r"\s*[/\\]+\s*", "-", str(case_number or "").strip())


def _norm(text):
    return re.sub(r"\s+", " ", str(text or "")).strip().lower()


def _party_in_case(party, case_number, case):
    linked = party.get("cases")
    items = linked if isinstance(linked, (list, tuple)) else _SPLIT.split(str(linked or ""))
    for i in items:                      # صفحة الأطراف تخزّن الربط كقائمة قواميس {"year", "number"}
        num = i.get("number") if isinstance(i, dict) else i
        if str(num or "").strip() and case_key(num) == case_key(case_number):
            return True
    return _norm(party.get("name")) in ({_norm(case.get("plaintiff")), _norm(case.get("defendant"))} - {""})


def build_snapshot(case_number):
    import storage
    case_number = str(case_number or "").strip()
    case = next((c for c in storage.load_cases() if str(c.get("case_number", "")).strip() == case_number), {})
    try:
        parties = [p for p in storage.load_parties() if _party_in_case(p, case_number, case)]
    except Exception:
        parties = []
    info = storage.load_expert_info() or {}
    return {
        "case": {k: case.get(k, "") for k in ("court", "plaintiff", "defendant", "index_number", "session_date")},
        "parties": [{"name": p.get("name", ""), "role": p.get("role", ""),
                     "lawyer_name": p.get("lawyer_name", "")} for p in parties],
        "expert": {"name": info.get("name", ""), "title": info.get("job", "") or info.get("title", ""),
                   "address": info.get("address", ""), "phone": info.get("phone", "")},
    }


# ----------------------------------------------------------------------- QR
def make_qr_png(url):
    if qrcode is None:
        raise RuntimeError("مكتبة QR غير مثبتة. نفّذ: pip install \"qrcode[pil]\"")
    qr = qrcode.QRCode(error_correction=ERROR_CORRECT_M, box_size=8, border=2)
    qr.add_data(url)
    qr.make(fit=True)
    buf = io.BytesIO()
    qr.make_image(fill_color="black", back_color="white").save(buf, format="PNG")
    return buf.getvalue()


def _data_uri(png):
    return "data:image/png;base64," + base64.b64encode(png).decode("ascii")


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _iso_date(value):
    value = str(value or "").strip()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
        try:
            return datetime.datetime.strptime(value, fmt).date().isoformat()
        except ValueError:
            continue
    return datetime.date.today().isoformat()


# ---------------------------------------------------------- التسجيل في الخادم
def party_code_for(party_name, case_number=None):
    """رمز صفة الطرف (1 مدعي، 2 مدعى عليه ...): من صفحة الأطراف، وإن لم يوجد فمن بيانات القضية؛ وإلا 6 (أخرى)."""
    try:
        import storage
        name = _norm(party_name)
        for p in storage.load_parties():
            if _norm(p.get("name")) == name:
                return ROLE_CODES.get(str(p.get("role", "")).strip(), 6)
        for c in storage.load_cases():
            if case_key(c.get("case_number", "")) == case_key(case_number):
                if name and name == _norm(c.get("plaintiff")):
                    return 1
                if name and name == _norm(c.get("defendant")):
                    return 2
    except Exception:
        pass
    return 6


def register(kind, doc_type, case_number, issue_date=None, source="", file_path=None, party_code=None):
    """يسجّل وثيقة ويعيد Réf التالي: السنة/رقم القضية/رمز الطرف/التسلسل (مثل 2026/123/2/4)."""
    if party_code is None:
        party_code = 0 if kind == "issued" else 6
    payload = {"kind": kind, "party_code": party_code, "doc_type": doc_type or "وثيقة", "case_number": case_key(case_number),
               "case_label": str(case_number or "").strip(),
               "issue_date": _iso_date(issue_date), "source": source or ""}
    if file_path:
        payload["file_name"] = os.path.basename(file_path)
        payload["file_sha256"] = sha256_file(file_path)
    payload.update(build_snapshot(case_number))
    res = _call("/documents", payload)
    if not res.get("ok") or not res.get("verify_url"):
        raise RuntimeError("استجابة غير صالحة من خادم التحقق")
    png = make_qr_png(res["verify_url"])
    return {"doc_id": res["ref"], "ref": res["ref"], "verify_url": res["verify_url"],
            "qr_payload": res["verify_url"], "qr_png": png, "qr_data_uri": _data_uri(png)}


def sign_document(doc_type_label, doc_id, case_number, expert_name, issue_date):
    """واجهة قديمة (للتوافق): وثيقة صادرة من البرنامج."""
    return register("issued", doc_type_label, case_number, issue_date)


# ------------------------------------------------------- إدراج في وثائق HTML
def verification_markup(document):
    if not document.get("qr_data_uri"):
        return ""
    ref = html.escape(str(document.get("doc_id", "")))
    return ('<section data-doc-verify="1" dir="rtl" style="page-break-inside:avoid;text-align:center;'
            'margin:16px auto 0;padding:8px;border-top:1px solid #999;font:10pt sans-serif">'
            f'<img src="{document["qr_data_uri"]}" alt="QR" style="width:100px;height:100px">'
            f'<div dir="ltr">Réf : <b>{ref}</b></div>'
            '<div style="font-size:8pt;color:#555">امسح الرمز للتحقق من الوثيقة</div></section>')


def header_ref_markup(document):
    ref = html.escape(str(document.get("doc_id", "")))
    side = "right" if REF_SIDE == "right" else "left"
    return ('<div data-doc-verify-top="1" dir="ltr" style="text-align:' + side +
            ';font:bold 9pt sans-serif;color:#000;margin:0 0 6px 0">R\u00e9f : ' + ref + '</div>')


def append_verification_markup(rendered_html, document):
    if "data-doc-verify" in rendered_html:
        return rendered_html
    markup = verification_markup(document)
    if not markup:
        return rendered_html
    top = header_ref_markup(document)
    m = re.search(r"<body[^>]*>", rendered_html, re.I)
    if m:
        rendered_html = rendered_html[:m.end()] + top + rendered_html[m.end():]
    pos = rendered_html.lower().rfind("</body>")
    return rendered_html + markup if pos < 0 else rendered_html[:pos] + markup + rendered_html[pos:]


GENERAL_CASE = "عام"   # للتقارير العامة غير المرتبطة بقضية (الوضعية العامة، سجل التسديدات)


def issue_fields(doc_type, case_number=None, issue_date=None):
    """حقول تُمرَّر إلى قالب Jinja: doc_id (Réf) و qr_data_uri و verify_url.
    إن تعذّر التسجيل (لا إنترنت مثلاً) تعود فارغة فتخرج الوثيقة بلا QR."""
    try:
        f = register("issued", doc_type, str(case_number or "").strip() or GENERAL_CASE, issue_date)
        return {"doc_id": f["doc_id"], "qr_data_uri": f["qr_data_uri"], "verify_url": f["verify_url"]}
    except Exception as exc:
        _log(f"issue_fields ({doc_type}): {exc}")
        return {"doc_id": "", "qr_data_uri": "", "verify_url": ""}


def ensure_markup(rendered_html, fields):
    """يضمن ظهور Réf + QR في الوثيقة حتى لو لم يحتوِ القالب على {{ doc_id }} و{{ qr_data_uri }}."""
    uri = (fields or {}).get("qr_data_uri", "")
    if not uri or uri in rendered_html:
        return rendered_html          # فشل التسجيل، أو القالب يعرض QR بنفسه
    return append_verification_markup(rendered_html, {"doc_id": fields.get("doc_id", ""), "qr_data_uri": uri})


def stamp_html(rendered_html, doc_type, case_number, issue_date=None, strict=False):
    """تستدعيها مولّدات التقارير: تضيف Réf + QR أسفل الوثيقة الصادرة."""
    if not str(case_number or "").strip():
        return rendered_html
    try:
        fields = register("issued", doc_type, case_number, issue_date)
    except Exception as exc:
        if strict:
            raise
        _log(f"stamp_html ({doc_type}): {exc}")
        return rendered_html
    return append_verification_markup(rendered_html, fields)


def register_document(data, prefix, doc_type, case_number=None, issue_date=None):
    fields = register("issued", doc_type, data.get("case_number", "") if case_number is None else case_number,
                      issue_date if issue_date is not None else data.get("date", ""))
    data.update(fields)
    return fields


# ------------------------------------- الوثائق المرفقة (joints): اكتشاف Réf/QR
def _pdf_text(path, pages=3):
    try:
        import pypdf
        r = pypdf.PdfReader(path)
        return "\n".join((p.extract_text() or "") for p in r.pages[:pages])
    except Exception:
        return ""


def _qr_texts(path):
    """يقرأ أي QR في الصفحة الأولى (يحتاج opencv-python؛ اختياري)."""
    try:
        import cv2
        import numpy as np
    except ImportError:
        return []
    img = None
    try:
        if path.lower().endswith(".pdf"):
            import fitz
            with fitz.open(path) as doc:
                pix = doc[0].get_pixmap(dpi=200)
                arr = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)
                img = cv2.cvtColor(arr, cv2.COLOR_RGBA2BGR if pix.n == 4 else cv2.COLOR_RGB2BGR) if pix.n >= 3 else arr
        else:
            img = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_COLOR)
        if img is None:
            return []
        text, _, _ = cv2.QRCodeDetector().detectAndDecode(img)
        return [text] if text else []
    except Exception:
        return []


def _detect_ref_local(path):
    """يبحث داخل الملف عن Réf مكتوب أو QR صادر من هذا النظام. يعيد {'ref':..} أو {'token':..} أو {}."""
    for text in _qr_texts(path):
        m = _TOKEN_URL.search(text)
        if m:
            return {"token": m.group(1)}
    if path.lower().endswith(".pdf"):
        m = _REF_TEXT.search(_pdf_text(path))
        if m:
            return {"ref": m.group(1)}
    return {}


def process_joint(path, case_number, source_name="", added_date=None):
    """يعالج ملفاً مرفوعاً في إدارة الوثائق:
    - فيه Réf/QR لوثيقة صادرة من مكتبك لنفس القضية → يُربط بها ويُسجَّل hash الملف (status='linked'/'mismatch').
    - بلا Réf (وثيقة طرف/مسح ضوئي) → يُسجَّل كوثيقة واردة ويأخذ Réf جديداً (status='registered').
    """
    sha = sha256_file(path)
    found = detect_ref(path)
    if found:
        q = urllib.parse.urlencode(found)
        rec = _call("/lookup?" + q)
        if rec.get("found") and case_key(rec.get("case_number", "")) == case_key(case_number) and not rec.get("revoked"):
            res = _call("/documents/attach", {"ref": rec["ref"], "file_name": os.path.basename(path), "file_sha256": sha})
            return {"status": "linked" if res.get("match") else "mismatch", "ref": rec["ref"], "sha256": sha}
    fields = register("received", "وثيقة واردة", case_number, added_date, source_name, path,
                      party_code=party_code_for(source_name, case_number))
    fields.update({"status": "registered", "sha256": sha})
    return fields


# ----------------------------------- ختم Réf + QR على نسخة من PDF/صورة ممسوحة
def _font(size):
    from PIL import ImageFont
    for name in ("arial.ttf", "Arial.ttf", "DejaVuSans.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except Exception:
            continue
    return ImageFont.load_default()


def _img_to_pdf_bytes(img, w_pt, h_pt):
    buf = io.BytesIO()
    img.save(buf, "PDF", resolution=img.size[0] * 72.0 / w_pt)
    return buf.getvalue()


def _stamp_file_local(src, dst, fields):
    """ينشئ ملف PDF جديداً يحمل QR + Réf (الأصل لا يُمسّ). يعتمد pypdf و Pillow فقط (بلا PyMuPDF).
    - PDF أو صورة: نسخة من الملف عليها Réf في الأعلى وQR + Réf في الشريط السفلي (stamp_kind='stamp').
    - أي نوع آخر (Word، Excel ...): ورقة غلاف PDF فيها QR + Réf + اسم الملف (stamp_kind='cover')."""
    from PIL import Image, ImageDraw
    try:
        from pypdf import PdfReader, PdfWriter, Transformation
    except ImportError as exc:
        raise RuntimeError('مكتبة pypdf غير مثبتة. نفّذ: python -m pip install "pypdf==4.3.1"') from exc

    ext = os.path.splitext(src)[1].lower()
    ref = fields["ref"]
    label = "R\u00e9f : " + ref
    qr = Image.open(io.BytesIO(fields["qr_png"])).convert("RGB")
    DPI = 150
    k = DPI / 72.0

    if ext not in STAMPABLE:                       # ورقة غلاف
        fields["stamp_kind"] = "cover"
        img = Image.new("RGB", (int(595 * k), int(842 * k)), "white")
        dr = ImageDraw.Draw(img)
        dr.text((60 * k, 70 * k), "Ref : " + ref, fill="black", font=_font(int(20 * k)))
        img.paste(qr.resize((int(240 * k), int(240 * k))), (int(60 * k), int(120 * k)))
        dr.text((60 * k, 380 * k), "File : " + os.path.basename(src), fill="black", font=_font(int(11 * k)))
        dr.text((60 * k, 402 * k), "Scan the QR code to verify this document.", fill="black", font=_font(int(10 * k)))
        with open(dst, "wb") as f:
            f.write(_img_to_pdf_bytes(img, 595, 842))
        return dst

    fields["stamp_kind"] = "stamp"
    if ext == ".pdf":
        reader = PdfReader(src)
    else:                                          # صورة -> صفحة PDF
        im = Image.open(src)
        im = im.convert("RGB")
        reader = PdfReader(io.BytesIO(_img_to_pdf_bytes(im, 595, im.size[1] * 595.0 / im.size[0])))

    top, bottom, m = 24, 72, 28
    bands = {}

    def band_pages(w, h):
        key = (round(w), round(h))
        if key not in bands:
            t = Image.new("RGB", (int(w * k), int(top * k)), "white")
            tw = ImageDraw.Draw(t).textlength(label, font=_font(int(9 * k)))
            x = (w - m) * k - tw if REF_SIDE == "right" else m * k
            ImageDraw.Draw(t).text((x, 6 * k), label, fill="black", font=_font(int(9 * k)))
            bt = Image.new("RGB", (int(w * k), int(bottom * k)), "white")
            d = ImageDraw.Draw(bt)
            d.line([(m * k, 8 * k), ((w - m) * k, 8 * k)], fill="black", width=max(1, int(0.5 * k)))
            bt.paste(qr.resize((int(52 * k), int(52 * k))), (int(m * k), int(12 * k)))
            d.text(((m + 62) * k, 26 * k), label, fill="black", font=_font(int(9 * k)))
            d.text(((m + 62) * k, 42 * k), "Scan to verify this document", fill="black", font=_font(int(8 * k)))
            bands[key] = (PdfReader(io.BytesIO(_img_to_pdf_bytes(t, w, top))).pages[0],
                          PdfReader(io.BytesIO(_img_to_pdf_bytes(bt, w, bottom))).pages[0])
        return bands[key]

    writer = PdfWriter()
    for page in reader.pages:
        try:
            page.transfer_rotation_to_content()
        except Exception:
            pass
        box = page.mediabox
        w, h = float(box.width), float(box.height)
        left, low = float(box.left), float(box.bottom)
        sc = (h - top - bottom) / h
        tx = (w - w * sc) / 2.0 - left * sc
        ty = bottom - low * sc
        new = writer.add_blank_page(width=w, height=h)
        new.merge_transformed_page(page, Transformation().scale(sc, sc).translate(tx, ty))
        tp, bp = band_pages(w, h)
        new.merge_transformed_page(tp, Transformation().translate(0, h - top))
        new.merge_transformed_page(bp, Transformation().translate(0, 0))
    with open(dst, "wb") as f:
        writer.write(f)
    return dst


# ------------------------------------------------------------------------------------
# تشغيل المكوّنات الثقيلة (opencv / PyMuPDF) في عملية منفصلة: إن تعطّلت مكتبة أصلية (crash)
# تتعطّل العملية الفرعية فقط ولا ينهار البرنامج، ويُكتب السبب في docs_log.txt
# ------------------------------------------------------------------------------------
def _frozen():
    import sys
    return bool(getattr(sys, "frozen", False))


def _run_worker(args, timeout=90):
    import subprocess
    import sys
    worker = os.path.join(os.path.dirname(os.path.abspath(__file__)), "docs_worker.py")
    if not os.path.exists(worker):
        raise RuntimeError("الملف docs_worker.py غير موجود بجانب البرنامج")
    kw = {"creationflags": 0x08000000} if os.name == "nt" else {}      # بلا نافذة سوداء
    p = subprocess.run([sys.executable, worker] + [str(a) for a in args],
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout, **kw)
    out = p.stdout.decode("utf-8", "replace").strip()
    err = p.stderr.decode("utf-8", "replace").strip()
    if p.returncode != 0:
        _log(f"worker {args[0]} انتهى برمز {p.returncode}\n{err[-1500:]}")
        raise RuntimeError(f"تعطّل مكوّن {args[0]} (رمز {p.returncode}) — التفاصيل في docs_log.txt")
    return json.loads(out.splitlines()[-1]) if out else {}


def detect_ref(path):
    if _frozen():
        return _detect_ref_local(path)
    try:
        return _run_worker(["detect", path], 60)
    except Exception as exc:
        _log(f"detect_ref: {exc}")
        return {}


def stamp_file(src, dst, fields):
    """ينشئ نسخة PDF مختومة بـ Réf + QR (تُنفَّذ في عملية منفصلة)."""
    if _frozen():
        return _stamp_file_local(src, dst, fields)
    import tempfile
    fd, tmp = tempfile.mkstemp(suffix=".json")
    os.close(fd)
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"ref": fields["ref"], "qr_png_b64": base64.b64encode(fields["qr_png"]).decode("ascii")}, f)
        res = _run_worker(["stamp", src, dst, tmp], 120)
        fields["stamp_kind"] = res.get("stamp_kind", "stamp")
        if not os.path.exists(dst):
            raise RuntimeError("لم يُنشأ ملف النسخة المختومة")
        return dst
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass
