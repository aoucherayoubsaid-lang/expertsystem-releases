# -*- coding: utf-8 -*-
"""كلمة مرور بدء التشغيل: تُحفظ كتجزئة (PBKDF2-SHA256 مع ملح)، ولا تُحفظ أبداً كنص صريح.

settings.json موقَّع (local_protect): تعطيل هذه الكلمة بتعديل الملف يدوياً يُكتشف.

ملاحظة صريحة: هذه كلمة مرور "بوابة" لفتح البرنامج، وليست تشفيراً للبيانات.
لحماية الملفات نفسها إن سُرق الجهاز يلزم تشفير القرص (BitLocker أو VeraCrypt).

تستعمل نفس دوال تجزئة وفحص كلمات مرور المستخدمين في storage.py، ونفس نظام
القفل المؤقت في security_manager.py (5 محاولات خاطئة ثم قفل دقائق).
"""
import storage
import security_manager

_LOCK_NAME = "__startup__"
import password_policy
MIN_LENGTH = password_policy.MIN_LENGTH  # نفس السياسة المعتمدة لكلمات مرور المستخدمين


def has_password(settings):
    return bool(settings.get("startup_password_hash"))


def set_password(settings, plain):
    """يحفظ تجزئة كلمة المرور ويمسح أي نسخة صريحة قديمة من settings.json."""
    ok, problems = password_policy.check(plain)
    if not ok:
        raise password_policy.WeakPassword(problems)
    settings.data.pop("startup_password", None)
    settings.set("startup_password_hash", storage._hash_password(plain))


def verify(settings, plain):
    return storage._verify_password(plain, settings.get("startup_password_hash"))


def migrate_legacy(settings):
    """نسخ قديمة حفظت كلمة المرور صريحة في المفتاح startup_password: نحوّلها لتجزئة."""
    legacy = settings.data.get("startup_password")
    if legacy and not settings.get("startup_password_hash"):
        settings.data.pop("startup_password", None)
        settings.set("startup_password_hash", storage._hash_password(legacy))
    elif "startup_password" in settings.data:
        settings.data.pop("startup_password", None)
        settings.save()


def is_locked():
    return security_manager.is_locked(_LOCK_NAME)


def lock_minutes():
    return security_manager.LOCK_MINUTES


def on_failure():
    security_manager.record_failure(_LOCK_NAME)


def on_success():
    security_manager.record_success(_LOCK_NAME)
