from msgbox_ltr import show_info, show_warning, show_question
# dossier_home_page.py
"""
"الصفحة الرئيسية" الخاصة بملف (Dossier) معيّن بعد فتحه.

تحتوي:
  - بطاقة معلومات الخبير (قابلة للتعديل، مشتركة بين كل الملفات).
  - إدارة السنوات: كل ملف يُقسَّم عمله إلى سنوات، ويمكن إقفال سنة كاملة.
  - اختيار "المحكمة" الافتراضية لهذه السنة.
  - إحصائيات حيّة عن السنة المختارة، مُصفّاة حسب المحكمة، وكل بطاقة
    إحصائية قابلة للنقر لعرض قائمة القضايا المعنية بالتفصيل.
  - زر "الدخول إلى صفحة العمل" الذي يفتح الواجهة الرئيسية (MainApp).

ملاحظة تقنية مهمة (سبب مشكلة "المستطيلات الفارغة" التي كانت تظهر سابقاً):
في Qt يَرِث الصنف QLabel من QFrame، لذلك أي قاعدة CSS تُكتب بالمحدد
"QFrame{...}" تُطبَّق أيضاً على كل QLabel داخل الإطار فتمنحه خلفية بيضاء
وحدوداً وحشواً، فتظهر النصوص داخل مستطيلات فارغة. الحل المعتمد هنا هو
استخدام محددات مرتبطة باسم الكائن (QFrame#cardFrame) حتى لا تتسرّب
القاعدة إلى الأبناء.
"""

import datetime
from PyQt5.QtCore import Qt, QSize, QRegExp, pyqtSignal
from PyQt5.QtGui import QFont, QCursor, QColor, QRegExpValidator
from PyQt5.QtWidgets import (
    QBoxLayout, QSizePolicy, QWidget, QMainWindow, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFrame, QGridLayout, QLineEdit, QMessageBox, QComboBox, QListWidget,
    QListWidgetItem, QAbstractItemView, QDialog, QTableWidget,
    QTableWidgetItem, QHeaderView, QScrollArea, QFormLayout
)
import qtawesome as qta
from modern_theme import style_button, style_soft_button, style_white_button
import theme_tokens as T
from ui_components import Card, GradientBanner, icon_badge, animate_number, mix, tint, figure, lead_align
from i18n import is_rtl

import storage
import datetime
from case_status import case_status, deposit_receipts, near_days, compute_deadline as _cs_deadline


# ======================================================================
#  دوال مساعدة لحساب مواعيد الإيداع (مشتركة بين الإحصائيات والنوافذ)
# ======================================================================

def compute_case_deadline(case):
    """يُرجع (تاريخ_الإيداع, الأيام_المتبقية) أو (None, None) إن تعذّر الحساب."""
    deadline = _cs_deadline(case)
    if deadline is None:
        return None, None
    days_left = (deadline - datetime.date.today()).days
    return datetime.datetime.combine(deadline, datetime.time()), days_left


def classify_case(case, receipts=None, near=None):
    """يُصنّف القضية إلى: 'done' (أُودع تقريرها بوصل إيداع) أو 'late' (متأخرة)
    أو 'near' (قريبة الإيداع حسب الإعدادات) أو 'ok' أو None.
    الإيداع يُحدَّد بوجود "وصل إيداع تقرير الخبرة" فقط."""
    state = case_status(case, receipts, near)["state"]
    return {"deposited": "done", "late": "late", "near": "near", "ok": "ok"}.get(state)


def filter_cases_by_court(cases, court):
    """تصفية القضايا حسب المحكمة. court فارغ يعني جميع المحاكم."""
    if not court:
        return list(cases)
    court_norm = court.strip()
    return [c for c in cases if (c.get("court") or "").strip() == court_norm]


# ======================================================================
#  نافذة عرض تفاصيل مجموعة قضايا (تُفتح عند النقر على بطاقة إحصائية)
# ======================================================================

class CasesDetailDialog(QDialog):
    """نافذة تعرض جدولاً بكل معلومات القضايا المعنية."""

    COLUMNS = [
        ("رقم القضية", "case_number"),
        ("رقم الفهرس", "index_number"),
        ("المحكمة", "court"),
        ("القسم", "section"),
        ("المدعي", "plaintiff"),
        ("المدعى عليه", "defendant"),
        ("تاريخ الاستلام", "receive_date"),
        ("المدة (أشهر)", "duration_months"),
    ]

    def __init__(self, title, cases, accent="#4338ca", parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(1080, 580)
        self.setStyleSheet("QDialog{background:#f4f5ff;}")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(12)

        header = QLabel(f"{title}      ({len(cases)} قضية)")
        header.setFont(QFont("Segoe UI", 14, QFont.Bold))
        header.setStyleSheet(f"color:{accent}; background:transparent; border:none;")
        header.setWordWrap(True)
        layout.addWidget(header)

        if not cases:
            empty = QLabel("لا توجد قضايا مطابقة لهذا التصنيف.")
            empty.setFont(QFont("Segoe UI", 12))
            empty.setAlignment(Qt.AlignCenter)
            empty.setStyleSheet(
                "color:#5b6485; background:transparent; border:none; padding:50px;")
            layout.addWidget(empty)
        else:
            layout.addWidget(self._build_table(cases))

        btn_row = QHBoxLayout()
        close_btn = QPushButton("إغلاق")
        close_btn.setIcon(qta.icon("fa5s.times", color="white"))
        close_btn.setMinimumWidth(140)
        close_btn.setMinimumHeight(38)
        close_btn.setCursor(QCursor(Qt.PointingHandCursor))
        style_button(close_btn, "secondary", radius=8, padding="9px 18px")
        close_btn.clicked.connect(self.accept)
        # الزر أولاً ثم الفراغ المرن: في اتجاه RTL (لغة الواجهة العربية) هذا
        # يضع الزر أقصى اليمين، لأن Qt يعكس ترتيب عناصر QHBoxLayout تلقائياً
        # حين يكون اتجاه الواجهة RTL (أول عنصر يُضاف يظهر أقصى اليمين).
        btn_row.addWidget(close_btn)
        btn_row.addStretch()
        layout.addLayout(btn_row)

    def _build_table(self, cases):
        _w = storage.unit_words()
        _ren = {"المحكمة": _w["unit"], "القسم": _w["section"]}
        headers = [_ren.get(h, h) for h, _ in self.COLUMNS] + ["تاريخ الإيداع", "الحالة"]
        table = QTableWidget(len(cases), len(headers))
        table.setHorizontalHeaderLabels(headers)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setSelectionBehavior(QAbstractItemView.SelectRows)
        table.setAlternatingRowColors(True)
        table.verticalHeader().setVisible(False)
        table.setStyleSheet("""
            QTableWidget {
                background:white;
                border:1px solid #dde1f3;
                border-radius:8px;
                font-size:11pt;
                gridline-color:#eef0ff;
            }
            QTableWidget::item { padding:6px; }
            QHeaderView::section {
                background:#4338ca;
                color:white;
                padding:9px;
                border:none;
                font-size:11pt;
                font-weight:bold;
            }
        """)

        receipts_map = deposit_receipts()
        near_n = near_days()

        # ترتيب القضايا: الأكثر تأخراً أولاً
        def sort_key(c):
            _, days_left = compute_case_deadline(c)
            return days_left if days_left is not None else 999999

        for row, case in enumerate(sorted(cases, key=sort_key)):
            for col, (_, key) in enumerate(self.COLUMNS):
                item = QTableWidgetItem(str(case.get(key, "") or ""))
                item.setTextAlignment(Qt.AlignCenter)
                table.setItem(row, col, item)

            deadline, days_left = compute_case_deadline(case)
            deadline_txt = deadline.strftime("%d/%m/%Y") if deadline else "غير محدد"
            deadline_item = QTableWidgetItem(deadline_txt)
            deadline_item.setTextAlignment(Qt.AlignCenter)
            table.setItem(row, len(self.COLUMNS), deadline_item)

            st = case_status(case, receipts_map, near_n)
            if st["state"] == "deposited":
                status_txt = "أُودعت — وصل رقم " + str((st["receipt"] or {}).get("receipt_number", ""))
            elif days_left is None:
                status_txt = "غير محدد"
            elif days_left < 0:
                status_txt = f"متأخرة بـ {abs(days_left)} يوم"
            else:
                status_txt = f"باقي {days_left} يوم"

            status_item = QTableWidgetItem(status_txt)
            status_item.setTextAlignment(Qt.AlignCenter)
            if st["state"] == "deposited":
                status_item.setBackground(QColor("#128456"))
                status_item.setForeground(QColor("white"))
            elif days_left is not None:
                if days_left < 0:
                    status_item.setBackground(QColor("#d03a50"))
                    status_item.setForeground(QColor("white"))
                elif days_left <= near_n:
                    status_item.setBackground(QColor("#b05c00"))
                    status_item.setForeground(QColor("white"))
                else:
                    status_item.setForeground(QColor("#128456"))
            table.setItem(row, len(self.COLUMNS) + 1, status_item)

        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        return table


# ======================================================================
#  بطاقة إحصائية قابلة للنقر
# ======================================================================

def _darken_hex(color, factor=0.8):
    """يُغمّق لوناً سداسياً (#rrggbb) بنسبة factor ليبقى الرقم الكبير مقروءاً على الخلفية البيضاء."""
    c = color.lstrip("#")
    if len(c) != 6:
        return color
    r, g, b = (int(c[i:i + 2], 16) for i in (0, 2, 4))
    return "#%02x%02x%02x" % (int(r * factor), int(g * factor), int(b * factor))


class StatCard(QFrame):
    """بطاقة إحصائية: أيقونة ملوّنة + رقم كبير + عنوان، بخلفية فاتحة بلون الحالة. قابلة للنقر."""

    clicked = pyqtSignal()

    def __init__(self, title, color, icon="fa5s.folder"):
        super().__init__()
        self.setObjectName("statCard")
        self.setFixedHeight(150)
        self.setCursor(QCursor(Qt.PointingHandCursor))
        soft, line = tint(color, 0.90), tint(color, 0.70)
        # محدد مرتبط باسم الكائن حتى لا تتسرّب القاعدة إلى الأبناء (QLabel)
        self.setStyleSheet(f"""
            QFrame#statCard {{
                background-color:{soft}; border:1px solid {line}; border-radius:16px;
            }}
            QFrame#statCard:hover {{
                background-color:{tint(color, 0.82)}; border:1px solid {color};
            }}
            QFrame#statCard QLabel {{ background:transparent; border:none; }}
        """)
        figure_color = figure(color)

        v = QVBoxLayout(self)
        v.setContentsMargins(18, 14, 18, 12)
        v.setSpacing(2)

        top = QHBoxLayout()
        top.addWidget(icon_badge(icon, "#ffffff", color, 40, 12, 18))
        top.addStretch(1)
        arrow = QLabel()
        arrow.setPixmap(qta.icon("fa5s.chevron-left" if is_rtl() else "fa5s.chevron-right",
                                 color=tint(color, 0.35)).pixmap(12, 12))
        top.addWidget(arrow)
        v.addLayout(top)

        self.value_label = QLabel("0")
        self.value_label.setFont(QFont("Segoe UI", 28, QFont.Bold))
        self.value_label.setStyleSheet("color:%s;" % figure_color)
        self.value_label.setAlignment(lead_align())
        v.addWidget(self.value_label)

        self.title_label = QLabel(title)
        self.title_label.setFont(QFont("Segoe UI", 11, QFont.Bold))
        self.title_label.setWordWrap(True)
        self.title_label.setStyleSheet("color:%s;" % T.TEXT)
        self.title_label.setAlignment(lead_align())
        v.addWidget(self.title_label)

    def set_value(self, value):
        animate_number(self.value_label, value)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit()
        super().mouseReleaseEvent(event)


# ======================================================================
#  نافذة تعديل معلومات الخبير
# ======================================================================

class EditExpertDialogHome(QWidget):
    """نافذة تعديل معلومات الخبير (تعمل من الصفحة الرئيسية دون فتح MainApp)."""

    def __init__(self, parent):
        super().__init__()
        self.setLayoutDirection(Qt.RightToLeft)
        self.parent = parent
        self.setWindowTitle("تعديل معلومات الخبير")
        self.setGeometry(420, 240, 500, 470)
        self.setStyleSheet("QWidget{background:#f4f5ff;}")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(12)

        header = QLabel("تعديل معلومات الخبير")
        header.setFont(QFont("Segoe UI", 14, QFont.Bold))
        header.setStyleSheet("color:#4338ca; background:transparent; border:none;")
        layout.addWidget(header)

        data = storage.load_expert_info()

        self.name_input = QLineEdit(data.get("name", ""))
        self.job_input = QLineEdit(data.get("job", ""))
        self.address_input = QLineEdit(data.get("address", ""))
        self.phone_input = QLineEdit(data.get("phone", ""))
        self.fax_input = QLineEdit(data.get("fax", ""))
        self.email_input = QLineEdit(data.get("email", ""))

        field_style = (
            "QLineEdit{background:white;border:1px solid #cdd3ee;border-radius:6px;"
            "padding:8px;font-size:11pt;color:#1f2347;}"
            "QLineEdit:focus{border:1px solid #5a4ee3;}"
        )

        form = QFormLayout()
        form.setSpacing(11)
        form.setLabelAlignment(Qt.AlignRight)
        for label_text, field in [
            ("الاسم و اللقب :", self.name_input),
            ("الصفة :", self.job_input),
            ("العنوان :", self.address_input),
            ("الهاتف :", self.phone_input),
            ("الفاكس :", self.fax_input),
            ("البريد الإلكتروني :", self.email_input),
        ]:
            field.setStyleSheet(field_style)
            field.setMinimumHeight(36)
            lbl = QLabel(label_text)
            lbl.setFont(QFont("Segoe UI", 11, QFont.Bold))
            lbl.setStyleSheet("background:transparent; border:none; color:#1f2347;")
            form.addRow(lbl, field)
        layout.addLayout(form)
        layout.addStretch()

        save_btn = QPushButton("حفظ")
        save_btn.setIcon(qta.icon("fa5s.save", color="white"))
        save_btn.setMinimumHeight(42)
        save_btn.setCursor(QCursor(Qt.PointingHandCursor))
        save_btn.setStyleSheet(
            "QPushButton{background:#128456;color:white;padding:9px;border-radius:6px;"
            "font-size:12pt;font-weight:bold;}"
            "QPushButton:hover{background:#0f7a52;}"
        )
        save_btn.clicked.connect(self.save_data)
        layout.addWidget(save_btn)

    def save_data(self):
        data = {
            "name": self.name_input.text(),
            "job": self.job_input.text(),
            "address": self.address_input.text(),
            "phone": self.phone_input.text(),
            "fax": self.fax_input.text(),
            "email": self.email_input.text(),
        }
        storage.save_expert_info(data)
        self.parent.refresh_expert_card()
        self.close()


# ======================================================================
#  الصفحة الرئيسية للملف
# ======================================================================

class DossierHomePage(QMainWindow):

    CARD_FRAME_STYLE = """
        QFrame#cardFrame {
            background:white;
            border-radius:12px;
            border:1px solid #e4e7f7;
        }
    """

    def __init__(self, current_user=None):
        super().__init__()
        self.current_user = current_user or {"username": "admin", "role": "admin"}

        dossier_name = storage.get_current_dossier_name() or "بدون اسم"
        self.W = storage.unit_words(dossier_name)   # مصطلحات حسب نوع الملف
        self.setWindowTitle(f"الصفحة الرئيسية — {dossier_name}")
        self.setGeometry(110, 50, 1200, 830)
        self.setMinimumSize(1000, 680)
        self.setStyleSheet(f"QMainWindow{{background:{T.BG};}}")

        central = QWidget()
        self.setCentralWidget(central)
        outer = QVBoxLayout(central)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        self._build_hero(dossier_name)

        # منطقة قابلة للتمرير حتى لا تُقصّ المحتويات على الشاشات الصغيرة
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet(f"QScrollArea{{background:{T.BG};border:none;}}")
        # اتجاه شريط التمرير ثابت؛ اتجاه الأقسام يُضبط صراحةً في كل صف (انظر _dir)
        scroll.setLayoutDirection(Qt.LeftToRight)

        scroll_content = QWidget()
        scroll_content.setObjectName("homeContent")
        scroll_content.setStyleSheet(f"QWidget#homeContent{{background-color:{T.BG};}}")
        page_row = QHBoxLayout(scroll_content)
        page_row.setContentsMargins(24, 22, 24, 22)
        page_row.setSpacing(0)
        # عمود محتوى متمركز بعرض أقصى: على الشاشات الكبيرة لا تتمدد البطاقات بلا نهاية
        column = QWidget()
        column.setMaximumWidth(1180)
        column.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        main_layout = QVBoxLayout(column)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(18)
        page_row.addStretch(1)
        page_row.addWidget(column, 100)
        page_row.addStretch(1)
        main_layout.addWidget(self._hero)

        scroll.setWidget(scroll_content)
        outer.addWidget(scroll)

        top_row = QHBoxLayout()
        top_row.setSpacing(18)
        top_row.setDirection(self._dir())
        main_layout.addLayout(top_row)
        self._init_expert_card(top_row)
        self._init_years_and_court_section(top_row)
        self._init_stats_section(main_layout)
        main_layout.addStretch()

        self.refresh_years_list()
        self.refresh_court_combo()
        self.refresh_stats_court_filter()
        self.refresh_stats()

    # ------------------------------------------------------------------
    @staticmethod
    def _dir():
        """اتجاه الصفوف: عربي RTL (أول عنصر يميناً)، وغيره LTR."""
        return QBoxLayout.RightToLeft if is_rtl() else QBoxLayout.LeftToRight

    def _card_title(self, text, icon, color=None):
        color = color or T.ACCENT
        row = QHBoxLayout()
        row.setSpacing(12)
        row.addWidget(icon_badge(icon, color, tint(color, 0.88), 38, 12, 18))
        tt = QLabel(text)
        tt.setAlignment(lead_align())
        tt.setFont(QFont("Segoe UI", 13, QFont.Bold))
        tt.setStyleSheet(f"color:{T.INK}; background:transparent; border:none;")
        row.addWidget(tt)
        row.addStretch(1)
        return row

    def _chip(self, text=""):
        c = QLabel(text)
        c.setStyleSheet(
            "background: rgba(255,255,255,46); color: white; border: none; border-radius: 13px;"
            " padding: 5px 14px; font-size: 10pt; font-weight: 600;")
        return c

    def _build_hero(self, dossier_name):
        """لوحة الترحيب: اسم الملف + تحية الخبير + السنة والمحكمة النشطتان + زر الدخول الرئيسي."""
        hero = GradientBanner(radius=22, margins=(30, 20, 30, 24), spacing=8)
        hero.setLayoutDirection(Qt.RightToLeft if is_rtl() else Qt.LeftToRight)
        self._hero = hero

        top = QHBoxLayout()
        cap = QLabel("الصفحة الرئيسية")
        cap.setStyleSheet(f"color:{T.TEXT_ON_DARK_MUTED}; font-size:10.5pt; font-weight:600;")
        top.addWidget(cap)
        top.addStretch(1)
        switch_btn = QPushButton("تبديل الملف")
        switch_btn.setIcon(qta.icon("fa5s.exchange-alt", color="white"))
        switch_btn.setMinimumHeight(36)
        switch_btn.setCursor(QCursor(Qt.PointingHandCursor))
        switch_btn.setStyleSheet(
            "QPushButton{background:rgba(255,255,255,40);color:white;padding:6px 18px;"
            "border:1px solid rgba(255,255,255,90);border-radius:12px;font-size:10.5pt;}"
            "QPushButton:hover{background:rgba(255,255,255,80);}")
        switch_btn.setProperty("_mt_styled", True)
        switch_btn.clicked.connect(self.switch_dossier)
        from theme_manager import make_theme_button
        top.addWidget(make_theme_button(self, "glass"))
        top.addWidget(switch_btn)
        hero.body.addLayout(top)

        mid = QHBoxLayout()
        mid.setSpacing(20)
        col = QVBoxLayout()
        col.setSpacing(4)
        title = QLabel(dossier_name)
        title.setWordWrap(True)
        title.setStyleSheet("color:white; font-size:25pt; font-weight:700;")
        col.addWidget(title)
        self.hero_greeting = QLabel("")
        self.hero_greeting.setStyleSheet(f"color:{T.TEXT_ON_DARK_MUTED}; font-size:11.5pt;")
        col.addWidget(self.hero_greeting)
        chips = QHBoxLayout()
        chips.setSpacing(8)
        self.year_chip = self._chip()
        self.court_chip = self._chip()
        chips.addWidget(self.year_chip)
        chips.addWidget(self.court_chip)
        chips.addStretch(1)
        col.addSpacing(6)
        col.addLayout(chips)
        mid.addLayout(col, 1)

        self.enter_btn = QPushButton("الدخول إلى صفحة العمل")
        self.enter_btn.setIcon(qta.icon("fa5s.arrow-left" if is_rtl() else "fa5s.arrow-right", color=T.PRIMARY_DARK))
        self.enter_btn.setIconSize(QSize(18, 18))
        self.enter_btn.setFixedHeight(58)
        self.enter_btn.setMinimumWidth(230)
        style_white_button(self.enter_btn, radius=16, padding="12px 26px")
        self.enter_btn.setFont(QFont("Segoe UI", 12, QFont.Bold))
        self.enter_btn.clicked.connect(self.enter_workspace)
        mid.addWidget(self.enter_btn, 0, Qt.AlignBottom)
        hero.body.addLayout(mid)

    def _refresh_hero_chips(self):
        year = storage.get_current_year() or "—"
        try:
            court = storage.get_current_court() or ""
        except Exception:
            court = ""
        self.year_chip.setText(f"سنة العمل: {year}")
        self.court_chip.setText(f"{self.W['unit']}: {court}" if court else f"{self.W['unit']}: —")

    # ------------------------------------------------------------------
    def _init_expert_card(self, layout):
        frame = Card(margins=(24, 20, 24, 20), spacing=14)
        frame.setLayoutDirection(Qt.RightToLeft if is_rtl() else Qt.LeftToRight)
        outer_v = frame.body
        outer_v.addLayout(self._card_title("مكتب المحاسبة و الخبرة القضائية", "fa5s.briefcase"))

        line = QFrame()
        line.setObjectName("sep")
        line.setFixedHeight(1)
        line.setStyleSheet(f"QFrame#sep{{background:{T.BORDER};border:none;}}")
        outer_v.addWidget(line)

        self.expert_name_lbl = QLabel()
        self.expert_job_lbl = QLabel()
        self.expert_address_lbl = QLabel()
        self.expert_phone_lbl = QLabel()
        self.expert_fax_lbl = QLabel()
        self.expert_email_lbl = QLabel()

        # (أيقونة، لون، تسمية، قيمة): كل صف بمربع أيقونة ملوّن بخلفية فاتحة
        rows = [
            ("fa5s.user-tie", T.ACCENT, "الاسم و اللقب :", self.expert_name_lbl),
            ("fa5s.id-badge", T.PURPLE, "الصفة :", self.expert_job_lbl),
            ("fa5s.map-marker-alt", T.CORAL, "العنوان :", self.expert_address_lbl),
            ("fa5s.phone-alt", T.SUCCESS, "الهاتف :", self.expert_phone_lbl),
            ("fa5s.fax", T.GOLD, "الفاكس :", self.expert_fax_lbl),
            ("fa5s.envelope", T.TEAL, "البريد الإلكتروني :", self.expert_email_lbl),
        ]
        for icon_name, color, label_text, value_lbl in rows:
            row = QHBoxLayout()
            row.setSpacing(12)
            row.addWidget(icon_badge(icon_name, color, tint(color, 0.88), 34, 11, 15), 0, Qt.AlignTop)
            col = QVBoxLayout()
            col.setSpacing(0)
            key_lbl = QLabel(label_text)
            key_lbl.setFont(QFont("Segoe UI", 9, QFont.Bold))
            key_lbl.setStyleSheet(f"color:{T.TEXT_MUTED}; background:transparent; border:none;")
            key_lbl.setAlignment(lead_align())
            value_lbl.setAlignment(lead_align())
            value_lbl.setFont(QFont("Segoe UI", 11))
            value_lbl.setWordWrap(True)
            value_lbl.setStyleSheet(f"color:{T.TEXT}; background:transparent; border:none;")
            value_lbl.setTextInteractionFlags(Qt.TextSelectableByMouse)
            col.addWidget(key_lbl)
            col.addWidget(value_lbl)
            row.addLayout(col, 1)
            outer_v.addLayout(row)

        outer_v.addStretch(1)

        btn_row = QHBoxLayout()
        edit_btn = QPushButton("تعديل المعلومات")
        edit_btn.setIcon(qta.icon("fa5s.user-edit", color=T.ACCENT))
        edit_btn.setMinimumHeight(40)
        style_soft_button(edit_btn, "info", radius=12, padding="8px 20px")
        edit_btn.clicked.connect(self.open_edit_expert)
        btn_row.addWidget(edit_btn)
        btn_row.addStretch()
        outer_v.addLayout(btn_row)

        layout.addWidget(frame, 4)
        self.refresh_expert_card()

    def refresh_expert_card(self):
        data = storage.load_expert_info()
        self.expert_name_lbl.setText(data.get("name", "") or "—")
        self.expert_job_lbl.setText(
            data.get("job", "") or "خبير قضائي لدى المجالس و المحاكم")
        self.expert_address_lbl.setText(data.get("address", "") or "—")
        self.expert_phone_lbl.setText(data.get("phone", "") or "—")
        self.expert_fax_lbl.setText(data.get("fax", "") or "—")
        self.expert_email_lbl.setText(data.get("email", "") or "—")
        who = (data.get("name", "") or "").strip()
        if hasattr(self, "hero_greeting"):
            self.hero_greeting.setText(f"مرحباً {who}" if who else "مرحباً بك")

    def open_edit_expert(self):
        self.edit_window = EditExpertDialogHome(self)
        self.edit_window.show()

    # ------------------------------------------------------------------
    @staticmethod
    def _combo_style():
        return f"""
            QComboBox {{
                background:white;
                border:2px solid {T.BORDER};
                border-radius:12px;
                padding:6px 12px;
                font-size:11pt;
                color:{T.TEXT};
            }}
            QComboBox:hover {{ border:2px solid {T.BORDER_STRONG}; }}
            QComboBox:focus {{ border:2px solid {T.ACCENT}; }}
            QComboBox QAbstractItemView {{
                background:white;
                selection-background-color:{T.ACCENT};
                selection-color:white;
                font-size:11pt;
            }}
        """

    # ------------------------------------------------------------------
    def _init_years_and_court_section(self, layout):
        frame = Card(margins=(24, 20, 24, 20), spacing=14)
        frame.setLayoutDirection(Qt.RightToLeft if is_rtl() else Qt.LeftToRight)
        v = frame.body
        v.addLayout(self._card_title("سنة العمل والمحكمة", "fa5s.calendar-alt", T.TEAL))

        row = QHBoxLayout()
        row.setSpacing(16)

        self.years_list = QListWidget()
        self.years_list.setMinimumHeight(150)
        self.years_list.setSelectionMode(QAbstractItemView.SingleSelection)
        self.years_list.setStyleSheet(f"""
            QListWidget {{
                background:white;
                border:1px solid {T.BORDER};
                border-radius:14px;
                font-size:12pt;
                padding:6px;
                color:{T.TEXT};
                outline:0;
            }}
            QListWidget::item {{ padding:11px 12px; margin:2px 0; border-radius:10px; }}
            QListWidget::item:hover {{ background:{T.HOVER_BG}; }}
            QListWidget::item:selected {{ background:{T.ACCENT}; color:white; }}
        """)
        self.years_list.itemSelectionChanged.connect(self.on_year_selected)
        row.addWidget(self.years_list, stretch=1)

        controls_col = QVBoxLayout()
        controls_col.setSpacing(10)

        self.new_year_input = QLineEdit()
        self.new_year_input.setMinimumHeight(38)
        # سنوات فقط: أرقام (4 خانات كحد أقصى) — لا يقبل الحقل حروفاً ولا رموزاً
        self.new_year_input.setValidator(QRegExpValidator(QRegExp(r"^\d{0,4}$"), self.new_year_input))
        self.new_year_input.setMaxLength(4)
        self.new_year_input.setPlaceholderText("2026")
        self.new_year_input.setAlignment(Qt.AlignCenter)
        self.new_year_input.setInputMethodHints(Qt.ImhDigitsOnly)
        self.new_year_input.returnPressed.connect(self.add_year)
        controls_col.addWidget(self.new_year_input)

        add_year_btn = QPushButton("إضافة سنة")
        add_year_btn.setIcon(qta.icon("fa5s.plus", color="white"))
        add_year_btn.setMinimumHeight(38)
        style_button(add_year_btn, "info", radius=8, padding="7px 14px")
        add_year_btn.clicked.connect(self.add_year)
        controls_col.addWidget(add_year_btn)

        self.close_year_btn = QPushButton("إقفال السنة المختارة")
        self.close_year_btn.setIcon(qta.icon("fa5s.lock", color=T.DANGER))
        self.close_year_btn.setMinimumHeight(38)
        style_soft_button(self.close_year_btn, "danger", radius=8, padding="7px 14px")
        self.close_year_btn.clicked.connect(self.close_selected_year)
        controls_col.addWidget(self.close_year_btn)

        self.reopen_year_btn = QPushButton("إعادة فتح السنة المختارة")
        self.reopen_year_btn.setIcon(qta.icon("fa5s.lock-open", color=T.SECONDARY))
        self.reopen_year_btn.setMinimumHeight(38)
        style_soft_button(self.reopen_year_btn, "secondary", radius=8, padding="7px 14px")
        self.reopen_year_btn.clicked.connect(self.reopen_selected_year)
        controls_col.addWidget(self.reopen_year_btn)

        controls_col.addStretch()
        controls_host = QWidget()
        controls_host.setLayout(controls_col)
        controls_host.setFixedWidth(250)
        controls_host.setStyleSheet("background:transparent;")
        row.addWidget(controls_host)
        v.addLayout(row)

        sep = QFrame()
        sep.setObjectName("sep2")
        sep.setFixedHeight(1)
        sep.setStyleSheet(f"QFrame#sep2{{background:{T.BORDER};border:none;}}")
        v.addWidget(sep)

        # --- اختيار المحكمة الافتراضية لهذه السنة ---
        unit_lbl = QLabel(f"{self.W['unit']} :")
        unit_lbl.setFont(QFont("Segoe UI", 10, QFont.Bold))
        unit_lbl.setStyleSheet(f"color:{T.TEXT_MUTED}; background:transparent; border:none;")
        v.addWidget(unit_lbl)

        court_row = QHBoxLayout()
        court_row.setSpacing(10)
        self.court_combo = QComboBox()
        self.court_combo.setEditable(True)
        self.court_combo.setMinimumWidth(200)
        self.court_combo.setToolTip(f"{self.W['unit']} النشط: كل القضايا والإحصائيات تخصه فقط")
        self.court_combo.setMinimumHeight(38)
        self.court_combo.setStyleSheet(self._combo_style())
        court_row.addWidget(self.court_combo, stretch=1)
        # اختيار محكمة من القائمة يفعّلها فوراً (القضايا/الإحصائيات/صفحة العمل)
        self.court_combo.activated.connect(self.on_court_chosen)

        save_court_btn = QPushButton(f"حفظ {self.W['unit']}")
        save_court_btn.setIcon(qta.icon("fa5s.check", color="white"))
        save_court_btn.setMinimumHeight(38)
        style_button(save_court_btn, "info", radius=8, padding="7px 14px")
        save_court_btn.clicked.connect(self.save_default_court)
        court_row.addWidget(save_court_btn)

        delete_court_btn = QPushButton(f"حذف {self.W['unit']}" if self.W["kind"] == "council" else "حذف المحكمة المختارة")
        delete_court_btn.setIcon(qta.icon("fa5s.trash", color=T.DANGER))
        delete_court_btn.setMinimumHeight(38)
        style_soft_button(delete_court_btn, "danger", radius=8, padding="7px 14px")
        delete_court_btn.clicked.connect(self.delete_selected_court)
        court_row.addWidget(delete_court_btn)

        v.addLayout(court_row)
        layout.addWidget(frame, 6)

    # ------------------------------------------------------------------
    def refresh_years_list(self):
        self.years_list.blockSignals(True)
        self.years_list.clear()
        years = storage.load_years()
        years_sorted = sorted(years, key=lambda y: y["year"], reverse=True)
        for y in years_sorted:
            status = "مُقفلة" if y.get("closed") else "مفتوحة"
            item = QListWidgetItem(f"{y['year']}      —      {status}")
            item.setData(Qt.UserRole, y["year"])
            self.years_list.addItem(item)

        current = storage.get_current_year()
        selected_row = None
        if current:
            for i in range(self.years_list.count()):
                if self.years_list.item(i).data(Qt.UserRole) == current:
                    selected_row = i
                    break
        if selected_row is None and self.years_list.count() > 0:
            selected_row = 0

        self.years_list.blockSignals(False)
        if selected_row is not None:
            self.years_list.setCurrentRow(selected_row)

    def selected_year(self):
        item = self.years_list.currentItem()
        return item.data(Qt.UserRole) if item else None

    def on_year_selected(self):
        year = self.selected_year()
        if not year:
            return
        storage.set_current_year(year)
        self.refresh_court_combo()
        self.refresh_stats_court_filter()
        self.refresh_stats()

    def add_year(self):
        year = self.new_year_input.text().strip()
        if not year:
            show_warning(self, "تنبيه", "الرجاء إدخال السنة.")
            return
        if not (year.isdigit() and len(year) == 4 and 1990 <= int(year) <= 2100):
            show_warning(self, "تنبيه", "أدخل سنة صحيحة من 4 أرقام (مثال: 2026).")
            return
        storage.add_year(year)
        self.new_year_input.clear()
        self.refresh_years_list()

    def close_selected_year(self):
        year = self.selected_year()
        if not year:
            show_warning(self, "تنبيه", "الرجاء اختيار سنة أولاً.")
            return
        reply = show_question(
            self, "تأكيد الإقفال",
            f"هل أنت متأكد من إقفال سنة {year}؟\n"
            "ستبقى بياناتها محفوظة، لكن يُفضّل عدم إضافة قضايا جديدة إليها بعد الإقفال."
        )
        if reply == QMessageBox.Yes:
            storage.close_year(year, True)
            self.refresh_years_list()

    def reopen_selected_year(self):
        year = self.selected_year()
        if not year:
            show_warning(self, "تنبيه", "الرجاء اختيار سنة أولاً.")
            return
        storage.close_year(year, False)
        self.refresh_years_list()

    def refresh_court_combo(self):
        self.court_combo.blockSignals(True)
        self.court_combo.clear()
        self.court_combo.addItems(storage.load_courts())
        active = storage.get_current_court() or storage.get_default_court()
        if active and active in storage.load_courts():
            self.court_combo.setCurrentText(active)
            if not storage.get_current_court():
                storage.set_current_court(active)
        self.court_combo.blockSignals(False)

    def _activate_court(self, court):
        storage.set_current_court(court)
        self.refresh_court_combo()
        self.refresh_stats_court_filter(force=court)
        self.refresh_stats()

    def on_court_chosen(self, _index=None):
        court = self.court_combo.currentText().strip()
        if court:
            self._activate_court(court)

    def save_default_court(self):
        """إضافة محكمة جديدة (أو تفعيل محكمة موجودة)."""
        court = self.court_combo.currentText().strip()
        if not court:
            return
        if not storage.get_current_year():
            show_warning(self, "تنبيه", "الرجاء اختيار سنة العمل أولاً.")
            return
        is_new = court not in storage.load_courts()
        self._activate_court(court)
        show_info(self, "تم", (f"تمت إضافة {self.W['unit']} وتفعيله: {court}" if is_new
                               else f"{self.W['unit']} النشط الآن: {court}"))

    def delete_selected_court(self):
        """يخفي المحكمة من القائمة. بياناتها تبقى محفوظة على القرص وتعود إن أُعيدت
        إضافة نفس الاسم."""
        court = self.court_combo.currentText().strip()
        if not court:
            return
        if court not in storage.load_courts():
            show_warning(self, "تنبيه", f"هذا {self.W['unit']} غير موجود في القائمة أصلاً." if self.W["kind"] == "council" else "هذه المحكمة غير موجودة في القائمة أصلاً.")
            return
        reply = show_question(
            self, "تأكيد الحذف",
            f'هل تريد حذف "{court}" من قائمة {self.W["units"]}؟\n'
            "(البيانات لا تُمسح من القرص؛ تعود كما كانت إذا أعدت إضافة نفس الاسم.)"
        )
        if reply != QMessageBox.Yes:
            return
        storage.delete_court(court)
        self.refresh_court_combo()
        self.refresh_stats_court_filter()
        self.refresh_stats()
        show_info(self, "تم", f'تم حذف "{court}" من قائمة {self.W["units"]}.')

    # ------------------------------------------------------------------
    #  قسم الإحصائيات (مرتبط بالمحكمة المختارة + بطاقات قابلة للنقر)
    # ------------------------------------------------------------------
    def _init_stats_section(self, layout):
        frame = Card(margins=(24, 20, 24, 22), spacing=16)
        frame.setLayoutDirection(Qt.RightToLeft if is_rtl() else Qt.LeftToRight)
        v = frame.body

        # --- العنوان (من أقصى اليمين في العربية) ---
        v.addLayout(self._card_title("إحصائيات القضايا", "fa5s.chart-bar", T.PURPLE))

        # --- مُصفّي المحكمة: في الوسط ---
        top_row = QHBoxLayout()
        top_row.setSpacing(12)
        top_row.addStretch(1)
        filter_lbl = QLabel(f"عرض إحصائيات {self.W['unit']} :")
        filter_lbl.setFont(QFont("Segoe UI", 10, QFont.Bold))
        filter_lbl.setStyleSheet(f"color:{T.TEXT_MUTED}; background:transparent; border:none;")
        top_row.addWidget(filter_lbl)

        self.stats_court_combo = QComboBox()
        self.stats_court_combo.setMinimumWidth(260)
        self.stats_court_combo.setMinimumHeight(38)
        self.stats_court_combo.setStyleSheet(self._combo_style())
        self.stats_court_combo.currentIndexChanged.connect(self.refresh_stats)
        top_row.addWidget(self.stats_court_combo)
        top_row.addStretch(1)
        v.addLayout(top_row)

        # --- البطاقات: الكل ← أُودع ← قريبة الإيداع ← متأخرة (الاتجاه يتبع اللغة) ---
        cards_layout = QHBoxLayout()
        cards_layout.setSpacing(14)

        self.card_cases = StatCard("عدد القضايا في هذه السنة", T.ACCENT, "fa5s.folder-open")
        self.card_near = StatCard("قريبة الإيداع (30 يوم أو أقل)", T.GOLD, "fa5s.hourglass-half")
        self.card_late = StatCard("متأخرة عن الإيداع", T.DANGER, "fa5s.exclamation-triangle")
        self.card_done = StatCard("أُودع تقريرها فعلاً", T.SUCCESS, "fa5s.check-double")

        self.card_cases.clicked.connect(lambda: self.show_cases_detail("all"))
        self.card_near.clicked.connect(lambda: self.show_cases_detail("near"))
        self.card_late.clicked.connect(lambda: self.show_cases_detail("late"))
        self.card_done.clicked.connect(lambda: self.show_cases_detail("done"))

        for card in (self.card_cases, self.card_done, self.card_near, self.card_late):
            cards_layout.addWidget(card, 1)
        v.addLayout(cards_layout)

        layout.addWidget(frame)

    def _load_cases_safe(self):
        try:
            return storage.load_cases() or []
        except Exception:
            return []

    def refresh_stats_court_filter(self, force=None):
        """قائمة إحصائيات المحاكم: \"جميع المحاكم\" + كل محكمة مسجّلة.
        تتبع افتراضياً المحكمة النشطة المختارة في الأعلى."""
        if not hasattr(self, "stats_court_combo"):
            return
        self.stats_court_combo.blockSignals(True)
        self.stats_court_combo.clear()
        self.stats_court_combo.addItem(f"جميع {self.W['units']}", "")
        for court in storage.load_courts():
            court = (court or "").strip()
            if court:
                self.stats_court_combo.addItem(court, court)
        target = force or storage.get_current_court() or ""
        idx = self.stats_court_combo.findData(target) if target else 0
        self.stats_court_combo.setCurrentIndex(idx if idx >= 0 else 0)
        self.stats_court_combo.blockSignals(False)

    def current_stats_court(self):
        if not hasattr(self, "stats_court_combo"):
            return ""
        return self.stats_court_combo.currentData() or ""

    def _cases_for_current_filter(self):
        """[(قضية, {رقم_القضية: وصل_الإيداع})] للمحكمة المختارة في الإحصائيات،
        أو لكل المحاكم عند اختيار \"جميع المحاكم\"، ولكل محكمة وصولاتها الخاصة."""
        selected = self.current_stats_court()
        courts = [selected] if selected else storage.load_courts()
        entries = []
        for court in courts:
            def _read():
                return storage.load_cases() or [], deposit_receipts()
            try:
                cases, receipts = storage.with_court(court, _read)
            except Exception:
                continue
            for c in cases:
                entries.append((c, receipts))
        return entries

    def refresh_stats(self):
        self._refresh_hero_chips()
        year = storage.get_current_year()
        if not year:
            return

        entries = self._cases_for_current_filter()
        near_n = near_days()
        kinds = [classify_case(c, r, near_n) for c, r in entries]
        self.card_near.title_label.setText(f"قريبة الإيداع ({near_n} يوم أو أقل)")

        self.card_cases.set_value(len(entries))
        self.card_near.set_value(kinds.count("near"))
        self.card_late.set_value(kinds.count("late"))
        self.card_done.set_value(kinds.count("done"))

    def show_cases_detail(self, kind):
        """يفتح نافذة بتفاصيل القضايا حسب التصنيف المطلوب."""
        year = storage.get_current_year()
        if not year:
            show_warning(self, "تنبيه", "الرجاء اختيار سنة العمل أولاً.")
            return

        entries = self._cases_for_current_filter()
        _nd = near_days()
        court = self.current_stats_court()
        court_txt = court if court else f"جميع {self.W['units']}"

        def pick(state):
            return [c for c, r in entries if classify_case(c, r, _nd) == state]

        if kind == "late":
            selected = pick("late")
            title = f"القضايا المتأخرة عن الإيداع — {court_txt} — سنة {year}"
            accent = "#d03a50"
        elif kind == "near":
            selected = pick("near")
            title = f"القضايا القريبة من الإيداع — {court_txt} — سنة {year}"
            accent = "#b05c00"
        elif kind == "done":
            selected = pick("done")
            title = f"القضايا المُودَع تقريرها فعلاً — {court_txt} — سنة {year}"
            accent = "#128456"
        else:
            selected = [c for c, _r in entries]
            title = f"جميع قضايا السنة — {court_txt} — سنة {year}"
            accent = "#5a4ee3"

        dlg = CasesDetailDialog(title, selected, accent=accent, parent=self)
        dlg.exec_()

    # ------------------------------------------------------------------
    def _init_enter_button(self, layout):
        """زر الدخول الرئيسي موجود الآن داخل لوحة الترحيب (انظر _build_hero)."""
        return

    def enter_workspace(self):
        year = self.selected_year()
        if not year:
            show_warning(
                self, "تنبيه",
                "الرجاء اختيار أو إضافة سنة عمل أولاً من القائمة أعلاه.")
            return

        storage.set_current_year(year)

        # لا ندخل صفحة العمل قبل تحديد المحكمة: كل بيانات العمل تخصها وحدها
        court = self.court_combo.currentText().strip()
        if not court:
            show_warning(
                self, "تنبيه",
                f"الرجاء اختيار {self.W['unit']} (أو كتابة اسمه ثم الضغط على \"حفظ {self.W['unit']}\") قبل الدخول.")
            return
        storage.set_current_court(court)

        from main_app import MainApp
        self.main_app = MainApp(current_user=self.current_user)
        self.main_app.showMaximized()
        self.close()

    def switch_dossier(self):
        from dossier_page import DossierPage
        storage.clear_current_year()
        storage.clear_current_court()
        storage.clear_current_dossier()
        self.dossier_page = DossierPage(current_user=self.current_user)
        self.dossier_page.show()
        self.close()
