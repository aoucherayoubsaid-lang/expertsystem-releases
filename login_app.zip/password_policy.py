# -*- coding: utf-8 -*-
"""سياسة كلمات المرور: نقطة واحدة تُفرض في storage وفي كل الواجهات.

المبدأ: لا يملك المستخدم حرية اختيار كلمة سر ضعيفة. أي كلمة مرور جديدة (مستخدم،
تغيير إجباري، استرجاع، كلمة مرور بدء التشغيل، كلمة مرور النسخ الاحتياطي) يجب أن:
  - لا تقل عن MIN_LENGTH حرفاً،
  - تجمع ثلاثة أصناف على الأقل من أربعة (صغيرة، كبيرة، أرقام، رموز)،
  - تضم MIN_UNIQUE حرفاً مختلفاً على الأقل،
  - لا تحتوي اسم المستخدم، ولا كلمة شائعة، ولا تسلسلاً أو تكراراً ظاهراً.
الأحرف العربية تُحسب ضمن صنف «الحروف الصغيرة» (لا تمييز بين كبيرها وصغيرها).
"""
import re
import unicodedata

MIN_LENGTH = 12
MIN_UNIQUE = 7
MIN_CLASSES = 3
MAX_LENGTH = 128

ANSWER_MIN_LENGTH = 6          # إجابة سؤال الأمان (مفتاح استرجاع، فيجب ألا تكون تافهة)

# كلمات شائعة تُرفض إن كانت هي الجزء الأكبر من كلمة المرور (تُقارن بعد حذف الأرقام والرموز)
_COMMON = {
    "password", "passw0rd", "admin", "administrator", "welcome", "letmein", "qwerty",
    "azerty", "azertyuiop", "qwertyuiop", "iloveyou", "monkey", "dragon", "master",
    "login", "abc", "secret", "changeme", "default", "expert", "expertise", "algerie",
    "algeria", "bismillah", "allah", "mohamed", "ahmed", "bureau", "office", "motdepasse",
    "كلمةالمرور", "كلمةالسر", "مكتب", "الخبير", "خبير", "الجزائر", "محمد", "احمد", "بسملة",
}
_SEQUENCES = (
    "abcdefghijklmnopqrstuvwxyz", "qwertyuiopasdfghjklzxcvbnm", "azertyuiopqsdfghjklmwxcvbn",
    "0123456789", "9876543210", "ابتثجحخدذرزسشصضطظعغفقكلمنهوي",
)


def _classes(pw):
    lower = any(c.islower() or (c.isalpha() and not c.isupper()) for c in pw)
    upper = any(c.isupper() for c in pw)
    digit = any(c.isdigit() for c in pw)
    symbol = any(not c.isalnum() for c in pw)
    return lower, upper, digit, symbol


def _has_sequence(pw, run=4):
    low = pw.lower()
    for seq in _SEQUENCES:
        for i in range(len(seq) - run + 1):
            chunk = seq[i:i + run]
            if chunk in low or chunk[::-1] in low:
                return True
    return False


def _core(pw):
    """الكلمة بعد حذف الأرقام والرموز وتوحيد الحالة، لمطابقتها مع الكلمات الشائعة."""
    s = unicodedata.normalize("NFKC", pw).lower()
    s = s.translate(str.maketrans("01345$@!", "oleasaai"))
    return re.sub(r"[^a-z؀-ۿ]", "", s)


def check(password, username=""):
    """يرجع (ok, [أسباب الرفض بالعربية])."""
    problems = []
    pw = password or ""
    if len(pw) < MIN_LENGTH:
        problems.append("طولها %d حرفاً؛ المطلوب %d على الأقل" % (len(pw), MIN_LENGTH))
    if len(pw) > MAX_LENGTH:
        problems.append("أطول من الحد المسموح (%d)" % MAX_LENGTH)
    if sum(_classes(pw)) < MIN_CLASSES:
        problems.append("اجمع %d أصناف على الأقل من: أحرف صغيرة، أحرف كبيرة، أرقام، رموز (مثل ! @ #)" % MIN_CLASSES)
    if len(set(pw)) < MIN_UNIQUE:
        problems.append("أحرفها متشابهة جداً (المطلوب %d أحرف مختلفة على الأقل)" % MIN_UNIQUE)
    if re.search(r"(.)\1{2,}", pw):
        problems.append("تكرر الحرف نفسه ثلاث مرات متتالية أو أكثر")
    if _has_sequence(pw):
        problems.append("تحتوي تسلسلاً سهلاً (مثل 1234 أو abcd أو qwer)")
    u = (username or "").strip().lower()
    if len(u) >= 3 and u in pw.lower():
        problems.append("تحتوي اسم المستخدم")
    core = _core(pw)
    if core:
        for w in _COMMON:
            if w in core and len(w) * 2 >= len(core):
                problems.append("مبنية على كلمة شائعة يسهل تخمينها")
                break
    return (not problems), problems


def explain(problems):
    return "كلمة المرور ضعيفة:\n• " + "\n• ".join(problems)


def requirements_text():
    return ("كلمة المرور يجب أن تكون %d حرفاً على الأقل وتجمع %d أصناف من: أحرف صغيرة، أحرف كبيرة، "
            "أرقام، رموز. لا تستعمل اسمك أو كلمة شائعة أو تسلسلاً مثل 1234." % (MIN_LENGTH, MIN_CLASSES))


def check_answer(answer):
    """إجابة سؤال الأمان: ليست فارغة ولا قصيرة ولا شائعة."""
    a = " ".join((answer or "").split()).lower()
    problems = []
    if len(a) < ANSWER_MIN_LENGTH:
        problems.append("إجابة سؤال الأمان قصيرة (%d أحرف على الأقل)" % ANSWER_MIN_LENGTH)
    if len(set(a)) < 4:
        problems.append("إجابة سؤال الأمان بسيطة جداً")
    if _core(a) in _COMMON or a in ("1234", "123456", "0000"):
        problems.append("إجابة سؤال الأمان شائعة يسهل تخمينها")
    return (not problems), problems


class WeakPassword(ValueError):
    """تُرفع من storage عند محاولة حفظ كلمة مرور لا تطابق السياسة."""
    def __init__(self, problems):
        self.problems = list(problems)
        super().__init__(explain(self.problems))
