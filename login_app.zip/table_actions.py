# -*- coding: utf-8 -*-
"""
أدوات مشتركة لتبويبات الإيداع (كشف الأتعاب / تسديد الأتعاب / وصل الإيداع):
- شريط أزرار موحّد تحت الجدول: حفظ | تعديل | حذف | (إضافة مرفق).
- حوار مرفق صغير (اختيار ملف / مسح ضوئي / إزالة) يُستعمل داخل نوافذ التعديل.
"""
import os
import platform
import subprocess

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QHBoxLayout, QPushButton, QLabel
import qtawesome as qta

from modern_theme import style_button
from msgbox_ltr import show_warning


def build_action_bar(on_save=None, on_edit=None, on_delete=None,
                     on_attach_scan=None, on_attach_file=None, parent=None):
    """يبني شريط أزرار ويُرجع (layout, buttons_dict).
    الزر غير المطلوب (callback=None) لا يُنشأ. زر المرفق بقائمة: مسح ضوئي / ملف من الجهاز."""
    bar = QHBoxLayout()
    bar.setSpacing(8)
    buttons = {}

    def _mk(key, text, icon, kind, cb):
        b = QPushButton(text)
        b.setIcon(qta.icon(icon, color="white"))
        b.setMinimumHeight(38)
        b.setCursor(Qt.PointingHandCursor)
        style_button(b, kind, radius=8, padding="8px 16px")
        b.clicked.connect(cb)
        bar.addWidget(b)
        buttons[key] = b

    if on_save:
        _mk("save", "حفظ", "fa5s.save", "success", on_save)
    if on_edit:
        _mk("edit", "تعديل", "fa5s.edit", "info", on_edit)
    if on_delete:
        _mk("delete", "حذف", "fa5s.trash-alt", "danger", on_delete)
    if on_attach_scan and on_attach_file:
        b = QPushButton("إضافة مرفق")
        b.setIcon(qta.icon("fa5s.paperclip", color="white"))
        b.setMinimumHeight(38)
        style_button(b, "purple", radius=8, padding="8px 16px")
        from scan_utils import attach_menu_for_button
        buttons["_attach_menu"] = attach_menu_for_button(
            b, parent, on_scan=on_attach_scan, on_pick_file=on_attach_file)
        bar.addWidget(b)
        buttons["attach"] = b
    bar.addStretch()
    return bar, buttons


def open_file(parent, path):
    """يفتح ملفاً بالبرنامج الافتراضي للنظام مع رسالة خطأ واضحة عند الفشل."""
    try:
        import safe_open
        safe_open.open_path(path)
    except Exception as e:
        show_warning(parent, "خطأ", f"تعذر فتح المرفق:\n{e}")


class AttachmentPicker:
    """حالة مرفق داخل نافذة تعديل: path (المسار الحالي/الجديد) + label لعرضه."""

    def __init__(self, dialog, current_path="", suggested_name="مرفق"):
        self.dialog = dialog
        self.path = current_path or ""
        self.is_new = False            # True إذا اختار المستخدم ملفاً جديداً لم يُنسخ بعد
        self.suggested_name = suggested_name
        self.label = QLabel()
        self._refresh()

    def _refresh(self):
        if self.path:
            self.label.setText(f"مرفق: {os.path.basename(self.path)}")
            self.label.setStyleSheet("color:#128456; font-weight:bold;")
        else:
            self.label.setText("لا يوجد مرفق")
            self.label.setStyleSheet("color:#5b6485;")

    def pick_file(self):
        from scan_utils import pick_existing_file
        p = pick_existing_file(self.dialog, "اختر صورة أو PDF")
        if p:
            self.path, self.is_new = p, True
            self._refresh()

    def scan(self):
        from scan_utils import scan_document
        p = scan_document(self.dialog, suggested_name=self.suggested_name)
        if p:
            self.path, self.is_new = p, True
            self._refresh()

    def clear(self):
        self.path, self.is_new = "", False
        self._refresh()

    def build_row(self):
        """صف جاهز (label + زر مرفق بقائمة + إزالة) لإضافته إلى QFormLayout."""
        row = QHBoxLayout()
        row.addWidget(self.label, 1)
        btn = QPushButton("إرفاق")
        btn.setIcon(qta.icon("fa5s.paperclip", color="#4338ca"))
        from scan_utils import attach_menu_for_button
        self._menu = attach_menu_for_button(btn, self.dialog, on_scan=self.scan, on_pick_file=self.pick_file)
        clear = QPushButton("إزالة")
        clear.clicked.connect(self.clear)
        row.addWidget(btn)
        row.addWidget(clear)
        return row
