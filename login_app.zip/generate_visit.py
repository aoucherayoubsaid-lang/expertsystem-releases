"""محضر الانتقال - قالب جديد. نفس الواجهة السابقة: generate_visit_report(data) -> (html_path, pdf_path)"""
import html as _h
import storage
import report_output as ro
import doc_signing

DOC_TYPE = "محضر انتقال"


def _e(v):
    return _h.escape(str(v if v is not None else ""))


def generate_visit_report(data):
    intro = _e(f"{data['intro_text']}{data.get('notes', '')}").replace("\n", "<br>")
    date = _e(data.get("date", "") or "....................")
    try:
        size = int(data.get("font_size", 19))
    except (TypeError, ValueError):
        size = 19
    font = _h.escape(str(data.get("font_family") or storage.get_font_family()), quote=True)

    page = f"""<!DOCTYPE html>
<html dir="rtl" lang="ar"><head><meta charset="utf-8">
<style>
@page {{ size: A4; margin: 0; }}
body {{ margin:0; padding:0; direction:rtl; font-family:"{font}", Tahoma, sans-serif; color:#222; }}
.sheet {{ margin:0; padding:38px 52px 30px 52px; }}
.band {{ background:#7a2e3a; height:12px; }}
.band2 {{ background:#d8b4ba; height:4px; margin-top:3px; }}
.id td {{ vertical-align:middle; }}
.who {{ font-size:19px; font-weight:bold; color:#7a2e3a; }}
.role {{ font-size:12px; color:#666; }}
.contact {{ font-size:12px; color:#444; text-align:left; line-height:1.7; }}
.title {{ text-align:center; margin:26px 0 8px 0; font-size:24px; font-weight:bold; color:#7a2e3a; }}
.title-sub {{ text-align:center; font-size:12px; color:#888; margin-bottom:22px; }}
.meta {{ width:100%; border-collapse:collapse; margin-bottom:20px; }}
.meta td {{ border-bottom:1px solid #d8b4ba; padding:6px 4px; font-size:13px; }}
.meta td.k {{ color:#7a2e3a; font-weight:bold; width:15%; }}
.body {{ font-size:{size}px; line-height:2; text-align:justify; border-right:4px solid #d8b4ba; padding:6px 18px 6px 4px; min-height:560px; }}
.sig {{ width:100%; margin-top:30px; }}
.sig td {{ width:45%; text-align:center; font-weight:bold; font-size:14px; color:#7a2e3a; }}
</style></head>
<body>
<div class="band"></div><div class="band2"></div>
<div class="sheet">
<table class="id" style="width:100%"><tr>
<td><div class="who">{_e(data.get('expert_name'))}</div><div class="role">خبير قضائي في المحاسبة</div></td>
<td class="contact">{_e(data.get('expert_address'))}<br>الهاتف : {_e(data.get('expert_phone'))} &nbsp; الفاكس : {_e(data.get('expert_fax'))}</td>
</tr></table>

<div class="title">محضر انتقال</div>
<div class="title-sub">— إثبات الانتقال إلى عين المكان —</div>

<table class="meta"><tr>
<td class="k">رقم القضية</td><td>{_e(data.get('case_number'))}</td>
<td class="k">التاريخ</td><td>{date}</td>
</tr></table>

<div class="body">{intro}</div>

<table class="sig"><tr><td>الخبير</td><td>&nbsp;</td><td>المعني</td></tr></table>
</div>
</body></html>"""

    page = doc_signing.stamp_html(page, DOC_TYPE, data.get("case_number"), data.get("date"))
    html_file = ro.write_html("visit_report_result.html", page)
    options = {
        "page-size": "A4", "margin-top": "0mm", "margin-bottom": "0mm",
        "margin-left": "0mm", "margin-right": "0mm", "encoding": "UTF-8",
        "zoom": "1.0", "disable-smart-shrinking": None,
    }
    pdf = ro.html_to_pdf(html_file, "visit", f"visit_report_{ro.stamp()}.pdf", options=options)
    return (html_file, pdf)
