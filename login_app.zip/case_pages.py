from msgbox_ltr import show_info, show_warning, show_question
from PyQt5.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QLabel,
    QPushButton,
    QHBoxLayout,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QAbstractItemView,
    QFrame,
    QMessageBox,
    QDialog,
    QLineEdit,
    QTextEdit,
    QGridLayout,
    QListWidget,
    QInputDialog,
)
from PyQt5.QtGui import QFont, QColor, QCursor
from PyQt5.QtCore import Qt, QEvent, QTimer
from PyQt5.QtWidgets import QScrollArea, QApplication
import qtawesome as qta
import datetime
import os
import platform
import subprocess
from storage import load_cases, save_cases
from case_status import case_status, deposit_receipts, near_days
import storage
from PyQt5.QtWidgets import QTabWidget, QWidget
from PyQt5.QtWidgets import QDateEdit
from PyQt5.QtGui import QDoubleValidator
from PyQt5.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QTabWidget,
    QWidget,
    QFormLayout,
    QLineEdit,
    QLabel,
    QPushButton,
    QDateEdit,
    QComboBox,
    QGroupBox,
    QTextEdit,
)
from PyQt5.QtGui import QDoubleValidator, QIntValidator, QFont
from PyQt5.QtCore import Qt, QDate
from excel_reports import generate_fees_excel
from modern_theme import style_button, style_soft_button
import os


# محاذاة نص خلايا جدول القضايا (غيّرها هنا فقط لتتغير في كل الجدول).
# مهم: Qt يعكس Right/Left تلقائياً في الواجهة العربية (RTL)، فكان Qt.AlignRight
# يظهر النص في أقصى اليسار. Qt.AlignLeading تعني "بداية الكتابة": أقصى اليمين
# في العربية، وأقصى اليسار في الفرنسية/الإنجليزية، تلقائياً بحسب لغة البرنامج.
#   لوضع النص في الوسط:  Qt.AlignCenter
CELL_ALIGN = Qt.AlignLeading | Qt.AlignVCenter
# أعمدة النصوص الطويلة (المدعي، المدعى عليه، المحكمة/المجلس): تلتف على أسطر
# بدل أن يُقطع نصها، ولا يتجاوز عرضها الحد التالي (بالبكسل).
WRAP_COLUMNS = (4, 5, 6)
MAX_WRAP_WIDTH = 260


class ManageSectionsDialog(QDialog):
    """نافذة لإدارة قائمة الأقسام (المحكمة) أو الغرف (المجلس القضائي):
    إضافة، تعديل الاسم، حذف، وتغيير الترتيب. كل تغيير يُحفظ فوراً."""

    def __init__(self, parent=None):
        super().__init__(parent)
        words = storage.unit_words()
        self._single = words["section"]                       # القسم / الغرفة
        self._plural = "الغرف" if words["kind"] == "council" else "الأقسام"
        self.setWindowTitle(f"إدارة {self._plural}")
        self.resize(420, 440)
        self.setLayoutDirection(Qt.RightToLeft)

        lay = QVBoxLayout(self)
        lay.addWidget(QLabel(f"قائمة {self._plural} المعروضة في صفحة القضايا:"))

        self.list = QListWidget()
        self.list.setLayoutDirection(Qt.RightToLeft)
        self.list.addItems(storage.load_sections())
        lay.addWidget(self.list)

        row1 = QHBoxLayout()
        for text, icon, handler in (
            ("إضافة", "fa5s.plus", self.add_item),
            ("تعديل الاسم", "fa5s.edit", self.rename_item),
            ("حذف", "fa5s.trash", self.delete_item),
        ):
            b = QPushButton(text)
            b.setIcon(qta.icon(icon, color="white"))
            b.clicked.connect(handler)
            row1.addWidget(b)
        lay.addLayout(row1)

        row2 = QHBoxLayout()
        up = QPushButton("▲ للأعلى")
        up.clicked.connect(lambda: self.move_item(-1))
        down = QPushButton("▼ للأسفل")
        down.clicked.connect(lambda: self.move_item(1))
        close = QPushButton("إغلاق")
        close.clicked.connect(self.accept)
        row2.addWidget(up)
        row2.addWidget(down)
        row2.addStretch(1)
        row2.addWidget(close)
        lay.addLayout(row2)

    def _names(self):
        return [self.list.item(i).text() for i in range(self.list.count())]

    def _save(self):
        storage.save_sections(self._names())

    def add_item(self):
        name, ok = QInputDialog.getText(self, f"إضافة {self._single}", f"اسم {self._single} الجديد:")
        name = (name or "").strip()
        if not ok or not name:
            return
        if name in self._names():
            show_warning(self, "تنبيه", "هذا الاسم موجود مسبقاً.")
            return
        self.list.addItem(name)
        self._save()

    def rename_item(self):
        item = self.list.currentItem()
        if item is None:
            show_warning(self, "تنبيه", f"اختر {self._single} أولاً.")
            return
        name, ok = QInputDialog.getText(
            self, f"تعديل اسم {self._single}", "الاسم الجديد:", text=item.text())
        name = (name or "").strip()
        if not ok or not name or name == item.text():
            return
        if name in self._names():
            show_warning(self, "تنبيه", "هذا الاسم موجود مسبقاً.")
            return
        item.setText(name)
        self._save()

    def delete_item(self):
        item = self.list.currentItem()
        if item is None:
            show_warning(self, "تنبيه", f"اختر {self._single} أولاً.")
            return
        reply = show_question(
            self, "تأكيد الحذف",
            f'هل تريد حذف "{item.text()}" من القائمة؟\n'
            "(القضايا المسجلة سابقاً لا تتأثر.)")
        if reply != QMessageBox.Yes:
            return
        self.list.takeItem(self.list.row(item))
        self._save()

    def move_item(self, delta):
        row = self.list.currentRow()
        new = row + delta
        if row < 0 or new < 0 or new >= self.list.count():
            return
        item = self.list.takeItem(row)
        self.list.insertItem(new, item)
        self.list.setCurrentRow(new)
        self._save()


class AddEditCaseDialog(QDialog):
    def __init__(self, parent=None, case_data=None):
        super().__init__(parent)
        self.setWindowTitle("إضافة / تعديل قضية")
        self.resize(550, 500)
        # اتجاه النافذة عربي (من اليمين لليسار) — كان مفقوداً هنا، ولهذا
        # كانت قيم الحقول (خصوصاً الأرقام والتواريخ) تظهر بمحاذاة يسار
        # رغم أن باقي نوافذ البرنامج تفرض هذا الاتجاه صراحةً.
        self.setLayoutDirection(Qt.RightToLeft)
        self.setStyleSheet(
            """
            QDialog {
                background-color: #fefefe;
                border-radius: 12px;
            }
            QLabel {
                font-weight: bold;
                font-size: 12pt;
                color: #1f2347;
            }
            QLineEdit {
                padding: 8px;
                border: 1px solid #cdd3ee;
                border-radius: 6px;
                font-size: 11pt;
            }
            QPushButton {
                background-color: #4338ca;
                color: white;
                padding: 10px 18px;
                border-radius: 6px;
                font-size: 11pt;
            }
            QPushButton:hover {
                background-color: #4338ca;
            }
        """
        )

        # Layout principal
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(15)

        # Titre
        header = QLabel("الرجاء ملء معلومات القضية:")
        header.setFont(QFont("Segoe UI", 13, QFont.Bold))
        main_layout.addWidget(header)

        # Scroll Area
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        main_layout.addWidget(scroll_area)

        scroll_content = QWidget()
        scroll_area.setWidget(scroll_content)

        scroll_layout = QVBoxLayout(scroll_content)
        scroll_layout.setContentsMargins(0, 0, 0, 0)
        scroll_layout.setSpacing(15)

        # Carte de formulaire
        card = QFrame()
        # ملاحظة: QLabel يرث من QFrame، لذلك نربط القاعدة باسم الكائن
        # (#formCard) حتى لا تُطبَّق على التسميات داخل البطاقة فتظهر
        # داخل مستطيلات فارغة.
        card.setObjectName("formCard")
        card.setStyleSheet(
            """
            QFrame#formCard {
                background-color: #f1f2ff;
                border: 1px solid #eef0ff;
                border-radius: 10px;
                padding: 20px;
            }
        """
        )
        form_layout = QGridLayout(card)
        form_layout.setVerticalSpacing(12)
        form_layout.setHorizontalSpacing(15)

        # Champs de formulaire
        self.inputs = {}
        labels = [
            ("رقم القضية", "case_number"),
            ("رقم الفهرس", "index_number"),
            ("رقم الغرفة", "room_number"),
            ("تاريخ الجلسة", "session_date"),
            (storage.unit_words()["unit"], "court"),
            (storage.unit_words()["section"], "section"),
            ("المدعي", "plaintiff"),
            ("المدعى عليه", "defendant"),
            ("تاريخ استلام القضية", "receive_date"),
            ("مدة إنجاز الخبرة (بالأشهر)", "duration_months"),
        ]

        for i, (label_text, key) in enumerate(labels):
            label = QLabel(label_text)
            if key == "section":
                # قائمة قابلة للتعديل: تسمح باختيار قسم موجود أو كتابة قسم
                # جديد يُضاف تلقائياً لقائمة الاقتراحات لاحقاً
                input_field = QComboBox()
                input_field.setEditable(True)
                input_field.addItems(storage.load_sections())
                input_field.lineEdit().setLayoutDirection(Qt.RightToLeft)
                input_field.lineEdit().setAlignment(Qt.AlignRight | Qt.AlignAbsolute | Qt.AlignVCenter)
            else:
                input_field = QLineEdit()
                input_field.setPlaceholderText(f"أدخل {label_text}")
                # نفرض محاذاة يمين صريحة للنص المكتوب داخل الحقل، حتى لا
                # تُعرض القيم الرقمية/التواريخ بمحاذاة يسار (الأرقام لا
                # تُعتبر نصاً عربياً بحد ذاتها فلا يكتشف Qt اتجاهها تلقائياً).
                input_field.setAlignment(Qt.AlignRight | Qt.AlignAbsolute | Qt.AlignVCenter)
            self.inputs[key] = input_field
            form_layout.addWidget(label, i, 0)
            form_layout.addWidget(input_field, i, 1)
            if key == "section":
                manage_btn = QPushButton()
                manage_btn.setIcon(qta.icon("fa5s.cog", color="#1f2347"))
                manage_btn.setToolTip(
                    "إدارة الغرف" if storage.unit_words()["kind"] == "council" else "إدارة الأقسام")
                manage_btn.setCursor(QCursor(Qt.PointingHandCursor))
                manage_btn.setFixedWidth(40)
                manage_btn.clicked.connect(self.manage_sections)
                form_layout.addWidget(manage_btn, i, 2)

        scroll_layout.addWidget(card)

        # Boutons d'action
        button_layout = QHBoxLayout()
        save_btn = QPushButton("حفظ القضية")
        save_btn.setIcon(qta.icon("fa5s.save", color="white"))
        save_btn.clicked.connect(self.accept)
        button_layout.addWidget(save_btn, 0, Qt.AlignRight)
        button_layout.addStretch(1)
        main_layout.addLayout(button_layout)

        # Remplir les champs s'il y a des données
        if case_data:
            for key, value in case_data.items():
                if key in self.inputs:
                    field = self.inputs[key]
                    if isinstance(field, QComboBox):
                        field.setCurrentText(value or "")
                    else:
                        field.setText(value)

        # المحكمة ثابتة = المحكمة النشطة المختارة من الصفحة الرئيسية. القضية تُحفظ
        # ضمن بيانات هذه المحكمة فقط، لذلك لا يمكن تغيير الحقل من هنا.
        try:
            active_court = storage.get_current_court()
            if active_court and "court" in self.inputs:
                self.inputs["court"].setText(active_court)
                self.inputs["court"].setReadOnly(True)
                self.inputs["court"].setStyleSheet("background:#f1f2ff;color:#5b6485;")
        except RuntimeError:
            pass

    def manage_sections(self):
        combo = self.inputs["section"]
        current = combo.currentText()
        ManageSectionsDialog(self).exec_()
        combo.clear()
        combo.addItems(storage.load_sections())
        combo.setCurrentText(current)

    def get_data(self):
        data = {}
        for k, field in self.inputs.items():
            if isinstance(field, QComboBox):
                data[k] = field.currentText().strip()
            else:
                data[k] = field.text()
        return data


class CaseManagementPage(QWidget):
    def __init__(self, main_app):
        super().__init__()
        self.main_app = main_app
        self._suppress_alert_banner = bool(getattr(main_app, "_suppress_case_alert_banner", False))

        self.setStyleSheet("background-color: #f8f9ff;")
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(20, 20, 20, 20)
        self.layout.setSpacing(15)

        title = QLabel("إدارة القضايا")
        title.setFont(QFont("Segoe UI", 16, QFont.Bold))
        self.layout.addWidget(title)

        self._status_filter = None
        self._report_map = {}
        self.init_alert_banner()
        self.init_search_bar()
        self.init_table()
        self.init_controls()

        self.load_data()

    def load_data(self):
        cases = load_cases()
        self.table.setRowCount(0)
        receipts = deposit_receipts()
        near = near_days()
        self._report_map = self._build_report_map()
        dirty = False

        for case in cases:
            row_position = self.table.rowCount()
            self.table.insertRow(row_position)

            for col, key in enumerate(
                [
                    "case_number",
                    "index_number",
                    "room_number",
                    "session_date",
                    "court",
                    "plaintiff",
                    "defendant",
                    "receive_date",
                    "duration_months",
                ]
            ):
                item = QTableWidgetItem(case.get(key, ""))
                # محاذاة يمين صريحة: الجدول يرث اتجاه LTR من QTabWidget الأب
                # (مفروض عمداً لإصلاح مشكلة عدم استجابة التبويبات مع RTL)،
                # فتُصبح محاذاة الخلايا الافتراضية يسارية ما لم تُحدَّد صراحة.
                item.setTextAlignment(CELL_ALIGN)
                self.table.setItem(row_position, col, item)

            # عمود "تاريخ الإيداع": يُشتق من وصل الإيداع + الأجل + إعدادات التنبيه
            dep_item = self._deposit_item(case, receipts, near)
            self.table.setItem(row_position, 9, dep_item)
            # قيم قديمة ملوّثة بنص العرض (مثل "(أجل تقديري)") تُصحَّح: التاريخ الفعلي من الوصل فقط
            if (case.get("submission_date") or "") != (dep_item.data(Qt.UserRole) or ""):
                dirty = True
            section_item = QTableWidgetItem(case.get("section", ""))
            section_item.setTextAlignment(CELL_ALIGN)
            # خلفية بيضاء صريحة: تفادياً لأي تلوّن غير مقصود يتسرّب من العمود
            # المجاور (كان يظهر على بعض الأجهزة قبل هذا التحديد الصريح).
            section_item.setBackground(QColor("white"))
            self.table.setItem(row_position, 10, section_item)

            self.add_details_button(row_position)
            self.add_fees_button(row_position)
            self.add_report_button(row_position, case.get("case_number", ""))

        if dirty:
            self.save_all_cases()
        self.refresh_alert_banner()
        self.schedule_fit()

    def show_alert_banner(self):
        """إظهار شريط التنبيه الصغير بعد التنبيه الكبير، عند العودة إلى القضايا."""
        self._suppress_alert_banner = False
        self.refresh_alert_banner()

    def init_search_bar(self):
        search_layout = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText(f"ابحث برقم القضية أو الطرف أو {storage.unit_words()['unit']}...")
        self.search_input.textChanged.connect(self.filter_table)
        search_layout.addWidget(self.search_input)
        self.layout.addLayout(search_layout)

    def init_table(self):
        self.table = QTableWidget(0, 14)
        self.table.setHorizontalHeaderLabels(
            [
                "رقم القضية",
                "رقم الفهرس",
                "رقم الغرفة",
                "تاريخ الجلسة",
                storage.unit_words()["unit"],
                "المدعي",
                "المدعى عليه",
                "تاريخ الاستلام",
                "مدة الإنجاز (أشهر)",
                "تاريخ الإيداع",
                storage.unit_words()["section"],
                "تفاصيل",
                "كشف الأتعاب",
                "الخبرة",
            ]
        )
        self.table.setStyleSheet(
            """
            QTableWidget {
                background-color: white;
                border: 1px solid #e4e7f7;
                border-radius: 8px;
            }
            QHeaderView::section {
                background-color: #4338ca;
                color: white;
                padding: 8px;
                font-weight: bold;
            }
            QTableWidget::item:hover {
                background-color: #f1f2ff;
            }
        """
        )
        # لا نستعمل Stretch (أعمدة متساوية العرض) لأنه يقطع النص عند تكبير الخط.
        # العرض يُحسب من محتوى كل عمود وعنوانه (انظر fit_table)، وتبقى الأعمدة
        # قابلة للسحب يدوياً. النص الطويل يلتف على عدة أسطر وترتفع الصفوف تلقائياً.
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.Interactive)
        hh.setStretchLastSection(False)
        hh.setMinimumSectionSize(60)
        self.table.setProperty("_no_autofit", True)   # لهذا الجدول ضبطه الخاص (fit_table)
        self.table.setWordWrap(True)
        self.table.setTextElideMode(Qt.ElideNone)
        vh = self.table.verticalHeader()
        vh.setMinimumSectionSize(40)
        vh.setDefaultSectionSize(40)
        vh.setSectionResizeMode(QHeaderView.ResizeToContents)
        self._fit_pending = False
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.layout.addWidget(self.table)

    # ------------------------------------------------------------------
    #  ضبط أعمدة الجدول حسب الخط والمحتوى
    # ------------------------------------------------------------------
    def schedule_fit(self):
        """يؤجل ضبط الأعمدة لحظة واحدة (يجمع عدة أحداث متتالية في ضبط واحد)."""
        if getattr(self, "_fit_pending", False):
            return
        self._fit_pending = True
        QTimer.singleShot(30, self.fit_table)

    def fit_table(self):
        self._fit_pending = False
        t = self.table
        hh = t.horizontalHeader()
        auto_cols = (9, 11, 12, 13)     # تاريخ الإيداع + أعمدة الأزرار
        for col in auto_cols:
            hh.setSectionResizeMode(col, QHeaderView.ResizeToContents)

        widths = {}
        for col in range(t.columnCount()):
            if col in auto_cols:
                continue
            hh.setSectionResizeMode(col, QHeaderView.Interactive)
            w = max(hh.sectionSizeHint(col), t.sizeHintForColumn(col) + 24)
            if col in WRAP_COLUMNS:
                w = min(w, MAX_WRAP_WIDTH)
            widths[col] = max(w, 60)

        # إن بقيت مساحة فارغة في عرض الجدول نوزعها على الأعمدة النصية بالتناسب
        fixed = sum(hh.sectionSize(c) for c in auto_cols)
        total = fixed + sum(widths.values())
        free = t.viewport().width() - total
        if free > 0 and widths:
            base = sum(widths.values())
            for col in widths:
                widths[col] += int(free * widths[col] / base)

        for col, w in widths.items():
            hh.resizeSection(col, w)
        t.resizeRowsToContents()

    def showEvent(self, event):
        super().showEvent(event)
        self.schedule_fit()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.schedule_fit()

    def changeEvent(self, event):
        # تغيير نوع/حجم الخط من الإعدادات يصل كحدث خط أو نمط -> نعيد ضبط الأعمدة
        super().changeEvent(event)
        if event.type() in (QEvent.FontChange, QEvent.ApplicationFontChange, QEvent.StyleChange):
            self.schedule_fit()

    def init_controls(self):
        control_layout = QHBoxLayout()

        # المحاسب (accountant) لا يملك صلاحية edit_cases: يرى الجدول ويستعمل
        # زر "كشف الأتعاب" فقط، دون إضافة/تعديل/حذف القضايا نفسها.
        current_user = getattr(self.main_app, "current_user", None)
        can_edit = storage.user_can(current_user, "edit_cases")

        if can_edit:
            add_btn = QPushButton("إضافة")
            add_btn.setIcon(qta.icon("fa5s.plus", color="white"))
            add_btn.setStyleSheet(self.button_style("#128456"))
            add_btn.clicked.connect(self.add_case)

            edit_btn = QPushButton("تعديل")
            edit_btn.setIcon(qta.icon("fa5s.edit", color="white"))
            edit_btn.setStyleSheet(self.button_style("#5a4ee3"))
            edit_btn.clicked.connect(self.edit_case)

            delete_btn = QPushButton("حذف")
            delete_btn.setIcon(qta.icon("fa5s.trash", color="white"))
            delete_btn.setStyleSheet(self.button_style("#d03a50"))
            delete_btn.clicked.connect(self.delete_case)

            control_layout.addWidget(add_btn)
            control_layout.addWidget(edit_btn)
            control_layout.addWidget(delete_btn)
        else:
            import license_manager as _lm
            hint = QLabel("وضع القراءة فقط — انتهت الفترة التجريبية. فعّل البرنامج من «مساعدة ← الترخيص والتفعيل»"
                          if _lm.is_read_only() else "وضع القراءة فقط — لا تملك صلاحية تعديل القضايا")
            hint.setStyleSheet("color:#5b6485; font-size:9pt;")
            control_layout.addWidget(hint)

        ai_btn = QPushButton("إعداد الغلاف والتقرير (AI)")
        ai_btn.setIcon(qta.icon("fa5s.magic", color="white"))
        ai_btn.setStyleSheet(self.button_style("#0e7490"))
        ai_btn.clicked.connect(self.open_ai_report)
        control_layout.addWidget(ai_btn)

        control_layout.addStretch()
        self.layout.addLayout(control_layout)

    def button_style(self, color):
        return f"""
            QPushButton {{
                background-color: {color};
                color: white;
                padding: 8px 15px;
                border-radius: 6px;
            }}
            QPushButton:hover {{
                background-color: #1f2347;
            }}
        """

    def add_case(self):
        if not storage.user_can(getattr(self.main_app, "current_user", None), "edit_cases"):
            show_warning(self, "غير مصرح", "لا تملك صلاحية إضافة قضايا.")
            return
        dialog = AddEditCaseDialog(self)
        if dialog.exec_() == QDialog.Accepted:
            data = dialog.get_data()

            # حفظ اسم المحكمة والقسم في قوائم الاقتراحات لهذا الملف (Dossier)
            if data.get("court"):
                try:
                    storage.add_court(data["court"])
                except RuntimeError:
                    pass
            if data.get("section"):
                try:
                    storage.add_section(data["section"])
                except RuntimeError:
                    pass

            row_position = self.table.rowCount()
            self.table.insertRow(row_position)

            for col, key in enumerate(
                [
                    "case_number",
                    "index_number",
                    "room_number",
                    "session_date",
                    "court",
                    "plaintiff",
                    "defendant",
                    "receive_date",
                    "duration_months",
                ]
            ):
                item = QTableWidgetItem(data[key])
                item.setTextAlignment(CELL_ALIGN)
                self.table.setItem(row_position, col, item)

            self.table.setItem(row_position, 9, self._deposit_item(data))
            section_item = QTableWidgetItem(data.get("section", ""))
            section_item.setTextAlignment(CELL_ALIGN)
            section_item.setBackground(QColor("white"))
            self.table.setItem(row_position, 10, section_item)
            self.add_details_button(row_position)
            self.add_fees_button(row_position)
            self.add_report_button(row_position, data["case_number"])

            self.save_all_cases()

    # ------------------------------------------------------------------
    # حالة الإيداع (مبنية على وصل الإيداع + الأجل + عدد أيام التنبيه في الإعدادات)
    # ------------------------------------------------------------------
    def _deposit_item(self, case, receipts=None, near=None):
        st = case_status(case, receipts, near)
        state = st["state"]
        item = QTableWidgetItem("")
        item.setTextAlignment(Qt.AlignCenter)
        item.setData(Qt.UserRole, "")            # تاريخ الإيداع الفعلي (من الوصل فقط)
        item.setData(Qt.UserRole + 1, state)     # الحالة (للتصفية والتنبيه)
        deadline = st["deadline"].strftime("%d/%m/%Y") if st["deadline"] else ""
        days = st["days_left"]
        bold = QFont("Segoe UI", 9, QFont.Bold)

        if state == "deposited":
            rec = st["receipt"] or {}
            date = str(rec.get("date", "") or "")
            item.setText(f"{date}  ✔ تم الإيداع".strip())
            item.setData(Qt.UserRole, date)
            item.setBackground(QColor("#c8f7c5"))
            item.setForeground(QColor("#0f7a52"))
            item.setFont(bold)
            item.setToolTip(f"أُودع تقرير الخبرة — وصل رقم {rec.get('receipt_number', '')}")
        elif state == "late":
            item.setText(f"{deadline}  ⚠ متأخرة {abs(days)} يوم")
            item.setBackground(QColor("#f5b7b1"))
            item.setForeground(QColor("#b1243c"))
            item.setFont(bold)
            item.setToolTip("انقضى الأجل ولم يصدر وصل إيداع تقرير الخبرة لهذه القضية.")
        elif state == "near":
            item.setText(f"{deadline}  ● آخر يوم اليوم" if days == 0 else f"{deadline}  ● باقي {days} يوم")
            item.setBackground(QColor("#fdebd0"))
            item.setForeground(QColor("#c2410c"))
            item.setFont(bold)
            item.setToolTip("اقترب أجل إيداع الخبرة ولم يصدر وصل الإيداع بعد.")
        elif state == "ok":
            item.setText(f"{deadline}")
        return item

    def _row_case(self, row):
        def txt(col):
            it = self.table.item(row, col)
            return it.text() if it else ""
        return {
            "case_number": txt(0), "receive_date": txt(7), "duration_months": txt(8),
        }

    def refresh_deposit_column(self):
        """يُستدعى بعد إصدار/تغيير وصل إيداع: يعيد حساب عمود الإيداع لكل القضايا ويحفظ."""
        receipts = deposit_receipts()
        near = near_days()
        self.table.blockSignals(True)
        for row in range(self.table.rowCount()):
            self.table.setItem(row, 9, self._deposit_item(self._row_case(row), receipts, near))
        self.table.blockSignals(False)
        self.save_all_cases()

    # ------------------------------------------------------------------
    # شريط التنبيه (متأخرة / قريبة الإيداع)
    # ------------------------------------------------------------------
    def init_alert_banner(self):
        self.alert_banner = QFrame()
        self.alert_banner.setObjectName("alertBanner")
        lay = QHBoxLayout(self.alert_banner)
        lay.setContentsMargins(14, 10, 14, 10)
        lay.setSpacing(10)
        self.alert_icon = QLabel()
        lay.addWidget(self.alert_icon)
        self.alert_text = QLabel()
        self.alert_text.setWordWrap(True)
        lay.addWidget(self.alert_text, stretch=1)

        def chip(text, state):
            b = QPushButton(text)
            b.setCursor(QCursor(Qt.PointingHandCursor))
            b.setStyleSheet("QPushButton{background:white;border:1px solid #e4e7f7;border-radius:12px;"
                            "padding:5px 14px;font-weight:bold;color:#1f2347;}"
                            "QPushButton:hover{background:#f8f9ff;}")
            b.clicked.connect(lambda: self.set_status_filter(state))
            return b

        self.btn_show_late = chip("عرض المتأخرة", "late")
        self.btn_show_near = chip("عرض القريبة", "near")
        self.btn_show_all = chip("إظهار الكل", None)
        for b in (self.btn_show_late, self.btn_show_near, self.btn_show_all):
            lay.addWidget(b)
        self.alert_banner.hide()

    def set_status_filter(self, state):
        self._status_filter = state
        self.filter_table()
        self.refresh_alert_banner()

    def refresh_alert_banner(self):
        if not hasattr(self, "alert_banner"):
            return
        if getattr(self, "_suppress_alert_banner", False):
            self.alert_banner.hide()
            return
        late = near = 0
        for row in range(self.table.rowCount()):
            it = self.table.item(row, 9)
            state = it.data(Qt.UserRole + 1) if it else None
            late += state == "late"
            near += state == "near"
        if not (late or near):
            self._status_filter = None
            self.alert_banner.hide()
            return

        parts = []
        if late:
            parts.append(f"<b>{late}</b> قضية متأخرة عن الإيداع")
        if near:
            parts.append(f"<b>{near}</b> قضية قريبة الإيداع (خلال {near_days()} يوماً)")
        red = late > 0
        bg, border, color = ("#ffe8ec", "#e6b0aa", "#b1243c") if red else ("#fff6e0", "#f5cba7", "#c2410c")
        self.alert_banner.setStyleSheet(
            f"QFrame#alertBanner{{background:{bg};border:1px solid {border};border-radius:8px;}}"
            f"QLabel{{background:transparent;color:{color};font-size:11pt;}}")
        self.alert_icon.setPixmap(qta.icon("fa5s.exclamation-triangle", color=color).pixmap(22, 22))
        self.alert_text.setText("  ·  ".join(parts) + "  —  لم يصدر وصل إيداع تقرير الخبرة لها بعد")
        self.btn_show_late.setVisible(bool(late))
        self.btn_show_near.setVisible(bool(near))
        self.btn_show_all.setVisible(self._status_filter is not None)
        self.alert_banner.show()

    # ------------------------------------------------------------------
    # زر الخبرة: يفتح ملف الخبرة (PDF) المرفق في صفحة إعداد التقرير
    # ------------------------------------------------------------------
    @staticmethod
    def _build_report_map():
        """{رقم القضية: مسار ملف الخبرة (PDF أولاً ثم Word)} للملفات الموجودة فعلاً."""
        result = {}
        try:
            from report_files_page import _normalize_records
            for case, docs in _normalize_records(storage.load_reports()).items():
                for slot in ("pdf", "edit"):
                    path = docs["report"][slot]
                    if path and os.path.exists(path):
                        result[case] = path
                        break
        except Exception:
            pass
        return result

    def add_report_button(self, row, case_number):
        case_number = str(case_number).strip()
        path = self._report_map.get(case_number, "")
        btn = QPushButton("الخبرة")
        if path:
            is_pdf = path.lower().endswith(".pdf")
            btn.setIcon(qta.icon("fa5s.file-pdf" if is_pdf else "fa5s.file-word", color="#d03a50" if is_pdf else "#2b579a"))
            btn.setStyleSheet("QPushButton{background:#ffe8ec;color:#b1243c;font-weight:bold;"
                              "border:1px solid #f1b0a8;border-radius:6px;padding:5px 14px;}"
                              "QPushButton:hover{background:#fadbd8;}")
            btn.setToolTip(os.path.basename(path))
        else:
            btn.setIcon(qta.icon("fa5s.file", color="#bcc3e4"))
            btn.setStyleSheet("QPushButton{background:#f8f9ff;color:#9aa3c7;border:1px dashed #d5daf0;border-radius:6px;padding:5px 14px;}")
            btn.setToolTip("لا توجد خبرة مرفقة — أضفها من تبويب إعداد التقرير")
        btn.clicked.connect(lambda _, n=case_number: self.open_case_report(n))
        self.table.setCellWidget(row, 13, btn)
        self._fit_action_columns()

    def open_ai_report(self):
        row = self.table.currentRow()
        item = self.table.item(row, 0) if row >= 0 else None
        number = item.text() if item else None
        try:
            page = getattr(self.main_app, "ai_report_page", None)
            if page is not None:                       # الصفحة المخصّصة في القائمة الجانبية
                page.select_case(number)
                self.main_app.tabs.setCurrentWidget(page)
                return
            from report_dialog import ReportDialog
            ReportDialog(self, case_number=number).exec_()
        except Exception as e:
            show_warning(self, "خطأ", f"تعذر فتح نافذة الذكاء الاصطناعي:\n{e}")

    def open_case_report(self, case_number):
        path = self._build_report_map().get(str(case_number).strip(), "")
        if not path:
            show_info(
                self, "الخبرة",
                f"لا توجد خبرة مرفقة للقضية {case_number}.\nأضفها من تبويب «إعداد التقرير».")
            return
        try:
            import safe_open
            safe_open.open_path(path)
        except Exception as e:
            show_warning(self, "خطأ", f"تعذر فتح الملف:\n{e}")

    def add_details_button(self, row):
        details_btn = QPushButton("تفاصيل")
        details_btn.setIcon(qta.icon("fa5s.info-circle", color="#4338ca"))
        style_soft_button(details_btn, "info", radius=6, padding="5px 14px")
        details_btn.clicked.connect(lambda _, r=row: self.view_case_details(r))
        self.table.setCellWidget(row, 11, details_btn)

    def open_fees_window(self, row):
        if not storage.user_can(getattr(self.main_app, "current_user", None), "view_fees"):
            show_warning(self, "غير مصرح", "لا تملك صلاحية الاطّلاع على الأتعاب.")
            return
        case_number = self.table.item(row, 0).text()
        self.fees_window = FeesWindow(
         self,
         row,
         case_number,
         self.main_app.fees_status_page,
         self.main_app.payments_page
        )
        self.fees_window.exec_()

    def add_fees_button(self, row):
        # المساعد لا يرى الشؤون المالية: لا زر "كشف الأتعاب" في صفّه
        if not storage.user_can(getattr(self.main_app, "current_user", None), "view_fees"):
            return
        btn = QPushButton("كشف الأتعاب")
        btn.setIcon(qta.icon("fa5s.money-bill-wave", color="white"))
        style_button(btn, "success", radius=6, padding="5px 14px")
        btn.setToolTip("فتح كشف الأتعاب لهذه القضية")
        btn.clicked.connect(lambda checked, r=row: self.open_fees_window(r))
        self.table.setCellWidget(row, 12, btn)
        self._fit_action_columns()

    def _fit_action_columns(self):
        """أعمدة الأزرار (تفاصيل / كشف الأتعاب / الخبرة) تتسع لنص الزر كاملاً
        (بدل التمدد المتساوي الذي كان يقصّ اسم \"كشف الأتعاب\")."""
        hh = self.table.horizontalHeader()
        for col in (11, 12, 13):
            hh.setSectionResizeMode(col, QHeaderView.ResizeToContents)

    def edit_case(self):
        if not storage.user_can(getattr(self.main_app, "current_user", None), "edit_cases"):
            show_warning(self, "غير مصرح", "لا تملك صلاحية تعديل القضايا.")
            return
        row = self.table.currentRow()
        if row < 0:
            show_warning(self, "خطأ", "يرجى اختيار صف لتعديله")
            return

        data = {
            "case_number": self.table.item(row, 0).text(),
            "index_number": self.table.item(row, 1).text(),
            "room_number": self.table.item(row, 2).text(),
            "session_date": self.table.item(row, 3).text(),
            "court": self.table.item(row, 4).text(),
            "plaintiff": self.table.item(row, 5).text(),
            "defendant": self.table.item(row, 6).text(),
            "receive_date": self.table.item(row, 7).text(),
            "duration_months": self.table.item(row, 8).text(),
            "submission_date": (self.table.item(row, 9).data(Qt.UserRole) or "") if self.table.item(row, 9) else "",
            "section": self.table.item(row, 10).text() if self.table.item(row, 10) else "",
        }

        dialog = AddEditCaseDialog(self, data)
        if dialog.exec_() == QDialog.Accepted:
            new_data = dialog.get_data()

            for col, key in enumerate(
                [
                    "case_number",
                    "index_number",
                    "room_number",
                    "session_date",
                    "court",
                    "plaintiff",
                    "defendant",
                    "receive_date",
                    "duration_months",
                ]
            ):
                item = QTableWidgetItem(new_data[key])
                item.setTextAlignment(CELL_ALIGN)
                self.table.setItem(row, col, item)

            self.table.setItem(row, 9, self._deposit_item(new_data))
            self.add_report_button(row, new_data["case_number"])
            section_item = QTableWidgetItem(new_data.get("section", ""))
            section_item.setTextAlignment(CELL_ALIGN)
            section_item.setBackground(QColor("white"))
            self.table.setItem(row, 10, section_item)

            if new_data.get("section"):
                try:
                    storage.add_section(new_data["section"])
                except RuntimeError:
                    pass
            if new_data.get("court"):
                try:
                    storage.add_court(new_data["court"])
                except RuntimeError:
                    pass

            self.save_all_cases()
            try:
                storage.rename_case_note(data["case_number"], new_data["case_number"])
            except RuntimeError:
                pass
            self.schedule_fit()

    def delete_case(self):
        if not storage.user_can(getattr(self.main_app, "current_user", None), "edit_cases"):
            show_warning(self, "غير مصرح", "لا تملك صلاحية حذف القضايا.")
            return
        row = self.table.currentRow()
        if row < 0:
            show_warning(self, "خطأ", "يرجى اختيار صف لحذفه")
            return

        reply = show_question(
            self,
            "تأكيد الحذف",
            "هل أنت متأكد من حذف هذه القضية؟",
        )

        if reply == QMessageBox.Yes:
            deleted_number = self.table.item(row, 0).text() if self.table.item(row, 0) else ""
            self.table.removeRow(row)
            self.save_all_cases()
            try:
                storage.delete_case_note(deleted_number)
            except RuntimeError:
                pass
            show_info(self, "نجح", "تم حذف القضية بنجاح")

    def view_case_details(self, row):
        dialog = QDialog(self)
        dialog.setWindowTitle("تفاصيل القضية")
        dialog.resize(700, 600)

        # الخط العام
        font = QFont("Segoe UI", 10)

        # تصميم عصري بالـ QSS
        dialog.setStyleSheet(
            """
        QDialog { background-color: #f8f9ff; }
        QTabWidget::pane { border: 1px solid #bcc3e4; background: white; }
        QGroupBox {
            font-weight: bold;
            border: 1px solid #5a4ee3;
            border-radius: 8px;
            margin-top: 10px;
            padding: 10px;
            background-color: #f8f9ff;
        }
        QLabel { font-weight: bold; }
        QLineEdit, QDateEdit, QComboBox, QTextEdit {
            border: 1px solid #cdd3ee;
            border-radius: 5px;
            padding: 5px;
            background: white;
        }
        QPushButton {
            background-color: #5a4ee3;
            color: white;
            padding: 8px 14px;
            border-radius: 6px;
            font-weight: bold;
        }
        QPushButton:hover { background-color: #5a4ee3; }
    """
        )

        main_layout = QVBoxLayout(dialog)
        tabs = QTabWidget()

        # ================================
        # تبويب تفاصيل القضية
        # ================================
        tab_details = QWidget()
        tab1_layout = QVBoxLayout(tab_details)

        tasks_group = QGroupBox("المهام")
        tasks_layout = QVBoxLayout()
        tasks_input = QTextEdit("")
        tasks_input.setPlaceholderText("اكتب المهام هنا...")
        tasks_input.setFont(font)
        tasks_layout.addWidget(tasks_input)
        tasks_group.setLayout(tasks_layout)

        summary_group = QGroupBox("نبذة عن القضية")
        summary_layout = QVBoxLayout()
        summary_input = QTextEdit("")
        summary_input.setPlaceholderText("اكتب نبذة عن القضية هنا...")
        summary_input.setFont(font)

        # تحميل المحفوظ سابقاً لهذه القضية (إن وُجد)
        case_item = self.table.item(row, 0)
        case_number = case_item.text().strip() if case_item else ""
        try:
            saved_note = storage.get_case_note(case_number)
        except RuntimeError:
            saved_note = {"tasks": "", "summary": ""}
        tasks_input.setPlainText(saved_note.get("tasks", ""))
        summary_input.setPlainText(saved_note.get("summary", ""))
        summary_layout.addWidget(summary_input)
        summary_group.setLayout(summary_layout)

        tab1_layout.addWidget(tasks_group)
        tab1_layout.addWidget(summary_group)
        tabs.addTab(tab_details,"تفاصيل القضية")

        # زر حفظ
        save_button = QPushButton("حفظ")
        save_button.setIcon(qta.icon("fa5s.save", color="white"))
        save_button.setFont(font)
        save_button.setMinimumWidth(140)
        save_button.setMinimumHeight(38)
        save_button.setCursor(Qt.PointingHandCursor)
        style_button(save_button, "info", radius=8, padding="9px 18px")
        def save_case_details():
            try:
                storage.set_case_note(
                    case_number,
                    tasks_input.toPlainText(),
                    summary_input.toPlainText(),
                )
            except Exception as e:
                show_warning(dialog, "خطأ", f"تعذر حفظ التفاصيل:\n{e}")
                return
            show_info(dialog, "تم", "تم حفظ المهام ونبذة القضية بنجاح")
            dialog.accept()

        save_button.clicked.connect(save_case_details)

        # layout للأزرار: الزر أولاً ثم الفراغ المرن، حتى يظهر أقصى اليمين
        # في اتجاه RTL (Qt يعكس ترتيب QHBoxLayout تلقائياً في هذه الحالة).
        btn_layout = QHBoxLayout()
        btn_layout.addWidget(save_button)
        btn_layout.addStretch()

        # إضافة العناصر
        main_layout.addWidget(tabs)
        main_layout.addLayout(btn_layout)

        dialog.exec_()


    def filter_table(self):
        query = self.search_input.text().lower()
        status_filter = getattr(self, "_status_filter", None)
        for row in range(self.table.rowCount()):
            visible = False
            for col in [0, 1, 2, 3, 4, 5, 6, 10]:  # يشمل القسم (عمود 10) أيضًا
                item = self.table.item(row, col)
                if item and query in item.text().lower():
                    visible = True
                    break
            if visible and status_filter:
                dep = self.table.item(row, 9)
                visible = bool(dep) and dep.data(Qt.UserRole + 1) == status_filter
            # تم إصلاح الخطأ: يجب أن يكون هذا السطر داخل الحلقة الخارجية
            # حتى يُطبَّق على كل صف على حدة، وليس فقط على آخر صف
            self.table.setRowHidden(row, not visible)

    def reload(self):
        """إعادة تحميل بيانات القضايا (تُستدعى عند تبديل الملف/Dossier أو عند تفعيل التبويب)."""
        self.load_data()

    def save_all_cases(self):
        cases = []
        for row in range(self.table.rowCount()):
            case = {
                "case_number": self.table.item(row, 0).text(),
                "index_number": self.table.item(row, 1).text(),
                "room_number": self.table.item(row, 2).text(),
                "session_date": self.table.item(row, 3).text(),
                "court": self.table.item(row, 4).text(),
                "plaintiff": self.table.item(row, 5).text(),
                "defendant": self.table.item(row, 6).text(),
                "receive_date": self.table.item(row, 7).text(),
                "duration_months": self.table.item(row, 8).text(),
                "submission_date": (self.table.item(row, 9).data(Qt.UserRole) or "") if self.table.item(row, 9) else "",
                "section": self.table.item(row, 10).text() if self.table.item(row, 10) else "",
            }
            cases.append(case)
        save_cases(cases)
        self.refresh_alert_banner()
class FeesWindow(QDialog):
    def __init__(self, parent, row,case_number, fees_status_page, payments_page):
        super().__init__(parent)

        self.parent = parent
        self.row = row
        self.case_number = case_number
        self.fees_status_page = fees_status_page
        self.payments_page = payments_page

        self.setWindowTitle("كشف الأتعاب")
        # الحجم يتكيّف مع الشاشة: كان 760x780 ثابتاً فيتجاوز ارتفاع الشاشات الصغيرة
        # وتختفي الأزرار السفلية (حفظ / توليد Excel). الآن لا يتجاوز 90% من مساحة الشاشة
        # المتاحة، والحقول قابلة للتمرير بينما الأزرار ثابتة في الأسفل دائماً.
        screen = QApplication.primaryScreen().availableGeometry()
        self.resize(min(760, int(screen.width() * 0.92)), min(780, int(screen.height() * 0.90)))
        self.setMinimumSize(min(560, int(screen.width() * 0.9)), min(420, int(screen.height() * 0.8)))

        self.layout = QVBoxLayout(self)

        # =========================
        # TABS
        # =========================
        self.tabs = QTabWidget()
        # مهم: نضبط الخط عبر setFont (لا عبر stylesheet) حتى يحسب Qt
        # عرض كل تبويب بشكل صحيح فلا تُقصّ أسماء التبويبات.
        self.tabs.tabBar().setFont(QFont("Segoe UI", 11, QFont.Bold))
        self.tabs.tabBar().setElideMode(Qt.ElideNone)
        self.tabs.tabBar().setExpanding(False)
        self.tabs.tabBar().setUsesScrollButtons(True)
        self.layout.addWidget(self.tabs)

        # =========================
        # STYLE
        # =========================
        self.setStyleSheet("""
QDialog {
    background-color: #f4f5ff;
}

QGroupBox {
    font-weight: bold;
    border: 1px solid #5a4ee3;
    border-radius: 10px;
    margin-top: 10px;
    padding: 10px;
    background-color: white;
}

QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 5px;
}

QLineEdit {
    padding: 6px;
    border: 1px solid #cdd3ee;
    border-radius: 6px;
}

QPushButton {
    background-color: #128456;
    color: white;
    padding: 10px;
    border-radius: 8px;
    font-weight: bold;
}

QPushButton:hover {
    background-color: #0f7a52;
}
""")

        # =====================================================
        # TAB 1: كشف الأتعاب (نفس تصميمك الأصلي)
        # =====================================================
        # التبويب مقسوم إلى: منطقة تمرير للحقول + شريط أزرار ثابت بالأسفل،
        # حتى يبقى زر "حفظ" ظاهراً دائماً مهما كان ارتفاع النافذة.
        tab1 = QWidget()
        tab1_outer = QVBoxLayout(tab1)
        tab1_outer.setContentsMargins(0, 0, 0, 0)
        tab1_outer.setSpacing(8)

        tab1_scroll = QScrollArea()
        tab1_scroll.setWidgetResizable(True)
        tab1_scroll.setFrameShape(QFrame.NoFrame)
        tab1_scroll.setStyleSheet("QScrollArea{background:transparent;border:none;}")

        tab1_content = QWidget()
        tab1_layout = QVBoxLayout(tab1_content)
        tab1_layout.setContentsMargins(10, 10, 10, 10)
        tab1_scroll.setWidget(tab1_content)
        tab1_outer.addWidget(tab1_scroll, stretch=1)

        # -------- بيانات القضية --------
        case_group = QGroupBox("بيانات القضية")
        case_layout = QFormLayout()

        self.index_number = QLineEdit(parent.table.item(row, 1).text())
        self.court = QLineEdit(parent.table.item(row, 4).text())
        self.court.setReadOnly(True)  # المحكمة ثابتة حسب المحكمة النشطة
        self.court.setStyleSheet("background:#f1f2ff;color:#5b6485;")
        self.case_number = QLineEdit(parent.table.item(row, 0).text())
        self.plaintiff = QLineEdit(parent.table.item(row, 5).text())
        self.defendant = QLineEdit(parent.table.item(row, 6).text())
        self.session_date = QLineEdit(parent.table.item(row, 3).text())

        case_layout.addRow("رقم الفهرس:", self.index_number)
        case_layout.addRow(f"{storage.unit_words()['unit']}:", self.court)
        case_layout.addRow("رقم القضية:", self.case_number)
        case_layout.addRow("المدعي:", self.plaintiff)
        case_layout.addRow("المدعى عليه:", self.defendant)
        case_layout.addRow("تاريخ الجلسة:", self.session_date)

        case_group.setLayout(case_layout)
        tab1_layout.addWidget(case_group)

   # -------- المصاريف --------
        fees_group = QGroupBox("المصاريف")
        fees_layout = QFormLayout()

        # بنود كشف الأتعاب (إدخال يدوي، والمجموع يُحسب تلقائياً)
        self.file_study = QLineEdit()      # تسلم الملف و دراسته
        self.travel_fees = QLineEdit()     # أتعاب التنقل
        self.research = QLineEdit()        # البحث و الاستفسار
        self.interview = QLineEdit()       # الاستقبال و المقابلة
        self.repot = QLineEdit()           # تحرير التقرير
        self.printing = QLineEdit()        # الطبع و النسخ
        self.filing = QLineEdit()          # الايداع
        self.stamp_duties = QLineEdit()    # الطوابع (يدوي)
        self.notification = QLineEdit()    # التبليغ

        self.total = QLineEdit()
        self.total.setReadOnly(True)

        fees_layout.addRow("تسلم الملف و دراسته :", self.file_study)
        fees_layout.addRow("أتعاب التنقل:", self.travel_fees)
        fees_layout.addRow("البحث و الاستفسار:", self.research)
        fees_layout.addRow("الاستقبال و المقابلة:", self.interview)
        fees_layout.addRow("تحرير التقرير:", self.repot)
        fees_layout.addRow("الطبع و النسخ:", self.printing)
        fees_layout.addRow("الايداع:", self.filing)
        fees_layout.addRow("الطوابع:", self.stamp_duties)
        fees_layout.addRow("التبليغ:", self.notification)
        fees_layout.addRow("المجموع:", self.total)

        fees_group.setLayout(fees_layout)
        tab1_layout.addWidget(fees_group)

        tab1_layout.addStretch()

        # -------- شريط الأزرار الثابت (خارج منطقة التمرير) --------
        buttons_row = QHBoxLayout()
        buttons_row.setContentsMargins(10, 0, 10, 10)
        buttons_row.setSpacing(10)

        self.btn_save = QPushButton("حفظ")
        self.btn_save.setIcon(qta.icon("fa5s.save", color="white"))
        self.btn_save.setMinimumHeight(44)
        self.btn_save.setMinimumWidth(180)
        self.btn_save.setCursor(QCursor(Qt.PointingHandCursor))
        style_button(self.btn_save, "info", radius=10, padding="10px 16px")
        self.btn_save.clicked.connect(self.save_fees)
        buttons_row.addWidget(self.btn_save, stretch=1)

        self.btn = QPushButton("توليد Excel")
        self.btn.setIcon(qta.icon("fa5s.file-excel", color="white"))
        self.btn.setMinimumHeight(44)
        self.btn.setMinimumWidth(180)
        self.btn.setCursor(QCursor(Qt.PointingHandCursor))
        style_button(self.btn, "success", radius=10, padding="10px 16px")
        self.btn.clicked.connect(self.export)
        buttons_row.addWidget(self.btn, stretch=1)

        tab1_outer.addLayout(buttons_row)
        tab1_outer.setStretch(0, 1)

        self.tabs.addTab(tab1, "كشف الأتعاب")

       # =====================================================
        # الحساب التلقائي
        # =====================================================
        self.file_study.textChanged.connect(self.calculate)
        self.travel_fees.textChanged.connect(self.calculate)
        self.research.textChanged.connect(self.calculate)
        self.interview.textChanged.connect(self.calculate)
        self.repot.textChanged.connect(self.calculate)
        self.printing.textChanged.connect(self.calculate)
        self.filing.textChanged.connect(self.calculate)
        self.stamp_duties.textChanged.connect(self.calculate)
        self.notification.textChanged.connect(self.calculate)



   # =========================
    # الحساب
    # =========================
    @staticmethod
    def _amount(widget):
        """يقرأ مبلغاً من خانة (فارغ = 0، ويقبل الفاصلة العشرية , أو .)."""
        text = widget.text().strip().replace(" ", "").replace(",", ".")
        return float(text) if text else 0.0

    def calculate(self):
        try:
            total_val = sum(self._amount(w) for w in (
                self.file_study, self.travel_fees, self.research, self.interview,
                self.repot, self.printing, self.filing, self.stamp_duties,
                self.notification))
            self.total.setText(f"{total_val:.2f}")
        except ValueError:
            self.total.setText("خطأ")

    # =========================
    # (تحتاج تكملها حسب نظامك)
    # =========================

    def save_fees(self):
        case_number = self.case_number.text().strip()
        total = self.total.text().strip()

        if not case_number:
            show_warning(self, "تنبيه", "رقم القضية غير موجود.")
            return

        # --- جدول كشف الأتعاب: تحديث السطر الموجود لهذه القضية إن وُجد،
        #     بدل إضافة سطر مكرر في كل مرة يُضغط فيها "حفظ" ---
        fees_table = self.fees_status_page.table
        fees_table.blockSignals(True)
        found = False
        for r in range(fees_table.rowCount()):
            item = fees_table.item(r, 0)
            if item and item.text().strip() == case_number:
                fees_table.setItem(r, 1, QTableWidgetItem(total))
                # إعادة حساب "الباقي" و"الحالة" بناءً على المدفوع الحالي (إن وُجد)
                try:
                    paid_item = fees_table.item(r, 2)
                    paid = float(paid_item.text()) if paid_item and paid_item.text() else 0.0
                    total_val = float(total or 0)
                    remaining = total_val - paid
                    fees_table.setItem(r, 3, QTableWidgetItem(f"{remaining:.2f}"))
                    if paid <= 0:
                        status = "غير مدفوع"
                    elif remaining <= 0:
                        status = "مدفوع بالكامل"
                    else:
                        status = "مدفوع جزئي"
                    fees_table.setItem(r, 4, QTableWidgetItem(status))
                except ValueError:
                    pass
                found = True
                break

        if not found:
            row = fees_table.rowCount()
            fees_table.insertRow(row)
            fees_table.setItem(row, 0, QTableWidgetItem(case_number))
            fees_table.setItem(row, 1, QTableWidgetItem(total))
            fees_table.setItem(row, 2, QTableWidgetItem("0"))
            fees_table.setItem(row, 3, QTableWidgetItem(total))
            fees_table.setItem(row, 4, QTableWidgetItem("غير مدفوع"))
        fees_table.blockSignals(False)
        self.fees_status_page.save_fees_to_json()

        show_info(self, "تم", "تم حفظ كشف الأتعاب بنجاح")

    def export(self):
        data = {
            "court": self.court.text(),
            "case": self.case_number.text(),
            "plaintiff": self.plaintiff.text(),
            "defendant": self.defendant.text(),
            "index_number": self.index_number.text(),
            "session_date": self.session_date.text(),
            "study": self.file_study.text(),
            "travel": self.travel_fees.text(),
            "research": self.research.text(),
            "interview": self.interview.text(),
            "report": self.repot.text(),
            "printing": self.printing.text(),
            "filing": self.filing.text(),
            "stamp": self.stamp_duties.text(),
            "notification": self.notification.text(),
            "total": self.total.text(),
        }

        # الحصول على معلومات الخبير من التخزين العام لإدراجها في التقرير
        expert_info = storage.load_expert_info()
        report_data = dict(data)
        report_data["expert_name"] = expert_info.get("name", "")
        report_data["expert_address"] = expert_info.get("address", "")
        report_data["expert_phone"] = expert_info.get("phone", "")

        generated_files = []

        # 1⃣ توليد نسخة Excel (باستخدام القالب fees_template.xlsx)
        try:
            excel_path = generate_fees_excel(data)
            generated_files.append(f"Excel:\n{excel_path}")
        except Exception as e:
            show_warning(self, "خطأ", f"تعذر توليد ملف Excel:\n{e}")

        # 2⃣ توليد نسخة PDF (كشف أتعاب قابل للطباعة مباشرة)
        try:
            from generate_fees_report import generate_fees_report
            html_file, pdf_file = generate_fees_report(report_data)
            generated_files.append(f"PDF:\n{pdf_file}")

            from report_viewer import ReportViewer
            self.report_viewer = ReportViewer(html_file, pdf_file=pdf_file, title="معاينة كشف الأتعاب")
            self.report_viewer.show()
        except Exception as e:
            show_warning(self, "خطأ", f"تعذر توليد ملف PDF:\n{e}")

        if generated_files:
            show_info(self, "تم", "تم إنشاء كشف الأتعاب بنجاح:\n\n" + "\n\n".join(generated_files))