# -*- coding: utf-8 -*-
"""رموز التصميم (Design Tokens): مصدر واحد للألوان والمسافات والخطوط.

وحدة بايثون صرفة (لا تستورد PyQt) كي تُستعمل من أي ملف وتُختبر بدون واجهة.

الهوية البصرية الجديدة «Lavender Aurora» — فاتحة، مبهجة، ومريحة للعين:
  - خلفيات لافندر فاتحة جداً وبطاقات بيضاء (لا خلفيات داكنة في أي صفحة).
  - نيلي/بنفسجي (PRIMARY/ACCENT) للأزرار والروابط والعناوين.
  - تدرّج بنفسجي ناعم (GRAD_*) للوحات الترحيب والأزرار الرئيسية فقط.
  - ألوان حالة دافئة وواضحة: تركواز (نجاح)، كهرماني (تنبيه)، مرجاني (خطر).
  - لكل لون حالة «خلفية فاتحة» (TINT) تُستعمل في البطاقات والشارات، فتبقى الواجهة
    ملوّنة دون إجهاد للعين.
تغيير لون هنا ينعكس على كل الصفحات.
"""

# ----------------------------- الهوية -----------------------------
INK = "#2d2a78"              # نيلي عميق: نصوص عناوين بارزة وبداية التدرّجات
PRIMARY = "#4338ca"          # عناوين، ترويسة الجداول، أزرار رئيسية
PRIMARY_DARK = "#3730a3"     # عناوين كبيرة ونصوص على خلفيات فاتحة ملوّنة
PRIMARY_SOFT = "#e6e4ff"     # فواصل وحدود ملوّنة ناعمة
ACTIVE_BG = "#ecebff"        # خلفية العنصر النشط في القائمة الجانبية
ACCENT = "#5a4ee3"           # لون التفاعل (أزرار، روابط، تركيز الحقول)
ACCENT_LIGHT = "#ffc857"     # لمسة دافئة (شمسي) للتفاصيل الصغيرة
GOLD = "#a55500"             # كهرماني داكن للنصوص/الأرقام على الخلفيات الفاتحة
TEAL = "#0a8076"             # تركواز: لمسة ثانوية منعشة
CORAL = "#d03a50"            # مرجاني

# ----------------------------- التدرّجات (لوحات الترحيب والأزرار الرئيسية) -----------------------------
GRAD_A = "#4f46e5"
GRAD_B = "#7c3aed"
GRAD_C = "#9b5cf6"

# ----------------------------- الحالات -----------------------------
SUCCESS = "#128456"
DANGER = "#d03a50"
WARNING = "#b05c00"
INFO = ACCENT
PURPLE = "#7c3aed"
SECONDARY = "#5b6485"

# خلفية/نص شارات الحالة (Badge)
OK_BG, OK_FG = "#dcf5ea", "#0f7a52"
WARN_BG, WARN_FG = "#fff0d1", "#8a4b00"
BAD_BG, BAD_FG = "#ffe4e8", "#b1243c"
INFO_BG, INFO_FG = "#e8e6ff", "#3730a3"
NEUTRAL_BG, NEUTRAL_FG = "#eaedf8", "#4b5578"

# خلفيات فاتحة لبطاقات المؤشرات (لكل حالة)
TINT_INDIGO = "#eef0ff"
TINT_TEAL = "#dff5f2"
TINT_AMBER = "#fff3da"
TINT_ROSE = "#ffe7ec"
TINT_GREEN = "#dff4ea"
TINT_VIOLET = "#f1e9ff"

# ----------------------------- الأسطح والحدود -----------------------------
BG = "#f4f5ff"              # خلفية الصفحات (لافندر فاتح)
BG_SOFT = "#eceeff"         # خلفية ثانوية
SURFACE = "#ffffff"          # البطاقات والحقول
SURFACE_ALT = "#f8f9ff"      # صفوف متناوبة / حقول للقراءة فقط
BORDER = "#e4e7f7"
BORDER_STRONG = "#cdd3ee"
HOVER_BG = "#eef0ff"
SELECT_BG = "#e2e0ff"

# ----------------------------- النصوص -----------------------------
TEXT = "#1f2347"
TEXT_MUTED = "#5b6485"
TEXT_ON_DARK = "#ffffff"          # فوق التدرّجات الملوّنة
TEXT_ON_DARK_MUTED = "#ece9ff"
TEXT_ON_DARK_FAINT = "#d9d4ff"

# ----------------------------- القائمة الجانبية (فاتحة) -----------------------------
SIDEBAR_BG = "#ffffff"
NAV_TEXT = "#4b5578"
NAV_HOVER_BG = "#f3f3ff"
NAV_ACTIVE_BG = "#ecebff"
NAV_ACTIVE_FG = "#3730a3"
NAV_GROUP_TEXT = "#8a92b5"

# ----------------------------- القياسات -----------------------------
RADIUS = 14                  # البطاقات
RADIUS_CTRL = 10             # الحقول والأزرار
RADIUS_SM = 8
SPACE = 8                    # وحدة المسافة الأساسية (مضاعفاتها: 8/16/24)
CONTROL_HEIGHT = 38          # ارتفاع الحقول والأزرار القياسي
ROW_HEIGHT = 46              # ارتفاع صف الجدول
SIDEBAR_WIDTH = 232

# ----------------------------- الخطوط -----------------------------
FONT_FAMILY = "Segoe UI"     # يدعم العربية واللاتينية على ويندوز
FONT_SIZE_SMALL = 9
FONT_SIZE_BASE = 10
FONT_SIZE_LABEL = 10.5
FONT_SIZE_SECTION = 12
FONT_SIZE_TITLE = 17         # عنوان الصفحة
FONT_SIZE_KPI = 26           # أرقام لوحة التحكم

# ----------------------------- الحركة -----------------------------
# حركات خفيفة جداً (رسم يدوي بلا مؤثرات رسومية): عدّاد الأرقام، دخول نافذة الدخول،
# تمرير البطاقات. أوقفها بوضع False على الأجهزة الضعيفة.
ANIMATIONS = True


# =====================================================================
#  الوضع الليلي «Midnight Aurora»
# =====================================================================
# يُحدَّد المظهر مرة واحدة عند أول استيراد لهذه الوحدة (من الملف ui_theme.txt بجانب بيانات البرنامج)،
# قبل أن تبني بقية الوحدات أنماطها. تبديل المظهر = حفظ التفضيل ثم إعادة تشغيل البرنامج (theme_manager).
IS_DARK = False

# ألوان خلفية الصفحات الكبيرة (الدخول واختيار الملف): ثلاث نقاط للتدرّج
BG_GRAD = ("#e9ecff", "#f4eeff", "#e3f6fb")

_LIGHT = {k: v for k, v in list(globals().items())
          if k.isupper() and not k.startswith("_") and isinstance(v, (str, tuple))}

_DARK = {
    "INK": "#e3e0ff", "PRIMARY": "#6d63ee", "PRIMARY_DARK": "#cfcaff", "PRIMARY_SOFT": "#2a2f66",
    "ACTIVE_BG": "#2a2f66", "ACCENT": "#7468f0", "ACCENT_LIGHT": "#ffc857", "GOLD": "#d27800",
    "TEAL": "#0e968a", "CORAL": "#e0495f",
    "GRAD_A": "#4a3fd6", "GRAD_B": "#6930d8", "GRAD_C": "#8b3fd6",
    "SUCCESS": "#14935f", "DANGER": "#e0495f", "WARNING": "#c26a00", "INFO": "#7468f0",
    "PURPLE": "#8b4df0", "SECONDARY": "#5d6699",
    "OK_BG": "#14382f", "OK_FG": "#6ee7b7", "WARN_BG": "#3d3216", "WARN_FG": "#ffd28a",
    "BAD_BG": "#3f1f2c", "BAD_FG": "#ff9aa8", "INFO_BG": "#2a2f66", "INFO_FG": "#cfcaff",
    "NEUTRAL_BG": "#262b52", "NEUTRAL_FG": "#b6bddf",
    "TINT_INDIGO": "#242a5e", "TINT_TEAL": "#123a3a", "TINT_AMBER": "#3d3216",
    "TINT_ROSE": "#3f1f2c", "TINT_GREEN": "#14382f", "TINT_VIOLET": "#2b2250",
    "BG": "#12142b", "BG_SOFT": "#171a36", "SURFACE": "#1c2040", "SURFACE_ALT": "#222750",
    "BORDER": "#2e3466", "BORDER_STRONG": "#3c4380", "HOVER_BG": "#262b5a", "SELECT_BG": "#2f3475",
    "TEXT": "#eceeff", "TEXT_MUTED": "#a3acd1", "TEXT_ON_DARK": "#ffffff",
    "TEXT_ON_DARK_MUTED": "#ece9ff", "TEXT_ON_DARK_FAINT": "#d9d4ff",
    "SIDEBAR_BG": "#161a38", "NAV_TEXT": "#b6bddf", "NAV_HOVER_BG": "#222750",
    "NAV_ACTIVE_BG": "#2a2f66", "NAV_ACTIVE_FG": "#cfcaff", "NAV_GROUP_TEXT": "#7f89b8",
    "BG_GRAD": ("#0f1128", "#16143a", "#0d1f33"),
}

# --- ترجمة الألوان المكتوبة يدوياً داخل أنماط QSS (آلاف المواضع في الصفحات) إلى ما يقابلها في الليلي ---
# خريطتان لأن اللون نفسه قد يكون نصاً (يصير فاتحاً) أو خلفية (تبقى قوية/داكنة).
_BG_MAP = {
    "#ffffff": "#1c2040", "#fff": "#1c2040", "#fefefe": "#1c2040",
    "#f8f9ff": "#222750", "#f4f5ff": "#12142b", "#f1f2ff": "#1f2347", "#eef0ff": "#262b5a",
    "#ecebff": "#2a2f66", "#e6e4ff": "#2a2f66", "#e8e6ff": "#2a2f66",
    "#e2e0ff": "#2f3475", "#e4e7f7": "#2e3466", "#cdd3ee": "#3c4380", "#eaedf8": "#262b52",
    "#dde1f3": "#363d78", "#d5daf0": "#363d78", "#d0d6ee": "#363d78", "#c7cdea": "#4a5190",
    "#bcc3e4": "#4a5190", "#a9b0d0": "#5a62a6", "#f3f2ff": "#262b5a", "#e7e5ff": "#2f3475",
    "#cfcaf7": "#3c4380", "#dcf5ea": "#14382f", "#fff0d1": "#3d3216", "#ffe4e8": "#3f1f2c",
    "#fff6e0": "#3d3216", "#fff3da": "#3d3216", "#ffe7ec": "#3f1f2c", "#ffe8ec": "#3f1f2c",
    "#dff5f2": "#123a3a", "#dff4ea": "#14382f", "#f1e9ff": "#2b2250",
    "#4338ca": "#4a43c9", "#5a4ee3": "#6c60f0", "#3730a3": "#3b34b8", "#5b52d6": "#5a52d0",
    "#128456": "#14935f", "#d03a50": "#e0495f", "#7c3aed": "#8b4df0", "#b05c00": "#c26a00",
    "#a55500": "#c26a00", "#0a8076": "#0e968a", "#0f7a52": "#14935f", "#b1243c": "#d03a50",
    "#8a4b00": "#c26a00", "#c2410c": "#d9561a", "#6d28d9": "#7a3be0", "#5b6485": "#5d6699",
    "#2d2a78": "#2a2f66",
}
_FG_MAP = {
    "#1f2347": "#eceeff", "#5b6485": "#a3acd1", "#6b7399": "#98a1c9", "#9199b8": "#7e87b0",
    "#8a92b5": "#8089b3", "#9aa3c7": "#8f98c0", "#4b5578": "#b6bddf", "#4338ca": "#cfcaff",
    "#3730a3": "#cfcaff", "#2d2a78": "#e3e0ff", "#5a4ee3": "#9d93ff", "#5b52d6": "#9d93ff",
    "#0f7a52": "#6ee7b7", "#128456": "#4ade9a", "#b1243c": "#ff9aa8", "#d03a50": "#ff8a9b",
    "#8a4b00": "#ffd28a", "#a55500": "#ffb454", "#b05c00": "#ffb454", "#c2410c": "#ffa56b",
    "#7c3aed": "#b69cff", "#6d28d9": "#b69cff", "#0a8076": "#4fd1c5", "#a9b0d0": "#8f98c0",
}
_HEX = None


def remap_qss(qss):
    """يترجم الألوان الفاتحة المكتوبة يدوياً في نص QSS إلى ألوان الوضع الليلي (لا تفعل شيئاً في الفاتح)."""
    import re
    global _HEX
    if not IS_DARK or not qss:
        return qss
    if _HEX is None:
        _HEX = re.compile(r"#[0-9a-fA-F]{6}\b|#[0-9a-fA-F]{3}\b")
    decl = re.compile(r"([\w-]+)\s*:\s*([^;{}]+)")

    def fix_value(prop, val):
        p = prop.lower()
        if p in ("color", "selection-color"):
            table = _FG_MAP
        elif p.startswith("background") or p.startswith("border") or p in (
                "alternate-background-color", "selection-background-color", "gridline-color", "outline"):
            table = _BG_MAP
            if p.startswith("background") and re.fullmatch(r"\s*white\s*", val):
                return " " + _DARK["SURFACE"]
        else:
            return val
        return _HEX.sub(lambda m: table.get(m.group(0).lower(), m.group(0)), val)

    def fix_body(body):
        return decl.sub(lambda m: "%s: %s" % (m.group(1), fix_value(m.group(1), m.group(2))) if m.group(1) else m.group(0), body)

    if "{" not in qss:
        return fix_body(qss)
    return re.sub(r"\{([^{}]*)\}", lambda m: "{" + fix_body(m.group(1)) + "}", qss)


def _pref_file():
    try:
        import app_paths
        return os.path.join(app_paths.app_base_dir(), "ui_theme.txt")
    except Exception:
        return os.path.join(os.path.expanduser("~"), ".expertsystem_ui_theme.txt")


def saved_theme():
    """'dark' أو 'light' (الافتراضي). يتحمّل غياب الملف أو تلفه."""
    try:
        with open(_pref_file(), "r", encoding="utf-8") as fh:
            return "dark" if fh.read().strip().lower() == "dark" else "light"
    except Exception:
        return "light"


def save_theme(name):
    try:
        with open(_pref_file(), "w", encoding="utf-8") as fh:
            fh.write("dark" if name == "dark" else "light")
        return True
    except Exception:
        return False


def set_theme(name):
    """يطبّق لوحة الألوان على متغيّرات هذه الوحدة. يجب أن يحدث قبل استيراد بقية وحدات الواجهة."""
    global IS_DARK
    table = _DARK if name == "dark" else _LIGHT
    globals().update(table)
    IS_DARK = (name == "dark")


import os  # noqa: E402  (مطلوبة لمسار ملف التفضيل)
set_theme(saved_theme())
