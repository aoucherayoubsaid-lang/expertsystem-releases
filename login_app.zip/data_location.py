# -*- coding: utf-8 -*-
"""التحويل بين وضع الجهاز الواحد ووضع المجلد المشترك، بنقل متحقَّق منه.

القاعدة: لا يُحذف الأصل قبل أن يتطابق المنسوخ ملفاً ملفاً (الحجم وSHA-256). عند أي فشل يبقى الأصل
والإعداد كما كانا. ملفات «الجهاز» (مفتاح الترخيص، حالة الترخيص، القفل، سجل التدقيق، فهارس المراجع)
لا تُنسخ إلى المجلد المشترك أبداً.
"""
import os
import shutil

import app_paths
import local_protect

# ما يخصّ الجهاز وحده، ويبقى/ينتقل إلى app_paths.machine_dir()
MACHINE_ONLY = (".es_dk", ".es_dk.tmp", ".es_state", ".es_mk", ".es_mk.tmp", ".es_meta",
                "security.json", "security.json.sig", "security_audit.jsonl",
                "rag_references.db", "rag_references.db-wal", "rag_references.db-shm")
# ما لا يُنقل إطلاقاً (حالة مؤقتة أو خاصة بوضع بعينه)
NEVER_COPY = (".writer.lease", local_protect.SHARED_DESCRIPTOR, ".write_test")


class SwitchError(Exception):
    pass


def _copy_verified(src, dst, skip_names=()):
    """ينسخ شجرة src إلى dst (تُنشأ) متخطياً الأسماء المعطاة، ويتحقق من تطابق كل ملف."""
    copied = {}
    for dp, dn, fns in os.walk(src):
        rel_dir = os.path.relpath(dp, src)
        target_dir = dst if rel_dir == "." else os.path.join(dst, rel_dir)
        os.makedirs(target_dir, exist_ok=True)
        for fn in fns:
            if fn in skip_names or fn.endswith(".tmp"):
                continue
            s = os.path.join(dp, fn)
            d = os.path.join(target_dir, fn)
            shutil.copy2(s, d)
            copied[os.path.relpath(s, src)] = (s, d)
    for rel, (s, d) in copied.items():
        if app_paths._tree_manifest_file(s) != app_paths._tree_manifest_file(d):
            raise SwitchError("فشل التحقق من الملف: " + rel)
    return list(copied)


def _wipe(path):
    shutil.rmtree(path, ignore_errors=True)


def switch_to_shared(shared_path, passphrase):
    """يحوّل هذا الجهاز إلى مجلد مشترك.

    - مجلد مشترك جديد (بلا .es_shared.json): تُنسخ بيانات هذا الجهاز إليه وتُضبط عبارة المرور.
    - مجلد مشترك قائم: ينضم الجهاز إليه بالعبارة، وبيانات الجهاز المحلية القديمة لا تُمَسّ (تبقى كما هي).
    يرجع {"created": bool}."""
    shared_path = os.path.abspath(shared_path)
    if not os.path.isdir(shared_path) or not app_paths._is_writable(shared_path):
        raise SwitchError("المجلد غير موجود أو لا يمكن الكتابة فيه: " + shared_path)

    shared_app = os.path.join(shared_path, "app_data")
    descriptor = os.path.join(shared_app, local_protect.SHARED_DESCRIPTOR)
    old_base = app_paths.app_base_dir()
    old_machine = app_paths.machine_dir()

    if os.path.exists(descriptor):
        # انضمام لمجلد قائم: نتحقق من العبارة قبل أي تغيير دائم
        prev = app_paths.read_location()
        app_paths.write_location("shared", shared_path)
        local_protect._cache["key"] = None
        try:
            local_protect.unlock_shared(passphrase)
        except ValueError:
            _restore_location(prev)
            raise
        return {"created": False}

    # إنشاء مجلد مشترك جديد من بيانات هذا الجهاز
    if os.path.isdir(shared_app) and os.listdir(shared_app):
        raise SwitchError("المجلد المشترك يحوي بيانات غير مهيّأة؛ اختر مجلداً فارغاً أو مجلداً أنشأه البرنامج.")
    problem = local_protect.passphrase_problem(passphrase)
    if problem:
        raise SwitchError(problem)

    staged = []
    try:
        for name in ("app_data", "dossiers_data"):
            src = os.path.join(old_base, name)
            if os.path.isdir(src):
                skip = MACHINE_ONLY + NEVER_COPY if name == "app_data" else NEVER_COPY
                _copy_verified(src, os.path.join(shared_path, name), skip_names=skip)
                staged.append(name)
        os.makedirs(shared_app, exist_ok=True)
    except Exception as exc:
        for name in staged:
            _wipe(os.path.join(shared_path, name))
        raise SwitchError(str(exc))

    prev = app_paths.read_location()
    new_machine = os.path.join(app_paths.local_dir(), "machine")
    os.makedirs(new_machine, exist_ok=True)
    # ملفات الجهاز تنتقل إلى مجلد الجهاز الجديد (نسخ ثم حذف الأصل)
    moved = []
    old_app = os.path.join(old_base, "app_data")
    for n in MACHINE_ONLY:
        s = os.path.join(old_app, n)
        if os.path.isfile(s) and n not in (".es_mk", ".es_mk.tmp", ".es_meta"):
            shutil.copy2(s, os.path.join(new_machine, n))
            moved.append(s)
    try:
        app_paths.write_location("shared", shared_path)
        local_protect.DATA_DIR = None             # يُحسب من الوضع الجديد
        local_protect._cache["key"] = None
        local_protect.clear_tamper_state()
        local_protect.setup_shared(passphrase)
        local_protect.reseal_shared_files()
        local_protect._sign_existing(("security.json",))
    except Exception as exc:
        _restore_location(prev)
        local_protect.DATA_DIR = None             # يُحسب من الوضع الجديد
        for name in staged:
            _wipe(os.path.join(shared_path, name))
        shutil.rmtree(shared_app, ignore_errors=True)
        raise SwitchError(str(exc))

    # نجح كل شيء: نحذف نسخة هذا الجهاز القديمة (كانت تحوي بيانات القضايا)
    for name in staged:
        _wipe(os.path.join(old_base, name))
    for s in moved:
        try:
            os.remove(s)
        except OSError:
            pass
    return {"created": True}


def _restore_location(prev):
    if prev and prev["mode"] == "shared":
        app_paths.write_location("shared", prev["path"])
    elif prev:
        app_paths.write_location("local")
    else:
        try:
            os.remove(app_paths._location_path())
        except OSError:
            pass
        app_paths.reset_cache()


def switch_to_local():
    """يعيد هذا الجهاز إلى وضع الجهاز الواحد بنسخة متحقَّق منها من البيانات المشتركة.
    المجلد المشترك نفسه لا يُمَسّ (قد تستعمله أجهزة أخرى). المفتاح الرئيسي يصير عشوائياً محلياً."""
    if app_paths.data_mode() != "shared":
        raise SwitchError("الجهاز ليس في الوضع المشترك.")
    shared_base = app_paths.app_base_dir()
    target = os.path.join(app_paths.local_dir(), "data")
    if os.path.isdir(os.path.join(target, "app_data")):
        raise SwitchError("توجد بيانات محلية سابقة في %s؛ انقلها أو احذفها أولاً." % target)
    staging = target + ".incoming"
    _wipe(staging)
    try:
        for name in ("app_data", "dossiers_data"):
            src = os.path.join(shared_base, name)
            if os.path.isdir(src):
                skip = NEVER_COPY + (".clock_probe",) if name == "app_data" else NEVER_COPY
                _copy_verified(src, os.path.join(staging, name), skip_names=skip)
        os.makedirs(os.path.join(staging, "app_data"), exist_ok=True)
    except Exception as exc:
        _wipe(staging)
        raise SwitchError(str(exc))
    if os.path.exists(target):
        _wipe(target)
    os.replace(staging, target)

    # ملفات هذا الجهاز تعود إلى app_data المحلي (وضع local يستعملها من هناك)
    old_machine = os.path.join(app_paths.local_dir(), "machine")
    new_app = os.path.join(target, "app_data")
    if os.path.isdir(old_machine):
        for n in os.listdir(old_machine):
            if n in (".es_mk", ".es_mk.tmp", ".es_meta"):
                continue
            shutil.copy2(os.path.join(old_machine, n), os.path.join(new_app, n))
    app_paths.write_location("local")
    local_protect.DATA_DIR = None             # يُحسب من الوضع الجديد
    local_protect._cache["key"] = None
    local_protect.reseal_all(("users.json", "settings.json", "security.json"))
    _wipe(old_machine)
    return {"target": target}
