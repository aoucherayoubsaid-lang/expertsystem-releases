from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QTableWidget, QTableWidgetItem,
    QPushButton, QLineEdit, QHBoxLayout, QHeaderView, QDialog, QFormLayout, QLabel, QMessageBox,
    QFileDialog, QDateEdit
)
from PyQt5.QtCore import Qt, QSize, QDate
import json
import os
import platform
import subprocess
import storage
import qtawesome as qta
from msgbox_ltr import show_info, show_warning, show_question
from modern_theme import show_toast
from table_actions import build_action_bar, AttachmentPicker, open_file

ATTACHMENTS_SUBFOLDER = "receipts_scans"
SCAN_ROLE = Qt.UserRole + 1

class CaseDetailsWindow(QDialog):
    """نافذة عرض تفاصيل القضية - منشأة داخلياً"""
    def __init__(self, case_data):
        super().__init__()
        self.setWindowTitle("تفاصيل القضية")
        self.resize(450, 450)
        
        # اتجاه النافذة عربي (من اليمين لليسار)
        self.setLayoutDirection(Qt.RightToLeft)
        
        layout = QFormLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(30, 30, 30, 30)

        # تنسيق بسيط وجميل
        label_style = "font-weight: bold; font-size: 13px; color: #1f2347;"
        value_style = "font-size: 13px; color: #000; border-bottom: 1px solid #e4e7f7; padding-bottom: 2px;"

        fields = [
            ("رقم الفهرس", "index_number"),
            ("رقم الغرفة", "room_number"),
            ("تاريخ الجلسة", "session_date"),
            (storage.unit_words()["unit"], "court"),
            ("المدعي", "plaintiff"),
            ("المدعى عليه", "defendant"),
        ]

        for label_text, key in fields:
            value = case_data.get(key, "---")
            
            lbl = QLabel(f"{label_text}:")
            lbl.setStyleSheet(label_style)
            
            val = QLabel(str(value))
            val.setStyleSheet(value_style)
            val.setTextInteractionFlags(Qt.TextSelectableByMouse) # قابل للنسخ
            
            layout.addRow(lbl, val)

        self.close_btn = QPushButton("إغلاق")
        self.close_btn.setFixedHeight(35)
        self.close_btn.clicked.connect(self.close)
        layout.addRow("", self.close_btn)

class PaymentsPage(QWidget):
    def __init__(self, main_app):
        super().__init__()
        self.main_app = main_app 

        # اتجاه الصفحة يتبع لغة البرنامج (عربي: من اليمين، وينقلب عند تغيير اللغة)

        layout = QVBoxLayout(self)

        # منطقة البحث (عربي)
        search_layout = QHBoxLayout()

        self.case_input = QLineEdit()
        self.case_input.setPlaceholderText("أدخل رقم القضية للبحث...")
        self.case_input.setFixedHeight(35)
        self.case_input.textChanged.connect(self.search_payments)

        self.btn_search = QPushButton("بحث")
        self.btn_search.setIcon(qta.icon("fa5s.search", color="white"))
        self.btn_search.setIconSize(QSize(16, 16))
        self.btn_search.setFixedHeight(35)
        self.btn_search.setStyleSheet("background:#5a4ee3;color:white;border-radius:6px;padding:0 12px;")
        self.btn_search.clicked.connect(self.search_payments)

        search_layout.addWidget(self.case_input)
        search_layout.addWidget(self.btn_search)
        layout.addLayout(search_layout) # جدول النتائج
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels([
            "رقم القضية", "التاريخ", "رقم الوصل", "المبلغ", "المرفق"
        ])
        
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        
        # ربط الدبل كليك: فتح تفاصيل القضية، أو فتح المرفق عند النقر على عمود "المرفق"
        self.table.cellDoubleClicked.connect(self.on_cell_double_clicked)
        
        layout.addWidget(self.table)

        # شريط الأزرار: حفظ | تعديل | حذف | إضافة مرفق (للسطر المحدد)
        action_bar, self._action_buttons = build_action_bar(
            on_save=self.save_clicked,
            on_edit=self.edit_selected_payment,
            on_delete=self.delete_selected_payment,
            on_attach_scan=self.attach_scan_to_selected,
            on_attach_file=self.attach_file_to_selected,
            parent=self,
        )
        layout.addLayout(action_bar)

        self.btn_print = QPushButton("طباعة التسديدات")
        self.btn_print.setIcon(qta.icon("fa5s.print", color="white"))
        self.btn_print.setIconSize(QSize(18, 18))
        self.btn_print.setFixedHeight(40)
        self.btn_print.setStyleSheet("""
            QPushButton { background-color:#4338ca; color:white; border-radius:6px; font-weight:bold; }
            QPushButton:hover { background-color:#4338ca; }
        """)
        self.btn_print.clicked.connect(self.print_payments)
        layout.addWidget(self.btn_print)

        self.btn_add_manual = QPushButton("إضافة تسديد يدوي")
        self.btn_add_manual.setIcon(qta.icon("fa5s.plus-circle", color="white"))
        self.btn_add_manual.setIconSize(QSize(18, 18))
        self.btn_add_manual.setFixedHeight(40)
        self.btn_add_manual.setStyleSheet("""
            QPushButton { background-color:#128456; color:white; border-radius:6px; font-weight:bold; }
            QPushButton:hover { background-color:#0f7a52; }
        """)
        self.btn_add_manual.clicked.connect(self.add_manual_payment)
        layout.addWidget(self.btn_add_manual)

        self.load_payments_from_json()
        self.table.itemChanged.connect(self.save_payments_to_json)

    def search_payments(self):
        """تصفية جدول التسديدات برقم القضية (إخفاء/إظهار فقط، بدون حذف أي بيانات)."""
        query = self.case_input.text().strip().lower()
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            visible = (not query) or (item and query in item.text().lower())
            self.table.setRowHidden(row, not visible)

    def print_payments(self):
        rows = []
        for row in range(self.table.rowCount()):
            if self.table.isRowHidden(row):
                continue
            rows.append({
                "case_number": self.table.item(row, 0).text() if self.table.item(row, 0) else "",
                "date": self.table.item(row, 1).text() if self.table.item(row, 1) else "",
                "receipt_number": self.table.item(row, 2).text() if self.table.item(row, 2) else "",
                "amount": self.table.item(row, 3).text() if self.table.item(row, 3) else "",
            })

        if not rows:
            QMessageBox.warning(self, "تنبيه", "لا توجد بيانات لطباعتها.")
            return

        try:
            from generate_status_reports import generate_payments_report
            html_file, pdf_file = generate_payments_report(rows)
        except Exception as e:
            show_warning(self, "خطأ", f"تعذر توليد التقرير:\n{e}")
            return

        from report_viewer import ReportViewer
        self.payments_viewer = ReportViewer(html_file, pdf_file=pdf_file, title="معاينة تقرير التسديدات")
        self.payments_viewer.show()
        show_info(self, "تم", f"تم إنشاء تقرير التسديدات:\n{pdf_file}")

    def on_cell_double_clicked(self, row, column):
        if column == 4:
            self.open_attachment(row)
        else:
            self.open_case_details(row, column)

    def open_attachment(self, row):
        item = self.table.item(row, 4)
        scan_path = item.data(SCAN_ROLE) if item else None
        if not scan_path or not os.path.isfile(scan_path):
            QMessageBox.information(self, "لا يوجد مرفق", "لا يوجد مسح ضوئي مرفق بهذا التسديد.")
            return
        try:
            import safe_open
            safe_open.open_path(scan_path)
        except Exception as e:
            QMessageBox.warning(self, "خطأ", f"تعذر فتح المرفق:\n{e}")

    def open_case_details(self, row, column):
        """جلب البيانات من صفحة case_page وفتح النافذة"""
        item = self.table.item(row, 0)
        if not item: return
        
        case_number = item.text()
        
        # الوصول لجدول القضايا الرئيسي في MainApp
        case_table = self.main_app.case_page.table 

        case_data = {}
        found = False

        for r in range(case_table.rowCount()):
            cell_item = case_table.item(r, 0)
            if cell_item and cell_item.text() == case_number:
                # سحب البيانات حسب ترتيب الأعمدة في صفحة القضايا
                case_data = {
                    "index_number": case_table.item(r, 1).text() if case_table.item(r, 1) else "",
                    "room_number": case_table.item(r, 2).text() if case_table.item(r, 2) else "",
                    "session_date": case_table.item(r, 3).text() if case_table.item(r, 3) else "",
                    "court": case_table.item(r, 4).text() if case_table.item(r, 4) else "",
                    "plaintiff": case_table.item(r, 5).text() if case_table.item(r, 5) else "",
                    "defendant": case_table.item(r, 6).text() if case_table.item(r, 6) else "",
                }
                found = True
                break

        if found:
            # تشغيل النافذة المعرفة في الأعلى
            details_window = CaseDetailsWindow(case_data)
            details_window.exec_()
    def save_payments_to_json(self):
        payments_list = []

        for row in range(self.table.rowCount()):
            scan_item = self.table.item(row, 4)
            row_data = {
                "case_number": self.table.item(row, 0).text() if self.table.item(row, 0) else "",
                "date": self.table.item(row, 1).text() if self.table.item(row, 1) else "",
                "receipt_number": self.table.item(row, 2).text() if self.table.item(row, 2) else "",
                "amount": self.table.item(row, 3).text() if self.table.item(row, 3) else "",
                "scan_path": scan_item.data(SCAN_ROLE) if scan_item and scan_item.data(SCAN_ROLE) else "",
            }
            payments_list.append(row_data)

        storage.save_payments(payments_list)

    def _make_attachment_item(self, scan_path):
        has_scan = bool(scan_path) and os.path.isfile(scan_path)
        item = QTableWidgetItem("📎 عرض" if has_scan else "—")
        item.setData(SCAN_ROLE, scan_path or "")
        return item

    def notes_for_case(self, case_number):
        """يُنشئ نصاً يسرد كل وصولات التسديد الخاصة بقضية معيّنة، ليُعرض في
        عمود 'ملاحظات' بصفحة كشف الأتعاب - الوضعية العامة."""
        entries = []
        for r in range(self.table.rowCount()):
            c_item = self.table.item(r, 0)
            if not c_item or c_item.text().strip() != case_number:
                continue
            date = self.table.item(r, 1).text().strip() if self.table.item(r, 1) else ""
            receipt = self.table.item(r, 2).text().strip() if self.table.item(r, 2) else ""
            if not date and not receipt:
                continue
            if date and receipt:
                entries.append(f"دفعة بتاريخ {date} - وصل رقم {receipt}")
            elif receipt:
                entries.append(f"وصل رقم {receipt}")
            else:
                entries.append(f"دفعة بتاريخ {date}")
        return " | ".join(entries)

    def load_payments_from_json(self):
        payments_list = storage.load_payments()
        if not payments_list:
            self.table.blockSignals(True)
            self.table.setRowCount(0)
            self.table.blockSignals(False)
            return

        # تم إصلاح خطأ الإزاحة (indentation): كل سطر من الحلقة يجب أن يُنفَّذ
        # لكل عنصر في القائمة، وليس فقط للعنصر الأخير
        self.table.blockSignals(True)
        self.table.setRowCount(0)

        for payment in payments_list:
            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(payment.get("case_number", "")))
            self.table.setItem(row, 1, QTableWidgetItem(payment.get("date", "")))
            self.table.setItem(row, 2, QTableWidgetItem(payment.get("receipt_number", "")))
            self.table.setItem(row, 3, QTableWidgetItem(payment.get("amount", "")))
            self.table.setItem(row, 4, self._make_attachment_item(payment.get("scan_path", "")))

        self.table.blockSignals(False)

    def reload(self):
        """إعادة تحميل بيانات التسديدات (تُستدعى عند تفعيل التبويب)."""
        self.load_payments_from_json()

    def add_manual_payment(self):
        """إضافة تسديد يدوياً دون المرور عبر نافذة كشف الأتعاب، مع تحديث حالة الأتعاب تلقائياً."""
        dialog = QDialog(self)
        dialog.setWindowTitle("إضافة تسديد يدوي")
        dialog.resize(380, 260)
        form = QFormLayout(dialog)

        case_input = QLineEdit()
        date_input = QDateEdit(calendarPopup=True)
        date_input.setDate(QDate.currentDate())
        receipt_input = QLineEdit()
        amount_input = QLineEdit()

        form.addRow("رقم القضية:", case_input)
        form.addRow("التاريخ:", date_input)
        form.addRow("رقم الوصل:", receipt_input)
        form.addRow("المبلغ:", amount_input)

        scan_state = {"path": ""}
        scan_label = QLabel("لا يوجد مرفق")
        scan_label.setStyleSheet("color:#5b6485;")

        def pick_scan():
            file_path, _ = QFileDialog.getOpenFileName(
                dialog, "اختر صورة أو PDF للوصل",
                "", "صور وملفات PDF (*.png *.jpg *.jpeg *.bmp *.pdf);;All Files (*.*)"
            )
            if file_path:
                scan_state["path"] = file_path
                scan_label.setText(f"مرفق: {os.path.basename(file_path)}")
                scan_label.setStyleSheet("color:#128456; font-weight:bold;")

        scan_btn = QPushButton("إرفاق سكان / صورة / PDF")
        scan_btn.setIcon(qta.icon("fa5s.paperclip", color="#4338ca"))
        scan_btn.clicked.connect(pick_scan)
        scan_row = QHBoxLayout()
        scan_row.addWidget(scan_label)
        scan_row.addWidget(scan_btn)
        form.addRow("المرفق:", scan_row)

        save_btn = QPushButton("حفظ")
        save_btn.setStyleSheet("background:#128456;color:white;padding:8px;border-radius:6px;")
        save_btn.clicked.connect(dialog.accept)
        form.addRow(save_btn)

        if dialog.exec_() != QDialog.Accepted:
            return

        case_number = case_input.text().strip()
        date = date_input.date().toString("dd/MM/yyyy")
        receipt_number = receipt_input.text().strip()
        amount = amount_input.text().strip()

        if not case_number or not amount:
            QMessageBox.warning(self, "تنبيه", "يرجى إدخال رقم القضية والمبلغ على الأقل.")
            return

        # تتبّع أرقام الوصولات: تحذير عند تكرار رقم وصل مُدخَل يدوياً هنا من قبل
        if receipt_number:
            existing_numbers = {
                self.table.item(r, 2).text().strip()
                for r in range(self.table.rowCount()) if self.table.item(r, 2)
            }
            if receipt_number in existing_numbers:
                reply = show_question(
                    self, "رقم وصل مكرر",
                    f"رقم الوصل «{receipt_number}» مستعمل من قبل في تسديد آخر.\nهل تريد المتابعة رغم ذلك؟",
                )
                if reply != QMessageBox.Yes:
                    return

        scan_path = ""
        if scan_state["path"]:
            try:
                desired_name = f"payment_{receipt_number or 'na'}_{case_number}"
                scan_path = storage.save_attachment_file(scan_state["path"], ATTACHMENTS_SUBFOLDER, desired_name)
            except Exception as e:
                QMessageBox.warning(self, "تنبيه", f"تم حفظ التسديد لكن تعذر حفظ المرفق:\n{e}")

        self.table.blockSignals(True)
        row = self.table.rowCount()
        self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(case_number))
        self.table.setItem(row, 1, QTableWidgetItem(date))
        self.table.setItem(row, 2, QTableWidgetItem(receipt_number))
        self.table.setItem(row, 3, QTableWidgetItem(amount))
        self.table.setItem(row, 4, self._make_attachment_item(scan_path))
        self.table.blockSignals(False)
        self.save_payments_to_json()

        # تحديث حالة كشف الأتعاب المرتبطة بنفس رقم القضية تلقائياً (إن وُجدت)
        fees_status_page = getattr(self.main_app, "fees_status_page", None)
        if fees_status_page is not None:
            fees_table = fees_status_page.table
            for r in range(fees_table.rowCount()):
                item = fees_table.item(r, 0)
                if item and item.text().strip() == case_number:
                    try:
                        total_amount = float(fees_table.item(r, 1).text() or 0)
                        prev_paid = float(fees_table.item(r, 2).text() or 0) if fees_table.item(r, 2) else 0
                        new_paid = prev_paid + float(amount or 0)
                        remaining = total_amount - new_paid
                        fees_table.setItem(r, 2, QTableWidgetItem(str(new_paid)))
                        fees_table.setItem(r, 3, QTableWidgetItem(str(remaining)))
                        status = "مدفوع بالكامل" if remaining <= 0 else ("مدفوع جزئي" if new_paid > 0 else "غير مدفوع")
                        fees_table.setItem(r, 4, QTableWidgetItem(status))
                        fees_table.setItem(r, 5, QTableWidgetItem(self.notes_for_case(case_number)))
                    except (ValueError, AttributeError):
                        pass
                    break

        QMessageBox.information(self, "تم", "تم إضافة التسديد بنجاح.")

    # =====================================================================
    # حفظ / تعديل / حذف / إضافة مرفق للسطر المحدد
    # =====================================================================
    @staticmethod
    def _to_num(text):
        try:
            return float(str(text).replace(",", "").replace(" ", "").replace("\u200e", "") or 0)
        except ValueError:
            return 0.0

    def _cell(self, row, col):
        it = self.table.item(row, col)
        return it.text().strip() if it else ""

    def _row_data(self, row):
        scan_item = self.table.item(row, 4)
        return {
            "case_number": self._cell(row, 0),
            "date": self._cell(row, 1),
            "receipt_number": self._cell(row, 2),
            "amount": self._cell(row, 3),
            "scan_path": (scan_item.data(SCAN_ROLE) or "") if scan_item else "",
        }

    def _selected_row(self, purpose):
        row = self.table.currentRow()
        if row < 0 or row >= self.table.rowCount() or self.table.isRowHidden(row):
            show_warning(self, "تنبيه", f"اختر سطراً من الجدول أولاً {purpose}.")
            return -1
        return row

    def save_clicked(self):
        self.save_payments_to_json()
        show_toast(self, "تم حفظ التسديدات ✓", "success")

    # ---------- مزامنة كشف الأتعاب ----------
    def refresh_fees_for_case(self, case_number):
        """يعيد حساب المدفوع/الباقي/الحالة/الملاحظات في كشف الأتعاب لقضية معيّنة
        اعتماداً على مجموع تسديداتها الحالية (يُستعمل بعد التعديل/الحذف)."""
        case_number = (case_number or "").strip()
        fees_page = getattr(self.main_app, "fees_status_page", None)
        if fees_page is None or not case_number:
            return
        paid = sum(
            self._to_num(self._cell(r, 3))
            for r in range(self.table.rowCount()) if self._cell(r, 0) == case_number
        )
        t = fees_page.table
        for r in range(t.rowCount()):
            item = t.item(r, 0)
            if item and item.text().strip() == case_number:
                total = self._to_num(t.item(r, 1).text() if t.item(r, 1) else 0)
                remaining = total - paid
                if paid <= 0:
                    status = "غير مدفوع"
                elif remaining <= 0:
                    status = "مدفوع بالكامل"
                else:
                    status = "مدفوع جزئي"
                t.blockSignals(True)
                t.setItem(r, 2, QTableWidgetItem(f"{paid:.2f}"))
                t.setItem(r, 3, QTableWidgetItem(f"{remaining:.2f}"))
                t.setItem(r, 4, QTableWidgetItem(status))
                t.setItem(r, 5, QTableWidgetItem(self.notes_for_case(case_number)))
                t.blockSignals(False)
                fees_page.save_fees_to_json()
                fees_page._refresh_view()
                break

    # ---------- مزامنة وصل الإيداع المرتبط (نفس القضية + نفس رقم الوصل) ----------
    def _update_linked_receipt(self, case_number, receipt_number, **changes):
        if not receipt_number:
            return
        records = storage.load_receipts()
        touched = False
        for rec in records:
            if (rec.get("type", "advance") == "advance"
                    and (rec.get("case_number") or "").strip() == case_number
                    and (rec.get("receipt_number") or "").strip() == receipt_number):
                rec.update(changes)
                touched = True
                break
        if touched:
            storage.save_receipts(records)
            rp = getattr(self.main_app, "receipt_page", None)
            if rp is not None:
                rp.load_receipts_data()

    # ---------- واجهات برمجية تستعملها صفحة وصل الإيداع ----------
    def _find_row(self, case_number, receipt_number):
        for r in range(self.table.rowCount()):
            if self._cell(r, 0) == case_number and self._cell(r, 2) == receipt_number:
                return r
        return -1

    def update_payment_by_key(self, old_case, old_receipt, case_number=None, receipt_number=None,
                              date=None, amount=None, scan_path=None):
        row = self._find_row((old_case or "").strip(), (old_receipt or "").strip())
        if row < 0:
            return False
        d = self._row_data(row)
        new = {
            "case_number": d["case_number"] if case_number is None else case_number,
            "date": d["date"] if date is None else date,
            "receipt_number": d["receipt_number"] if receipt_number is None else receipt_number,
            "amount": d["amount"] if amount is None else amount,
            "scan_path": d["scan_path"] if scan_path is None else scan_path,
        }
        self._apply_row(row, new)
        self.save_payments_to_json()
        self.refresh_fees_for_case(d["case_number"])
        self.refresh_fees_for_case(new["case_number"])
        return True

    def delete_payment_by_key(self, case_number, receipt_number):
        row = self._find_row((case_number or "").strip(), (receipt_number or "").strip())
        if row < 0:
            return False
        self.table.blockSignals(True)
        self.table.removeRow(row)
        self.table.blockSignals(False)
        self.save_payments_to_json()
        self.refresh_fees_for_case(case_number)
        return True

    def _apply_row(self, row, d):
        self.table.blockSignals(True)
        self.table.setItem(row, 0, QTableWidgetItem(d["case_number"]))
        self.table.setItem(row, 1, QTableWidgetItem(d["date"]))
        self.table.setItem(row, 2, QTableWidgetItem(d["receipt_number"]))
        self.table.setItem(row, 3, QTableWidgetItem(d["amount"]))
        self.table.setItem(row, 4, self._make_attachment_item(d["scan_path"]))
        self.table.blockSignals(False)

    # ---------- تعديل ----------
    def edit_selected_payment(self):
        row = self._selected_row("لتعديله")
        if row < 0:
            return
        old = self._row_data(row)

        dialog = QDialog(self)
        dialog.setWindowTitle("تعديل التسديد")
        dialog.resize(420, 300)
        form = QFormLayout(dialog)

        case_input = QLineEdit(old["case_number"])
        date_input = QDateEdit(calendarPopup=True)
        qd = QDate.fromString(old["date"], "dd/MM/yyyy")
        date_input.setDate(qd if qd.isValid() else QDate.currentDate())
        date_input.setDisplayFormat("dd/MM/yyyy")
        receipt_input = QLineEdit(old["receipt_number"])
        amount_input = QLineEdit(old["amount"])
        picker = AttachmentPicker(dialog, old["scan_path"], "payment")

        form.addRow("رقم القضية:", case_input)
        form.addRow("التاريخ:", date_input)
        form.addRow("رقم الوصل:", receipt_input)
        form.addRow("المبلغ:", amount_input)
        form.addRow("المرفق:", picker.build_row())

        btns = QHBoxLayout()
        save_btn = QPushButton("حفظ التعديلات")
        save_btn.setStyleSheet("background:#128456;color:white;padding:8px 16px;border-radius:6px;font-weight:bold;")
        save_btn.clicked.connect(dialog.accept)
        cancel_btn = QPushButton("إلغاء")
        cancel_btn.clicked.connect(dialog.reject)
        btns.addWidget(save_btn)
        btns.addWidget(cancel_btn)
        form.addRow(btns)

        if dialog.exec_() != QDialog.Accepted:
            return

        new_case = case_input.text().strip()
        new_receipt = receipt_input.text().strip()
        new_amount = amount_input.text().strip()
        new_date = date_input.date().toString("dd/MM/yyyy")
        if not new_case or not new_amount:
            show_warning(self, "تنبيه", "يرجى إدخال رقم القضية والمبلغ على الأقل.")
            return

        if new_receipt and new_receipt != old["receipt_number"]:
            others = {self._cell(r, 2) for r in range(self.table.rowCount()) if r != row}
            if new_receipt in others:
                reply = show_question(
                    self, "رقم وصل مكرر",
                    f"رقم الوصل «{new_receipt}» مستعمل من قبل في تسديد آخر.\nهل تريد المتابعة رغم ذلك؟")
                if reply != QMessageBox.Yes:
                    return

        scan_path = old["scan_path"]
        if picker.path != old["scan_path"]:
            if not picker.path:
                scan_path = ""
            elif picker.is_new:
                try:
                    scan_path = storage.save_attachment_file(
                        picker.path, ATTACHMENTS_SUBFOLDER,
                        f"payment_{new_receipt or 'na'}_{new_case}") or ""
                except Exception as e:
                    show_warning(self, "تنبيه", f"تعذر حفظ المرفق:\n{e}")
                    scan_path = old["scan_path"]

        new = {"case_number": new_case, "date": new_date, "receipt_number": new_receipt,
               "amount": new_amount, "scan_path": scan_path}
        self._apply_row(row, new)
        self.save_payments_to_json()

        # مزامنة وصل الإيداع المرتبط + كشف الأتعاب (للقضية القديمة والجديدة)
        self._update_linked_receipt(old["case_number"], old["receipt_number"],
                                    case_number=new_case, receipt_number=new_receipt,
                                    date=new_date, amount=new_amount, scan_path=scan_path)
        self.refresh_fees_for_case(old["case_number"])
        self.refresh_fees_for_case(new_case)
        self.search_payments()
        show_toast(self, "تم حفظ التعديلات ✓", "success")

    # ---------- حذف ----------
    def delete_selected_payment(self):
        row = self._selected_row("لحذفه")
        if row < 0:
            return
        d = self._row_data(row)
        reply = show_question(
            self, "تأكيد الحذف",
            f"هل أنت متأكد من حذف تسديد القضية «{d['case_number']}» بمبلغ {d['amount']}؟\n"
            "سيُعاد حساب المدفوع/الباقي في كشف الأتعاب تلقائياً.")
        if reply != QMessageBox.Yes:
            return
        self.table.blockSignals(True)
        self.table.removeRow(row)
        self.table.blockSignals(False)
        self.save_payments_to_json()
        self.refresh_fees_for_case(d["case_number"])
        show_toast(self, "تم حذف التسديد", "success")

    # ---------- إضافة مرفق لسطر موجود ----------
    def attach_file_to_selected(self):
        row = self._selected_row("لإضافة مرفق إليه")
        if row < 0:
            return
        from scan_utils import pick_existing_file
        path = pick_existing_file(self, "اختر صورة أو PDF للتسديد")
        if path:
            self._set_row_attachment(row, path)

    def attach_scan_to_selected(self):
        row = self._selected_row("لإضافة مرفق إليه")
        if row < 0:
            return
        from scan_utils import scan_document
        path = scan_document(self, suggested_name="تسديد")
        if path:
            self._set_row_attachment(row, path)

    def _set_row_attachment(self, row, source_path):
        d = self._row_data(row)
        try:
            new_path = storage.save_attachment_file(
                source_path, ATTACHMENTS_SUBFOLDER,
                f"payment_{d['receipt_number'] or 'na'}_{d['case_number']}")
        except Exception as e:
            show_warning(self, "خطأ", f"تعذر حفظ المرفق:\n{e}")
            return
        if not new_path:
            show_warning(self, "خطأ", "الملف المختار غير موجود.")
            return
        self.table.blockSignals(True)
        self.table.setItem(row, 4, self._make_attachment_item(new_path))
        self.table.blockSignals(False)
        self.save_payments_to_json()
        self._update_linked_receipt(d["case_number"], d["receipt_number"], scan_path=new_path)
        show_toast(self, "تمت إضافة المرفق ✓", "success")
