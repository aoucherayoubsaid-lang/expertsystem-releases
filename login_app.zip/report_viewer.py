import os
import platform
import subprocess

from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QHBoxLayout, QFileDialog, QMessageBox
from PyQt5.QtPrintSupport import QPrinter

from msgbox_ltr import show_warning


class ReportViewer(QWidget):
    def __init__(self, html_file, pdf_file=None, title="معاينة التقرير"):
        super().__init__()

        from PyQt5.QtWebEngineWidgets import QWebEngineView
        from PyQt5.QtCore import QUrl
        # عنوان صحيح خاص بكل تقرير (بدل عنوان ثابت لا يتغيّر مهما كان
        # المحتوى المعروض فعلياً، وهو ما كان يسبب لبساً: نافذة عنوانها
        # "محضر الحضور" بينما محتواها تقرير تسديدات مثلاً)
        self.setWindowTitle(title)
        self.resize(900, 900)

        # نحتفظ بمسار PDF (إن كان متوفراً) لاستعماله عند الطباعة، بدل
        # الاعتماد على محرك الطباعة الداخلي لمتصفح Chromium المضمَّن، والذي
        # يتسبب أحياناً بانهيار البرنامج بالكامل ("Python has stopped
        # working") بدل رمي استثناء بايثون عادي يمكن الإمساك به.
        self.pdf_file = pdf_file

        layout = QVBoxLayout()

        # متصفح داخلي (مثل Chrome) لعرض المعاينة فقط
        self.browser = QWebEngineView()
        file_url = QUrl.fromLocalFile(html_file)
        self.browser.load(file_url)

        layout.addWidget(self.browser)

        # الأزرار
        btn_layout = QHBoxLayout()

        self.print_btn = QPushButton("طباعة")
        self.pdf_btn = QPushButton("حفظ PDF")

        btn_layout.addWidget(self.print_btn)
        btn_layout.addWidget(self.pdf_btn)

        layout.addLayout(btn_layout)
        self.setLayout(layout)

        # ربط الأزرار
        self.print_btn.clicked.connect(self.print_report)
        self.pdf_btn.clicked.connect(self.save_pdf)

    # طباعة
    def print_report(self):
        if self.pdf_file and os.path.isfile(self.pdf_file):
            # نرسل أمر الطباعة إلى نظام التشغيل مباشرة على ملف الـ PDF
            # الجاهز (نفس ما يحدث لو فتحت الملف يدوياً وضغطت "طباعة" من
            # أي قارئ PDF) بدل المرور بمحرك طباعة Chromium الداخلي غير
            # المستقر الذي كان يتسبب بانهيار كامل للبرنامج.
            try:
                system = platform.system()
                if system == "Windows":
                    os.startfile(self.pdf_file, "print")
                elif system == "Darwin":
                    subprocess.run(["lp", self.pdf_file], check=False)
                else:
                    subprocess.run(["lp", self.pdf_file], check=False)
            except Exception as e:
                show_warning(
                    self, "تعذّرت الطباعة",
                    "تعذّر إرسال الملف للطباعة تلقائياً.\n"
                    f"يمكنك فتح ملف PDF التالي وطباعته يدوياً:\n{self.pdf_file}\n\nتفاصيل: {e}"
                )
            return

        # احتياط فقط إن لم يُمرَّر مسار PDF لأي سبب (لا يجب أن يحدث عادةً
        # بما أن كل الصفحات تُمرّره الآن). لا نحاول الطباعة عبر محرك
        # Chromium الداخلي (self.browser.page().print) لأنه معروف بتسببه
        # بانهيار كامل وصامت للبرنامج ("Python has stopped working") على
        # بعض الأجهزة (خصوصاً بطاقات رسوميات قديمة) - وهذا انهيار C++ حقيقي
        # لا يمكن الإمساك به بـ try/except، فتفادي الاستدعاء أصلاً أضمن حل.
        show_warning(
            self, "تعذّرت الطباعة",
            "لم يتم العثور على ملف PDF جاهز لهذا المستند.\n"
            "أعد توليد المستند أولاً، ثم اضغط طباعة مجدداً."
        )

    # حفظ PDF
    def save_pdf(self):
        if self.pdf_file and os.path.isfile(self.pdf_file):
            # يوجد أصلاً ملف PDF جاهز، ننسخه للمكان الذي يختاره المستخدم
            # بدل توليد نسخة جديدة عبر محرك Chromium الداخلي.
            file_path, _ = QFileDialog.getSaveFileName(
                self, "حفظ PDF", os.path.basename(self.pdf_file), "PDF Files (*.pdf)"
            )
            if file_path:
                try:
                    import shutil
                    shutil.copyfile(self.pdf_file, file_path)
                except Exception as e:
                    show_warning(self, "تعذّر الحفظ", f"تعذّر حفظ الملف:\n{e}")
            return

        file_path, _ = QFileDialog.getSaveFileName(
            self, "حفظ PDF", "", "PDF Files (*.pdf)"
        )
        if file_path:
            self.browser.page().printToPdf(file_path)
