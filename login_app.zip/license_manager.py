# -*- coding: utf-8 -*-
"""نظام النسخة التجريبية (30 يوماً) والاشتراك بمفتاح يُتحقَّق منه في الخادم.

كيف يعمل
--------
* التجربة: عند أول تشغيل يسأل البرنامج الخادم متى ظهر هذا الجهاز لأول مرة، فحذف الملفات
  أو إعادة تثبيت البرنامج لا يعيد الشهر المجاني.
* الاشتراك: مفتاح التفعيل يُنشئه المطوّر في الخادم (أداة admin_tool.py) ويُربط بجهاز واحد عند
  أول تفعيل. الخادم يردّ بشهادة موقَّعة بـ Ed25519 بمفتاحه الخاص (لا يوجد في البرنامج)،
  والبرنامج يحتوي المفتاح العام فقط: لا يمكن توليد مفاتيح ولا تزوير الرد منه.
* يتجدد التحقق من الخادم كل يوم عند التشغيل؛ يعمل البرنامج بدون إنترنت حتى GRACE_DAYS أيام
  من آخر تحقق ناجح، ثم يطلب الاتصال. إلغاء المفتاح في الخادم يسري عند أول تحقق.
* حالة التجربة والاشتراك تُحفظ في عدة أماكن موقَّعة بـ HMAC مرتبط بالجهاز، ويُسجَّل "آخر تاريخ
  تشغيل" لكشف الرجوع بساعة الجهاز للوراء.
* بعد انتهاء التجربة/الاشتراك يمكن للزبون متابعة "القراءة فقط" (عرض بياناته وتصديرها) حتى
  لا يفقد عمله.
لا حماية مطلقة في أي برنامج بايثون، لكن وضع التحقق في الخادم يمنع التجاوز العادي.
"""
import base64
import hashlib
import hmac
import json
import os
import platform
import threading
import time
import uuid
from datetime import date, datetime, timedelta

import device_fingerprint
import guard_client
import trial_online
from app_paths import app_base_dir

TRIAL_DAYS = 30
REMIND_DAYS = 7            # تذكير عند تبقّي هذا العدد من الأيام أو أقل
GRACE_DAYS = 7             # أقصى مدة عمل بدون اتصال بعد آخر تحقق ناجح من الاشتراك
REFRESH_DAYS = 1           # تجديد التحقق من الخادم إن مضى هذا العدد من الأيام
GUARD_GRACE_DAYS = 7       # أقصى مدة عمل للتجربة بدون اتصال بعد آخر تحقق ناجح من خادم الحماية
GUARD_MAX_DAYS = 7         # لا يُسمح بتأجيل التحقق الدوري أكثر من هذا مهما كان الموعد المخزَّن

_REG_KEYS = (r"Software\ExpertSystem\Core", r"Software\ExpertSystem\Cache")   # نسختان في السجل
_REG_VALUE = "s"
_READ_ONLY = False


# ----------------------------------------------------------------------
# الوقت (دالة مستقلة ليسهل اختبارها)
# ----------------------------------------------------------------------
def _today():
    return date.today()


# ----------------------------------------------------------------------
# رمز الجهاز
# ----------------------------------------------------------------------
def _machine_raw():
    if os.name == "nt":
        try:
            import winreg
            access = winreg.KEY_READ | getattr(winreg, "KEY_WOW64_64KEY", 0)
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                                r"SOFTWARE\Microsoft\Cryptography", 0, access) as k:
                return "G:" + str(winreg.QueryValueEx(k, "MachineGuid")[0])
        except Exception:
            pass
    return "N:%s|%s" % (platform.node(), uuid.getnode())


def machine_code():
    """رمز الجهاز بصيغة XXXX-XXXX-XXXX-XXXX (ثابت ما دام ويندوز لم يُعَد تثبيته)."""
    h = hashlib.sha256(("ES-LIC|" + _machine_raw()).encode("utf-8")).hexdigest()[:16].upper()
    return "-".join(h[i:i + 4] for i in range(0, 16, 4))


def _machine_bytes():
    return bytes.fromhex(machine_code().replace("-", ""))


# ----------------------------------------------------------------------
# تخزين الحالة (نسخ متعددة موقَّعة)
# ----------------------------------------------------------------------
def _legacy_hmac_key():
    """المفتاح القديم: مشتق من رمز الجهاز وحده (غير سري). يُقبل للقراءة فقط لترحيل الحالات المخزَّنة."""
    return hashlib.sha256(("ES-STATE|" + machine_code()).encode("utf-8")).digest()


def _hmac_key():
    """مفتاح التوقيع الحالي: رمز الجهاز + سر محلي عشوائي محميّ بـ DPAPI (local_protect).
    من لا يملك حساب ويندوز نفسه على هذا الجهاز لا يستطيع حسابه (بخلاف المفتاح القديم).
    ملاحظة صريحة: يبقى توقيعاً محلياً (كشف عبث)؛ المرجع النهائي هو الخادم والتحقق بـ Ed25519،
    ومالك الحساب نفسه يستطيع استدعاء DPAPI.
    إن تعذّر السر المحلي: قبل أول ترحيل نعود للمفتاح القديم (لا نرفض حالة صحيحة)، وبعده نُفشل
    مغلقاً بمفتاح عشوائي (حذف ملف المفتاح لا يعيدنا إلى مفتاح يحسبه أي شخص)."""
    try:
        import local_protect
        return hashlib.sha256(b"ES-STATE-2|" + machine_code().encode("utf-8")
                              + b"|" + local_protect.derived_key("license-state")).digest()
    except Exception:
        try:
            import local_protect
            migrated = local_protect.flag_get("license-state-v2")
        except Exception:
            migrated = False
        return os.urandom(32) if migrated else _legacy_hmac_key()


def _legacy_accepted():
    """التوقيع القديم يُقبل فقط قبل أول كتابة بالتوقيع الجديد (ترحيل لمرة واحدة)."""
    try:
        import local_protect
        return not local_protect.flag_get("license-state-v2")
    except Exception:
        return True


def _sign(body, key):
    return hmac.new(key, body.encode("ascii"), hashlib.sha256).hexdigest()[:32]


def _pack(state):
    body = base64.urlsafe_b64encode(json.dumps(state, sort_keys=True).encode("utf-8")).decode("ascii")
    return body + "." + _sign(body, _hmac_key())


def _unpack(text):
    """يرجع dict إن كان صحيحاً، None إن كان تالفاً/معدَّلاً. يقبل التوقيع القديم (وتُعاد كتابته بالجديد عند أول حفظ)."""
    try:
        body, sig = text.strip().rsplit(".", 1)
        if not (hmac.compare_digest(sig, _sign(body, _hmac_key()))
                or (_legacy_accepted() and hmac.compare_digest(sig, _sign(body, _legacy_hmac_key())))):
            return None
        state = json.loads(base64.urlsafe_b64decode(body.encode("ascii")).decode("utf-8"))
        return state if isinstance(state, dict) else None
    except Exception:
        return None


def _file_locations():
    import app_paths
    paths = [os.path.join(app_paths.machine_dir(), ".es_state")]      # حالة الترخيص خاصة بالجهاز
    appdata = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), ".config")
    paths.append(os.path.join(appdata, "ExpertSystem", ".state"))
    shared = os.environ.get("PROGRAMDATA")
    if shared:
        paths.append(os.path.join(shared, "ExpertSystem", ".state"))
    return paths


def _read_all():
    """يرجع (قائمة الحالات الصحيحة، هل وُجدت نسخة تالفة؟)."""
    valid, bad = [], False
    for p in _file_locations():
        try:
            if os.path.exists(p):
                with open(p, "r", encoding="ascii") as f:
                    s = _unpack(f.read())
                (valid.append(s) if s else None)
                bad = bad or (s is None)
        except Exception:
            bad = True
    if os.name == "nt":
        import winreg
        for reg_key in _REG_KEYS:
            try:
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER, reg_key) as k:
                    s = _unpack(str(winreg.QueryValueEx(k, _REG_VALUE)[0]))
                    (valid.append(s) if s else None)
                    bad = bad or (s is None)
            except FileNotFoundError:
                pass
            except Exception:
                pass
    return valid, bad


def _write_all(state):
    blob = _pack(state)
    try:
        import local_protect
        local_protect.derived_key("license-state")        # السر متاح، فالتوقيع الجديد صالح
        local_protect.flag_set("license-state-v2")        # من الآن لا يُقبل التوقيع القديم
    except Exception:
        pass
    for p in _file_locations():
        try:
            os.makedirs(os.path.dirname(p), exist_ok=True)
            tmp = p + ".tmp"
            with open(tmp, "w", encoding="ascii") as f:
                f.write(blob)
            os.replace(tmp, p)
        except Exception:
            pass
    if os.name == "nt":
        import winreg
        for reg_key in _REG_KEYS:
            try:
                with winreg.CreateKey(winreg.HKEY_CURRENT_USER, reg_key) as k:
                    winreg.SetValueEx(k, _REG_VALUE, 0, winreg.REG_SZ, blob)
            except Exception:
                pass


# ----------------------------------------------------------------------
# مفتاح التفعيل (يُتحقَّق منه في الخادم)
# ----------------------------------------------------------------------
def _clean_key(text):
    return "".join(ch for ch in (text or "").upper() if ch.isalnum())


_ERRORS = {
    "invalid": "مفتاح التفعيل غير صحيح أو أُلغي. تأكد من نسخه كاملاً.",
    "expired": "انتهت صلاحية هذا المفتاح. تواصل مع المطوّر لتجديده.",
    "other_device": "هذا المفتاح مُفعَّل على جهاز آخر. تواصل مع المطوّر إن غيّرت حاسوبك.",
    "bad": "رد غير صالح من الخادم. تأكد من اتصالك وأعد المحاولة.",
    "rate_limited": "محاولات كثيرة من هذه الشبكة. انتظر قليلاً ثم أعد المحاولة.",
}


def _iat_date(d):
    return trial_online._parse_time(d["iat"]).date()


# ----------------------------------------------------------------------
# خادم الحماية: بصمة جهاز متعددة المكوّنات + تحقق دوري بموعد عشوائي يحدده الخادم
# ----------------------------------------------------------------------
_IDENTITY = {"email": None, "otp": None}
_BG = {"thread": None, "result": None}


def set_trial_identity(email, otp):
    """تضعها نافذة بدء التجربة (بريد + رمز التحقق) ثم يُعاد تقييم الحالة."""
    _IDENTITY["email"], _IDENTITY["otp"] = (email or "").strip(), (otp or "").strip()


_OTP_MSGS = {
    "sent": (True, "أُرسل رمز التحقق إلى بريدك. تفقّد البريد (وصندوق الرسائل المزعجة)."),
    "wait": (False, "انتظر دقيقة قبل طلب رمز جديد."),
    "bad_email": (False, "البريد الإلكتروني غير صالح أو غير مقبول."),
    "rate_limited": (False, "محاولات كثيرة. حاول لاحقاً."),
    "mail_failed": (False, "تعذّر إرسال البريد الآن. حاول لاحقاً أو تواصل مع المطوّر."),
    "offline": (False, "لا يوجد اتصال بالإنترنت."),
}


def request_otp(email):
    """يطلب من الخادم إرسال رمز تحقق إلى البريد. يرجع (نجح؟، رسالة)."""
    st, _d = guard_client.request_otp(machine_code(), (email or "").strip())
    return _OTP_MSGS.get(st, (False, "تعذّر الاتصال بالخادم. حاول لاحقاً."))


def _gr_info(resp):
    """يتحقق من رد الحماية الموقَّع المخزَّن ويرجع معلوماته (أو None إن زُوِّر/لا يخص هذا الجهاز).
    التاريخ والبدء هنا من توقيع الخادم، فلا تفيد ملفات الحالة المعدَّلة ولا حجب الخادم."""
    d = guard_client.verify_stored(resp, machine_code()) if isinstance(resp, dict) else None
    if d is None:
        return None
    try:
        nxt = max(1, min(int(d.get("next") or 3), GUARD_MAX_DAYS))
        extra = max(0, min(int(d.get("extra") or 0), 365))      # أيام يمنحها المطوّر يدوياً
        iat = trial_online._parse_time(d["iat"]).date()
        return {"iat": iat, "nx": iat + timedelta(days=nxt), "extra": extra,
                "start": date.fromisoformat(d["start"])}
    except Exception:
        return None


def _guard_pack(st, d, today):
    if st == "ok":
        gi = _gr_info(d.get("_resp"))
        if gi is None:
            return "bad", d
        return "ok", {"start": gi["start"], "extra": gi["extra"], "gr": d["_resp"], "gi": gi}
    return st, d


def _guard_register(local_start, today):
    st, d = guard_client.first_run(machine_code(), device_fingerprint.collect(),
                                   _IDENTITY["email"], _IDENTITY["otp"], local_start)
    out = _guard_pack(st, d, today)
    if out[0] == "ok":
        _IDENTITY["otp"] = None
    return out


def _guard_beat(local_start, today):
    st, d = guard_client.heartbeat(machine_code(), device_fingerprint.collect())
    if st == "unknown":                               # جهاز لا يعرفه الخادم بعد (تحديث من نسخة قديمة)
        return _guard_register(local_start, today)
    return _guard_pack(st, d, today)


def _gr_load(states):
    """أحدث رد حماية موقَّع صالح بين النسخ المحفوظة: (info, resp) أو (None, None).
    لا يمكن اختلاق رد أحدث؛ ولا يفيد حذف النسخ لأن غيابها يُعامل كأنه لم يتحقق قط."""
    best = (None, None)
    for s in states:
        gr = s.get("gr")
        gi = _gr_info(gr)
        if gi and (best[0] is None or gi["iat"] > best[0]["iat"]):
            best = (gi, gr)
    return best


def _guard_due(gi, today):
    if gi is None:
        return True
    return (today >= gi["nx"] or (today - gi["iat"]).days >= GUARD_MAX_DAYS
            or today < gi["iat"] - timedelta(days=1))


def _guard_result(st, d, today):
    if st in ("offline", "error"):
        state = "need_online"
    elif st in ("otp_required", "otp_invalid", "otp_locked", "bad_email"):
        state = "need_otp"
    elif st in ("banned", "rate_limited"):
        state = "blocked"
    elif st == "trial_closed":                        # الخادم أغلق التجارب الجديدة: تظهر نافذة الترخيص ليُدخل المستعمل مفتاحه
        state = "expired"
    else:                                             # توقيع خاطئ / ساعة الجهاز بعيدة عن وقت الخادم
        state = "tampered"
    res = _result(state, today, None, None, "")
    res["reason"] = st
    return res


def start_background_check():
    """يُستدعى من مؤقّت الواجهة: يفحص الخادم في خيط جانبي إن حان الموعد، دون تجميد النافذة."""
    t = _BG["thread"]
    if (t is not None and t.is_alive()) or not guard_client.is_configured():
        return
    states, _bad = _read_all()
    if not states or any(s.get("lic") for s in states) or not _guard_due(_gr_load(states)[0], _today()):
        return

    def work():
        try:
            _BG["result"] = evaluate(update=True)
        except Exception:
            pass

    _BG["thread"] = threading.Thread(target=work, daemon=True)
    _BG["thread"].start()


def take_background_result():
    r, _BG["result"] = _BG["result"], None
    return r


# ----------------------------------------------------------------------
# الحالة العامة
# ----------------------------------------------------------------------
def evaluate(update=True):
    """يحسب حالة الترخيص الآن.

    state: trial | licensed | expired | license_expired | tampered | need_online
    update=False: بدون أي اتصال بالخادم وبدون كتابة (للقوائم والشاشات).
    """
    today = _today()
    states, bad = _read_all()
    resp = None

    gi, gr = None, None
    first_run = False
    if not states and not bad:                       # أول تشغيل (أو حُذفت ملفات الحالة)
        start, last, lic = today, today, ""
        if update and (trial_online.is_configured() or guard_client.is_configured()):
            # الخادم يتذكّر أول ظهور لهذا الجهاز: حذف الملفات لا يعيد التجربة
            if trial_online.is_configured():
                srv = trial_online.fetch_trial_start(machine_code())
                if srv is None:                      # لا اتصال: لا تبدأ التجربة
                    return _result("need_online", today, None, None, "")
                start = min(srv, today)
            if guard_client.is_configured():
                # خادم الحماية: يتعرّف على الجهاز ببصمته حتى لو تغيّر رمزه (إعادة تثبيت ويندوز...)
                gst, ginfo = _guard_register(start, today)
                if gst != "ok":
                    return _guard_result(gst, ginfo, today)
                start = min(start, ginfo["start"]) + timedelta(days=ginfo["extra"])
                gi, gr = ginfo["gi"], ginfo["gr"]
            first_run = True
    elif not states:                                 # كل النسخ تالفة/معدَّلة
        return _result("tampered", today, None, None, "")
    else:
        try:
            starts = [date.fromisoformat(s["start"]) for s in states if s.get("start")]
            lasts = [date.fromisoformat(s["last"]) for s in states if s.get("last")]
        except (ValueError, TypeError):              # حالة بتوقيع صحيح لكن بتواريخ تالفة = تلاعب
            return _result("tampered", today, None, None, "")
        start = min(starts) if starts else today
        last = max(lasts) if lasts else today
        lic = next((s["lic"] for s in states if s.get("lic")), "")
        resp = next((s["resp"] for s in states if s.get("resp")), None)
        gi, gr = _gr_load(states)

    rolled_back = today < last - timedelta(days=1)

    if lic:
        # ---------- اشتراك: التحقق من الشهادة الموقَّعة ----------
        mc = machine_code()
        d = trial_online.verify_resp(resp, mc) if resp else None
        if d is not None and d.get("t") != "license":
            d = None
        prev_exp = None
        if d is not None:
            try:
                prev_exp = trial_online._parse_time(d["exp"]).date()
            except Exception:
                d = None

        refused = None
        stale = d is None
        if d is not None:
            try:
                stale = (today - _iat_date(d)).days >= REFRESH_DAYS
            except Exception:
                d, stale = None, True
        if update and stale and not rolled_back and trial_online.is_configured():
            st, nd, nresp = trial_online.activate_online(lic, mc)
            if st == "ok":
                if not trial_online.server_clock_ok(nd):
                    return _result("tampered", today, start, prev_exp, "")
                d, resp = nd, nresp
                try:
                    prev_exp = trial_online._parse_time(d["exp"]).date()
                except Exception:
                    d = None
            elif st in ("invalid", "expired", "other_device"):
                refused = st                          # الخادم رفض: سقط الترخيص
            # offline / bad: نكمل بالشهادة المخزّنة إن كانت ضمن مهلة GRACE_DAYS

        if refused:
            if update:
                _write_all({"start": start.isoformat(), "last": max(last, today).isoformat(), "lic": ""})
            res = _result("license_expired", today, start, prev_exp or today, "")
            res["reason"] = refused
            return res
        if rolled_back:
            return _result("tampered", today, start, prev_exp, "")
        if d is None:                                 # لا شهادة صالحة: يلزم اتصال
            res = _result("need_online", today, start, None, "")
            res["reason"] = "license"
            return res
        age = (today - _iat_date(d)).days
        if age < -2:                                  # شهادة "من المستقبل": ساعة الجهاز رُجعت للوراء
            return _result("tampered", today, start, prev_exp, "")
        if age > GRACE_DAYS:
            res = _result("need_online", today, start, prev_exp, "")
            res["reason"] = "license"
            return res
        if today > prev_exp:
            res = _result("license_expired", today, start, prev_exp, "")
        else:
            res = _result("licensed", today, start, prev_exp, "")
        if update:
            new = {"start": start.isoformat(), "last": max(last, today).isoformat(), "lic": lic}
            if resp:
                new["resp"] = resp
            _write_all(new)
        return res

    # ---------- تجربة مجانية ----------
    if rolled_back:
        return _result("tampered", today, start, None, "")
    if gi is not None and today < gi["iat"] - timedelta(days=2):
        return _result("tampered", today, start, None, "")   # آخر تحقق موقَّع "من المستقبل": ساعة رُجعت للوراء
    if guard_client.is_configured():
        if update and not first_run and _guard_due(gi, today):
            gst, ginfo = _guard_beat(start, today)
            if gst == "ok":
                gi, gr = ginfo["gi"], ginfo["gr"]
            elif gst in ("offline", "error"):
                if gi is None or (today - gi["iat"]).days > GUARD_GRACE_DAYS:
                    res = _result("need_online", today, start, None, "")
                    res["reason"] = "guard"
                    return res
            else:
                return _guard_result(gst, ginfo, today)
        elif gi is None or (today - gi["iat"]).days > GUARD_GRACE_DAYS:
            # بلا تحقق موقَّع حديث لا نسمح بالعمل (نسخ قديمة بلا رد موقَّع تتصل مرة واحدة فقط لتُرقّى)
            res = _result("need_online", today, start, None, "")
            res["reason"] = "guard"
            return res
        if gi is not None:
            start = min(start, gi["start"]) + timedelta(days=gi["extra"])
    left = TRIAL_DAYS - (today - start).days
    res = _result("trial" if left > 0 else "expired", today, start, None, "")
    res["days_left"] = max(left, 0)
    res["first_run"] = first_run
    if update:
        new = {"start": start.isoformat(), "last": max(last, today).isoformat(), "lic": ""}
        if gr:
            new["gr"] = gr
        _write_all(new)
    return res


def _result(state, today, start, expiry, name):
    days_left = None
    if state == "licensed" and expiry:
        days_left = (expiry - today).days
    return {"state": state, "days_left": days_left, "start": start,
            "expiry": expiry, "customer": name, "machine": machine_code(), "reason": None}


def current_license_key():
    """مفتاح الترخيص الحالي إن كان مفعَّلاً، وإلا نص فارغ (نسخة تجريبية). لا يرفع استثناءً."""
    try:
        states, _bad = _read_all()
        return next((s["lic"] for s in states if s.get("lic")), "")
    except Exception:
        return ""


def activate(key_text):
    """يفعّل البرنامج بمفتاح بعد التحقق منه في الخادم. يرجع (نجح؟، رسالة)."""
    key = _clean_key(key_text)
    if not key:
        return False, "الصق مفتاح التفعيل أولاً."
    if not trial_online.is_configured():
        return False, "خادم التفعيل غير مضبوط في هذه النسخة."
    mc = machine_code()
    st, d, resp = trial_online.activate_online(key, mc)
    if st == "offline":
        return False, "لا يوجد اتصال بالإنترنت. اتصل ثم أعد المحاولة."
    if st != "ok":
        return False, _ERRORS.get(st, _ERRORS["bad"])
    if not trial_online.server_clock_ok(d):
        return False, "تاريخ الجهاز غير صحيح. صحّح التاريخ والساعة ثم أعد المحاولة."
    states, _bad = _read_all()
    start = min([date.fromisoformat(s["start"]) for s in states if s.get("start")] or [_today()])
    _write_all({"start": start.isoformat(), "last": _today().isoformat(), "lic": key, "resp": resp})
    set_read_only(False)
    exp = trial_online._parse_time(d["exp"]).date()
    return True, "تم تفعيل البرنامج (حتى %s). شكراً لثقتك." % exp.strftime("%d/%m/%Y")


# ----------------------------------------------------------------------
# وضع القراءة فقط (بعد انتهاء التجربة إن اختاره المستخدم)
# ----------------------------------------------------------------------
_RO_STATES = ("expired", "license_expired", "tampered", "blocked", "need_online")
_RO_CACHE = {"t": 0.0, "v": False}


def set_read_only(value):
    global _READ_ONLY
    _READ_ONLY = bool(value)
    _RO_CACHE["t"] = 0.0


def is_read_only():
    """قراءة فقط إن اختارها المستخدم/الواجهة، أو إن كانت الحالة المحسوبة من الملفات الموقَّعة تقتضي ذلك.
    الحالة تُعاد من الملفات كل دقيقة، فتثبيت المتغير العام على False وحده لا يكفي لتجاوزها."""
    if _READ_ONLY:
        return True
    try:
        import hardening
        if hardening.tampered_runtime():
            return True
    except Exception:
        pass
    now = time.monotonic()
    if now - _RO_CACHE["t"] > 60 or _RO_CACHE["t"] == 0.0:
        try:
            _RO_CACHE["v"] = evaluate(update=False)["state"] in _RO_STATES
        except Exception:
            _RO_CACHE["v"] = True                    # فشل مغلق: خطأ غير متوقع لا يمنح صلاحية الكتابة
        _RO_CACHE["t"] = now
    return _RO_CACHE["v"]


def status_text(st=None):
    """سطر قصير يصف الحالة (للشاشات والقوائم)."""
    st = st or evaluate(update=False)
    s = st["state"]
    if s == "trial":
        return "نسخة تجريبية — باقي %d يوماً" % st["days_left"]
    if s == "licensed":
        who = (" — " + st["customer"]) if st["customer"] else ""
        if st["expiry"]:
            return "نسخة مفعّلة%s (حتى %s)" % (who, st["expiry"].strftime("%d/%m/%Y"))
        return "نسخة مفعّلة%s" % who
    if s == "license_expired":
        return "انتهت صلاحية الترخيص"
    if s == "tampered":
        return "تم اكتشاف تغيير في تاريخ الجهاز"
    if s == "blocked":
        return "تعذّر تشغيل النسخة التجريبية على هذا الجهاز"
    if s in ("need_online", "need_otp"):
        return "يلزم الاتصال بالإنترنت للتحقق"
    return "انتهت الفترة التجريبية"
