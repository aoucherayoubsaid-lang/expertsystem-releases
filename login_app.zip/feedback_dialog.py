# -*- coding: utf-8 -*-
"""نافذة «إرسال اقتراح أو مشكلة».

لا يرسل البرنامج أي شيء تلقائياً ولا يتصل بأي خادم: يُجهِّز نصاً مرتباً، ثم يختار
المستخدم بنفسه طريقة إرساله (واتساب، بريد، نسخ، أو حفظ ملف).
المعلومات التقنية المرفقة اختيارية وليس فيها أي بيانات قضايا أو أطراف.
"""
import os
import platform
from datetime import datetime

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QApplication, QButtonGroup, QCheckBox, QDialog, QFileDialog, QFrame,
    QGridLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QTextEdit,
    QVBoxLayout,
)
import qtawesome as qta

import app_info
import contact_utils
import message_templates as mt
from msgbox_ltr import show_info, show_warning

NAVY = "#4338ca"
TYPES = [
    ("suggestion", "اقتراح", "fa5s.lightbulb", "#b05c00", "اقتراح"),
    ("problem", "مشكلة", "fa5s.bug", "#d03a50", "مشكلة"),
    ("question", "سؤال", "fa5s.question-circle", "#5a4ee3", "سؤال"),
]


class FeedbackDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("إرسال اقتراح أو مشكلة")
        self.setLayoutDirection(Qt.RightToLeft)
        self.setMinimumWidth(620)
        self.setStyleSheet("""
            QDialog { background: #f8f9ff; }
            QLabel { color: #1f2347; }
            QLineEdit, QTextEdit { background: white; border: 1px solid #cdd3ee;
                                   border-radius: 6px; padding: 6px; }
            QLineEdit:focus, QTextEdit:focus { border: 1px solid #5a4ee3; }
        """)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 14)
        root.setSpacing(10)

        # ---- الترويسة ----
        head = QFrame()
        head.setStyleSheet("QFrame { background: %s; } QLabel { color: white; background: transparent; }" % NAVY)
        hl = QVBoxLayout(head)
        hl.setContentsMargins(22, 14, 22, 14)
        t = QLabel("رأيك يصنع الفرق")
        t.setStyleSheet("font-size: 18px; font-weight: bold; color: white;")
        s = QLabel("اقتراح لتطوير البرنامج، أو مشكلة واجهتك؟ اكتبها هنا وأرسلها لي مباشرة.")
        s.setStyleSheet("color: #cdd3ee; font-size: 12px;")
        s.setWordWrap(True)
        hl.addWidget(t)
        hl.addWidget(s)
        root.addWidget(head)

        body = QVBoxLayout()
        body.setContentsMargins(22, 4, 22, 0)
        body.setSpacing(10)
        root.addLayout(body)

        # ---- نوع الرسالة ----
        body.addWidget(QLabel("نوع الرسالة:"))
        row = QHBoxLayout()
        self.group = QButtonGroup(self)
        self.type_buttons = {}
        for key, label, icon, color, _word in TYPES:
            b = QPushButton("  " + label)
            b.setCheckable(True)
            b.setIcon(qta.icon(icon, color=color))
            b.setCursor(Qt.PointingHandCursor)
            b.setMinimumHeight(40)
            b.setStyleSheet(
                "QPushButton { background: white; border: 2px solid #e4e7f7; border-radius: 8px;"
                " color: #1f2347; font-weight: bold; padding: 4px 14px; }"
                "QPushButton:hover { border-color: %s; }"
                "QPushButton:checked { border-color: %s; background: #f1f2ff; }" % (color, color))
            self.group.addButton(b)
            self.type_buttons[key] = b
            row.addWidget(b)
        self.type_buttons["suggestion"].setChecked(True)
        self.group.setExclusive(True)
        self.group.buttonClicked.connect(self._on_type)
        body.addLayout(row)

        # ---- العنوان والوصف ----
        body.addWidget(QLabel("العنوان (جملة قصيرة):"))
        self.subject = QLineEdit()
        self.subject.setPlaceholderText("مثال: أريد إضافة طباعة قائمة الجلسات")
        body.addWidget(self.subject)

        self.desc_label = QLabel()
        body.addWidget(self.desc_label)
        self.desc = QTextEdit()
        self.desc.setMinimumHeight(130)
        body.addWidget(self.desc)
        self._on_type()

        # ---- بيانات التواصل ----
        grid = QGridLayout()
        grid.setHorizontalSpacing(10)
        grid.addWidget(QLabel("اسمك (اختياري):"), 0, 0)
        grid.addWidget(QLabel("هاتفك أو بريدك للرد عليك (اختياري):"), 0, 1)
        self.name = QLineEdit()
        self.contact = QLineEdit()
        grid.addWidget(self.name, 1, 0)
        grid.addWidget(self.contact, 1, 1)
        body.addLayout(grid)

        # ---- المعلومات التقنية + الخصوصية ----
        self.tech_cb = QCheckBox("إرفاق معلومات تقنية تساعدني في فهم المشكلة (الإصدار ونظام ويندوز فقط)")
        self.tech_cb.setChecked(True)
        body.addWidget(self.tech_cb)
        privacy = QLabel("لا يُرسَل أي شيء تلقائياً، وأنت من يضغط الإرسال. "
                         "من فضلك لا تكتب أسماء الأطراف أو أرقام القضايا فهي بيانات سرّية.")
        privacy.setWordWrap(True)
        privacy.setStyleSheet("color: #5b6485; font-size: 11px;")
        body.addWidget(privacy)

        # ---- أزرار الإرسال ----
        send_row = QHBoxLayout()
        send_row.setSpacing(8)
        self._add_btn(send_row, "واتساب", "fa5b.whatsapp", "#128456", self.send_whatsapp)
        self._add_btn(send_row, "بريد Gmail", "fa5s.envelope", "#d03a50", self.send_gmail)
        self._add_btn(send_row, "برنامج البريد", "fa5s.at", "#5a4ee3", self.send_mailto)
        body.addLayout(send_row)

        other = QHBoxLayout()
        other.setSpacing(8)
        self._add_btn(other, "معاينة", "fa5s.eye", "#1f2347", self.preview)
        self._add_btn(other, "نسخ النص", "fa5s.copy", "#5b6485", self.copy_text)
        self._add_btn(other, "حفظ كملف نصي", "fa5s.save", "#5b6485", self.save_file)
        close = QPushButton("إغلاق")
        close.setMinimumHeight(36)
        close.clicked.connect(self.reject)
        other.addStretch(1)
        other.addWidget(close)
        body.addLayout(other)

        who = QLabel("للتواصل المباشر:  %s  |  %s" % (app_info.DEVELOPER_PHONE, app_info.DEVELOPER_EMAIL))
        who.setAlignment(Qt.AlignCenter)
        who.setStyleSheet("color: #5b6485; font-size: 11px;")
        who.setTextInteractionFlags(Qt.TextSelectableByMouse)
        body.addWidget(who)

    # ------------------------------------------------------------------
    def _add_btn(self, layout, text, icon, color, handler):
        b = QPushButton("  " + text)
        b.setIcon(qta.icon(icon, color="white"))
        b.setMinimumHeight(38)
        b.setCursor(Qt.PointingHandCursor)
        b.setStyleSheet(
            "QPushButton { background: %s; color: white; border: none; border-radius: 6px;"
            " padding: 6px 16px; font-weight: bold; }"
            "QPushButton:hover { background: #1f2347; }" % color)
        b.clicked.connect(handler)
        layout.addWidget(b)
        return b

    def _current_type(self):
        for key, label, _i, _c, word in TYPES:
            if self.type_buttons[key].isChecked():
                return key, label, word
        return TYPES[0][0], TYPES[0][1], TYPES[0][4]

    def _on_type(self, *_):
        key, _label, _word = self._current_type()
        if key == "problem":
            self.desc_label.setText("صف المشكلة: ماذا فعلت؟ ماذا ظهر لك؟ وماذا كنت تنتظر؟")
            self.desc.setPlaceholderText("1) فتحت صفحة ...\n2) ضغطت على ...\n3) ظهرت رسالة / لم يحدث شيء ...")
        elif key == "question":
            self.desc_label.setText("اكتب سؤالك:")
            self.desc.setPlaceholderText("اكتب سؤالك بوضوح وسأجيبك في أقرب وقت.")
        else:
            self.desc_label.setText("اشرح اقتراحك:")
            self.desc.setPlaceholderText("ما الذي تتمنى إضافته أو تحسينه؟ وكيف سيفيدك في عملك؟")

    # ------------------------------------------------------------------
    def build_message(self, style="plain"):
        _key, _label, word = self._current_type()
        return mt.feedback_message(
            style, word, self.subject.text().strip(), self.desc.toPlainText().strip(),
            self.name.text().strip(), self.contact.text().strip(), self.tech_cb.isChecked())

    def _subject_line(self):
        _k, _l, word = self._current_type()
        return mt.feedback_subject(word, self.subject.text().strip())

    def _validate(self):
        if len(self.desc.toPlainText().strip()) < 10:
            show_warning(self, "تنبيه", "اكتب وصفاً أوضح (10 أحرف على الأقل) قبل الإرسال.")
            self.desc.setFocus()
            return False
        return True

    def preview(self):
        if not self._validate():
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("معاينة الرسالة")
        dlg.setLayoutDirection(Qt.RightToLeft)
        dlg.resize(520, 480)
        lay = QVBoxLayout(dlg)
        lay.addWidget(QLabel("هكذا ستصل الرسالة إلى المطوّر:"))
        box = QTextEdit()
        box.setReadOnly(True)
        box.setPlainText(self.build_message("wa").replace("*", ""))
        lay.addWidget(box)
        ok = QPushButton("إغلاق")
        ok.clicked.connect(dlg.accept)
        lay.addWidget(ok)
        dlg.exec_()

    def send_whatsapp(self):
        if self._validate():
            contact_utils.open_whatsapp(self.build_message("wa"))
            show_info(self, "واتساب", "فُتحت المحادثة مع المطوّر. اضغط «إرسال» هناك لإكمال الرسالة.")

    def send_gmail(self):
        if self._validate():
            contact_utils.open_gmail(self._subject_line(), self.build_message("mail"))
            show_info(self, "Gmail", "فُتحت رسالة جاهزة في المتصفح. اضغط «إرسال» هناك لإكمالها.")

    def send_mailto(self):
        if self._validate():
            contact_utils.open_mail_client(self._subject_line(), self.build_message("plain"))

    def copy_text(self):
        if self._validate():
            QApplication.clipboard().setText(self.build_message("wa"))
            show_info(self, "تم النسخ", "نُسخ النص. الصقه في أي تطبيق (واتساب، بريد، ماسنجر ...) وأرسله.")

    def save_file(self):
        if not self._validate():
            return
        desktop = os.path.join(os.path.expanduser("~"), "Desktop")
        start = os.path.join(desktop if os.path.isdir(desktop) else os.path.expanduser("~"),
                             "رسالة_للمطور_%s.txt" % datetime.now().strftime("%Y%m%d_%H%M"))
        path, _ = QFileDialog.getSaveFileName(self, "حفظ الرسالة", start, "ملف نصي (*.txt)")
        if path:
            with open(path, "w", encoding="utf-8-sig") as f:
                f.write(self.build_message())
            show_info(self, "تم الحفظ", "حُفظ الملف:\n%s\nأرسله لي على البريد أو واتساب." % path)
