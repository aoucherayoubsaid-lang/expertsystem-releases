# -*- coding: utf-8 -*-
"""تدقيق وثائق القضية قبل أن يعتمد عليها التقرير.

ثلاث طبقات، والأرقام لا تُحسب أبداً بالذكاء الاصطناعي:
  1) استخراج منظّم: يقرأ النموذج كل وثيقة مرة واحدة كاملة (لا مقتطفات) ويكتب الأرقام كما هي في JSON ثابت.
  2) فحص حسابي بالكود: كمية×سعر = مبلغ البند، مجموع البنود = HT، HT×النسبة = TVA، HT+TVA+الطابع = TTC،
     المدفوع+المتبقي = TTC، ثم مطابقة الوثائق التي تحمل نفس الرقم بعضها مع بعض.
  3) تأكيد الخبير: كل مبلغ يؤكّده أو يصحّحه الخبير يُخزَّن ويصبح أقوى دليل في التحقق (verify_inputs).

التخزين: ملف JSON لكل قضية داخل مجلد السنة. لا يُعاد استخراج وثيقة لم يتغيّر ملفها (بصمة sha).
متوافق مع بايثون 3.8.
"""
import json
import os
import re

SCHEMA = (
    '{"doc_type":"invoice|proforma|customs_declaration|payment|contract|statement|payslip|tax_return|other",'
    '"number":"","date":"YYYY-MM-DD أو فارغ","issuer":"","recipient":"","currency":"رمز ISO مثل DZD أو EUR أو فارغ",'
    '"lines":[{"desc":"","qty":null,"unit_price":null,"amount":null,"vat_rate":null}],'
    '"totals":{"ht":null,"discount":null,"vat":null,"vat_rate":null,"stamp":null,"ttc":null,"paid":null,"balance":null},'
    '"other_amounts":[{"label":"","value":null,"date":""}],'
    '"refs":[{"type":"أمر شراء|عقد|فاتورة|تصريح|...","number":""}],'
    '"unreadable":["كل حقل أو رقم غير واضح أو مشكوك فيه"]}'
)

EXTRACT_RULES = (
    "أنت تنقل بيانات وثيقة مالية إلى JSON فقط، دون أي شرح. القواعد: (1) انقل كل رقم كما هو مكتوب بالضبط، "
    "ولا تحسب ولا تصحّح ولا تُكمل رقماً ناقصاً ولا تخمّن. (2) الأرقام قيم JSON عادية: نقطة عشرية وبلا فواصل آلاف "
    "وبلا رمز عملة (1 250 000,50 تصبح 1250000.5). (3) النسب أرقام عادية (19% تصبح 19). (4) إن كان رقم غير واضح أو "
    "ممكن القراءة بأكثر من وجه فضع null واذكره في unreadable مع وصفه. (5) أي رقم لا يتبع الحقول المعروفة "
    "(غرامة، حق جمركي، قسط، دفعة...) ضعه في other_amounts بوصفه كما ورد. (6) الحقل غير الموجود في الوثيقة null أو فارغ. "
    "(7) التواريخ بصيغة YYYY-MM-DD. (8) وثيقة بلا أي مبلغ: أعد lines و other_amounts فارغتين. "
    "(9) لا تُسقط أي بند: كل سطر فيه مبلغ يدخل lines أو other_amounts حتى لو بدا مكرراً أو هامشياً. "
    "(10) refs: كل وثيقة أخرى تحيل إليها هذه الوثيقة برقمها (أمر شراء، عقد، فاتورة، تصريح جمركي...) دون تخمين."
)

FACTS_PREFIX = "بيانات مستخرجة: "         # يطابق report_engine.FACTS_PREFIX
SEG = 12000                  # حجم الجزء الواحد المرسل للاستخراج؛ الوثيقة الأطول تُقسَّم ولا تُقتطع أبداً
MAX_SEGS = 12
MIN_DIGITS_DOC = 3          # وثيقة بلا ثلاثة أرقام (3 خانات فأكثر) لا تستحق استخراجاً
_MONEY_RE = re.compile(r"\d[\d\s\u00a0\u202f.,]{2,}\d|\d{3,}")


# ---------------------------------------------------------------------------
# أرقام
# ---------------------------------------------------------------------------
def _to_num(v):
    """يرجع (قيمة|None, ملتبس:bool). النص الملتبس (مثل 1,000) لا يُخمَّن."""
    import report_engine as R
    if v is None or (isinstance(v, str) and not v.strip()):
        return None, False
    try:
        return R.to_number(v), False
    except ValueError:
        return None, True


_TOT = ("ht", "discount", "vat", "vat_rate", "stamp", "ttc", "paid", "balance")


def normalize_doc(raw):
    """ينظّف ناتج النموذج: أرقام float أو None، ويرجع (doc, bad) حيث bad قائمة حقول بأرقام ملتبسة."""
    bad = []
    raw = raw if isinstance(raw, dict) else {}
    doc = {"doc_type": str(raw.get("doc_type") or "other").strip().lower(),
           "number": str(raw.get("number") or "").strip(),
           "date": str(raw.get("date") or "").strip(),
           "issuer": str(raw.get("issuer") or "").strip(),
           "recipient": str(raw.get("recipient") or "").strip(),
           "currency": str(raw.get("currency") or "").strip().upper(),
           "lines": [], "totals": {}, "other_amounts": [], "refs": [],
           "unreadable": [str(x) for x in (raw.get("unreadable") or []) if str(x).strip()]}
    for i, ln in enumerate(raw.get("lines") or []):
        if not isinstance(ln, dict):
            continue
        row = {"desc": str(ln.get("desc") or "").strip()}
        for k in ("qty", "unit_price", "amount", "vat_rate"):
            v, amb = _to_num(ln.get(k))
            row[k] = v
            if amb:
                bad.append("البند %d (%s): «%s»" % (i + 1, k, ln.get(k)))
        doc["lines"].append(row)
    tot = raw.get("totals") if isinstance(raw.get("totals"), dict) else {}
    for k in _TOT:
        v, amb = _to_num(tot.get(k))
        doc["totals"][k] = v
        if amb:
            bad.append("%s: «%s»" % (k, tot.get(k)))
    for o in raw.get("other_amounts") or []:
        if not isinstance(o, dict):
            continue
        v, amb = _to_num(o.get("value"))
        if v is None:
            if amb:
                bad.append("%s: «%s»" % (o.get("label", ""), o.get("value")))
            continue
        doc["other_amounts"].append({"label": str(o.get("label") or "").strip(), "value": v,
                                     "date": str(o.get("date") or "").strip()})
    for r in raw.get("refs") or []:
        if isinstance(r, dict) and str(r.get("number") or "").strip():
            doc["refs"].append({"type": str(r.get("type") or "").strip(), "number": str(r["number"]).strip()})
    return doc, bad


# ---------------------------------------------------------------------------
# الفحص الحسابي (كود فقط)
# ---------------------------------------------------------------------------
def _issue(sev, code, msg, fields=()):
    return {"sev": sev, "code": code, "msg": msg, "fields": list(fields)}


def audit_doc(doc, bad=()):
    """يفحص وثيقة واحدة. يرجع قائمة مشكلات {sev: error|warn, code, msg, fields}."""
    from report_engine import fmt_num as f
    out = []
    for b in bad:
        out.append(_issue("error", "ambiguous", "رقم ملتبس لا يُعرف إن كانت الفاصلة آلافاً أو عشرية: " + b))
    for u in doc.get("unreadable") or []:
        out.append(_issue("warn", "unreadable", "النموذج لم يقرأ بوضوح: " + u))
    t = doc.get("totals", {})
    lines = doc.get("lines", [])
    ht, vat, ttc = t.get("ht"), t.get("vat"), t.get("ttc")
    stamp = t.get("stamp") or 0.0
    disc = t.get("discount") or 0.0

    # (1) كل بند: كمية × سعر = مبلغ (السعر قد يكون مقرّباً إلى سنتيمين فنسمح بنصف سنتيم لكل وحدة)
    for i, ln in enumerate(lines):
        q, p, a = ln.get("qty"), ln.get("unit_price"), ln.get("amount")
        if q is not None and p is not None and a is not None:
            calc = q * p
            tol = 0.011 + abs(q) * 0.005
            if abs(calc - a) > tol:
                out.append(_issue("error", "line_mul",
                                  "البند %d «%s»: %s × %s = %s لكن المكتوب %s (فرق %s)." % (
                                      i + 1, ln.get("desc", "")[:40], f(q), f(p), f(calc), f(a), f(abs(calc - a))),
                                  ["lines.%d.amount" % i]))
        for k in ("qty", "unit_price", "amount"):
            if ln.get(k) is not None and ln[k] < 0:
                out.append(_issue("warn", "negative", "البند %d: قيمة سالبة في %s." % (i + 1, k), ["lines.%d.%s" % (i, k)]))

    amounts = [ln["amount"] for ln in lines if ln.get("amount") is not None]
    complete_lines = bool(lines) and len(amounts) == len(lines)

    # (2) مجموع البنود = HT (قبل أو بعد الخصم)
    if complete_lines and ht is not None:
        s = sum(amounts)
        if abs(s - ht) > 0.02 and abs(s - disc - ht) > 0.02:
            out.append(_issue("error", "sum_lines",
                              "مجموع مبالغ البنود %s لا يساوي المبلغ خارج الرسم %s (فرق %s)." % (
                                  f(s), f(ht), f(abs(s - ht))), ["totals.ht"]))

    # (3) TVA = HT × النسبة
    rate = t.get("vat_rate")
    if vat is not None and ht is not None:
        base = ht
        line_rates = {ln.get("vat_rate") for ln in lines if ln.get("vat_rate") is not None}
        if rate is not None:
            exp = base * rate / 100.0
            if abs(exp - vat) > 0.02:
                out.append(_issue("error", "vat", "الرسم %s لا يساوي %s%% من %s (المتوقع %s)." % (
                    f(vat), f(rate), f(base), f(exp)), ["totals.vat"]))
        elif len(line_rates) > 1 and complete_lines and all(ln.get("vat_rate") is not None for ln in lines):
            exp = sum(ln["amount"] * ln["vat_rate"] / 100.0 for ln in lines)
            if abs(exp - vat) > 0.05 * len(lines):
                out.append(_issue("error", "vat", "مجموع الرسم حسب نسب البنود %s لا يساوي المكتوب %s." % (f(exp), f(vat)),
                                  ["totals.vat"]))
        elif ht != 0:
            out.append(_issue("warn", "vat_rate_missing",
                              "نسبة الرسم غير مذكورة؛ النسبة الضمنية %s%% (تحقق أنها النسبة القانونية)." % f(vat / ht * 100.0),
                              ["totals.vat_rate"]))

    # (4) TTC = HT + TVA + الطابع
    if ttc is not None and ht is not None and vat is not None:
        exp = ht + vat + stamp
        if abs(exp - ttc) > 0.02:
            out.append(_issue("error", "ttc", "المبلغ الإجمالي %s لا يساوي %s + %s + %s = %s (فرق %s)." % (
                f(ttc), f(ht), f(vat), f(stamp), f(exp), f(abs(exp - ttc))), ["totals.ttc"]))
    elif ttc is not None and ht is not None and vat is None and abs(ttc - ht) > 0.02:
        out.append(_issue("warn", "ttc_no_vat", "المبلغ الإجمالي %s يختلف عن HT %s ولا رسم مذكور." % (f(ttc), f(ht)),
                          ["totals.ttc"]))

    # (5) المدفوع + المتبقي = الإجمالي
    paid, bal = t.get("paid"), t.get("balance")
    if paid is not None and bal is not None:
        base = ttc if ttc is not None else ht
        if base is not None and abs(paid + bal - base) > 0.02:
            out.append(_issue("error", "balance", "المدفوع %s + المتبقي %s لا يساوي الإجمالي %s." % (f(paid), f(bal), f(base)),
                              ["totals.balance"]))

    # (6) تناسق عام
    has_money = bool(amounts) or any(t.get(k) is not None for k in _TOT) or doc.get("other_amounts")
    if has_money and not doc.get("currency"):
        out.append(_issue("warn", "no_currency", "العملة غير مذكورة في الوثيقة؛ حدّدها قبل استعمال المبالغ."))
    for k in ("ht", "vat", "ttc", "paid"):
        if t.get(k) is not None and t[k] < 0:
            out.append(_issue("warn", "negative", "قيمة سالبة في %s (قد تكون إشعار دائن)." % k, ["totals." + k]))
    return out


def cross_check(docs):
    """docs: قائمة (العنوان, doc). يطابق الوثائق التي تحمل نفس النوع والرقم، ويرجع قائمة نصوص."""
    from report_engine import fmt_num as f
    groups = {}
    for title, d in docs:
        num = re.sub(r"[\s/\\\-_.]", "", str(d.get("number", ""))).lower()
        if num:
            groups.setdefault((d.get("doc_type", ""), num), []).append((title, d))
    out = []
    for (_typ, _num), items in groups.items():
        if len(items) < 2:
            continue
        for key, label in (("ttc", "المبلغ الإجمالي"), ("ht", "المبلغ خارج الرسم")):
            vals = [(t, d["totals"].get(key)) for t, d in items if d["totals"].get(key) is not None]
            if len({round(v, 2) for _, v in vals}) > 1:
                out.append("تعارض بين نسخ الوثيقة رقم %s في %s: %s." % (
                    items[0][1].get("number"), label, " ، ".join("«%s»: %s" % (t, f(v)) for t, v in vals)))
        dates = {d.get("date") for _, d in items if d.get("date")}
        if len(dates) > 1:
            out.append("تعارض في تاريخ الوثيقة رقم %s بين نسخها: %s." % (items[0][1].get("number"), " ، ".join(sorted(dates))))
    return out


# ---------------------------------------------------------------------------
# تخزين التدقيق لكل قضية
# ---------------------------------------------------------------------------
def _path(case_number):
    import storage
    safe = re.sub(r"[^\w\-]+", "_", str(case_number), flags=re.UNICODE)
    return storage._year_path(os.path.join("doc_audit", safe + ".json"))


def load(case_number):
    try:
        with open(_path(case_number), "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception:
        data = {}
    data.setdefault("docs", {})
    data.setdefault("cross", [])
    return data


def save(case_number, data):
    p = _path(case_number)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=1)
    os.replace(tmp, p)


def _get(doc, path):
    cur = doc
    for part in path.split("."):
        cur = cur[int(part)] if isinstance(cur, list) else cur.get(part)
        if cur is None:
            return None
    return cur


def _set(doc, path, value):
    parts = path.split(".")
    cur = doc
    for part in parts[:-1]:
        cur = cur[int(part)] if isinstance(cur, list) else cur[part]
    last = parts[-1]
    if isinstance(cur, list):
        cur[int(last)] = value
    else:
        cur[last] = value


def doc_fields(doc):
    """كل الحقول الرقمية الموجودة: [(مسار, وصف عربي, قيمة)] لشاشة التأكيد."""
    names = {"ht": "المبلغ خارج الرسم", "discount": "الخصم", "vat": "الرسم على القيمة المضافة", "vat_rate": "نسبة الرسم %",
             "stamp": "حق الطابع", "ttc": "المبلغ الإجمالي", "paid": "المدفوع", "balance": "المتبقي"}
    out = []
    for i, ln in enumerate(doc.get("lines", [])):
        tag = "بند %d%s" % (i + 1, (" — " + ln["desc"][:30]) if ln.get("desc") else "")
        for k, lab in (("qty", "الكمية"), ("unit_price", "سعر الوحدة"), ("amount", "المبلغ"), ("vat_rate", "نسبة الرسم %")):
            if ln.get(k) is not None:
                out.append(("lines.%d.%s" % (i, k), "%s — %s" % (tag, lab), ln[k]))
    for k in _TOT:
        v = doc.get("totals", {}).get(k)
        if v is not None:
            out.append(("totals." + k, names[k], v))
    for i, o in enumerate(doc.get("other_amounts", [])):
        out.append(("other_amounts.%d.value" % i, o.get("label") or "مبلغ آخر", o["value"]))
    return out


# ---------------------------------------------------------------------------
# تنفيذ التدقيق على قضية
# ---------------------------------------------------------------------------
def _looks_financial(text):
    return len(_MONEY_RE.findall(text or "")) >= MIN_DIGITS_DOC


def _segments(text):
    """يقسّم النص إلى أجزاء ≤ SEG عند حدود الأسطر (لا اقتطاع: الجزء الأخير من وثيقة طويلة فيه عادةً المجاميع)."""
    segs, cur = [], ""
    for line in (text or "").split("\n"):
        while len(line) > SEG:
            if cur:
                segs.append(cur)
                cur = ""
            segs.append(line[:SEG])
            line = line[SEG:]
        if cur and len(cur) + len(line) + 1 > SEG:
            segs.append(cur)
            cur = ""
        cur += line + "\n"
    if cur.strip():
        segs.append(cur)
    return segs


def _merge(parts):
    """يدمج استخراج أجزاء وثيقة واحدة: البنود تُجمع بترتيبها، والمجاميع تؤخذ من الجزء الذي ذكرها،
    وإن ذكر جزءان قيمتين مختلفتين لنفس المجموع فهذا يُبلَّغ (unreadable) بدل أن يفوز الأخير بصمت."""
    base = {"doc_type": "other", "number": "", "date": "", "issuer": "", "recipient": "", "currency": "",
            "lines": [], "totals": dict((k, None) for k in _TOT), "other_amounts": [], "refs": [], "unreadable": []}
    bad_all = []
    for doc, bad in parts:
        for k in ("doc_type", "number", "date", "issuer", "recipient", "currency"):
            v = doc.get(k)
            if v and (not base[k] or (k == "doc_type" and base[k] == "other")):
                base[k] = v
        for k in ("lines", "other_amounts", "refs", "unreadable"):
            base[k].extend(doc.get(k, []))
        for k in _TOT:
            v = doc["totals"].get(k)
            if v is None:
                continue
            old = base["totals"][k]
            if old is not None and abs(old - v) > 0.005:
                base["unreadable"].append("قيمتان مختلفتان للحقل %s في أجزاء الوثيقة: %s و%s" % (k, old, v))
            base["totals"][k] = v
        bad_all.extend(bad)
    return base, bad_all


def _extract_one(body, title, part, parts, ai, anon):
    import report_engine as R
    note = ("\n(هذا الجزء %d من %d من الوثيقة؛ استخرج ما فيه فقط. المجاميع والنهايات قد تكون في جزء آخر فاتركها null إن لم تظهر هنا.)"
            % (part, parts)) if parts > 1 else ""
    prompt = ("عنوان الوثيقة: %s%s\n\nنص الوثيقة (قد يكون ناتج OCR وفيه أخطاء طفيفة؛ لا تصحّح الأرقام):\n%s\n\n"
              "أعد JSON بهذا الشكل فقط:\n%s\n%s") % (anon.hide(title) if anon else title, note, body, SCHEMA, EXTRACT_RULES)
    last = None
    for _ in range(2):
        try:
            raw = R._parse_json(R._call(ai, prompt, R.SYSTEM, True))
            if anon:
                raw = anon.show(raw)
            return normalize_doc(raw)
        except ValueError as e:                      # JSON غير صالح: محاولة ثانية
            last = e
    raise ValueError("تعذّر تحليل رد الاستخراج: %s" % last)


def extract_document(text, title="", ai=None, anon=None):
    """استخراج منظّم للوثيقة كاملة (تُقسَّم الطويلة إلى أجزاء وتُدمج). يرجع (doc, bad)."""
    import report_engine as R
    ai = ai or R._ai_default
    segs = _segments(text)
    cut = len(segs) > MAX_SEGS
    segs = segs[:MAX_SEGS] or [""]
    parts = []
    for i, seg in enumerate(segs, 1):
        parts.append(_extract_one(anon.hide(seg) if anon else seg, title, i, len(segs), ai, anon))
    doc, bad = _merge(parts) if len(parts) > 1 else parts[0]
    if cut:
        doc["unreadable"].append("الوثيقة أطول من الحد (%d جزءاً)؛ لم تُقرأ أجزاؤها الأخيرة." % MAX_SEGS)
    return doc, bad


# ---------------------------------------------------------------------------
# فحوص على نص الوثيقة نفسه: أرقام مختلقة، حقل خاطئ، بند فات الاستخراج
# ---------------------------------------------------------------------------
_KEYS = {
    "ht": ("ht", "hors", "total", "montant", "net", "sous", "مجموع", "المجموع", "مبلغ", "المبلغ", "إجمالي", "اجمالي", "خارج", "قبل"),
    "vat": ("tva", "t.v.a", "taxe", "رسم", "الرسم", "القيمة المضافة"),
    "ttc": ("ttc", "toutes", "payer", "total", "net", "إجمالي", "اجمالي", "الإجمالي", "شامل", "الكلي", "العام", "مجموع", "المجموع"),
    "paid": ("pay", "verse", "acompte", "règlement", "reglement", "avance", "encaiss", "مدفوع", "دفعة", "تسديد", "سداد", "مسدد", "عربون", "دفع"),
    "balance": ("solde", "reste", "reliquat", "dû", "du ", "متبقي", "المتبقي", "الباقي", "رصيد", "المتبقى", "مستحق"),
    "stamp": ("timbre", "طابع"),
    "discount": ("remise", "rabais", "réduction", "reduction", "escompte", "خصم", "تخفيض", "تخفيضات"),
}
_DATE_STRIP = re.compile(r"\b\d{1,2}[./-]\d{1,2}[./-]\d{2,4}\b|\b\d{4}-\d{2}-\d{2}\b")


def text_checks(doc, text):
    """يقارن ما استخرجه النموذج بنص الوثيقة نفسه. لا يستعمل ذكاءً اصطناعياً.
      not_in_text : رقم مستخرج لا يوجد في النص (مختلق أو محسوب أو منقول خطأً)  → error
      label_far   : رقم منسوب إلى حقل (الرسم، المتبقي...) ولا كلمة تدل عليه بجواره في كل مواضعه  → warn
      uncovered   : أرقام مالية في النص لم تدخل أي حقل (قد يكون بنداً فات)  → warn"""
    import rag_index
    from report_engine import fmt_num
    out = []
    src = (text or "").translate(rag_index._AR_DIGITS_RAG)
    low = src.lower()
    allnums = rag_index.amount_tokens(src, min_digits=0, with_spans=True)
    extracted = set()
    for path, label, val in doc_fields(doc):
        c = rag_index.canon_number(val)
        extracted.add(c)
        if c not in allnums:
            out.append(_issue("error", "not_in_text",
                              "الرقم %s في «%s» لا يرد في نص الوثيقة المقروء: قد يكون النموذج خمّنه أو حسبه أو أخطأ في نقله." % (
                                  fmt_num(val), label), [path]))
            continue
        kind = path.split(".", 1)[1] if path.startswith("totals.") else None
        if kind in _KEYS and not any(any(k in low[max(0, a - 80):b + 80] for k in _KEYS[kind]) for a, b in allnums[c]):
            out.append(_issue("warn", "label_far",
                              "الرقم %s منسوب إلى «%s» لكن لا كلمة تدل على هذا الحقل بجواره في الوثيقة؛ تأكد أنه الحقل الصحيح." % (
                                  fmt_num(val), label), [path]))
    ident = set()
    for k in ("number",):
        digits = re.sub(r"\D", "", str(doc.get(k) or ""))
        if digits:
            ident.add(digits)
    cov = rag_index.amount_tokens(_DATE_STRIP.sub(" ", src), min_digits=4)
    miss = []
    for c, tok in cov.items():
        if c in extracted or c in ident:
            continue
        digits = re.sub(r"\D", "", c)
        grouped = bool(re.search(r"\d[ \u00a0\u202f.,]\d{3}", tok))
        if "." not in c and not grouped:
            if 1990 <= float(c) <= 2100 or len(digits) >= 10:
                continue                           # سنة أو رقم تعريف طويل
        miss.append(tok)
    if miss:
        shown = " ، ".join(miss[:8]) + ((" … و%d أخرى" % (len(miss) - 8)) if len(miss) > 8 else "")
        out.append(_issue("warn", "uncovered",
                          "أرقام في نص الوثيقة لم تدخل أي حقل مستخرج: %s. تأكد أنها ليست بنوداً فاتها الاستخراج "
                          "(قد تكون أرقاماً غير مالية كرقم هاتف أو سجل)." % shown))
    return out


def _all_issues(entry):
    """كل مشكلات الوثيقة: الحساب + فحوص النص + خلاف القراءتين. ما أكّد الخبير حقله لا يُعاد من فحوص النص."""
    conf = entry.get("confirmed", {})
    ti = [i for i in entry.get("text_issues", []) if not (i["fields"] and all(f in conf for f in i["fields"]))]
    return audit_doc(entry["doc"], entry.get("bad", [])) + ti + _ocr_flag_issues(entry.get("ocr_flags"))


# ---------------------------------------------------------------------------
# تغطية الملف: ما لم يُقرأ لا يعرفه البرنامج، فيجب أن يُقال ذلك بصوت عالٍ
# ---------------------------------------------------------------------------
def coverage_issues(case_number, case_idx, skipped=()):
    out = []
    for name, why in skipped:
        out.append("❌ «%s»: %s — لم تُقرأ، ولا يعرف الذكاء الاصطناعي عنها شيئاً." % (name, why))
    for c in case_idx.case_coverage(case_number):
        if c["status"] != "ok":
            out.append("❌ «%s»: لم يُستخرج منها أي نص (صورة غير مقروءة، أو الـ OCR معطّل أو فشل). "
                       "ارفع نسخة أوضح أو أدخل أرقامها يدوياً." % c["title"])
        elif c["ocr_pages"]:
            out.append("⚠ «%s»: %d صفحة بلا نص مقروء (لم تُقرأ، وقد تحوي مبالغ لا يعرفها البرنامج)." % (c["title"], c["ocr_pages"]))
    return out


def _norm_ref(x):
    return re.sub(r"[\s/\\\-_.]", "", str(x or "")).lower()


def unresolved_refs(data, case_idx, case_number):
    """وثائق تحيل إلى وثيقة رقمها لا يوجد في أي وثيقة أخرى من الملف (لا في الأرقام المستخرجة ولا في نصوصها)."""
    texts = {}

    def body(title):
        if title not in texts:
            texts[title] = _norm_ref(case_idx.full_text(title, case_number))
        return texts[title]
    titles = [v["title"] for v in data["docs"].values()]
    out = []
    for v in data["docs"].values():
        for r in v["doc"].get("refs", []):
            num = _norm_ref(r["number"])
            if len(num) < 3 or num == _norm_ref(v["doc"].get("number")):
                continue
            found = any(num == _norm_ref(o["doc"].get("number")) for o in data["docs"].values() if o is not v)
            if not found:
                found = any(num in body(t) for t in titles if t != v["title"])
            if not found:
                out.append("⚠ «%s» تحيل إلى %s رقم %s وهي غير موجودة بين وثائق الملف؛ اطلبها أو تأكد من رفعها." % (
                    v["title"], r.get("type") or "وثيقة", r["number"]))
    return out


def _ocr_flag_issues(flags):
    out = []
    for fl in flags or []:
        out.append(_issue("error", "ocr_disagree",
                          "اختلفت قراءتا الصورة في الصفحة %s: «%s» مقابل «%s». افتح الوثيقة وحدّد الصحيح." % (
                              fl.get("page") or "1", fl.get("a", ""), fl.get("b", ""))))
    return out


def audit_case(case_number, case_idx=None, ai=None, anon=None, progress=None, force=False, skipped=()):
    """يستخرج ويفحص كل وثائق القضية المالية (المخزَّنة سابقاً لا تُعاد). يرجع ملخصاً {docs, extracted, failed, issues}."""
    import rag_index
    say = progress or (lambda m: None)
    case_idx = case_idx or rag_index.case_index()
    data = load(case_number)
    sources = case_idx.case_sources(case_number)
    keep, failed, done_new = set(), [], 0
    for n, s in enumerate(sources, 1):
        key = s["doc_key"]
        keep.add(key)
        old = data["docs"].get(key)
        flags = case_idx.ocr_flags(key)
        if old and old.get("sha") == s["sha"] and not force:
            old["ocr_flags"] = flags
            old["issues"] = _all_issues(old)
            continue
        text = case_idx.full_text(s["title"], case_number)
        if not _looks_financial(text):
            data["docs"].pop(key, None)
            continue
        say("تدقيق الوثيقة %d من %d: %s" % (n, len(sources), s["title"]))
        try:
            doc, bad = extract_document(text, s["title"], ai, anon)
        except Exception as e:                       # وثيقة واحدة فاشلة لا توقف الباقي
            failed.append("%s (%s)" % (s["title"], str(e)[:80]))
            continue
        confirmed = (old or {}).get("confirmed", {}) if old and old.get("sha") == s["sha"] else {}
        entry = {"title": s["title"], "party": s.get("party", ""), "sha": s["sha"], "doc": doc, "bad": bad,
                 "confirmed": confirmed, "ocr_flags": flags, "text_issues": text_checks(doc, text)}
        entry["issues"] = _all_issues(entry)
        data["docs"][key] = entry
        done_new += 1
    for gone in set(data["docs"]) - keep:
        data["docs"].pop(gone, None)
    data["cross"] = cross_check([(v["title"], v["doc"]) for v in data["docs"].values()])
    try:
        data["refs"] = unresolved_refs(data, case_idx, case_number)
        data["coverage"] = coverage_issues(case_number, case_idx, skipped)
    except Exception as e:                           # فحوص التغطية لا تُسقط التدقيق
        data["refs"], data["coverage"] = data.get("refs", []), data.get("coverage", [])
        failed.append("فحص التغطية (%s)" % str(e)[:60])
    save(case_number, data)
    return {"docs": len(data["docs"]), "extracted": done_new, "failed": failed, "issues": issues_text(case_number, data)}


def issues_text(case_number, data=None):
    """قائمة نصوص للتبويب: أخطاء الحساب أولاً. المشكلات التي عالجها الخبير بتأكيد حقولها لا تظهر."""
    data = data or load(case_number)
    errs, warns = [], []
    for v in data["docs"].values():
        conf = v.get("confirmed", {})
        for it in v.get("issues", []):
            line = "«%s»: %s" % (v["title"], it["msg"])
            if it["fields"] and all(fp in conf for fp in it["fields"]):
                if it["code"] in ("ocr_disagree", "ambiguous"):
                    continue                                # خلاف قراءة حسمه الخبير بتأكيده
                line += " (القراءة مؤكَّدة منك، فالتناقض في الوثيقة نفسها وهو من نتائج الخبرة)"
            (errs if it["sev"] == "error" else warns).append(("❌ " if it["sev"] == "error" else "⚠ ") + line)
    cross = ["❌ " + c for c in data.get("cross", [])]
    cov = data.get("coverage", [])
    return [c for c in cov if c.startswith("❌")] + errs + cross + data.get("refs", []) + [c for c in cov if not c.startswith("❌")] + warns


def _plain(x):
    """رقم بلا فواصل آلاف (لا التباس في القراءة اللاحقة): 1250000 أو 1250000.50"""
    return str(int(round(x))) if abs(x - round(x)) < 1e-9 else "%.2f" % x


def facts_evidence(case_number):
    """نصوص الأدلة المنظّمة (للمسودة): كل وثيقة بأرقامها المستخرجة ونتيجة فحصها. تُحال بـ [D#]."""
    f = _plain
    out = []
    data = load(case_number)
    for v in data["docs"].values():
        d, conf = v["doc"], v.get("confirmed", {})
        parts = ["نوع الوثيقة: %s | الرقم: %s | التاريخ: %s | العملة: %s" % (
            d.get("doc_type"), d.get("number") or "-", d.get("date") or "-", d.get("currency") or "-")]
        if d.get("issuer") or d.get("recipient"):
            parts.append("من: %s إلى: %s" % (d.get("issuer") or "-", d.get("recipient") or "-"))
        for i, ln in enumerate(d.get("lines", [])):
            seg = [ln.get("desc") or "بند %d" % (i + 1)]
            for k, lab in (("qty", "كمية"), ("unit_price", "سعر"), ("amount", "مبلغ")):
                if ln.get(k) is not None:
                    seg.append("%s %s" % (lab, f(ln[k])))
            parts.append("بند: " + " | ".join(seg))
        for k, lab in (("ht", "خارج الرسم"), ("discount", "خصم"), ("vat", "الرسم"), ("vat_rate", "نسبة الرسم"),
                       ("stamp", "الطابع"), ("ttc", "الإجمالي"), ("paid", "المدفوع"), ("balance", "المتبقي")):
            if d["totals"].get(k) is not None:
                parts.append("%s: %s%s" % (lab, f(d["totals"][k]), " (مؤكَّد)" if ("totals." + k) in conf else ""))
        for o in d.get("other_amounts", []):
            parts.append("%s: %s%s" % (o.get("label") or "مبلغ", f(o["value"]), (" بتاريخ " + o["date"]) if o.get("date") else ""))
        errs = [it["msg"] for it in v.get("issues", []) if it["sev"] == "error"]
        parts.append("نتيجة الفحص الحسابي: " + ("سليمة" if not errs else "أخطاء: " + " ؛ ".join(errs)))
        out.append({"title": FACTS_PREFIX + v["title"], "text": "\n".join(parts)})
    return out


def confirmed_numbers(case_number):
    """مجموعة الأرقام التي أكّدها الخبير (أقوى مصدر في verify_inputs)."""
    out = set()
    for v in load(case_number)["docs"].values():
        for fp, val in (v.get("confirmed") or {}).items():
            try:
                out.add(round(float(val), 2))
            except (TypeError, ValueError):
                pass
    return out


def set_confirmed(case_number, doc_key, changes):
    """changes: {مسار_الحقل: القيمة_الجديدة_أو_None}. None = تأكيد القيمة المقروءة كما هي.
    تصحيح القيمة يعدّل الوثيقة المخزّنة ويعيد فحصها حسابياً. يرجع عدد الحقول المعدّلة بتصحيح."""
    data = load(case_number)
    v = data["docs"].get(doc_key)
    if not v:
        return 0
    fixed = 0
    for fp, new in changes.items():
        cur = _get(v["doc"], fp)
        if new is not None and cur is not None and abs(float(new) - float(cur)) > 1e-9:
            v.setdefault("original", {}).setdefault(fp, cur)
            _set(v["doc"], fp, float(new))
            fixed += 1
        v.setdefault("confirmed", {})[fp] = _get(v["doc"], fp)
    v["issues"] = _all_issues(v)
    data["cross"] = cross_check([(x["title"], x["doc"]) for x in data["docs"].values()])
    save(case_number, data)
    return fixed


def confirmed_by_title(case_number):
    """{عنوان الوثيقة: {القيم التي أكّدها الخبير}} — يستعملها verify_inputs لتأكيد رقم بالنسبة لوثيقته هو."""
    out = {}
    for v in load(case_number)["docs"].values():
        vals = set()
        for val in (v.get("confirmed") or {}).values():
            try:
                vals.add(round(float(val), 2))
            except (TypeError, ValueError):
                pass
        if vals:
            out[v["title"]] = vals
    return out


def coverage_evidence(case_number):
    """دليل تنبيه يضعه البرنامج في أدلة المسودة ليذكر النموذج الناقص في missing بدل أن يفترض أن كل شيء قُرئ."""
    data = load(case_number)
    items = list(data.get("coverage", [])) + list(data.get("refs", []))
    if not items:
        return None
    return {"title": FACTS_PREFIX + "تنبيه تغطية الملف",
            "text": "وثائق لم تُقرأ أو قُرئت ناقصة أو محال إليها وغير موجودة (لا تفترض ما فيها، واذكرها في missing):\n" +
                    "\n".join(re.sub(r"^[❌⚠]\s*", "", x) for x in items)}
