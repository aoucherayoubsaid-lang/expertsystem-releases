# -*- coding: utf-8 -*-
"""تشخيص الذكاء الاصطناعي. شغّله من مجلد البرنامج:  python diag_ai.py
يكتب النتيجة في الشاشة وفي الملف diag_out.txt (UTF-8)."""
import sys
import traceback

lines = []


def say(*a):
    t = " ".join(str(x) for x in a)
    lines.append(t)
    try:
        print(t)
    except Exception:
        print(t.encode("ascii", "replace").decode("ascii"))


try:
    import inspect
    import license_manager
    import ai_client

    key = license_manager.current_license_key()
    say("1) license key:", (key[:5] + "..." + key[-3:]) if key else "(EMPTY)")
    say("2) machine code:", license_manager.machine_code())
    say("3) ai_client file:", ai_client.__file__)
    say("4) has fix:", "machine_code" in inspect.getsource(ai_client._post))
    say("5) server test ...")
    try:
        say("   OK:", ai_client.generate("write one word: done"))
    except Exception as e:
        say("   FAIL:", type(e).__name__, str(e))
except BaseException:
    say("SCRIPT ERROR:")
    say(traceback.format_exc())

try:
    with open("diag_out.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    say("\n(saved to diag_out.txt)")
except Exception:
    pass
