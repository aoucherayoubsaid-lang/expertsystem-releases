# -*- coding: utf-8 -*-
"""اختبار بلا واجهة ولا إنترنت لإصلاحات الأمان: python selftest_security.py
يعمل داخل مجلد مؤقت ولا يمس app_data الحقيقي."""
import json, os, sys, tempfile, shutil, base64, importlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

tmp = tempfile.mkdtemp(prefix="es_sec_")
data = os.path.join(tmp, "app_data")
os.makedirs(data)
import local_protect, security_manager, storage, password_policy
local_protect.DATA_DIR = data
security_manager.BASE = data
security_manager.SECURITY_FILE = os.path.join(data, "security.json")
security_manager.AUDIT_FILE = os.path.join(data, "security_audit.jsonl")
storage.APP_DATA_DIR = data
storage.USERS_FILE = os.path.join(data, "users.json")
storage.SETTINGS_FILE = os.path.join(data, "settings.json")

fails = []
def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    if not cond: fails.append(name)

def fresh():
    local_protect._cache["key"] = None
    local_protect.clear_tamper_state()
    local_protect._meta_clear()
    for f in os.listdir(data):
        os.remove(os.path.join(data, f))

# 1 --- سياسة كلمات المرور
for pw, ok in [("1234", False), ("admin123", False), ("Abcdefgh1234", False), ("password!A1b2", False),
               ("Zx9!kQw#mP4v", True), ("حِبر-أزرق_7391!X", True), ("short1!A", False),
               ("aaaaBBBB1111!!!!", False), ("Tr0ub4dor&3xyz", True), ("expert.Ali#2291xx", False)]:
    check("policy %r -> %s" % (pw, ok), password_policy.check(pw, "ali")[0] == ok)
check("answer 'مكتب' rejected", not password_policy.check_answer("مكتب")[0])
check("answer ok", password_policy.check_answer("بلدة سيدي عيسى")[0])

# 2 --- أول تشغيل: لا إجابة افتراضية
fresh()
us = storage.load_users()
check("default admin has no answer hash", us[0]["security_answer_hash"] == "" and us[0]["security_question"] == "")
check("admin needs recovery setup + pw change", storage.needs_recovery_setup("admin") and storage.must_change_password("admin"))
check("old default answer 'مكتب' does not reset admin",
      storage.reset_password_with_security_answer("admin", "مكتب", "Zx9!kQw#mP4v") is False)
check("password still admin123", storage.verify_login("admin", "admin123") not in (None, "disabled"))
try:
    storage.change_password("admin", "1234"); check("weak change rejected", False)
except password_policy.WeakPassword:
    check("weak change rejected", True)
try:
    storage.set_recovery("admin", "ما اسم قريتك الأولى؟", "مكتب"); check("trivial answer rejected", False)
except ValueError:
    check("trivial answer rejected", True)
storage.change_password("admin", "Zx9!kQw#mP4v")
storage.set_recovery("admin", "ما اسم قريتك الأولى؟", "دوار أولاد سيدي")
check("recovery configured clears flag", not storage.needs_recovery_setup("admin"))
check("reset with wrong answer fails", storage.reset_password_with_security_answer("admin", "غلط تماما", "Qv7#nLp2$Wr9") is False)
check("reset with right answer works", storage.reset_password_with_security_answer("admin", "دوار أولاد سيدي", "Qv7#nLp2$Wr9") is True)
check("new password valid", storage.verify_login("admin", "Qv7#nLp2$Wr9") not in (None, "disabled"))
try:
    storage.reset_password_with_security_answer("admin", "دوار أولاد سيدي", "1234"); check("weak reset rejected", False)
except password_policy.WeakPassword:
    check("weak reset rejected", True)

# 3 --- عدم كشف الحسابات
q_ghost = storage.recovery_question_for_display("ghost")
check("fake question stable", q_ghost == storage.recovery_question_for_display("ghost") and q_ghost)
check("real question for real user", storage.recovery_question_for_display("admin") == "ما اسم قريتك الأولى؟")
check("reset on ghost returns False", storage.reset_password_with_security_answer("ghost", "x" * 8, "Qv7#nLp2$Wr9") is False)

# 4 --- ترحيل نسخة قديمة تحمل الإجابة الافتراضية وكلمة admin123 وتجزئة بلا ملح
fresh()
import hashlib
legacy = [{"username": "admin", "password_hash": storage._hash_password("admin123"), "role": "admin", "active": True,
           "security_question": "ما هو اسم مكتبك؟", "security_answer_hash": storage._hash_password("مكتب")},
          {"username": "sara", "password_hash": hashlib.sha256(b"1234").hexdigest(), "role": "assistant", "active": True}]
with open(storage.USERS_FILE, "w", encoding="utf-8") as f: json.dump(legacy, f)
us = storage.load_users()
check("legacy default answer revoked", us[0]["security_answer_hash"] == "" and us[0].get("force_recovery_setup"))
check("legacy default password forces change", us[0].get("force_password_change"))
check("legacy unsigned file adopted + signed", os.path.exists(storage.USERS_FILE + ".sig"))
check("old default answer no longer resets", storage.reset_password_with_security_answer("admin", "مكتب", "Zx9!kQw#mP4v") is False)
u = storage.verify_login("sara", "1234")
sara = next(x for x in storage.load_users() if x["username"] == "sara")
check("weak legacy login forces change + rehash",
      u not in (None, "disabled") and u.get("force_password_change") and sara["password_hash"].startswith("pbkdf2_sha256$"))

# 5 --- العبث بالملفات
fresh()
storage.load_users()
storage.change_password("admin", "Zx9!kQw#mP4v")
security_manager.record_failure("admin")
# 5a تعديل الدور
us = json.load(open(storage.USERS_FILE, encoding="utf-8"))
us.append({"username": "evil", "password_hash": storage._hash_password("Zx9!kQw#mP4v"), "role": "admin", "active": True})
json.dump(us, open(storage.USERS_FILE, "w", encoding="utf-8"))
local_protect.clear_tamper_state()
check("edited users.json -> no accounts + tamper flag", storage.load_users() == [] and local_protect.tamper_detected())
check("login blocked under tamper", storage.verify_login("evil", "Zx9!kQw#mP4v") is None)
try:
    storage.save_users([{"username": "x"}]); check("no overwrite under tamper", False)
except local_protect.IntegrityError:
    check("no overwrite under tamper", True)
# 5b حذف users.json لإعادة admin/admin123
fresh()
storage.load_users()
os.remove(storage.USERS_FILE); os.remove(storage.USERS_FILE + ".sig")
local_protect.clear_tamper_state()
check("deleted users.json -> tamper, no default admin recreated", storage.load_users() == [] and local_protect.tamper_detected()
      and not os.path.exists(storage.USERS_FILE))
# 5c حذف security.json لتصفير القفل
fresh()
storage.load_users()
for _ in range(5): security_manager.record_failure("admin")
check("locked after 5 failures", security_manager.is_locked("admin"))
os.remove(security_manager.SECURITY_FILE)
os.remove(security_manager.SECURITY_FILE + ".sig")
local_protect.clear_tamper_state()
check("deleting security.json does NOT unlock", security_manager.is_locked("admin") and security_manager.is_locked("anyone"))
# 5d تعديل settings.json لتعطيل كلمة بدء التشغيل
fresh()
storage.save_settings({"require_password_on_start": True, "startup_password_hash": "x"})
s = json.load(open(storage.SETTINGS_FILE, encoding="utf-8")); s["require_password_on_start"] = False
json.dump(s, open(storage.SETTINGS_FILE, "w", encoding="utf-8"))
local_protect.clear_tamper_state()
check("edited settings.json detected", storage.load_settings({}) == {} and local_protect.tamper_detected())
# 5e الكتابة المشروعة تبقى صالحة
fresh()
storage.save_settings({"a": 1}); storage.save_settings({"a": 2})
check("legit rewrite verifies", storage.load_settings({}) == {"a": 2} and not local_protect.tamper_detected())
# 5f مفتاح من جهاز آخر (ملف المفتاح تالف) -> فشل مغلق وبلا مفتاح جديد
fresh()
storage.save_settings({"a": 1})
local_protect._cache["key"] = None
open(os.path.join(data, ".es_mk"), "wb").write(b"DPAPI1:AAAA")
local_protect.clear_tamper_state()
check("foreign/undecryptable key -> fail closed", storage.load_settings({}) == {} and local_protect.tamper_detected())
# 5g مسار الاسترداد
done = local_protect.reseal_all()
check("reseal adopts current files", "settings.json" in done and storage.load_settings({}) == {"a": 1} and not local_protect.tamper_detected())

# 6 --- القفل المتصاعد والعام
fresh()
for _ in range(5): security_manager.record_failure("Ali")
check("lock applies to case variants", security_manager.is_locked("ali") and security_manager.is_locked("  ALI "))
d = security_manager._load()
d["failed"]["ali"]["locked_until"] = "2000-01-01T00:00:00"; security_manager._save(d)
check("expired lock opens", not security_manager.is_locked("ali"))
for _ in range(5): security_manager.record_failure("ali")
d = security_manager._load()
from datetime import datetime
mins = (datetime.fromisoformat(d["failed"]["ali"]["locked_until"]) - datetime.now()).total_seconds() / 60
check("second lock doubles (~10 min)", 9 < mins <= 10.1)
fresh()
for i in range(25): security_manager.record_failure("user%d" % i)
check("global lock after 25 failures across names", security_manager.is_locked("never-seen"))
security_manager.record_success("x")

# 7 --- سلسلة التدقيق
fresh()
security_manager.audit("A", "u"); security_manager.audit("B", "u"); security_manager.audit("C", "u")
check("audit chain ok", security_manager.verify_audit_chain() == (True, None))
lines = open(security_manager.AUDIT_FILE, encoding="utf-8").read().splitlines()
del lines[1]
open(security_manager.AUDIT_FILE, "w", encoding="utf-8").write("\n".join(lines) + "\n")
check("deleted audit line detected", security_manager.verify_audit_chain()[0] is False)
fresh()
storage.load_users()
security_manager.record_failure("reset:admin", action="RESET_FAILED")
acts = [json.loads(l)["action"] for l in open(security_manager.AUDIT_FILE, encoding="utf-8")]
check("reset failures audited", "RESET_FAILED" in acts)

# 8 --- DPAPI المحاكاة: ترحيل المفتاح الخاص في bundle_loader
import bundle_loader
fresh()
bundle_loader._keypair_path = lambda: os.path.join(data, ".es_dk")
sk = bundle_loader._load_or_create_keypair()
check("keypair created", os.path.exists(bundle_loader._keypair_path()))
local_protect.dpapi_available = lambda: True
local_protect.protect = lambda b: b"DPAPI1:" + base64.b64encode(bytes(x ^ 0x5A for x in b))
local_protect.unprotect = lambda blob: bytes(x ^ 0x5A for x in base64.b64decode(blob[7:]))
sk2 = bundle_loader._load_or_create_keypair()
blob = open(bundle_loader._keypair_path(), "rb").read()
check("legacy plain key migrated to protected blob", blob.startswith(b"DPAPI1:"))
sk3 = bundle_loader._load_or_create_keypair()
from cryptography.hazmat.primitives import serialization as _ser
raw = lambda k: k.private_bytes(_ser.Encoding.Raw, _ser.PrivateFormat.Raw, _ser.NoEncryption())
check("same keypair across loads", raw(sk) == raw(sk2) == raw(sk3))
open(bundle_loader._keypair_path(), "wb").write(b"DPAPI1:" + base64.b64encode(b"x" * 10))  # ملف من جهاز آخر
local_protect.unprotect = lambda blob: (_ for _ in ()).throw(local_protect.IntegrityError("other machine"))
sk4 = bundle_loader._load_or_create_keypair()
check("foreign key file -> fresh keypair, not copied key", raw(sk4) != raw(sk))

# 9 --- حالة الترخيص: ترحيل التوقيع القديم مرة واحدة
importlib.reload(local_protect); local_protect.DATA_DIR = data
fresh()
import license_manager as lm
lm._file_locations = lambda: [os.path.join(tmp, 'state1'), os.path.join(tmp, 'state2')]
legacy_blob = None
body = base64.urlsafe_b64encode(json.dumps({"start": "2026-01-01"}, sort_keys=True).encode()).decode()
legacy_blob = body + "." + lm._sign(body, lm._legacy_hmac_key())
check("legacy-signed state accepted before migration", lm._unpack(legacy_blob) is not None)
lm._write_all({"start": "2026-01-01", "last": "2026-01-02"})
check("new-signed state verifies", lm._unpack(lm._pack({"start": "2026-01-01"})) is not None)
check("legacy forgery rejected after migration", lm._unpack(legacy_blob) is None)

shutil.rmtree(tmp, ignore_errors=True)
print("\n%d failure(s)" % len(fails))
sys.exit(1 if fails else 0)
