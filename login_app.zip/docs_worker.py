# -*- coding: utf-8 -*-
"""عملية مساعدة لـ doc_signing: قراءة QR/Réf من ملف، وختم نسخة PDF.
تُشغَّل تلقائياً من البرنامج، ولا حاجة لتشغيلها يدوياً."""
import base64
import json
import os
import sys

try:                                    # يمنع نافذة "Python has stopped working" إن انهارت مكتبة أصلية
    import ctypes
    ctypes.windll.kernel32.SetErrorMode(0x8003)
except Exception:
    pass

import faulthandler
faulthandler.enable()                   # عند الانهيار يكتب أين وقع إلى stderr فيُسجَّل في docs_log.txt

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import doc_signing as d


def main():
    cmd = sys.argv[1]
    if cmd == "detect":
        print(json.dumps(d._detect_ref_local(sys.argv[2])))
    elif cmd == "stamp":
        src, dst, jf = sys.argv[2], sys.argv[3], sys.argv[4]
        with open(jf, encoding="utf-8") as f:
            data = json.load(f)
        fields = {"ref": data["ref"], "qr_png": base64.b64decode(data["qr_png_b64"])}
        d._stamp_file_local(src, dst, fields)
        print(json.dumps({"stamp_kind": fields.get("stamp_kind", "stamp")}))
    else:
        sys.exit(2)


if __name__ == "__main__":
    main()
