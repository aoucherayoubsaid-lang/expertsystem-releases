from msgbox_ltr import show_warning, show_question
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QComboBox, QPushButton, QHBoxLayout,
    QTreeWidget, QTreeWidgetItem, QFileDialog, QMessageBox, QHeaderView,
    QAbstractItemView, QLineEdit, QInputDialog
)
from PyQt5.QtGui import QFont, QColor
from PyQt5.QtCore import Qt
import qtawesome as qta
import datetime
import os
import platform
import re
import shutil
import secure_storage
import subprocess
import storage

# ---------------------------------------------------------------------------
# نصوص الصفحة بثلاث لغات (تتبدّل فوراً عند تغيير لغة البرنامج)
# ---------------------------------------------------------------------------
TEXTS = {
    "ar": {
        "title": "إدارة الوثائق", "party": "الطرف", "case": "القضية",
        "choose_party": "اختر الطرف", "choose_case": "اختر القضية",
        "upload": "تحميل وثيقة", "search": "ابحث في الوثائق...",
        "col_name": "القضية / الطرف / الوثيقة", "col_type": "النوع",
        "col_date": "تاريخ الإضافة", "col_notes": "ملاحظات",
        "btn_open": "فتح الوثيقة", "btn_folder": "إظهار في المجلد",
        "btn_note": "ملاحظة", "btn_delete": "حذف",
        "expand": "توسيع الكل", "collapse": "طي الكل",
        "total": "عدد الوثائق: {n}", "clear_filter": "مسح الفلتر", "all": "الكل", "f_parties": "كل الأطراف", "f_cases": "كل القضايا",
        "filter_none": "الفلتر: عرض كل الوثائق", "filter_on": "الفلتر الحالي  —  {party}: {pv}   |   {case}: {cv}", "case_node": "قضية رقم {n}",
        "empty": "لا توجد وثائق بعد. اختر الطرف والقضية ثم اضغط «تحميل وثيقة».",
        "warn": "تنبيه", "error": "خطأ",
        "select_both": "يرجى اختيار القضية والطرف أولاً",
        "pick_files": "اختر وثيقة أو أكثر",
        "select_doc": "يرجى اختيار وثيقة أولاً",
        "missing": "الملف غير موجود",
        "open_err": "تعذر فتح الوثيقة:",
        "confirm_title": "تأكيد الحذف",
        "confirm_delete": "هل تريد حذف الوثيقة «{f}»؟",
        "note_title": "ملاحظات", "note_prompt": "ملاحظة الوثيقة:",
        "copy_fail": "تعذر نسخ بعض الملفات إلى مجلد البرنامج، وتم الاحتفاظ بمسارها الأصلي:",
    },
    "fr": {
        "title": "Gestion des documents", "party": "Partie", "case": "Affaire",
        "choose_party": "Choisir la partie", "choose_case": "Choisir l'affaire",
        "upload": "Ajouter un document", "search": "Rechercher un document...",
        "col_name": "Affaire / Partie / Document", "col_type": "Type",
        "col_date": "Date d'ajout", "col_notes": "Notes",
        "btn_open": "Ouvrir", "btn_folder": "Afficher le dossier",
        "btn_note": "Note", "btn_delete": "Supprimer",
        "expand": "Tout développer", "collapse": "Tout réduire",
        "total": "Nombre de documents : {n}", "clear_filter": "Effacer le filtre", "all": "Tous", "f_parties": "Toutes les parties", "f_cases": "Toutes les affaires",
        "filter_none": "Filtre : tous les documents", "filter_on": "Filtre actuel  —  {party} : {pv}   |   {case} : {cv}", "case_node": "Affaire n° {n}",
        "empty": "Aucun document pour le moment. Choisissez la partie et l'affaire, puis cliquez sur « Ajouter un document ».",
        "warn": "Attention", "error": "Erreur",
        "select_both": "Veuillez d'abord choisir l'affaire et la partie.",
        "pick_files": "Choisir un ou plusieurs documents",
        "select_doc": "Veuillez d'abord sélectionner un document.",
        "missing": "Fichier introuvable",
        "open_err": "Impossible d'ouvrir le document :",
        "confirm_title": "Confirmer la suppression",
        "confirm_delete": "Supprimer le document « {f} » ?",
        "note_title": "Notes", "note_prompt": "Note du document :",
        "copy_fail": "Impossible de copier certains fichiers dans le dossier du programme ; leur chemin d'origine est conservé :",
    },
    "en": {
        "title": "Document management", "party": "Party", "case": "Case",
        "choose_party": "Select party", "choose_case": "Select case",
        "upload": "Upload document", "search": "Search documents...",
        "col_name": "Case / Party / Document", "col_type": "Type",
        "col_date": "Date added", "col_notes": "Notes",
        "btn_open": "Open", "btn_folder": "Show in folder",
        "btn_note": "Note", "btn_delete": "Delete",
        "expand": "Expand all", "collapse": "Collapse all",
        "total": "Documents: {n}", "clear_filter": "Clear filter", "all": "All", "f_parties": "All parties", "f_cases": "All cases",
        "filter_none": "Filter: showing all documents", "filter_on": "Current filter  —  {party}: {pv}   |   {case}: {cv}", "case_node": "Case No. {n}",
        "empty": "No documents yet. Select a party and a case, then click \"Upload document\".",
        "warn": "Warning", "error": "Error",
        "select_both": "Please select the case and the party first.",
        "pick_files": "Choose one or more documents",
        "select_doc": "Please select a document first.",
        "missing": "File not found",
        "open_err": "Could not open the document:",
        "confirm_title": "Confirm deletion",
        "confirm_delete": "Delete the document \"{f}\"?",
        "note_title": "Notes", "note_prompt": "Document note:",
        "copy_fail": "Some files could not be copied to the program folder; their original path was kept:",
    },
}

FILE_ICONS = {
    "pdf": ("fa5s.file-pdf", "#d03a50"),
    "doc": ("fa5s.file-word", "#2b579a"), "docx": ("fa5s.file-word", "#2b579a"),
    "xls": ("fa5s.file-excel", "#0f7a52"), "xlsx": ("fa5s.file-excel", "#0f7a52"),
    "csv": ("fa5s.file-excel", "#0f7a52"),
    "jpg": ("fa5s.file-image", "#7c3aed"), "jpeg": ("fa5s.file-image", "#7c3aed"),
    "png": ("fa5s.file-image", "#7c3aed"),
    "zip": ("fa5s.file-archive", "#b05c00"), "rar": ("fa5s.file-archive", "#b05c00"),
}


def _safe_name(text):
    cleaned = re.sub(r'[\\/:*?"<>|]+', "_", str(text)).strip().strip(".")
    return cleaned or "_"


# ---------------------------------------------------------------------------
# مطابقة الأسماء وبناء العلاقات (طرف <-> قضايا) — دوال نقية قابلة للاختبار
# ---------------------------------------------------------------------------
_AR_DIACRITICS = re.compile(r"[\u0640\u064B-\u065F\u0670]")
_NAME_SPLIT = re.compile(r"[،,;؛/\\|\n\r]+|\s+و\s+")


def _norm(text):
    """توحيد الاسم للمقارنة: مسافات، تشكيل، همزات، ياء/ألف مقصورة، تاء مربوطة."""
    s = _AR_DIACRITICS.sub("", str(text or ""))
    s = (s.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
          .replace("ى", "ي").replace("ة", "ه"))
    return re.sub(r"\s+", " ", s).strip().casefold()


def build_relations(rows, registered_parties, linked_cases=()):
    """
    rows: [(case_number, plaintiff_text, defendant_text)]
    registered_parties: [اسم الطرف المسجّل في صفحة الأطراف]
    linked_cases: [(اسم الطرف, رقم القضية)] من ربط صفحة الأطراف

    يعيد: (cases, parties, party_to_cases, case_to_parties)
    الأسماء تُطابق بعد التوحيد، وخانة المدعي/المدعى عليه قد تحوي عدة أسماء.
    """
    display = {}                       # اسم موحّد -> الاسم المعروض
    for name in registered_parties:
        n = _norm(name)
        if n:
            display.setdefault(n, str(name).strip())

    cases, party_to_cases, case_to_parties = [], {}, {}

    def link(norm_name, shown, number):
        display.setdefault(norm_name, shown)
        d = display[norm_name]
        party_to_cases.setdefault(d, set()).add(number)
        case_to_parties.setdefault(number, set()).add(d)

    for number, plaintiff, defendant in rows:
        number = str(number or "").strip()
        if not number:
            continue
        if number not in cases:
            cases.append(number)
        for cell in (plaintiff, defendant):
            cell = str(cell or "").strip()
            if not cell:
                continue
            found = set()
            # كل جزء من الخانة اسم مستقل (مطابقة تامة بعد التوحيد فقط)
            for part in _NAME_SPLIT.split(cell):
                n = _norm(part)
                if n:
                    found.add((n, part.strip()))
            for n, shown in found:
                link(n, shown, number)

    for name, number in linked_cases:
        number = str(number or "").strip()
        n = _norm(name)
        if not n or not number:
            continue
        if number not in cases:
            cases.append(number)
        link(n, str(name).strip(), number)

    parties = sorted(set(display.values()))
    return sorted(cases), parties, party_to_cases, case_to_parties


class _NoWheelCombo(QComboBox):
    """قائمة منسدلة لا تتغير بعجلة الفأرة (تمنع تغيير الفلتر دون قصد أثناء التمرير)."""
    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.setProperty("_auto_i18n_skip", True)   # عناصرها أسماء/أرقام تُعبّأ ديناميكياً، لا تُترجم آلياً

    def wheelEvent(self, event):
        event.ignore()


class DocumentManagementPage(QWidget):
    def __init__(self, case_page):
        super().__init__()
        self.case_page = case_page
        self.documents_data = []  # وثائق الملف/السنة الحالية
        self.lang = self._saved_language()
        self._syncing = False
        self._party_to_cases = {}
        self._case_to_parties = {}
        self._all_cases = []
        self._all_parties = []

        self.setStyleSheet("background-color: #f8f9ff;")
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(20, 20, 20, 20)
        self.layout.setSpacing(12)

        self.title_lbl = QLabel()
        self.title_lbl.setFont(QFont("Segoe UI", 16, QFont.Bold))
        self.layout.addWidget(self.title_lbl)

        self.init_form()
        self.init_tree()
        self.init_buttons()

        self.apply_language(self.lang)
        self.reload()

    # ------------------------------------------------------------------
    @staticmethod
    def _saved_language():
        try:
            from settings_page import AppSettings
            return AppSettings().get_language_code()
        except Exception:
            return "ar"

    def _t(self, key, **kw):
        text = TEXTS.get(self.lang, TEXTS["ar"]).get(key, TEXTS["ar"].get(key, key))
        return text.format(**kw) if kw else text

    def apply_language(self, lang_code):
        """يُستدعى عند تغيير لغة البرنامج: يبدّل كل النصوص والمصطلحات."""
        self.lang = lang_code if lang_code in TEXTS else "ar"
        self.title_lbl.setText(self._t("title"))
        self.party_lbl.setText(self._t("party") + " :")
        self.case_lbl.setText(self._t("case") + " :")
        self.upload_btn.setText(self._t("upload"))
        self.search_bar.setPlaceholderText(self._t("search"))
        self.tree.setHeaderLabels([self._t("col_name"), self._t("col_type"),
                                   self._t("col_date"), self._t("col_notes")])
        self.clear_btn.setText(self._t("clear_filter"))
        self.expand_btn.setText(self._t("expand"))
        self.collapse_btn.setText(self._t("collapse"))
        self.open_btn.setText(self._t("btn_open"))
        self.folder_btn.setText(self._t("btn_folder"))
        self.note_btn.setText(self._t("btn_note"))
        self.delete_btn.setText(self._t("btn_delete"))
        self.empty_lbl.setText(self._t("empty"))
        self._refresh_combos()
        self._on_data_changed()

    # ------------------------------------------------------------------
    def showEvent(self, event):
        self.reload()
        super().showEvent(event)

    def reload(self):
        """إعادة تحميل الوثائق والعلاقات بين الأطراف والقضايا (عند تفعيل التبويب)."""
        self.documents_data = storage.load_documents()
        self._load_relations()
        self._refresh_combos()
        self._on_data_changed()

    # الاسم القديم يبقى للتوافق
    def update_case_and_party_lists(self):
        self._load_relations()
        self._refresh_combos()

    def load_documents_data(self):
        self.documents_data = storage.load_documents()
        self._on_data_changed()

    def save_documents_data(self):
        storage.save_documents(self.documents_data)
        try:                                   # فهرسة الوثائق للذكاء الاصطناعي (معطّلة ما لم يفعّلها الخبير)
            import index_sync
            index_sync.schedule()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # العلاقات: أي أطراف في أي قضية (من المدعي/المدعى عليه ومن ربط صفحة الأطراف)
    # ------------------------------------------------------------------
    def _load_relations(self):
        """
        العلاقات تُبنى من صفحة القضايا فقط (رقم القضية + عمودا المدعي والمدعى عليه):
          - طرف  ← كل قضية يرد اسمه في المدعي أو المدعى عليه
          - قضية ← المدعي والمدعى عليه في صفّها
        لا تُستعمل روابط صفحة الأطراف هنا حتى لا تُلوّث النتيجة.
        """
        rows = []
        try:
            for c in storage.load_cases():
                rows.append((c.get("case_number", ""), c.get("plaintiff", ""), c.get("defendant", "")))
        except Exception:
            rows = []
        if not rows:  # احتياط: من الجدول المعروض
            table = self.case_page.table
            for row in range(table.rowCount()):
                def txt(col):
                    item = table.item(row, col)
                    return item.text().strip() if item else ""
                rows.append((txt(0), txt(5), txt(6)))

        (self._all_cases, self._all_parties,
         self._party_to_cases, self._case_to_parties) = build_relations(rows, [], [])
        self._cases_read = len(self._all_cases)

    def _refresh_combos(self, driver=None):
        """
        قائمتان مترابطتان دون قفل:
          - driver="party": تُصفّى القضايا بقضايا الطرف المختار، وتبقى قائمة الأطراف كاملة.
          - driver="case" : تُصفّى الأطراف بأطراف القضية المختارة، وتبقى قائمة القضايا كاملة.
          - driver=None   : تحديث عام (القائمة المختارة تُصفّي الأخرى؛ وإن اختيرتا معاً فتُحترم القضية).
        القائمة التي يغيّرها المستخدم لا تُقيَّد أبداً، وإن لم يناسب اختيارها الاختيارَ الآخر يُصفَّر الآخر.
        """
        if self._syncing:
            return
        self._syncing = True
        try:
            party = self.party_combo.currentData()
            case = self.case_combo.currentData()
            explicit = driver is not None
            if driver is None:
                driver = "case" if case else ("party" if party else None)

            if driver == "party" and party:
                case_opts = sorted(self._party_to_cases.get(party, []))
                if case not in case_opts:
                    case = None
                if explicit and case is None and len(case_opts) == 1:
                    case = case_opts[0]          # طرف له قضية واحدة: تظهر مباشرة
                party_opts = self._all_parties
            elif driver == "case" and case:
                party_opts = sorted(self._case_to_parties.get(case, []))
                if party not in party_opts:
                    party = None
                if explicit and party is None and len(party_opts) == 1:
                    party = party_opts[0]        # قضية بطرف واحد: يظهر مباشرة
                case_opts = self._all_cases
            else:
                party_opts, case_opts = self._all_parties, self._all_cases
                if driver == "party":
                    party = None
                elif driver == "case":
                    case = None

            self._fill_combo(self.party_combo, self._t("choose_party"), party_opts, party)
            self._fill_combo(self.case_combo, self._t("choose_case"), case_opts, case)
        finally:
            self._syncing = False

    def _on_data_changed(self):
        """بعد أي تغيير في الوثائق: تحديث قوائم فلترة الجدول (من الوثائق نفسها) ثم إعادة بناء الجدول."""
        self._refresh_filter_combos()
        self.rebuild_tree()

    def _refresh_filter_combos(self):
        """قائمتا فلترة الجدول: مستقلتان تماماً عن قائمتي اختيار الطرف/القضية للإضافة."""
        parties = sorted({str(d.get("party", "")).strip() for d in self.documents_data if d.get("party")})
        cases = sorted({str(d.get("case", "")).strip() for d in self.documents_data if d.get("case")})
        self._fill_combo(self.f_party_combo, self._t("f_parties"), parties, self.f_party_combo.currentData())
        self._fill_combo(self.f_case_combo, self._t("f_cases"), cases, self.f_case_combo.currentData())

    def clear_filters(self):
        """يُلغي فلترة الجدول والبحث فقط (لا يمسّ قائمتي اختيار الطرف/القضية للإضافة)."""
        for combo in (self.f_party_combo, self.f_case_combo):
            combo.blockSignals(True)
            combo.setCurrentIndex(0)
            combo.blockSignals(False)
        self.search_bar.clear()
        self.rebuild_tree()

    @staticmethod
    def _fill_combo(combo, placeholder, values, selected):
        combo.blockSignals(True)
        combo.clear()
        combo.addItem(placeholder, None)
        for v in values:
            combo.addItem(v, v)
        idx = combo.findData(selected) if selected else 0
        combo.setCurrentIndex(idx if idx >= 0 else 0)
        combo.blockSignals(False)

    def _on_party_changed(self, *_):
        self._refresh_combos("party")

    def _on_case_changed(self, *_):
        self._refresh_combos("case")

    # ------------------------------------------------------------------
    def init_form(self):
        form_layout = QHBoxLayout()
        form_layout.setSpacing(8)
        label_style = "color:#1f2347; background:transparent; font-weight:bold;"

        # الترتيب في كل اللغات: التسمية ثم القائمة (تتبع اتجاه اللغة تلقائياً)
        self.party_lbl = QLabel()
        self.party_lbl.setStyleSheet(label_style)
        form_layout.addWidget(self.party_lbl)
        self.party_combo = _NoWheelCombo()
        self.party_combo.setFocusPolicy(Qt.StrongFocus)
        self.party_combo.setMinimumWidth(200)
        self.party_combo.setMinimumHeight(34)
        self.party_combo.currentIndexChanged.connect(self._on_party_changed)
        form_layout.addWidget(self.party_combo)

        form_layout.addSpacing(16)

        self.case_lbl = QLabel()
        self.case_lbl.setStyleSheet(label_style)
        form_layout.addWidget(self.case_lbl)
        self.case_combo = _NoWheelCombo()
        self.case_combo.setFocusPolicy(Qt.StrongFocus)
        self.case_combo.setMinimumWidth(200)
        self.case_combo.setMinimumHeight(34)
        self.case_combo.currentIndexChanged.connect(self._on_case_changed)
        form_layout.addWidget(self.case_combo)

        form_layout.addStretch()

        self.upload_btn = QPushButton()
        self.upload_btn.setIcon(qta.icon("fa5s.upload", color="white"))
        self.upload_btn.setMinimumHeight(34)
        self.upload_btn.setStyleSheet(self._btn_style("#128456"))
        self.upload_btn.clicked.connect(self.upload_documents)
        form_layout.addWidget(self.upload_btn)

        self.scan_btn = QPushButton()
        self.scan_btn.setIcon(qta.icon("fa5s.camera", color="white"))
        self.scan_btn.setToolTip("مسح ضوئي لوثيقة جديدة")
        self.scan_btn.setMinimumHeight(34)
        self.scan_btn.setStyleSheet(self._btn_style("#5a4ee3"))
        self.scan_btn.clicked.connect(self.scan_new_document)
        form_layout.addWidget(self.scan_btn)

        self.layout.addLayout(form_layout)

        # بحث + توسيع/طي
        tools = QHBoxLayout()
        self.search_bar = QLineEdit()
        self.search_bar.setMinimumHeight(32)
        self.search_bar.textChanged.connect(self.rebuild_tree)
        tools.addWidget(self.search_bar, stretch=1)

        self.expand_btn = QPushButton()
        self.expand_btn.setIcon(qta.icon("fa5s.angle-double-down", color="#4338ca"))
        self.expand_btn.setStyleSheet(self._flat_btn_style())
        self.expand_btn.clicked.connect(lambda: self.tree.expandAll())
        self.collapse_btn = QPushButton()
        self.collapse_btn.setIcon(qta.icon("fa5s.angle-double-up", color="#4338ca"))
        self.collapse_btn.setStyleSheet(self._flat_btn_style())
        self.collapse_btn.clicked.connect(lambda: self.tree.collapseAll())
        self.f_party_combo = _NoWheelCombo()
        self.f_party_combo.setMinimumHeight(32)
        self.f_party_combo.setMinimumWidth(150)
        self.f_party_combo.currentIndexChanged.connect(self.rebuild_tree)
        self.f_case_combo = _NoWheelCombo()
        self.f_case_combo.setMinimumHeight(32)
        self.f_case_combo.setMinimumWidth(150)
        self.f_case_combo.currentIndexChanged.connect(self.rebuild_tree)
        tools.addWidget(self.f_party_combo)
        tools.addWidget(self.f_case_combo)

        self.clear_btn = QPushButton()
        self.clear_btn.setIcon(qta.icon("fa5s.times-circle", color="#d03a50"))
        self.clear_btn.setStyleSheet(self._flat_btn_style())
        self.clear_btn.clicked.connect(self.clear_filters)
        tools.addWidget(self.clear_btn)
        tools.addWidget(self.expand_btn)
        tools.addWidget(self.collapse_btn)
        self.layout.addLayout(tools)

    def init_tree(self):
        """شجرة منظّمة: القضية ← الطرف ← وثائقه (بدل جدول مسطّح تختلط فيه الصفوف)."""
        self.tree = QTreeWidget()
        self.tree.setColumnCount(4)
        self.tree.setAlternatingRowColors(True)
        self.tree.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tree.setSelectionMode(QAbstractItemView.SingleSelection)
        self.tree.setUniformRowHeights(True)
        self.tree.setIndentation(22)
        self.tree.setStyleSheet("""
            QTreeWidget { background: white; alternate-background-color: #f1f2ff;
                          border: 1px solid #e4e7f7; font-size: 10.5pt; }
            QTreeWidget::item { padding: 5px 2px; }
            QTreeWidget::item:selected { background-color: #5a4ee3; color: white; }
            QHeaderView::section { background-color: #4338ca; color: white; padding: 6px;
                                   border: none; font-weight: bold; }
        """)
        header = self.tree.header()
        header.setSectionResizeMode(0, QHeaderView.Stretch)
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.ResizeToContents)   # كان عرضاً ثابتاً 260 فيُقطع النص بالخط الكبير
        header.setMinimumSectionSize(110)
        self.tree.itemDoubleClicked.connect(lambda *_: self.open_selected())
        self.filter_lbl = QLabel()
        self.filter_lbl.setStyleSheet(
            "color:#4338ca; background:#f1f2ff; border:1px solid #e2e0ff; border-radius:5px;"
            " padding:5px 10px; font-weight:bold;")
        self.layout.addWidget(self.filter_lbl)
        self.layout.addWidget(self.tree, stretch=1)

        self.empty_lbl = QLabel()
        self.empty_lbl.setAlignment(Qt.AlignCenter)
        self.empty_lbl.setWordWrap(True)
        self.empty_lbl.setStyleSheet("color:#5b6485; font-size:11pt; background:transparent; padding:14px;")
        self.layout.addWidget(self.empty_lbl)

    def init_buttons(self):
        row = QHBoxLayout()
        self.open_btn = QPushButton()
        self.open_btn.setIcon(qta.icon("fa5s.folder-open", color="white"))
        self.open_btn.setStyleSheet(self._btn_style("#5a4ee3"))
        self.open_btn.clicked.connect(self.open_selected)

        self.folder_btn = QPushButton()
        self.folder_btn.setIcon(qta.icon("fa5s.search", color="white"))
        self.folder_btn.setStyleSheet(self._btn_style("#5b6485"))
        self.folder_btn.clicked.connect(self.show_in_folder)

        self.note_btn = QPushButton()
        self.note_btn.setIcon(qta.icon("fa5s.edit", color="white"))
        self.note_btn.setStyleSheet(self._btn_style("#b05c00"))
        self.note_btn.clicked.connect(self.edit_note)

        self.delete_btn = QPushButton()
        self.delete_btn.setIcon(qta.icon("fa5s.trash", color="white"))
        self.delete_btn.setStyleSheet(self._btn_style("#d03a50"))
        self.delete_btn.clicked.connect(self.delete_selected)

        for b in (self.open_btn, self.folder_btn, self.note_btn, self.delete_btn):
            row.addWidget(b)
        row.addStretch()

        self.total_lbl = QLabel()
        self.total_lbl.setStyleSheet("color:#5b6485; background:transparent;")
        row.addWidget(self.total_lbl)
        self.layout.addLayout(row)

    @staticmethod
    def _btn_style(color):
        return f"""
            QPushButton {{ background-color: {color}; color: white; padding: 8px 14px;
                           border-radius: 6px; }}
            QPushButton:hover {{ background-color: #1f2347; }}
        """

    @staticmethod
    def _flat_btn_style():
        return """
            QPushButton { background: white; color: #4338ca; padding: 6px 12px;
                          border: 1px solid #cdd3ee; border-radius: 6px; }
            QPushButton:hover { background: #f1f2ff; }
        """

    # ------------------------------------------------------------------
    # بناء الشجرة
    # ------------------------------------------------------------------
    def rebuild_tree(self, *_):
        if not hasattr(self, "tree"):
            return
        party_sel = self.f_party_combo.currentData()
        case_sel = self.f_case_combo.currentData()
        query = self.search_bar.text().strip().lower()

        grouped = {}  # case -> party -> [(index, doc)]
        shown = 0
        for i, doc in enumerate(self.documents_data):
            case, party = doc.get("case", ""), doc.get("party", "")
            if case_sel and str(case).strip() != str(case_sel).strip():
                continue
            if party_sel and _norm(party) != _norm(party_sel):
                continue
            if query and query not in " ".join(
                    str(doc.get(k, "")) for k in ("case", "party", "filename", "original_name", "notes")).lower():
                continue
            grouped.setdefault(case, {}).setdefault(party, []).append((i, doc))
            shown += 1

        self.tree.clear()
        bold = QFont("Segoe UI", 10.5, QFont.Bold)
        for case in sorted(grouped):
            parties = grouped[case]
            case_count = sum(len(v) for v in parties.values())
            case_item = QTreeWidgetItem([f"{self._t('case_node', n=case)}   ({case_count})"])
            case_item.setIcon(0, qta.icon("fa5s.balance-scale", color="#4338ca"))
            case_item.setFont(0, bold)
            case_item.setBackground(0, QColor("#eef0ff"))
            for c in range(1, 4):
                case_item.setBackground(c, QColor("#eef0ff"))
            self.tree.addTopLevelItem(case_item)

            for party in sorted(parties):
                docs = parties[party]
                party_item = QTreeWidgetItem([f"{party}   ({len(docs)})"])
                party_item.setIcon(0, qta.icon("fa5s.user", color="#5a4ee3"))
                party_item.setFont(0, bold)
                case_item.addChild(party_item)

                for index, doc in sorted(docs, key=lambda x: self._display_name(x[1]).lower()):
                    filename = self._display_name(doc)
                    ext = os.path.splitext(doc.get("filename", "") or filename)[1].lstrip(".").lower()
                    icon_name, icon_color = FILE_ICONS.get(ext, ("fa5s.file-alt", "#5b6485"))
                    ref_txt = f"Réf {doc['ref']}" if doc.get("ref") else ""
                    item = QTreeWidgetItem([filename, ext.upper(), doc.get("added", ""),
                                            (ref_txt + "   " if ref_txt else "") + doc.get("notes", "")])
                    item.setIcon(0, qta.icon(icon_name, color=icon_color))
                    item.setData(0, Qt.UserRole, index)
                    path = doc.get("full_path", "")
                    if path and not os.path.exists(path):
                        item.setForeground(0, QColor("#d03a50"))
                        item.setToolTip(0, self._t("missing"))
                    else:
                        item.setToolTip(0, path)
                    party_item.addChild(item)

        self.tree.expandAll()
        self.total_lbl.setText(self._t("total", n=shown))
        if party_sel or case_sel:
            allv = self._t("all")
            self.filter_lbl.setText(self._t("filter_on", party=self._t("party"), pv=party_sel or allv,
                                            case=self._t("case"), cv=case_sel or allv))
        else:
            self.filter_lbl.setText(self._t("filter_none"))
        has_docs = shown > 0
        self.tree.setVisible(True)
        self.empty_lbl.setVisible(not has_docs)

    # ------------------------------------------------------------------
    # رفع الوثائق: تُنسخ إلى مجلد البرنامج (وثائق/القضية/الطرف) فلا تضيع إن نُقل الأصل
    # ------------------------------------------------------------------
    def _managed_dir(self, case, party):
        base = os.path.join(os.path.dirname(storage._year_path("documents.json")),
                            "documents_files", _safe_name(case), _safe_name(party))
        os.makedirs(base, exist_ok=True)
        return base

    @staticmethod
    def _display_name(doc):
        """الاسم الأصلي للملف (لا الاسم المشفّر/العشوائي الذي خُزّن به)."""
        name = doc.get("original_name") or ""
        if not name and doc.get("source_path"):
            name = os.path.basename(str(doc.get("source_path")))
        return name or doc.get("filename", "")

    @staticmethod
    def _unique_path(folder, filename):
        dest = os.path.join(folder, filename)
        stem, ext = os.path.splitext(filename)
        n = 2
        while os.path.exists(dest):
            dest = os.path.join(folder, f"{stem} ({n}){ext}")
            n += 1
        return dest

    def upload_documents(self):
        case = self.case_combo.currentData()
        party = self.party_combo.currentData()
        if not case or not party:
            show_warning(self, self._t("warn"), self._t("select_both"))
            return

        files, _ = QFileDialog.getOpenFileNames(self, self._t("pick_files"), "", "All Files (*.*)")
        if not files:
            return
        self._ingest_files(case, party, files)

    def scan_new_document(self):
        case = self.case_combo.currentData()
        party = self.party_combo.currentData()
        if not case or not party:
            show_warning(self, self._t("warn"), self._t("select_both"))
            return

        from scan_utils import scan_document
        file_path = scan_document(self, suggested_name=f"document_{_safe_name(case)}")
        if not file_path:
            return
        self._ingest_files(case, party, [file_path])

    def _ingest_files(self, case, party, files):
        failed = []
        ref_lines, ref_errors = [], []
        extra_records = []
        today = datetime.date.today().strftime("%Y-%m-%d")
        for src in files:
            stored_path, managed = src, False
            try:
                stored = secure_storage.store_file(src, self._managed_dir(case, party))
                stored_path = stored["path"]
                managed = True
            except Exception:
                failed.append(os.path.basename(src))
            ref_info = {}
            try:
                import doc_signing
                ref_info = doc_signing.process_joint(src, case, party, today)
                if ref_info.get("status") == "registered":
                    import tempfile
                    from pathlib import Path
                    tmp_dir = tempfile.mkdtemp(prefix="refstamp_")
                    try:
                        stem = Path(src).stem
                        tmp_pdf = os.path.join(tmp_dir, f"{stem}__REF-{ref_info['ref'].replace('/', '-')}.pdf")
                        doc_signing.stamp_file(src, tmp_pdf, ref_info)
                        stored2 = secure_storage.store_file(tmp_pdf, self._managed_dir(case, party))
                        extra_records.append({
                            "ref": ref_info["ref"], "ref_status": "stamped_copy",
                            "case": case, "party": party,
                            "filename": os.path.basename(stored2["path"]),
                            "original_name": os.path.basename(tmp_pdf),
                            "full_path": stored2["path"], "source_path": src, "managed": True,
                            "stored_name": os.path.basename(stored2["path"]),
                            "sha256": stored2["sha256"], "size": stored2["size"], "added": today,
                            "notes": ("ورقة غلاف بـ Réf — للطباعة والإيداع" if ref_info.get("stamp_kind") == "cover"
                                      else "نسخة مختومة بـ Réf وQR — للطباعة والإيداع"),
                        })
                        ref_info["stamped"] = True
                    except Exception as exc:
                        ref_errors.append(f"{os.path.basename(src)}: تعذّر إنشاء النسخة المختومة ({exc})")
                    finally:
                        import shutil as _sh
                        _sh.rmtree(tmp_dir, ignore_errors=True)
                label = {"linked": "مرتبطة بوثيقتك الصادرة", "mismatch": "⚠ Réf موجود لكن الملف يختلف عن المسجّل",
                         "registered": "وثيقة واردة جديدة"}.get(ref_info.get("status"), "")
                ref_lines.append(f"{os.path.basename(src)}  →  Réf {ref_info['ref']}  ({label})"
                                 + ("\n    أُضيفت إلى القائمة " + ("ورقة غلاف" if ref_info.get("stamp_kind") == "cover" else "نسخة مختومة") + " للطباعة" if ref_info.get("stamped") else ""))
            except Exception as exc:
                ref_errors.append(f"{os.path.basename(src)}: {exc}")
            self.documents_data.append({
                "ref": ref_info.get("ref", ""),
                "ref_status": ref_info.get("status", ""),
                "case": case,
                "party": party,
                "filename": os.path.basename(stored_path),
                "original_name": os.path.basename(src),
                "full_path": stored_path,
                "source_path": src,
                "managed": managed,
                "stored_name": (os.path.basename(stored_path) if managed else ""),
                "sha256": (secure_storage.sha256_file(stored_path) if managed else ""),
                "size": (os.path.getsize(stored_path) if managed and os.path.exists(stored_path) else 0),
                "added": today,
                "notes": "",
            })

        self.documents_data.extend(extra_records)
        self.save_documents_data()
        self.clear_filters()          # لتظهر الوثيقة المضافة حتماً
        self._on_data_changed()
        if failed:
            show_warning(self, self._t("warn"),
                                self._t("copy_fail") + "\n" + "\n".join(failed))
        if ref_lines or ref_errors:
            QMessageBox.information(
                self, "Réf",
                "\n".join(ref_lines) + (("\n\n" if ref_lines else "") + "لم يُسجَّل في الخادم:\n"
                                         + "\n".join(ref_errors) if ref_errors else ""))

    # ------------------------------------------------------------------
    def _selected_doc_index(self):
        item = self.tree.currentItem()
        if not item:
            return None
        index = item.data(0, Qt.UserRole)
        return index if isinstance(index, int) and 0 <= index < len(self.documents_data) else None

    def _require_selection(self):
        index = self._selected_doc_index()
        if index is None:
            show_warning(self, self._t("warn"), self._t("select_doc"))
        return index

    def open_selected(self):
        index = self._selected_doc_index()
        if index is None:
            return
        try:
            record = self.documents_data[index]
            file_path = record["full_path"]
            if not os.path.exists(file_path):
                raise FileNotFoundError(self._t("missing"))
            if record.get("managed") and record.get("sha256"):
                ok, reason = secure_storage.verify_file(file_path, record.get("sha256"), record.get("size"))
                if not ok:
                    raise IOError("Integrity check failed: " + reason)
            import safe_open
            safe_open.open_path(file_path)
        except Exception as e:
            show_warning(self, self._t("error"), f"{self._t('open_err')}\n{e}")

    def show_in_folder(self):
        index = self._require_selection()
        if index is None:
            return
        path = self.documents_data[index].get("full_path", "")
        try:
            if platform.system() == "Windows":
                subprocess.call(["explorer", "/select,", os.path.normpath(path)])
            elif platform.system() == "Darwin":
                subprocess.call(["open", "-R", path])
            else:
                subprocess.call(["xdg-open", os.path.dirname(path)])
        except Exception as e:
            show_warning(self, self._t("error"), str(e))

    def edit_note(self):
        index = self._require_selection()
        if index is None:
            return
        doc = self.documents_data[index]
        text, ok = QInputDialog.getText(self, self._t("note_title"), self._t("note_prompt"),
                                        QLineEdit.Normal, doc.get("notes", ""))
        if ok:
            doc["notes"] = text.strip()
            self.save_documents_data()
            self._on_data_changed()

    def delete_selected(self):
        index = self._require_selection()
        if index is None:
            return
        doc = self.documents_data[index]
        reply = show_question(
            self, self._t("confirm_title"),
            self._t("confirm_delete", f=self._display_name(doc)))
        if reply != QMessageBox.Yes:
            return
        # نحذف النسخة التي أنشأها البرنامج فقط، ولا نلمس الملف الأصلي للمستخدم
        if doc.get("managed") and os.path.exists(doc.get("full_path", "")):
            try:
                os.remove(doc["full_path"])
                folder = os.path.dirname(doc["full_path"])
                for _level in range(2):  # ننظّف مجلد الطرف ثم مجلد القضية إن أصبحا فارغين
                    if os.path.isdir(folder) and not os.listdir(folder):
                        os.rmdir(folder)
                        folder = os.path.dirname(folder)
            except Exception:
                pass
        del self.documents_data[index]
        self.save_documents_data()
        self._on_data_changed()

    # تُستدعى من الصفحة الرئيسية عند النقر على قضية في جدول القضايا
    def filter_by_case(self, case_number):
        self._load_relations()
        self.party_combo.blockSignals(True)
        self.party_combo.setCurrentIndex(0)
        self.party_combo.blockSignals(False)
        self._fill_combo(self.case_combo, self._t("choose_case"), self._all_cases, case_number)
        self._refresh_combos("case")
