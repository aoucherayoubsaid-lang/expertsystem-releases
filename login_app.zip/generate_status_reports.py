from jinja2 import Environment, FileSystemLoader
import datetime

import storage
import report_output as ro


def _render(template_name, rows, font_size, font_family, doc_type):
    env = ro.make_env()
    template = env.get_template(template_name)
    import doc_signing
    expert_info = storage.load_expert_info()
    today = datetime.date.today().strftime("%d/%m/%Y")
    return template.render(
        **doc_signing.issue_fields(doc_type, None, today),
        rows=rows,
        expert_name=expert_info.get("name", ""),
        year=storage.get_current_year() or "",
        today=datetime.date.today().strftime("%d/%m/%Y"),
        font_size=font_size,
        font_family=font_family or storage.get_font_family(),
    )


def generate_fees_status_report(rows, font_size=13, font_family=None):
    """تقرير PDF للوضعية العامة لكشف الأتعاب. rows: case_number/total/paid/remaining/status."""
    html_file = ro.write_html("fees_status_result.html",
                              _render("fees_status_print.html", rows, font_size, font_family,
                                    "الوضعية العامة لكشف الأتعاب"))
    pdf_file = ro.html_to_pdf(html_file, "status", f"fees_status_report_{ro.stamp()}.pdf")
    return html_file, pdf_file


def generate_payments_report(rows, font_size=13, font_family=None):
    """تقرير PDF لسجل التسديدات. rows: case_number/date/receipt_number/amount."""
    html_file = ro.write_html("payments_result.html",
                              _render("payments_print.html", rows, font_size, font_family,
                                    "سجل التسديدات"))
    pdf_file = ro.html_to_pdf(html_file, "payments", f"payments_report_{ro.stamp()}.pdf")
    return html_file, pdf_file
