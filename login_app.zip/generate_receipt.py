from jinja2 import Environment, FileSystemLoader

import storage
import report_output as ro


def generate_receipt(data):
    """
    توليد وصل إيداع (تسديد) بصيغة PDF.
    data: expert_name, expert_address, expert_phone, receipt_number, date,
          case_number, payer, amount, total, remaining
    """
    env = ro.make_env()
    template = env.get_template("receipt.html")

    data = dict(data)
    data.setdefault("font_size", 17)
    # نفس الخط الذي اختاره المستخدم في إعدادات البرنامج
    data.setdefault("font_family", storage.get_font_family())

    import doc_signing
    data.update(doc_signing.issue_fields("وصل إيداع", data.get("case_number"), data.get("date")))
    html = template.render(data)
    html_file = ro.write_html("receipt_result.html", html)

    number_part = ro.safe_name(data.get("receipt_number"))
    pdf_file = ro.html_to_pdf(html_file, "receipt", f"receipt_{number_part}.pdf",
                              options=ro.default_options("A5"))
    return html_file, pdf_file
