# -*- coding: utf-8 -*-
"""الحارس المتقدّم (Thread دائم): رصد فقط، لا إنهاء للبرنامج أبداً.

التغييرات عن النسخة السابقة (بعد المراجعة الأمنية):
- حُذف إنهاء العملية (os._exit): الإنهاء كان يحجب عملاء شرعيين (أجهزة افتراضية، Hyper-V،
  أدوات مراقبة) ويكشف للمهاجم مكان الفحص. الآن: تنبيه عبر telegram_alert (يمرّ بالـ Worker)
  والبرنامج يتابع. التحويل إلى القراءة فقط عند التلاعب يتولاه hardening.tampered_runtime.
- حُذف فحص الجهاز الافتراضي (wmic + "microsoft corporation"): إيجابيات كاذبة كثيرة، و wmic
  محذوف من ويندوز 11 الحديث فكان يتوقف بصمت.
- حُذف فحص التجميد: نوم/إسبات الجهاز يسبّبه عند عميل عادي.
- فحص Dr0-Dr3 يعمل على 32 و64-بت ببنية CONTEXT الصحيحة لكل منهما، ويفحص الخيط الرئيسي (لا خيط
  الحارس) بإيقافه لحظة ثم استئنافه. يبقى تنبيهاً فقط.
- tasklist يُشغَّل بلا نافذة (CREATE_NO_WINDOW) عبر subprocess: os.popen كان يُظهر وميض نافذة
  CMD كل 8 ثوانٍ في نسخة exe بلا كونسول.
- كشف الأدوات بالاسم يُتجاوز بإعادة تسمية الأداة؛ فائدته رفع الكلفة فقط. المرجع الحقيقي الخادم.
"""
import ctypes
import ctypes.wintypes as wintypes   # noqa: F401  (يُستعمل في _debug_port_present)
import os
import subprocess
import sys
import threading
import time

_SUSPECT_PROCESSES = ("x64dbg.exe", "x32dbg.exe", "ida64.exe", "ida.exe", "ollydbg.exe",
                      "scylla.exe", "scylla_x64.exe", "cheatengine", "dnspy.exe",
                      "processhacker.exe", "ghidra")      # wireshark حُذف: أداة شرعية شائعة عند فنيي الشبكات

_IS64 = ctypes.sizeof(ctypes.c_void_p) == 8
CONTEXT_DEBUG_REGISTERS = (0x00100000 if _IS64 else 0x00010000) | 0x10   # AMD64 / i386
_NO_WINDOW = 0x08000000
THREAD_ACCESS = 0x0002 | 0x0008 | 0x0010      # SUSPEND_RESUME | GET_CONTEXT | QUERY_INFORMATION
_MAIN_TID = [0]


class _CONTEXT_X86(ctypes.Structure):
    """x86: الحجم 716 بايت. الأعداد صريحة (c_uint32) فلا تتأثر بنظام التشغيل."""
    _fields_ = [("ContextFlags", ctypes.c_uint32),
                ("Dr0", ctypes.c_uint32), ("Dr1", ctypes.c_uint32), ("Dr2", ctypes.c_uint32),
                ("Dr3", ctypes.c_uint32), ("Dr6", ctypes.c_uint32), ("Dr7", ctypes.c_uint32),
                ("_rest", ctypes.c_ubyte * (716 - 4 - 6 * 4))]


class _CONTEXT_X64(ctypes.Structure):
    """AMD64: الحجم 1232 بايت، و Dr0..Dr7 عند الإزاحات 0x48..0x70. يجب محاذاة 16 بايت."""
    _fields_ = [("P1Home", ctypes.c_uint64), ("P2Home", ctypes.c_uint64), ("P3Home", ctypes.c_uint64),
                ("P4Home", ctypes.c_uint64), ("P5Home", ctypes.c_uint64), ("P6Home", ctypes.c_uint64),
                ("ContextFlags", ctypes.c_uint32), ("MxCsr", ctypes.c_uint32),
                ("Seg", ctypes.c_uint16 * 6), ("EFlags", ctypes.c_uint32),
                ("Dr0", ctypes.c_uint64), ("Dr1", ctypes.c_uint64), ("Dr2", ctypes.c_uint64),
                ("Dr3", ctypes.c_uint64), ("Dr6", ctypes.c_uint64), ("Dr7", ctypes.c_uint64),
                ("_rest", ctypes.c_ubyte * (1232 - 0x78))]


def _aligned_context():
    """بنية CONTEXT محاذاة على 16 بايت (شرط ويندوز لـ x64)."""
    cls = _CONTEXT_X64 if _IS64 else _CONTEXT_X86
    size = ctypes.sizeof(cls)
    raw = ctypes.create_string_buffer(size + 16)
    addr = (ctypes.addressof(raw) + 15) & ~15
    return raw, cls.from_address(addr)


def _alert(reason):
    """تنبيه غير حاجز ومخفَّف التكرار (telegram_alert.alert). لا شيء يظهر محلياً."""
    try:
        import telegram_alert
        telegram_alert.alert(reason)
    except Exception:
        pass


def _debug_port_present():
    try:
        ntdll = ctypes.windll.ntdll
        kernel32 = ctypes.windll.kernel32
        port = ctypes.c_void_p(0)
        ret_len = wintypes.ULONG(0)
        status = ntdll.NtQueryInformationProcess(
            kernel32.GetCurrentProcess(), 7, ctypes.byref(port), ctypes.sizeof(port), ctypes.byref(ret_len))
        if status != 0:
            return False
        return port.value not in (0, None)
    except Exception:
        return False


def _hw_breakpoint_present():
    """يفحص Dr0-Dr3 في الخيط الرئيسي (لا خيط الحارس: السجلات خاصة بكل خيط). يوقفه لأجزاء من
    الملّي ثانية ثم يستأنفه. أي فشل في أي خطوة => False (لا نخمّن)."""
    tid = _MAIN_TID[0]
    if not tid:
        return False
    k = ctypes.windll.kernel32
    k.OpenThread.restype = ctypes.c_void_p
    h = k.OpenThread(THREAD_ACCESS, False, tid)
    if not h:
        return False
    suspended = False
    try:
        if k.SuspendThread(ctypes.c_void_p(h)) == 0xFFFFFFFF:
            return False
        suspended = True
        _raw, ctx = _aligned_context()
        ctx.ContextFlags = CONTEXT_DEBUG_REGISTERS
        if not k.GetThreadContext(ctypes.c_void_p(h), ctypes.byref(ctx)):
            return False
        return bool(ctx.Dr0 or ctx.Dr1 or ctx.Dr2 or ctx.Dr3)
    except Exception:
        return False
    finally:
        if suspended:
            k.ResumeThread(ctypes.c_void_p(h))
        k.CloseHandle(ctypes.c_void_p(h))


_PROC_CACHE = {"t": 0.0, "hit": False}
_PROC_CHECK_EVERY = 15.0


def _suspect_process():
    now = time.monotonic()
    if now - _PROC_CACHE["t"] < _PROC_CHECK_EVERY:
        return _PROC_CACHE["hit"]
    _PROC_CACHE["t"] = now
    hit = False
    try:
        p = subprocess.run(["tasklist"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                           timeout=10, creationflags=_NO_WINDOW)
        out = p.stdout.decode("utf-8", "replace").lower()
        hit = any(n in out for n in _SUSPECT_PROCESSES)
    except Exception:
        hit = False
    _PROC_CACHE["hit"] = hit
    return hit


_TICK_SECONDS = 2.0


def _loop():
    while True:
        time.sleep(_TICK_SECONDS)
        try:
            if _hw_breakpoint_present():
                _alert("hardware-breakpoint")
            if _debug_port_present():
                _alert("kernel-debug-port")
            if _suspect_process():
                _alert("suspect-process")
        except Exception:
            pass                       # الحارس لا يُسقط البرنامج ولا يظهر شيئاً


_STARTED = False


def start():
    """مرة واحدة بعد startup_check(). لا يعمل خارج ويندوز أو في وضع التطوير."""
    global _STARTED
    if _STARTED or os.name != "nt" or not getattr(sys, "frozen", False):
        return
    _STARTED = True
    _MAIN_TID[0] = ctypes.windll.kernel32.GetCurrentThreadId()   # start() يُستدعى من الخيط الرئيسي
    threading.Thread(target=_loop, daemon=True).start()
