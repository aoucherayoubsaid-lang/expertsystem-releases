# -*- coding: utf-8 -*-
"""نافذة إعداد الغلاف والتقرير بالذكاء الاصطناعي مع مراجعة الخبير قبل الحساب والتصدير.

    from report_dialog import ReportDialog
    ReportDialog(self, case_number="123/2026").exec_()      # case_number اختياري
"""
import os
import re

from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QPlainTextEdit, QPushButton, QTableWidget, QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget,
)

import index_sync
import report_engine
import report_render
import storage
import word_cover
from msgbox_ltr import show_confirm, show_info, show_warning


class _DraftWorker(QThread):
    progress = pyqtSignal(str)
    done = pyqtSignal(object, str)           # (مسودة أو None, رسالة خطأ)

    def __init__(self, case_number, parent=None):
        super().__init__(parent)
        self.case_number = case_number

    def run(self):
        try:
            d = report_engine.build_draft(self.case_number, progress=self.progress.emit)
            self.done.emit(d, "")
        except Exception as e:
            self.done.emit(None, str(e))


class _SyncWorker(QThread):
    done = pyqtSignal(str)

    def run(self):
        import rag_index
        try:
            rep = rag_index.sync_case_documents()
            bad = [r.get("error", "") for _, r in rep if r["status"] == "error"]
            scanned = sum(1 for _, r in rep if r["status"] == "no_text")
            msg = "تمت مزامنة %d وثيقة." % len(rep)
            if scanned:
                msg += "\nوثائق تعذّرت قراءة نصها (صورة غير واضحة أو تجاوزت السقف أو تعذّر الاتصال): %d" % scanned
            if bad:
                msg += "\nأخطاء: " + bad[0]
            self.done.emit(msg)
        except Exception as e:
            self.done.emit("فشلت المزامنة: %s" % e)


class ReportDialog(QDialog):
    def __init__(self, parent=None, case_number=None):
        super().__init__(parent)
        self.setWindowTitle("إعداد الغلاف والتقرير")
        self.setLayoutDirection(Qt.RightToLeft)
        self.resize(980, 680)
        self.draft = None
        self._cur_sec = -1
        self._cur_calc = -1
        self._loading = False
        self._worker = None

        root = QVBoxLayout(self)

        # ---- الصف العلوي ----
        top = QHBoxLayout()
        top.addWidget(QLabel("القضية :"))
        self.case_box = QComboBox()
        self.case_box.setMinimumWidth(320)
        for c in storage.load_cases():
            n = str(c.get("case_number", "")).strip()
            if n:
                self.case_box.addItem("%s — %s / %s" % (n, c.get("plaintiff", ""), c.get("defendant", "")), n)
        top.addWidget(self.case_box, 1)
        self.btn_cover = QPushButton("إنشاء الغلاف")
        self.btn_sync = QPushButton("فهرسة الوثائق الآن")
        self.btn_draft = QPushButton("تحضير المسودة (ذكاء اصطناعي)")
        self.btn_report = QPushButton("حساب وإنشاء التقرير")
        self.btn_tpl = QPushButton("نماذجي...")
        self.btn_ref = QPushButton("المراجع...")
        self.btn_fx = QPushButton("أسعار الصرف...")
        self.btn_gl = QPushButton("المصطلحات...")
        for b in (self.btn_cover, self.btn_sync, self.btn_draft, self.btn_report, self.btn_tpl, self.btn_ref,
                  self.btn_fx, self.btn_gl):
            top.addWidget(b)
        root.addLayout(top)

        self.auto = QCheckBox("فهرسة وثائق القضايا تلقائياً عند رفعها (ترسل نصوصها وصور صفحاتها الممسوحة إلى خدمة الذكاء الاصطناعي)")
        self.auto.setChecked(index_sync.get_auto_index())
        self.auto.toggled.connect(index_sync.set_auto_index)
        root.addWidget(self.auto)

        self.status = QLabel("")
        root.addWidget(self.status)

        # ---- التبويبات ----
        self.tabs = QTabWidget()
        root.addWidget(self.tabs, 1)
        self._build_sections_tab()
        self._build_calcs_tab()
        self._build_notes_tab()
        self._build_evidence_tab()

        # ---- الأحداث ----
        self.case_box.currentIndexChanged.connect(self._case_changed)
        self.btn_cover.clicked.connect(self._make_cover)
        self.btn_sync.clicked.connect(self._sync_docs)
        self.btn_draft.clicked.connect(self._make_draft)
        self.btn_report.clicked.connect(self._make_report)
        self.btn_tpl.clicked.connect(self._open_templates)
        self.btn_ref.clicked.connect(self._open_refs)
        self.btn_fx.clicked.connect(self._open_fx)
        self.btn_gl.clicked.connect(self._open_gl)

        if case_number is not None:
            i = self.case_box.findData(str(case_number).strip())
            if i >= 0:
                self.case_box.setCurrentIndex(i)
        self._case_changed()

    # ------------------------------------------------------------------ بناء التبويبات
    def _build_sections_tab(self):
        w = QWidget()
        lay = QHBoxLayout(w)
        left = QVBoxLayout()
        self.sec_list = QListWidget()
        left.addWidget(self.sec_list, 1)
        row = QHBoxLayout()
        b_add = QPushButton("إضافة عنوان")
        b_del = QPushButton("حذف")
        row.addWidget(b_add)
        row.addWidget(b_del)
        left.addLayout(row)
        lay.addLayout(left, 1)
        right = QVBoxLayout()
        right.addWidget(QLabel("العنوان :"))
        self.sec_title = QLineEdit()
        right.addWidget(self.sec_title)
        right.addWidget(QLabel("النص :"))
        self.sec_body = QPlainTextEdit()
        right.addWidget(self.sec_body, 1)
        self.sec_src = QLabel("")
        self.sec_src.setWordWrap(True)
        right.addWidget(self.sec_src)
        lay.addLayout(right, 2)
        self.tabs.addTab(w, "العناوين والنصوص")
        self.sec_list.currentRowChanged.connect(self._sec_row_changed)
        b_add.clicked.connect(self._sec_add)
        b_del.clicked.connect(self._sec_del)

    def _build_calcs_tab(self):
        w = QWidget()
        lay = QHBoxLayout(w)
        left = QVBoxLayout()
        self.calc_list = QListWidget()
        left.addWidget(self.calc_list, 1)
        row = QHBoxLayout()
        b_add = QPushButton("إضافة حساب")
        b_del = QPushButton("حذف")
        row.addWidget(b_add)
        row.addWidget(b_del)
        left.addLayout(row)
        lay.addLayout(left, 1)
        right = QVBoxLayout()
        right.addWidget(QLabel("اسم الحساب :"))
        self.calc_title = QLineEdit()
        right.addWidget(self.calc_title)
        right.addWidget(QLabel("المعادلة (أسماء المتغيرات من الجدول، والعمليات + - * / ** وأقواس) :"))
        self.calc_formula = QLineEdit()
        self.calc_formula.setLayoutDirection(Qt.LeftToRight)
        right.addWidget(self.calc_formula)
        self.calc_table = QTableWidget(0, 6)
        self.calc_table.setHorizontalHeaderLabels(["الاسم (لاتيني)", "الوصف", "القيمة (المبلغ الأصلي)", "المصدر (D1/R1)",
                                                   "العملة (EUR…)", "تاريخ سعر الصرف (YYYY-MM-DD)"])
        self.calc_table.horizontalHeader().setStretchLastSection(True)
        right.addWidget(self.calc_table, 1)
        row2 = QHBoxLayout()
        b_row = QPushButton("إضافة رقم")
        b_rdel = QPushButton("حذف الرقم المحدد")
        b_calc = QPushButton("احسب")
        for b in (b_row, b_rdel, b_calc):
            row2.addWidget(b)
        right.addLayout(row2)
        self.calc_result = QLabel("")
        self.calc_result.setWordWrap(True)
        right.addWidget(self.calc_result)
        lay.addLayout(right, 3)
        self.tabs.addTab(w, "الحسابات")
        self.calc_list.currentRowChanged.connect(self._calc_row_changed)
        b_add.clicked.connect(self._calc_add)
        b_del.clicked.connect(self._calc_del)
        b_row.clicked.connect(lambda: self._input_row("", "", "", "", "", ""))
        b_rdel.clicked.connect(lambda: self.calc_table.removeRow(self.calc_table.currentRow())
                               if self.calc_table.currentRow() >= 0 else None)
        b_calc.clicked.connect(self._calc_now)

    def _build_notes_tab(self):
        self.notes = QPlainTextEdit()
        self.notes.setReadOnly(True)
        self.tabs.addTab(self.notes, "نواقص وتعارضات")

    def _build_evidence_tab(self):
        w = QWidget()
        lay = QHBoxLayout(w)
        self.ev_list = QListWidget()
        self.ev_text = QPlainTextEdit()
        self.ev_text.setReadOnly(True)
        lay.addWidget(self.ev_list, 1)
        lay.addWidget(self.ev_text, 2)
        self.tabs.addTab(w, "الأدلة المستعملة")
        self.ev_list.currentRowChanged.connect(self._ev_row_changed)

    # ------------------------------------------------------------------ الحالة
    def _case_number(self):
        return self.case_box.currentData() or ""

    def _case_changed(self):
        self._commit()
        n = self._case_number()
        self.draft = report_engine.load_draft(n) if n else None
        self._populate()
        self.status.setText("مسودة محفوظة من قبل." if self.draft else "لا توجد مسودة لهذه القضية بعد.")

    def _set_busy(self, busy):
        for b in (self.btn_cover, self.btn_sync, self.btn_draft, self.btn_report):
            b.setEnabled(not busy)

    # ------------------------------------------------------------------ تعبئة الواجهة
    def _populate(self):
        self._loading = True
        d = self.draft or {}
        self.sec_list.clear()
        for s in d.get("sections", []):
            self.sec_list.addItem(s["title"])
        self.calc_list.clear()
        for c in d.get("calculations", []):
            self.calc_list.addItem(c["title"])
        self.ev_list.clear()
        for e in d.get("evidence", []):
            self.ev_list.addItem("[%s] %s%s" % (e["id"], e["title"], (" ص %s" % e["page"]) if e["page"] else ""))
        lines = []
        if d.get("conflicts"):
            lines.append("تعارضات وبدائل:")
            lines += ["• " + c for c in d["conflicts"]]
            lines.append("")
        if d.get("warnings"):
            lines.append("تنبيهات التحقق الآلي (أرقام لم تُطابَق بمصدرها أو مصطلحات لم تُطبَّق):")
            lines += ["• " + w for w in d["warnings"]]
            lines.append("")
        if d.get("missing"):
            lines.append("نواقص يجب عليك توفيرها:")
            lines += ["• " + m for m in d["missing"]]
        self.notes.setPlainText("\n".join(lines) or "لا شيء.")
        self._cur_sec = self._cur_calc = -1
        self._loading = False
        self._clear_sec()
        self._clear_calc()
        if self.sec_list.count():
            self.sec_list.setCurrentRow(0)
        if self.calc_list.count():
            self.calc_list.setCurrentRow(0)

    # ---- العناوين
    def _clear_sec(self):
        self.sec_title.clear()
        self.sec_body.clear()
        self.sec_src.setText("")

    def _sec_row_changed(self, row):
        if self._loading:
            return
        self._commit_sec()
        self._cur_sec = row
        if self.draft and 0 <= row < len(self.draft["sections"]):
            s = self.draft["sections"][row]
            self.sec_title.setText(s["title"])
            self.sec_body.setPlainText(s.get("body", ""))
            labels = "؛ ".join(report_engine.source_label(self.draft, x) for x in s.get("sources", []))
            self.sec_src.setText("المصادر: " + labels if labels else "")
        else:
            self._clear_sec()

    def _commit_sec(self):
        if self.draft and 0 <= self._cur_sec < len(self.draft["sections"]):
            s = self.draft["sections"][self._cur_sec]
            s["title"] = self.sec_title.text().strip() or s["title"]
            s["body"] = self.sec_body.toPlainText()
            item = self.sec_list.item(self._cur_sec)
            if item:
                item.setText(s["title"])

    def _ensure_draft(self):
        if self.draft is None:
            self.draft = {"case_number": self._case_number(), "sections": [], "calculations": [],
                          "missing": [], "conflicts": [], "evidence": [], "plan": {}}

    def _sec_add(self):
        self._commit_sec()
        self._ensure_draft()
        self.draft["sections"].append({"title": "عنوان جديد", "body": "", "sources": []})
        self.sec_list.addItem("عنوان جديد")
        self.sec_list.setCurrentRow(self.sec_list.count() - 1)

    def _sec_del(self):
        row = self.sec_list.currentRow()
        if self.draft and 0 <= row < len(self.draft["sections"]):
            self._loading = True
            del self.draft["sections"][row]
            self.sec_list.takeItem(row)
            self._cur_sec = -1
            self._loading = False
            self._clear_sec()
            if self.sec_list.count():
                self.sec_list.setCurrentRow(min(row, self.sec_list.count() - 1))

    # ---- الحسابات
    def _clear_calc(self):
        self.calc_title.clear()
        self.calc_formula.clear()
        self.calc_table.setRowCount(0)
        self.calc_result.setText("")

    @staticmethod
    def _plain(v):
        """رقم بلا فواصل آلاف حتى لا يُقرأ ملتبساً عند إعادة القراءة."""
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            return "%d" % v if float(v).is_integer() else repr(float(v))
        return v

    def _input_row(self, name, label, value, source, currency="", date=""):
        r = self.calc_table.rowCount()
        self.calc_table.insertRow(r)
        for j, v in enumerate((name, label, value, source, currency, date)):
            self.calc_table.setItem(r, j, QTableWidgetItem(str(v)))

    def _calc_row_changed(self, row):
        if self._loading:
            return
        self._commit_calc()
        self._cur_calc = row
        self._clear_calc()
        if self.draft and 0 <= row < len(self.draft["calculations"]):
            c = self.draft["calculations"][row]
            self.calc_title.setText(c["title"])
            self.calc_formula.setText(c["formula"])
            for i in c["inputs"]:
                self._input_row(i["name"], i.get("label", ""), self._plain(i["value"]), i.get("source", ""),
                                i.get("currency", ""), i.get("rate_date", ""))

    def _read_calc_widgets(self, base):
        valid = {e["id"] for e in (self.draft or {}).get("evidence", [])}
        inputs = []
        prev = {i["name"]: i for i in base.get("inputs", [])}
        for r in range(self.calc_table.rowCount()):
            cell = lambda j: (self.calc_table.item(r, j).text().strip() if self.calc_table.item(r, j) else "")
            if not cell(0):
                continue
            raw = cell(2)
            try:
                value = report_engine.to_number(raw)
            except ValueError:
                value = raw                    # يبقى نصاً فيظهر خطأ واضح عند الحساب
            item = {"name": cell(0), "label": cell(1) or cell(0), "value": value,
                    "source": cell(3) if cell(3) in valid else "",
                    "currency": cell(4), "rate_date": cell(5)}
            p = prev.get(item["name"])
            # نُبقي علامة الفحص الآلي ما دام الخبير لم يغيّر الرقم أو مصدره (حتى لا يضيع التنبيه عند التبديل بين الحسابات)
            if p and "verified" in p and p.get("value") == value and p.get("source") == item["source"]:
                item["verified"] = p["verified"]
            inputs.append(item)
        out = dict(base)
        out.update({"title": self.calc_title.text().strip() or base.get("title", "حساب"),
                    "formula": self.calc_formula.text().strip(), "inputs": inputs})
        return out

    def _commit_calc(self):
        if self.draft and 0 <= self._cur_calc < len(self.draft["calculations"]):
            base = self.draft["calculations"][self._cur_calc]
            self.draft["calculations"][self._cur_calc] = self._read_calc_widgets(base)
            item = self.calc_list.item(self._cur_calc)
            if item:
                item.setText(self.draft["calculations"][self._cur_calc]["title"])

    def _calc_add(self):
        self._commit_calc()
        self._ensure_draft()
        self.draft["calculations"].append({"title": "حساب جديد", "method_sources": [], "inputs": [],
                                           "formula": "", "note": ""})
        self.calc_list.addItem("حساب جديد")
        self.calc_list.setCurrentRow(self.calc_list.count() - 1)

    def _calc_del(self):
        row = self.calc_list.currentRow()
        if self.draft and 0 <= row < len(self.draft["calculations"]):
            self._loading = True
            del self.draft["calculations"][row]
            self.calc_list.takeItem(row)
            self._cur_calc = -1
            self._loading = False
            self._clear_calc()
            if self.calc_list.count():
                self.calc_list.setCurrentRow(min(row, self.calc_list.count() - 1))

    def _calc_now(self):
        self._commit_calc()
        if not (self.draft and 0 <= self._cur_calc < len(self.draft["calculations"])):
            return
        res = report_engine.compute_calc(self.draft["calculations"][self._cur_calc])
        if res["error"]:
            self.calc_result.setText("تعذّر الحساب: " + res["error"])
        else:
            self.calc_result.setText("النتيجة: " + res["steps"] + "\n" + "\n".join(res.get("inputs_detail", [])))

    # ---- الأدلة
    def _ev_row_changed(self, row):
        ev = (self.draft or {}).get("evidence", [])
        self.ev_text.setPlainText(ev[row]["text"] if 0 <= row < len(ev) else "")

    def _commit(self):
        self._commit_sec()
        self._commit_calc()

    def _save(self):
        if self.draft:
            self._commit()
            report_engine.save_draft(self.draft)

    # ------------------------------------------------------------------ الأزرار
    def _make_draft(self):
        n = self._case_number()
        if not n or self._worker is not None:
            return
        if not show_confirm(self, "الذكاء الاصطناعي",
                            "سيُرسل نص النبذة والمهام ومقاطع من الوثائق والمراجع إلى خدمة الذكاء الاصطناعي. "
                            "أسماء الأطراف تُخفى قبل الإرسال، لكن بقية النصوص تُرسل. أتابع؟"):
            return
        if self.draft and (self.draft.get("sections") or self.draft.get("calculations")):
            if not show_confirm(self, "مسودة موجودة", "توجد مسودة محفوظة لهذه القضية وستُستبدل بالجديدة. أتابع؟", danger=True):
                return
        self._set_busy(True)
        self._worker = _DraftWorker(n, self)
        self._worker.progress.connect(self.status.setText)
        self._worker.done.connect(self._draft_done)
        self._worker.start()

    def _draft_done(self, draft, err):
        self._worker = None
        self._set_busy(False)
        if err or draft is None:
            self.status.setText("فشل تحضير المسودة.")
            show_warning(self, "المسودة", err or "حدث خطأ غير معروف")
            return
        self.draft = draft
        report_engine.save_draft(draft)
        self._populate()
        self.status.setText("المسودة جاهزة. راجع العناوين والأرقام والمصادر، وعدّل ما يلزم قبل الحساب.")
        self.tabs.setCurrentIndex(0)

    def _sync_docs(self):
        if self._worker is not None:
            return
        if not show_confirm(self, "فهرسة الوثائق",
                            "ستُرسل نصوص وثائق القضايا، وصور الصفحات الممسوحة ضوئياً لقراءتها، إلى خدمة الذكاء الاصطناعي لتحويلها إلى فهرس بحث. أتابع؟"):
            return
        self._set_busy(True)
        self.status.setText("جارٍ فهرسة الوثائق...")
        self._worker = _SyncWorker(self)
        self._worker.done.connect(self._sync_done)
        self._worker.start()

    def _sync_done(self, msg):
        self._worker = None
        self._set_busy(False)
        self.status.setText(msg)

    def _out_path(self, default_name):
        safe = re.sub(r"[^\w\-]+", "_", default_name, flags=re.UNICODE)
        path, _ = QFileDialog.getSaveFileName(self, "حفظ الملف", safe + ".docx", "Word (*.docx)")
        return path

    def _need_template(self, kind):
        import templates_page
        p = templates_page.get_template_paths().get(kind, "")
        if not p:
            show_warning(self, "نماذجي", "ارفع النموذج أولاً من زر «نماذجي».")
        return p

    def _make_cover(self):
        n = self._case_number()
        tpl = n and self._need_template("cover")
        if not tpl:
            return
        out = self._out_path("غلاف_" + n)
        if not out:
            return
        try:
            missing = word_cover.generate_cover(n, tpl, out)
        except Exception as e:
            show_warning(self, "الغلاف", "تعذّر إنشاء الغلاف: %s" % e)
            return
        msg = "تم إنشاء الغلاف."
        if missing:
            msg += "\nعلامات لم أجد لها قيمة وبقيت كما هي:\n" + "  ".join("{{%s}}" % k for k in sorted(missing))
        show_info(self, "الغلاف", msg)

    def _make_report(self):
        n = self._case_number()
        if not (n and self.draft):
            show_warning(self, "التقرير", "حضّر المسودة أولاً أو أضف عناوين يدوياً.")
            return
        tpl = self._need_template("report")
        if not tpl:
            return
        self._commit()
        report_engine.compute_all(self.draft)
        failed = [c["title"] for c, r in zip(self.draft["calculations"], self.draft["results"]) if r["error"]]
        if failed and not show_confirm(self, "حسابات متعذّرة",
                                       "تعذّر حساب: " + "، ".join(failed) + "\nستظهر في التقرير كأخطاء. أتابع؟"):
            return
        unverified = sum(1 for c in self.draft["calculations"] for i in c["inputs"] if i.get("verified") is False)
        if unverified and not show_confirm(self, "أرقام لم يُتحقق منها",
                                           "%d رقماً في الحسابات لم يُعثر عليه آلياً في نص مصدره (راجع تبويب «نواقص وتعارضات»). أتابع؟" % unverified):
            return
        out = self._out_path("تقرير_" + n)
        if not out:
            return
        try:
            report_engine.save_draft(self.draft)
            report_render.render_report(tpl, out, word_cover.build_case_context(n), self.draft)
        except Exception as e:
            show_warning(self, "التقرير", "تعذّر إنشاء التقرير: %s" % e)
            return
        show_info(self, "التقرير", "تم إنشاء التقرير.\nراجعه بالكامل قبل اعتماده، فالمسؤولية المهنية عليك.")

    def _open_templates(self):
        from templates_page import TemplatesDialog
        TemplatesDialog(self).exec_()

    def _open_fx(self):
        from reference_data_page import FxRatesDialog
        FxRatesDialog(self).exec_()

    def _open_gl(self):
        from reference_data_page import GlossaryDialog
        GlossaryDialog(self).exec_()

    def _open_refs(self):
        from references_page import ReferencesDialog
        ReferencesDialog(self).exec_()

    def closeEvent(self, e):
        self._save()
        super().closeEvent(e)

    def done(self, r):
        self._save()
        super().done(r)
