# -*- coding: utf-8 -*-
"""مكوّنات واجهة مشتركة (PyQt5): القائمة الجانبية للتنقل.

القائمة الجانبية تحلّ محل شريط التبويبات العلوي في النافذة الرئيسية، لكنها لا
تحذف التبويبات: QTabWidget يبقى موجوداً (شريطه مخفي) فتبقى كل المراجع القديمة
(tabs.indexOf / setCurrentIndex / setTabText ...) تعمل كما هي.

الاتجاه: تتبع القائمة اتجاه النافذة (يمين في العربية، يسار في الفرنسية/الإنجليزية).
الحركات المستعملة خفيفة جداً (رسم يدوي + QVariantAnimation) ولا تستعمل أي مؤثّر رسومي/ظل.
"""

import math

import qtawesome as qta
from PyQt5.QtCore import (Qt, QSize, QRectF, QPointF, QVariantAnimation, QEasingCurve,
                          pyqtSignal)
from PyQt5.QtGui import (QColor, QPainter, QPainterPath, QLinearGradient, QPixmap, QPen,
                         QFont)
from PyQt5.QtWidgets import (
    QFrame, QPushButton, QLabel, QHBoxLayout, QVBoxLayout, QButtonGroup,
    QSizePolicy, QScrollArea, QWidget, QLineEdit, QGridLayout,
)

import theme_tokens as T

# يمنع مرشّح الترجمة التلقائية من لمس نصوص نتحكم بها يدوياً
_SKIP_I18N = "_auto_i18n_skip"


def _label(text="", color=T.TEXT, size=T.FONT_SIZE_BASE, bold=False):
    lbl = QLabel(text)
    lbl.setProperty(_SKIP_I18N, True)
    lbl.setAttribute(Qt.WA_TransparentForMouseEvents)
    weight = "600" if bold else "normal"
    lbl.setStyleSheet(
        f"background: transparent; color: {color}; font-size: {size}pt; font-weight: {weight};")
    return lbl


class NavButton(QPushButton):
    """زر تنقّل: أيقونة + نص داخل تخطيط خاص بالزر (وليس نص الزر نفسه).

    السبب: ui_style.RtlButtonPainter يعيد رسم أي QPushButton فيه نص وأيقونة
    ويوسّطهما؛ أما هنا فنريد محاذاة بداية السطر، فنضع الأيقونة والنص في QLabel
    داخل الزر بحيث لا يعترضه ذلك المرشّح، ويتبع التخطيط اتجاه النافذة تلقائياً.
    """

    def __init__(self, icon_name, text, parent=None):
        super().__init__(parent)
        self.setObjectName("navBtn")
        self.setCheckable(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(44)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        # modern_theme._setup_button يعيد تنسيق الأزرار غير المعلَّمة؛ نعلّمه كمُعدّ مسبقاً
        self.setProperty("_mt_setup", True)
        self.setProperty("_mt_styled", True)
        self.setProperty(_SKIP_I18N, True)
        self._icon_name = icon_name

        lay = QHBoxLayout(self)
        lay.setContentsMargins(16, 0, 14, 0)
        lay.setSpacing(12)
        self._icon = QLabel()
        self._icon.setFixedSize(22, 22)
        self._icon.setAlignment(Qt.AlignCenter)
        self._icon.setAttribute(Qt.WA_TransparentForMouseEvents)
        self._icon.setStyleSheet("background: transparent;")
        self._text = _label(text, T.NAV_TEXT, 10.5)
        lay.addWidget(self._icon)
        lay.addWidget(self._text, 1)

        self.toggled.connect(self._refresh)
        self._refresh(False)

    def set_text(self, text):
        self._text.setText(text)
        self.setToolTip(text)

    def text_value(self):
        return self._text.text()

    def _refresh(self, checked):
        color = "#ffffff" if checked else T.NAV_TEXT
        icon_color = "#ffffff" if checked else T.ACCENT
        self._icon.setPixmap(qta.icon(self._icon_name, color=icon_color).pixmap(QSize(18, 18)))
        self._text.setStyleSheet(
            f"background: transparent; color: {color}; font-size: 10.5pt;"
            f" font-weight: {'600' if checked else 'normal'};")


_SIDEBAR_QSS = f"""
    QFrame#sidebar {{ background: {T.SIDEBAR_BG}; border: none; }}
    QFrame#sidebar[rtl="true"] {{ border-left: 1px solid {T.BORDER}; }}
    QFrame#sidebar[rtl="false"] {{ border-right: 1px solid {T.BORDER}; }}
    QFrame#sidebar QLabel {{ background: transparent; }}
    QFrame#sidebarSep {{ background: {T.BORDER}; max-height: 1px; min-height: 1px; border: none; }}
    QPushButton#navBtn {{
        background: transparent; border: none; border-radius: 12px;
    }}
    QPushButton#navBtn:hover {{ background: {T.NAV_HOVER_BG}; }}
    QPushButton#navBtn:checked {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {T.GRAD_A}, stop:1 {T.GRAD_B});
    }}
"""


class Sidebar(QFrame):
    """قائمة جانبية عمودية. تُصدر nav_requested(widget) عند اختيار عنصر."""

    nav_requested = pyqtSignal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("sidebar")
        self.setFixedWidth(T.SIDEBAR_WIDTH)
        self.setStyleSheet(_SIDEBAR_QSS)
        self.setProperty("rtl", False)
        self._items = []            # [(widget, NavButton)]
        self._groups = {}           # key -> QLabel (عنوان مجموعة)
        self._group = QButtonGroup(self)
        self._group.setExclusive(True)

        root = QVBoxLayout(self)
        root.setContentsMargins(12, 0, 12, 12)
        root.setSpacing(4)

        # --- الشعار ---
        brand = QWidget()
        brand.setFixedHeight(72)
        bl = QHBoxLayout(brand)
        bl.setContentsMargins(6, 0, 6, 0)
        bl.setSpacing(10)
        self._brand_icon = QLabel()
        self._brand_icon.setFixedSize(34, 34)
        self._brand_icon.setAlignment(Qt.AlignCenter)
        self._brand_icon.setStyleSheet(
            f"background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 {T.GRAD_A}, stop:1 {T.GRAD_C});"
            " border-radius: 11px;")
        self._brand_icon.setPixmap(qta.icon("fa5s.balance-scale", color="white").pixmap(QSize(18, 18)))
        self._brand_title = _label("", T.INK, 10, True)
        self._brand_title.setWordWrap(True)
        bl.addWidget(self._brand_icon)
        bl.addWidget(self._brand_title, 1)
        root.addWidget(brand)

        sep = QFrame()
        sep.setObjectName("sidebarSep")
        root.addWidget(sep)
        root.addSpacing(8)

        # --- العناصر (داخل منطقة تمرير احتياطاً للشاشات الصغيرة) ---
        self._nav_host = QWidget()
        self._nav_host.setStyleSheet("background: transparent;")
        self._nav_layout = QVBoxLayout(self._nav_host)
        self._nav_layout.setContentsMargins(0, 0, 0, 0)
        self._nav_layout.setSpacing(4)
        self._nav_layout.addStretch(1)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }"
                             "QScrollArea > QWidget > QWidget { background: transparent; }")
        scroll.setWidget(self._nav_host)
        root.addWidget(scroll, 1)

        # --- التذييل ---
        self._footer = _label("", T.NAV_GROUP_TEXT, 8.5)
        self._footer.setAlignment(Qt.AlignCenter)
        root.addWidget(self._footer)

    # ------------------------------------------------------------------
    def set_brand(self, title):
        self._brand_title.setText(title)

    def set_footer(self, text):
        self._footer.setText(text)

    def add_group(self, key, text=""):
        """يضيف عنوان مجموعة (يُستعمل قبل عناصرها)."""
        lbl = _label(text, T.NAV_GROUP_TEXT, 8.5, True)
        lbl.setContentsMargins(10, 12, 10, 2)
        self._groups[key] = lbl
        self._nav_layout.insertWidget(self._nav_layout.count() - 1, lbl)
        return lbl

    def set_group_text(self, key, text):
        if key in self._groups:
            self._groups[key].setText(text)

    def add_item(self, icon_name, text, widget):
        btn = NavButton(icon_name, text)
        self._group.addButton(btn)
        self._nav_layout.insertWidget(self._nav_layout.count() - 1, btn)
        btn.clicked.connect(lambda _checked=False, w=widget: self.nav_requested.emit(w))
        self._items.append((widget, btn))
        return btn

    def set_item_text(self, widget, text):
        for w, btn in self._items:
            if w is widget:
                btn.set_text(text)
                return

    def set_current(self, widget):
        """يحدّد العنصر المطابق دون إصدار إشارة (المزامنة مع التبويب الحالي)."""
        for w, btn in self._items:
            was = btn.blockSignals(True)
            btn.setChecked(w is widget)
            btn.blockSignals(was)
            btn._refresh(btn.isChecked())   # blockSignals منع toggled فنحدّث الشكل يدوياً

    def set_rtl(self, rtl):
        """يُحدّث مؤشر العنصر النشط (حافة يمين/يسار) حسب اتجاه اللغة."""
        self.setProperty("rtl", bool(rtl))
        st = self.style()
        st.unpolish(self)
        st.polish(self)
        for _w, btn in self._items:
            st.unpolish(btn)
            st.polish(btn)


# ======================================================================
#  مكوّنات نظام التصميم (M1) — تُستعمل في كل الصفحات لتوحيد المظهر
# ======================================================================

def direction_for(lang_code):
    """اتجاه الواجهة: عربي RTL، وغيره LTR (قاعدة واحدة للتطبيق كله)."""
    return Qt.RightToLeft if lang_code == "ar" else Qt.LeftToRight


class Card(QFrame):
    """بطاقة بيضاء بحدود ناعمة. المحتوى يُضاف إلى self.body (QVBoxLayout)."""

    def __init__(self, parent=None, margins=(18, 16, 18, 16), spacing=12):
        super().__init__(parent)
        self.setObjectName("dsCard")
        self.setStyleSheet(
            f"QFrame#dsCard {{ background: {T.SURFACE}; border: 1px solid {T.BORDER};"
            f" border-radius: {T.RADIUS}px; }}"
            "QFrame#dsCard QLabel { background: transparent; border: none; }")
        self.body = QVBoxLayout(self)
        self.body.setContentsMargins(*margins)
        self.body.setSpacing(spacing)


_BADGE_KINDS = {
    "ok": (T.OK_BG, T.OK_FG), "warn": (T.WARN_BG, T.WARN_FG), "bad": (T.BAD_BG, T.BAD_FG),
    "info": (T.INFO_BG, T.INFO_FG), "neutral": (T.NEUTRAL_BG, T.NEUTRAL_FG),
}


def badge_qss(kind="neutral"):
    bg, fg = _BADGE_KINDS.get(kind, _BADGE_KINDS["neutral"])
    return (f"background: {bg}; color: {fg}; border: none; border-radius: 11px;"
            " padding: 3px 12px; font-size: 9pt; font-weight: 600;")


class Badge(QLabel):
    """شارة حالة صغيرة (ok / warn / bad / info / neutral)."""

    def __init__(self, text="", kind="neutral", parent=None):
        super().__init__(text, parent)
        self.setAlignment(Qt.AlignCenter)
        self.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Fixed)
        self.set_kind(kind)

    def set_kind(self, kind):
        self.setStyleSheet(badge_qss(kind))


class PageHeader(QFrame):
    """ترويسة الصفحة: عنوان + وصف قصير، وفي الطرف الآخر أزرار الإجراءات."""

    def __init__(self, title="", subtitle="", parent=None):
        super().__init__(parent)
        self.setObjectName("dsPageHeader")
        self.setStyleSheet("QFrame#dsPageHeader { background: transparent; border: none; }")
        row = QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(T.SPACE * 2)
        col = QVBoxLayout()
        col.setSpacing(2)
        self.title_label = QLabel(title)
        self.title_label.setStyleSheet(
            f"color: {T.PRIMARY}; font-size: {T.FONT_SIZE_TITLE}pt; font-weight: 700; background: transparent;")
        self.subtitle_label = QLabel(subtitle)
        self.subtitle_label.setWordWrap(True)
        self.subtitle_label.setStyleSheet(
            f"color: {T.TEXT_MUTED}; font-size: {T.FONT_SIZE_BASE}pt; background: transparent;")
        self.subtitle_label.setVisible(bool(subtitle))
        col.addWidget(self.title_label)
        col.addWidget(self.subtitle_label)
        row.addLayout(col, 1)
        self.actions = QHBoxLayout()
        self.actions.setSpacing(T.SPACE)
        row.addLayout(self.actions)

    def set_title(self, text):
        self.title_label.setText(text)

    def set_subtitle(self, text):
        self.subtitle_label.setText(text)
        self.subtitle_label.setVisible(bool(text))

    def add_action(self, widget):
        self.actions.addWidget(widget)
        return widget


def mix(color, other="#ffffff", amount=0.85):
    """يمزج لوناً مع آخر (amount = نسبة اللون الآخر). يُستعمل لاشتقاق خلفيات فاتحة من لون الحالة."""
    a, b = QColor(color), QColor(other)
    k = max(0.0, min(1.0, amount))
    return QColor(int(a.red() * (1 - k) + b.red() * k),
                  int(a.green() * (1 - k) + b.green() * k),
                  int(a.blue() * (1 - k) + b.blue() * k)).name()


def tint(color, amt=0.88):
    """خلفية فاتحة بلون الحالة. في الوضع الليلي تُمزج مع سطح البطاقة الداكن بدل الأبيض."""
    if T.IS_DARK:
        amt = max(0.0, amt - 0.14)
    return mix(color, T.SURFACE, amt)


def figure(color):
    """لون الأرقام الكبيرة: أغمق من لون الحالة في الفاتح، وأفتح منه في الليلي (للقراءة)."""
    return mix(color, "#ffffff", 0.30) if T.IS_DARK else mix(color, "#000000", 0.18)


def lead_align(vcenter=True):
    """محاذاة بداية السطر بشكل مطلق: يمين في العربية ويسار في غيرها.
    ضرورية للنصوص التي تبدأ بأرقام/حروف لاتينية، لأن Qt يعاملها كفقرة LTR ويلصقها باليسار حتى في الواجهة العربية."""
    from PyQt5.QtWidgets import QApplication
    rtl = QApplication.layoutDirection() == Qt.RightToLeft
    a = (Qt.AlignRight if rtl else Qt.AlignLeft) | Qt.AlignAbsolute
    return a | Qt.AlignVCenter if vcenter else a


def icon_badge(icon_name, fg="#ffffff", bg=None, size=44, radius=14, icon_size=20, gradient=False):
    """مربع أيقونة مستدير (لون صلب أو تدرّج بنفسجي) يُستعمل في البطاقات والترويسات."""
    lbl = QLabel()
    lbl.setProperty(_SKIP_I18N, True)
    lbl.setFixedSize(size, size)
    lbl.setAlignment(Qt.AlignCenter)
    if gradient:
        fill = (f"qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 {T.GRAD_A}, stop:1 {T.GRAD_C})")
    else:
        fill = bg or T.ACCENT
    lbl.setStyleSheet(f"background: {fill}; border: none; border-radius: {radius}px;")
    lbl.setPixmap(qta.icon(icon_name, color=fg).pixmap(QSize(icon_size, icon_size)))
    return lbl


def animate_number(label, target, ms=480):
    """عدّاد يصعد من القيمة الحالية إلى الهدف (QLabel.setText فقط: خفيف جداً)."""
    try:
        target = int(target)
    except (TypeError, ValueError):
        label.setText(str(target))
        return
    try:
        start = int(float(label.text() or 0))
    except (TypeError, ValueError):
        start = 0
    old = getattr(label, "_count_anim", None)
    if old is not None:
        old.stop()
    if not T.ANIMATIONS or start == target or not label.isVisible():
        label.setText(str(target))
        return
    anim = QVariantAnimation(label)
    anim.setDuration(ms)
    anim.setStartValue(float(start))
    anim.setEndValue(float(target))
    anim.setEasingCurve(QEasingCurve.OutCubic)
    anim.valueChanged.connect(lambda v: label.setText(str(int(round(float(v))))))
    anim.finished.connect(lambda: label.setText(str(target)))
    label._count_anim = anim
    anim.start()


class KpiCard(QFrame):
    """بطاقة مؤشر: أيقونة ملوّنة + رقم كبير + عنوان، بخلفية فاتحة بلون الحالة. قابلة للنقر."""

    clicked = pyqtSignal()

    def __init__(self, label, color=T.ACCENT, value="0", parent=None, icon="fa5s.circle", hint=""):
        super().__init__(parent)
        self.setObjectName("dsKpi")
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(98)
        soft, line = tint(color, 0.90), tint(color, 0.72)
        self.setStyleSheet(
            f"QFrame#dsKpi {{ background: {soft}; border: 1px solid {line};"
            f" border-radius: {T.RADIUS}px; }}"
            f"QFrame#dsKpi:hover {{ background: {tint(color, 0.84)}; border: 1px solid {color}; }}"
            "QFrame#dsKpi QLabel { background: transparent; border: none; }")
        row = QHBoxLayout(self)
        row.setContentsMargins(16, 12, 16, 12)
        row.setSpacing(14)
        row.addWidget(icon_badge(icon, "#ffffff", color, 46, 14, 20), 0, Qt.AlignVCenter)
        col = QVBoxLayout()
        col.setSpacing(0)
        self.value_label = QLabel(str(value))
        self.value_label.setProperty(_SKIP_I18N, True)
        self.value_label.setStyleSheet(
            f"color: {figure(color)}; font-size: {T.FONT_SIZE_KPI}pt; font-weight: 700;")
        self.value_label.setAlignment(lead_align())
        self.text_label = QLabel(label)
        self.text_label.setWordWrap(True)
        self.text_label.setStyleSheet(
            f"color: {T.TEXT}; font-size: {T.FONT_SIZE_LABEL}pt; font-weight: 600;")
        self.text_label.setAlignment(lead_align())
        col.addWidget(self.value_label)
        col.addWidget(self.text_label)
        row.addLayout(col, 1)

    def set_value(self, value):
        animate_number(self.value_label, value)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit()
        super().mouseReleaseEvent(event)


class SearchField(QLineEdit):
    """حقل بحث موحّد: أيقونة بداية + زر مسح."""

    def __init__(self, placeholder="", parent=None):
        super().__init__(parent)
        self.setPlaceholderText(placeholder)
        self.setClearButtonEnabled(True)
        self.setMinimumHeight(T.CONTROL_HEIGHT)
        self.addAction(qta.icon("fa5s.search", color=T.TEXT_MUTED), QLineEdit.LeadingPosition)


class EmptyState(QFrame):
    """حالة فارغة موحّدة: أيقونة + عنوان + إرشاد + زر اختياري (action_button)."""

    def __init__(self, title, hint="", icon_name="fa5s.folder-open", parent=None):
        super().__init__(parent)
        self.setObjectName("dsEmpty")
        self.setStyleSheet("QFrame#dsEmpty { background: transparent; border: none; }"
                           "QFrame#dsEmpty QLabel { background: transparent; }")
        v = QVBoxLayout(self)
        v.setContentsMargins(24, 32, 24, 32)
        v.setSpacing(8)
        v.setAlignment(Qt.AlignCenter)
        ic = QLabel()
        ic.setAlignment(Qt.AlignCenter)
        ic.setPixmap(qta.icon(icon_name, color=T.BORDER_STRONG).pixmap(QSize(44, 44)))
        t = QLabel(title)
        t.setAlignment(Qt.AlignCenter)
        t.setStyleSheet(f"color: {T.TEXT}; font-size: {T.FONT_SIZE_SECTION}pt; font-weight: 600;")
        h = QLabel(hint)
        h.setAlignment(Qt.AlignCenter)
        h.setWordWrap(True)
        h.setStyleSheet(f"color: {T.TEXT_MUTED}; font-size: {T.FONT_SIZE_BASE}pt;")
        h.setVisible(bool(hint))
        for w in (ic, t, h):
            v.addWidget(w)
        self.action_button = None

    def set_action(self, button):
        self.action_button = button
        self.layout().addWidget(button, 0, Qt.AlignCenter)


class FormSection(Card):
    """مجموعة حقول داخل بطاقة بعنوان: كل حقل = تسمية صغيرة فوقه، بعدد أعمدة ثابت."""

    def __init__(self, title="", columns=2, parent=None):
        super().__init__(parent)
        if title:
            t = QLabel(title)
            t.setStyleSheet(
                f"color: {T.PRIMARY}; font-size: {T.FONT_SIZE_SECTION}pt; font-weight: 700;")
            self.body.addWidget(t)
        self.grid = QGridLayout()
        self.grid.setHorizontalSpacing(T.SPACE * 2)
        self.grid.setVerticalSpacing(T.SPACE * 2)
        self.body.addLayout(self.grid)
        self._columns = max(1, columns)
        self._pos = 0

    def add_field(self, label_text, widget, span=1):
        """يضيف حقلاً بتسميته؛ span=عدد الأعمدة التي يشغلها."""
        span = min(span, self._columns)
        col = self._pos % self._columns
        if col + span > self._columns:       # لا يتّسع في بقية الصف: ابدأ صفاً جديداً
            self._pos += self._columns - col
            col = 0
        row = self._pos // self._columns
        cell = QWidget()
        cell.setStyleSheet("background: transparent;")
        v = QVBoxLayout(cell)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(4)
        lbl = QLabel(label_text)
        lbl.setStyleSheet(
            f"color: {T.TEXT_MUTED}; font-size: {T.FONT_SIZE_BASE}pt; font-weight: 600; background: transparent;")
        v.addWidget(lbl)
        v.addWidget(widget)
        self.grid.addWidget(cell, row, col, 1, span)
        for c in range(self._columns):
            self.grid.setColumnStretch(c, 1)
        self._pos += span
        return cell


class GradientBanner(QFrame):
    """لوحة ترحيب بتدرّج بنفسجي ناعم وأشكال زخرفية شفافة (تُرسم مرة واحدة وتُخزَّن).

    المحتوى يُضاف إلى self.body (QVBoxLayout). الأشكال الزخرفية تكون في الجهة المقابلة
    للنص تلقائياً (يسار في العربية، يمين في غيرها). لا ظلال ولا مؤثرات رسومية.
    """

    def __init__(self, parent=None, radius=18, margins=(28, 22, 28, 22), spacing=6, stops=None):
        super().__init__(parent)
        self.setObjectName("gradBanner")
        self._radius = radius
        self._stops = stops or (T.GRAD_A, T.GRAD_B, T.GRAD_C)
        self._cache = None
        self._cache_key = None
        self.body = QVBoxLayout(self)
        self.body.setContentsMargins(*margins)
        self.body.setSpacing(spacing)
        self.setStyleSheet("QFrame#gradBanner { background: transparent; border: none; }"
                           "QFrame#gradBanner QLabel { background: transparent; border: none; }")

    def _render(self, w, h, rtl, dpr):
        pm = QPixmap(int(w * dpr), int(h * dpr))
        pm.setDevicePixelRatio(dpr)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing)
        path = QPainterPath()
        path.addRoundedRect(QRectF(0, 0, w, h), self._radius, self._radius)
        p.setClipPath(path)
        g = QLinearGradient(0 if not rtl else w, 0, w if not rtl else 0, h)
        g.setColorAt(0.0, QColor(self._stops[0]))
        g.setColorAt(0.55, QColor(self._stops[1]))
        g.setColorAt(1.0, QColor(self._stops[2]))
        p.fillRect(QRectF(0, 0, w, h), g)

        def x_end(d):                       # مسافة من الحافة البعيدة عن النص
            return (w - d) if not rtl else d

        p.setPen(Qt.NoPen)
        p.setBrush(QColor(255, 255, 255, 30))
        p.drawEllipse(QPointF(x_end(70), h * 0.18), 120, 120)
        p.setBrush(QColor(255, 255, 255, 22))
        p.drawEllipse(QPointF(x_end(210), h * 0.95), 90, 90)
        p.setBrush(QColor(255, 200, 87, 235))              # نقطة شمسية صغيرة
        p.drawEllipse(QPointF(x_end(150), h * 0.30), 7, 7)
        p.setBrush(QColor(249, 168, 212, 200))             # نقطة وردية
        p.drawEllipse(QPointF(x_end(46), h * 0.72), 5, 5)
        p.setBrush(Qt.NoBrush)
        p.setPen(QPen(QColor(255, 255, 255, 70), 2))
        p.drawEllipse(QPointF(x_end(120), h * 0.62), 26, 26)
        p.end()
        return pm

    def paintEvent(self, _):
        w, h = self.width(), self.height()
        if w <= 0 or h <= 0:
            return
        rtl = self.layoutDirection() == Qt.RightToLeft
        dpr = self.devicePixelRatioF()
        key = (w, h, rtl, dpr)
        if self._cache is None or self._cache_key != key:
            self._cache = self._render(w, h, rtl, dpr)
            self._cache_key = key
        p = QPainter(self)
        p.drawPixmap(0, 0, self._cache)
        p.end()


class RingGauge(QWidget):
    """حلقة نسبة مئوية (مثل نسبة الإيداع). set_value(0..100) يحرّك القوس بنعومة."""

    def __init__(self, color=T.ACCENT, size=132, parent=None):
        super().__init__(parent)
        self._color = QColor(color)
        self._value = 0.0
        self._caption = ""
        self.setFixedSize(size, size)
        self._anim = None

    def set_caption(self, text):
        self._caption = text
        self.update()

    def set_value(self, pct):
        pct = max(0.0, min(100.0, float(pct)))
        if not T.ANIMATIONS or not self.isVisible():
            self._value = pct
            self.update()
            return
        if self._anim is not None:
            self._anim.stop()
        a = QVariantAnimation(self)
        a.setDuration(650)
        a.setStartValue(float(self._value))
        a.setEndValue(pct)
        a.setEasingCurve(QEasingCurve.OutCubic)
        a.valueChanged.connect(self._tick)
        self._anim = a
        a.start()

    def _tick(self, v):
        self._value = float(v)
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        side = min(self.width(), self.height())
        pad = 11
        rect = QRectF((self.width() - side) / 2 + pad, (self.height() - side) / 2 + pad,
                      side - 2 * pad, side - 2 * pad)
        pen = QPen(QColor(T.BORDER), 11)
        pen.setCapStyle(Qt.RoundCap)
        p.setPen(pen)
        p.drawArc(rect, 0, 360 * 16)
        if self._value > 0.1:
            pen = QPen(self._color, 11)
            pen.setCapStyle(Qt.RoundCap)
            p.setPen(pen)
            p.drawArc(rect, 90 * 16, int(-360 * 16 * self._value / 100.0))
        p.setPen(QColor(T.TEXT))
        f = QFont(self.font())
        f.setBold(True)
        f.setPointSizeF(17)
        p.setFont(f)
        p.drawText(QRectF(0, 0, self.width(), self.height() * (0.56 if self._caption else 1.0)),
                   Qt.AlignHCenter | Qt.AlignBottom if self._caption else Qt.AlignCenter,
                   "%d%%" % int(round(self._value)))
        if self._caption:
            f2 = QFont(self.font())
            f2.setPointSizeF(8.5)
            p.setFont(f2)
            p.setPen(QColor(T.TEXT_MUTED))
            p.drawText(QRectF(8, self.height() * 0.58, self.width() - 16, self.height() * 0.3),
                       Qt.AlignHCenter | Qt.AlignTop | Qt.TextWordWrap, self._caption)
        p.end()


class StackedBar(QWidget):
    """شريط مقسّم بنسب (متأخرة/قريبة/في الأجل/مودعة) مع أطراف مستديرة وفواصل رفيعة."""

    def __init__(self, parent=None, height=14):
        super().__init__(parent)
        self._segments = []
        self.setFixedHeight(height)
        self.setMinimumWidth(80)

    def set_segments(self, segments):
        """segments = [(قيمة, لون)]"""
        self._segments = [(max(0, v), c) for v, c in segments]
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        path = QPainterPath()
        path.addRoundedRect(QRectF(0, 0, w, h), h / 2.0, h / 2.0)
        p.setClipPath(path)
        p.fillRect(QRectF(0, 0, w, h), QColor(T.BORDER))
        total = sum(v for v, _c in self._segments)
        if total > 0:
            rtl = self.layoutDirection() == Qt.RightToLeft
            x = float(w) if rtl else 0.0
            for v, c in self._segments:
                if v <= 0:
                    continue
                seg = w * v / total
                p.setPen(Qt.NoPen)
                p.setBrush(QColor(c))
                p.drawRect(QRectF(x - seg if rtl else x, 0, seg, h))
                x = x - seg if rtl else x + seg
                p.setBrush(QColor("#ffffff"))
                p.drawRect(QRectF(x - 1 if not rtl else x, 0, 2, h))
        p.end()


class CollapsibleCard(Card):
    """بطاقة بترويسة قابلة للطي بسهم (▾/▴): النقر على الترويسة يطوي المحتوى أو يوسّعه بحركة قصيرة.
    المحتوى يُضاف إلى self.inner (QVBoxLayout). تُستعمل في العمود الجانبي لصفحة التخطيط."""

    def __init__(self, title, icon_name="fa5s.circle", color=T.ACCENT, expanded=True, parent=None):
        super().__init__(parent, margins=(14, 10, 14, 12), spacing=8)
        self._expanded = bool(expanded)
        self._anim = None
        self._header = QFrame()
        self._header.setObjectName("collHeader")
        self._header.setCursor(Qt.PointingHandCursor)
        self._header.setStyleSheet("QFrame#collHeader { background: transparent; border: none; }"
                                   "QFrame#collHeader QLabel { background: transparent; border: none; }")
        hl = QHBoxLayout(self._header)
        hl.setContentsMargins(0, 0, 0, 0)
        hl.setSpacing(10)
        hl.addWidget(icon_badge(icon_name, color, tint(color, 0.86), 32, 10, 15))
        self.title_label = QLabel(title)
        self.title_label.setProperty(_SKIP_I18N, True)
        self.title_label.setStyleSheet(
            f"color: {T.INK}; font-size: {T.FONT_SIZE_SECTION}pt; font-weight: 700;")
        self.title_label.setAlignment(lead_align())
        hl.addWidget(self.title_label, 1)
        self._chev = QLabel()
        self._chev.setFixedSize(26, 26)
        self._chev.setAlignment(Qt.AlignCenter)
        self._chev.setStyleSheet(f"background: {T.HOVER_BG}; border-radius: 13px;")
        hl.addWidget(self._chev)
        self.body.addWidget(self._header)

        self.content = QWidget()
        self.content.setStyleSheet("background: transparent;")
        self.inner = QVBoxLayout(self.content)
        self.inner.setContentsMargins(0, 0, 0, 0)
        self.inner.setSpacing(8)
        self.body.addWidget(self.content)
        self._header.mousePressEvent = self._on_header_press
        self._update_chevron()
        self.content.setVisible(self._expanded)

    def set_title(self, text):
        self.title_label.setText(text)

    def is_expanded(self):
        return self._expanded

    def _update_chevron(self):
        name = "fa5s.chevron-up" if self._expanded else "fa5s.chevron-down"
        self._chev.setPixmap(qta.icon(name, color=T.ACCENT).pixmap(QSize(12, 12)))

    def _on_header_press(self, event):
        if event.button() == Qt.LeftButton:
            self.set_expanded(not self._expanded)

    def set_expanded(self, on, animate=True):
        on = bool(on)
        if on == self._expanded:
            return
        self._expanded = on
        self._update_chevron()
        if self._anim is not None:
            self._anim.stop()
        if not (T.ANIMATIONS and animate and self.isVisible()):
            self.content.setMaximumHeight(16777215)
            self.content.setVisible(on)
            return
        anim = QVariantAnimation(self)
        anim.setDuration(220)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        if on:
            self.content.setMaximumHeight(0)
            self.content.setVisible(True)
            anim.setStartValue(0)
            anim.setEndValue(max(1, self.content.sizeHint().height()))
            anim.finished.connect(lambda: self.content.setMaximumHeight(16777215))
        else:
            anim.setStartValue(max(1, self.content.height()))
            anim.setEndValue(0)
            anim.finished.connect(lambda: (self.content.setVisible(False),
                                           self.content.setMaximumHeight(16777215)))
        anim.valueChanged.connect(lambda v: self.content.setMaximumHeight(int(v)))
        self._anim = anim
        anim.start()
