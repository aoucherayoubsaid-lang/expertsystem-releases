# -*- coding: utf-8 -*-
"""نظام الفهرسة والبحث (الخطوة 3).

- فهرستان منفصلتان:
    * فهرس وثائق القضايا: يُبنى تلقائياً من صفحة الوثائق (sync_case_documents)، ويُصفّى برقم القضية والطرف.
    * فهرس المراجع (قوانين وكتب): مشترك لكل القضايا، ويُصفّى بالتصنيف.
- التخزين: SQLite (مدمجة في بايثون) + numpy للبحث بالتشابه. بدون Chroma ويعمل على بايثون 3.8.
- الـ embeddings تأتي من ai_client.embed (وسيط Cloudflare).

اختبار ذاتي بلا إنترنت:   python rag_index.py --selftest
"""
import base64
import hashlib
import os
import re
import sqlite3

import numpy as np
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

import app_paths
import local_protect

IMAGE_EXT = (".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp")
SUPPORTED = (".pdf", ".docx", ".txt", ".md") + IMAGE_EXT
MAX_OCR_PAGES = 80          # سقف صفحات OCR للملف الواحد (ضبط التكلفة)
_ARTICLE = re.compile(r"^\s*(المادة|مادة|Article|Art\.?)\s*\(?\d+", re.IGNORECASE)


# ---------------------------------------------------------------------------
# استخراج النص
# ---------------------------------------------------------------------------

_PRES = re.compile("[\ufb50-\ufdff\ufe70-\ufeff]")          # أشكال عربية مُشكَّلة (تدل على نص بترتيب بصري)
_LTR_RUN = re.compile(r"[A-Za-z0-9][A-Za-z0-9\.\-/:@_,%°]*")
_EXTRACT_VER = "|x3"                                          # يغيّر بصمة الفهرسة فتُعاد قراءة الملفات القديمة


def fix_visual_arabic(text):
    """بعض ملفات PDF (مثل شهادات CNAS) تخزّن العربي بترتيب بصري وبأشكال مُشكَّلة (ﺭﺎﻌﺸﻟﺍ)،
    فيخرج من الاستخراج معكوساً ومبعثراً. نكتشف ذلك بوجود هذه الأشكال في السطر، فنحوّلها إلى
    حروف عادية (NFKC) ونعكس السطر، ثم نعيد عكس مقاطع اللاتينية والأرقام لتبقى سليمة."""
    import unicodedata
    out = []
    for line in (text or "").split("\n"):
        if _PRES.search(line):
            line = unicodedata.normalize("NFKC", line)[::-1]
            line = _LTR_RUN.sub(lambda m: m.group(0)[::-1], line)
        out.append(line)
    return "\n".join(out)


def _pdf_pages(path):
    try:
        import fitz  # PyMuPDF
        doc = fitz.open(path)
        try:
            out = []
            for i, p in enumerate(doc):
                text = fix_visual_arabic(p.get_text("text") or "")
                tables = _pdf_tables_text(p) if len(text.strip()) >= 20 else ""
                out.append((str(i + 1), (text + "\n" + fix_visual_arabic(tables)) if tables else text))
            return out
        finally:
            doc.close()
    except ImportError:
        from pypdf import PdfReader
        return [(str(i + 1), fix_visual_arabic(p.extract_text() or "")) for i, p in enumerate(PdfReader(path).pages)]


def _docx_pages(path):
    from docx import Document
    d = Document(path)
    parts = [p.text for p in d.paragraphs]
    for t in d.tables:
        for row in t.rows:
            parts.append(" | ".join(c.text.strip() for c in row.cells))
    return [("", "\n".join(parts))]


def extract_text(path):
    """يرجع قائمة (رقم_الصفحة, النص). الصفحة الممسوحة ضوئياً ترجع نصاً فارغاً (تحتاج OCR لاحقاً)."""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".pdf":
        return _pdf_pages(path)
    if ext == ".docx":
        return _docx_pages(path)
    if ext in IMAGE_EXT:
        return [("", "")]                       # صورة: لا نص مباشر، تُقرأ بالـ OCR
    if ext in (".txt", ".md"):
        for enc in ("utf-8-sig", "cp1256", "latin-1"):
            try:
                with open(path, "r", encoding=enc) as f:
                    return [("", f.read())]
            except UnicodeDecodeError:
                continue
    raise ValueError("نوع ملف غير مدعوم: %s" % ext)


def enhance_image(img):
    """يحسّن صورة وثيقة قبل قراءتها: يصحّح الدوران حسب EXIF، يكبّر الصغيرة، يوازن التباين ويزيل الضجيج
    ويشحذ الحروف. صور الهاتف الباهتة أو الممسوحة بجودة منخفضة تُقرأ بدقة أعلى بعد ذلك."""
    from PIL import ImageFilter, ImageOps
    try:
        img = ImageOps.exif_transpose(img)
    except Exception:
        pass
    img = img.convert("RGB")
    w, h = img.size
    if max(w, h) < 1500:                                   # صورة صغيرة: تكبير قبل المعالجة
        k = 1500.0 / max(w, h)
        img = img.resize((int(w * k), int(h * k)))
    gray = ImageOps.grayscale(img)
    gray = ImageOps.autocontrast(gray, cutoff=1)           # يمدّ التباين ويشدّ الخلفية للأبيض
    gray = gray.filter(ImageFilter.MedianFilter(3))        # إزالة ضجيج الحبيبات
    gray = gray.filter(ImageFilter.UnsharpMask(radius=2, percent=140, threshold=3))
    return gray.convert("RGB")


# ---------------------------------------------------------------------------
# قراءة مزدوجة للصور: أرقام تختلف بين قراءتين مستقلتين تُرفع للخبير بدل أن تمرّ بصمت
# ---------------------------------------------------------------------------
_AR_DIGITS_RAG = str.maketrans("٠١٢٣٤٥٦٧٨٩٫٬", "0123456789.,")
_DATE_AROUND = re.compile(r"\d{1,2}[./-]\d{1,2}[./-]\d{2,4}")
_AMT = re.compile(r"\d{1,3}(?:[ \u00a0\u202f.,]\d{3})+(?:[.,]\d{1,2})?|\d+(?:[.,]\d{1,2})?")
MAX_FLAGS_PER_SOURCE = 12


def _dual_ocr_enabled():
    """القراءة المزدوجة تضاعف تكلفة OCR؛ مفعّلة افتراضياً لأن الدقة أهم، ويمكن إيقافها بالمفتاح dual_ocr في ai_settings.json."""
    try:
        import json
        import storage
        with open(os.path.join(storage.APP_DATA_DIR, "ai_settings.json"), "r", encoding="utf-8") as f:
            return bool(json.load(f).get("dual_ocr", True))
    except Exception:
        return True


def canon_number(x):
    """الصيغة الموحّدة لقيمة رقمية: 1250.0 و1250.00 كلها '1250'."""
    from decimal import Decimal
    return format(Decimal(repr(float(x))).normalize(), "f")


def amount_tokens(text, min_digits=4, with_spans=False):
    """الأرقام ذات الشأن في نص (min_digits خانات فأكثر، أو أي رقم بكسر عشري) بصيغة موحّدة:
    1 250,00 و1.250,00 و1250 كلها 1250. with_spans=True يرجع {canon: [(بداية, نهاية), ...]} بدل النص الأصلي.
    الأرقام التي في تواريخ (12.03.2020) تُستبعد."""
    from decimal import Decimal, InvalidOperation
    out = {}
    src = (text or "").translate(_AR_DIGITS_RAG)
    for m in _AMT.finditer(src):
        if _DATE_AROUND.search(src[max(0, m.start() - 6):m.end() + 6]) and re.fullmatch(r"\d{1,2}[.,]\d{1,2}|\d{4}", m.group(0)):
            continue
        tok = m.group(0)
        g = re.fullmatch(r"(\d{1,3}(?:[ \u00a0\u202f.,]\d{3})+)([.,]\d{1,2})?", tok)
        if g:
            canon = re.sub(r"\D", "", g.group(1)) + ("." + g.group(2)[1:] if g.group(2) else "")
        else:
            canon = tok.replace(",", ".")
        try:
            canon = format(Decimal(canon).normalize(), "f")
        except InvalidOperation:
            continue
        has_dec = "." in canon
        if len(re.sub(r"\D", "", canon)) < min_digits and not has_dec:
            continue                                   # كميات وأيام صغيرة: ضجيجها أكثر من فائدتها
        if with_spans:
            out.setdefault(canon, []).append((m.start(), m.end()))
        else:
            out.setdefault(canon, tok.strip())
    return out


def ocr_number_diff(a_text, b_text):
    """يقارن أرقام قراءتين لنفس الصفحة. يرجع [{'a': ما قرأته الأولى, 'b': ما قرأته الثانية أو ''}]."""
    import difflib
    ta, tb = amount_tokens(a_text), amount_tokens(b_text)
    only_a = [k for k in ta if k not in tb]
    only_b = [k for k in tb if k not in ta]
    out = []
    for ka in only_a:
        best, score = None, 0.0
        for kb in only_b:
            r = difflib.SequenceMatcher(None, ka, kb).ratio()
            if r > score:
                best, score = kb, r
        if best is not None and score >= 0.6:
            only_b.remove(best)
            out.append({"a": ta[ka], "b": tb[best]})
        else:
            out.append({"a": ta[ka], "b": ""})
    out.extend({"a": "", "b": tb[kb]} for kb in only_b)
    return out


def _join_chunks(chunks):
    """يعيد وصل مقاطع الصفحة الواحدة مع حذف التداخل (150 حرفاً) فلا يتكرر سطر ولا مبلغ عند القراءة الكاملة.
    إذا وُجد تداخل فالوصل مباشر بلا فاصل: المقطع الأول قد ينتهي وسط رقم (1 25 | 0,00) ولا يجوز كسره بسطر جديد."""
    out, prev, prev_page = [], "", None
    for page, text in chunks:
        t = text or ""
        joined = False
        if out and prev and page == prev_page:
            k = min(len(prev), len(t), 150)               # التداخل في chunk_text لا يتجاوز 150 حرفاً
            while k >= 20:
                if prev.endswith(t[:k]):
                    out[-1] += t[k:]
                    joined = True
                    break
                k -= 1
        if not joined and t:
            out.append(t)
        prev, prev_page = text or "", page
    return "\n".join(out)


def pdf_partial_pages(path, min_chars=20, max_chars=400, img_ratio=0.35):
    """صفحات PDF فيها نص قليل وصورة تغطي جزءاً كبيراً منها (جدول أو فاتورة ملصقة كصورة داخل صفحة نصية).
    هذه الصفحات كانت تفوت الـ OCR لأن لها «نصاً» ولو قليلاً."""
    try:
        import fitz
    except ImportError:
        return []
    out = []
    try:
        doc = fitz.open(path)
    except Exception:
        return []
    try:
        for i, p in enumerate(doc):
            n = len((p.get_text("text") or "").strip())
            if n < min_chars or n > max_chars:
                continue
            area = (p.rect.width * p.rect.height) or 1.0
            cover = 0.0
            for info in p.get_image_info():
                x0, y0, x1, y1 = info["bbox"]
                cover += max(0.0, x1 - x0) * max(0.0, y1 - y0)
            if cover / area >= img_ratio:
                out.append(str(i + 1))
    except Exception:
        return out
    finally:
        doc.close()
    return out


def _pdf_tables_text(page, limit=6):
    """جداول الصفحة بصفوفها (خلايا مفصولة بـ « | ») لتبقى علاقة الصف بالعمود؛ get_text وحده يسطّحها."""
    try:
        found = page.find_tables()
    except Exception:
        return ""
    parts = []
    for t in list(getattr(found, "tables", []) or [])[:limit]:
        try:
            rows = t.extract()
        except Exception:
            continue
        lines = [" | ".join((c or "").replace("\n", " ").strip() for c in r) for r in rows if any(r)]
        if len(lines) >= 2:
            parts.append("[جدول]\n" + "\n".join(lines))
    return "\n".join(parts)


def render_pages(path, labels, max_side=2200, quality=82, dpi=200, enhance=True):
    """يحوّل صفحات ممسوحة (PDF) أو ملف صورة إلى JPEG. يرجع {رقم_الصفحة: بايتات}.
    الدقة العالية مقصودة: الأرقام الصغيرة (3 و8، 0 و6، الفاصلة العشرية) تضيع عند 150 dpi وجودة 60.
    enhance=False للقراءة الثانية المستقلة: صورة بلا تحسين تكشف أخطاء قد يصنعها التحسين نفسه."""
    from io import BytesIO
    from PIL import Image

    def to_jpeg(img):
        img = enhance_image(img) if enhance else img.convert("RGB")
        w, h = img.size
        if max(w, h) > max_side:
            k = max_side / float(max(w, h))
            img = img.resize((max(1, int(w * k)), max(1, int(h * k))))
        buf = BytesIO()
        img.save(buf, "JPEG", quality=quality)
        return buf.getvalue()

    ext = os.path.splitext(path)[1].lower()
    out = {}
    if ext in IMAGE_EXT:
        out[labels[0]] = to_jpeg(Image.open(path))
        return out
    if ext == ".pdf":
        try:
            import fitz
        except ImportError:
            raise RuntimeError("قراءة PDF الممسوح تحتاج PyMuPDF")
        doc = fitz.open(path)
        try:
            for lab in labels:
                pix = doc[int(lab) - 1].get_pixmap(dpi=dpi, alpha=False)
                out[lab] = to_jpeg(Image.frombytes("RGB", (pix.width, pix.height), pix.samples))
        finally:
            doc.close()
    return out


# ---------------------------------------------------------------------------
# التقطيع (يبدأ قطعة جديدة عند كل «المادة N»)
# ---------------------------------------------------------------------------
def chunk_text(text, size=900, overlap=150):
    text = re.sub(r"[ \t\u00a0]+", " ", text or "")
    chunks, cur = [], ""

    def flush():
        nonlocal cur
        if cur.strip():
            chunks.append(cur.strip())
        cur = ""

    for line in text.split("\n"):
        line = line.strip()
        if not line:
            continue
        if _ARTICLE.match(line):
            flush()
        pieces = re.split(r"(?<=[\.\!\?؟۔])\s+", line) if len(line) > size else [line]
        for piece in pieces:
            while len(piece) > size:
                if cur:
                    flush()
                chunks.append(piece[:size])
                piece = piece[size - overlap:]
            if cur and len(cur) + 1 + len(piece) > size:
                tail = cur[-overlap:]
                tail = tail[tail.find(" ") + 1:] if " " in tail else ""
                flush()
                cur = (tail + " " + piece).strip()
            else:
                cur = (cur + " " + piece).strip() if cur else piece
    flush()
    return chunks


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


# ---------------------------------------------------------------------------
# تشفير أعمدة الفهرس (AES-256-GCM)
# نص المقاطع (chunks.text) والمتجهات (chunks.vec) ومقتطفات الـ OCR (ocr_flags.a/b) لا تُخزَّن صريحة على القرص.
# المفتاح مشتق من المفتاح الرئيسي المحمي بـ DPAPI (local_protect). ما يبقى صريحاً عمداً: العنوان ورقم القضية
# والطرف والتصنيف (تُستعمل في الاستعلام والتصفية)؛ يغطيها BitLocker. الفهرس قابل لإعادة البناء من الوثائق.
# القراءة تقبل القيم القديمة غير المشفّرة (ترحيل شفاف) ويُشفَّرها الترحيل عند أول فتح.
# ---------------------------------------------------------------------------
_MAGIC = b"ESv1\x00\xff"
_TMAGIC = "ESv1:"
_aead_cache = {}


def _aead():
    key = local_protect.derived_key("rag-db")
    a = _aead_cache.get(key)
    if a is None:
        _aead_cache.clear()
        a = _aead_cache[key] = AESGCM(key)
    return a


def _enc_bytes(data, aad):
    nonce = os.urandom(12)
    return _MAGIC + nonce + _aead().encrypt(nonce, data, aad)


def _is_enc_bytes(b):
    return isinstance(b, (bytes, bytearray)) and bytes(b[:len(_MAGIC)]) == _MAGIC


def _dec_bytes(blob, aad):
    if not _is_enc_bytes(blob):
        return blob                                   # قيمة قديمة غير مشفّرة
    blob = bytes(blob)
    n = len(_MAGIC)
    return _aead().decrypt(blob[n:n + 12], blob[n + 12:], aad)


def _enc_text(text, aad):
    if text is None:
        return None
    return _TMAGIC + base64.b64encode(_enc_bytes(text.encode("utf-8"), aad)).decode("ascii")


def _dec_text(val, aad):
    if val is None or not isinstance(val, str) or not val.startswith(_TMAGIC):
        return val
    return _dec_bytes(base64.b64decode(val[len(_TMAGIC):]), aad).decode("utf-8")


_AAD_TEXT, _AAD_VEC, _AAD_A, _AAD_B = b"chunks.text", b"chunks.vec", b"ocr_flags.a", b"ocr_flags.b"


# ---------------------------------------------------------------------------
# الفهرس
# ---------------------------------------------------------------------------
class Index:
    def __init__(self, db_path, embed_fn=None, ocr_fn=None, use_ocr=True):
        self.db_path = db_path
        self._embed = embed_fn
        self._ocr = ocr_fn
        self.use_ocr = use_ocr
        os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
        with self._conn() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT);
            CREATE TABLE IF NOT EXISTS sources (
                id INTEGER PRIMARY KEY AUTOINCREMENT, doc_key TEXT UNIQUE NOT NULL,
                title TEXT, case_number TEXT, party TEXT, category TEXT,
                sha256 TEXT, status TEXT, n_chunks INTEGER, ocr_pages INTEGER);
            CREATE TABLE IF NOT EXISTS chunks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_id INTEGER NOT NULL REFERENCES sources(id) ON DELETE CASCADE,
                page TEXT, text TEXT, vec BLOB);
            CREATE TABLE IF NOT EXISTS ocr_flags (
                id INTEGER PRIMARY KEY AUTOINCREMENT, source_id INTEGER NOT NULL REFERENCES sources(id) ON DELETE CASCADE,
                page TEXT, a TEXT, b TEXT);
            CREATE INDEX IF NOT EXISTS ix_flag_src ON ocr_flags(source_id);
            CREATE INDEX IF NOT EXISTS ix_src_case ON sources(case_number);
            CREATE INDEX IF NOT EXISTS ix_chunk_src ON chunks(source_id);
            """)
            try:                                   # ترحيل قواعد أُنشئت قبل إضافة OCR
                c.execute("ALTER TABLE sources ADD COLUMN ocr_done INTEGER DEFAULT 0")
            except sqlite3.OperationalError:
                pass
        self._ensure_encrypted()

    def _ensure_encrypted(self):
        """يتحقق من مفتاح التشفير ويشفّر أي صفوف قديمة صريحة (مرة واحدة)."""
        with self._conn() as c:
            row = c.execute("SELECT v FROM meta WHERE k='enc_check'").fetchone()
            if row:
                try:
                    ok = _dec_text(row[0], b"meta") == "ok"
                except Exception:
                    ok = False
                if not ok:
                    # المفتاح تغيّر (إعادة ختم/جهاز جديد): الفهرس مخزَّن مؤقت يُعاد بناؤه من الوثائق، فنفرغه
                    c.execute("DELETE FROM ocr_flags"); c.execute("DELETE FROM chunks"); c.execute("DELETE FROM sources")
                    c.execute("DELETE FROM meta WHERE k='enc_check'")
                    row = None
            if row:
                return
            for cid, text, vec in c.execute("SELECT id,text,vec FROM chunks").fetchall():
                c.execute("UPDATE chunks SET text=?, vec=? WHERE id=?",
                          (text if (text or "").startswith(_TMAGIC) else _enc_text(text, _AAD_TEXT),
                           vec if (vec is None or _is_enc_bytes(vec)) else _enc_bytes(bytes(vec), _AAD_VEC), cid))
            for fid, a, b in c.execute("SELECT id,a,b FROM ocr_flags").fetchall():
                c.execute("UPDATE ocr_flags SET a=?, b=? WHERE id=?",
                          (a if (a or "").startswith(_TMAGIC) else _enc_text(a, _AAD_A),
                           b if (b or "").startswith(_TMAGIC) else _enc_text(b, _AAD_B), fid))
            c.execute("INSERT OR REPLACE INTO meta(k,v) VALUES('enc_check',?)", (_enc_text("ok", b"meta"),))
        # تفريغ صفحات القاعدة الحرة التي قد تحمل النسخة القديمة الصريحة
        c = sqlite3.connect(self.db_path, timeout=30)
        try:
            c.execute("VACUUM")
        finally:
            c.close()

    def _conn(self):
        c = sqlite3.connect(self.db_path, timeout=30)
        c.execute("PRAGMA foreign_keys=ON")
        c.execute("PRAGMA secure_delete=ON")           # الحذف يمحو المحتوى فعلاً لا يكتفي بتحرير الصفحة
        return c

    def _embed_texts(self, texts, is_query=False):
        fn = self._embed
        if fn is None:
            import ai_client
            fn = ai_client.embed
        vecs = np.asarray(fn(texts, is_query=is_query), dtype=np.float32)
        if vecs.ndim != 2 or vecs.shape[0] != len(texts):
            raise RuntimeError("استجابة embeddings غير صالحة")
        norms = np.linalg.norm(vecs, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        return vecs / norms

    def _check_dim(self, conn, dim):
        row = conn.execute("SELECT v FROM meta WHERE k='dim'").fetchone()
        if row is None:
            conn.execute("INSERT INTO meta(k,v) VALUES('dim',?)", (str(dim),))
        elif int(row[0]) != dim:
            raise RuntimeError(
                "تغيّر نموذج الـ embeddings (البعد %s بدل %s). يجب إعادة بناء الفهرس كاملاً." % (dim, row[0]))

    # -- إضافة / تحديث مصدر --------------------------------------------------
    def _ocr_texts(self, images):
        fn = self._ocr
        if fn is None:
            import ai_client
            fn = ai_client.ocr_images
        return fn(images)

    def add_source(self, doc_key, path, title="", case_number="", party="", category=""):
        """يفهرس ملفاً. يرجع {'status': ok | unchanged | no_text, 'chunks': n, 'ocr_pages': n, 'ocr_flags': n}.
        الصفحات الممسوحة (وكذلك صفحات PDF التي فيها صورة كبيرة ونص قليل) تُقرأ بالـ OCR إن كان مفعّلاً،
        وتُقرأ مرتين بمعالجتين مختلفتين للصورة فتُرفع الأرقام المختلفة بين القراءتين إلى الخبير (ocr_flags)."""
        sha = _sha256(path) + _EXTRACT_VER
        with self._conn() as c:
            row = c.execute("SELECT sha256,status,ocr_done FROM sources WHERE doc_key=?", (doc_key,)).fetchone()
        if row and row[0] == sha and not (row[1] == "no_text" and not row[2] and self.use_ocr):
            return {"status": "unchanged", "chunks": 0, "ocr_pages": 0, "ocr_flags": 0}

        pages = extract_text(path)
        base = dict(pages)
        texts, flags = {}, []
        empty = [lab for lab, t in pages if len((t or "").strip()) < 20]
        partial = []
        if self.use_ocr and path.lower().endswith(".pdf"):
            partial = [lab for lab in pdf_partial_pages(path) if lab not in empty]
        ocr_ok = False
        todo_all = empty + partial
        if todo_all and self.use_ocr:
            todo = todo_all[:MAX_OCR_PAGES]
            try:
                imgs = render_pages(path, todo)
                labs = [l for l in todo if l in imgs]
                first = dict(zip(labs, self._ocr_texts([imgs[l] for l in labs])))
                ocr_ok = True
                second = {}
                if _dual_ocr_enabled():
                    try:                                  # قراءة ثانية بمعالجة مختلفة (بلا تحسين، دقة أعلى) لكشف أخطاء الأرقام
                        imgs_b = render_pages(path, labs, max_side=2600, dpi=220, quality=85, enhance=False)
                        labs_b = [l for l in labs if l in imgs_b]
                        second = dict(zip(labs_b, self._ocr_texts([imgs_b[l] for l in labs_b])))
                    except Exception:
                        second = {}                       # فشل القراءة الثانية لا يُفقد الأولى
                for lab in labs:
                    ocr_text = first.get(lab, "")
                    texts[lab] = ((base.get(lab) or "") + "\n" + ocr_text).strip() if lab in partial else ocr_text
                    if lab in second and ocr_text and second[lab]:
                        for d in ocr_number_diff(ocr_text, second[lab]):
                            flags.append((lab, d["a"], d["b"]))
            except Exception:
                ocr_ok = False                      # تبقى الصفحات بلا نص وتُعاد المحاولة لاحقاً

        chunks, ocr_pages = [], 0
        for page, text in pages:
            text = texts.get(page, text)
            if len((text or "").strip()) < 20:
                ocr_pages += 1
                continue
            chunks.extend((page, t) for t in chunk_text(text))

        vecs = self._embed_texts([t for _, t in chunks]) if chunks else None  # قبل لمس القاعدة
        status = "ok" if chunks else "no_text"
        with self._conn() as c:
            if vecs is not None:
                self._check_dim(c, vecs.shape[1])
            c.execute("DELETE FROM sources WHERE doc_key=?", (doc_key,))
            cur = c.execute(
                "INSERT INTO sources(doc_key,title,case_number,party,category,sha256,status,n_chunks,ocr_pages,ocr_done) "
                "VALUES(?,?,?,?,?,?,?,?,?,?)",
                (doc_key, title, str(case_number or ""), party or "", category or "",
                 sha, status, len(chunks), ocr_pages, 1 if ocr_ok else 0))
            sid = cur.lastrowid
            if vecs is not None:
                c.executemany(
                    "INSERT INTO chunks(source_id,page,text,vec) VALUES(?,?,?,?)",
                    [(sid, p, _enc_text(t, _AAD_TEXT), _enc_bytes(vecs[i].tobytes(), _AAD_VEC))
                     for i, (p, t) in enumerate(chunks)])
            if flags:
                c.executemany("INSERT INTO ocr_flags(source_id,page,a,b) VALUES(?,?,?,?)",
                              [(sid, p, _enc_text(a, _AAD_A), _enc_text(b, _AAD_B)) for p, a, b in flags[:MAX_FLAGS_PER_SOURCE]])
        return {"status": status, "chunks": len(chunks), "ocr_pages": ocr_pages, "ocr_flags": len(flags)}

    # -- واجهات للتدقيق ------------------------------------------------------
    def case_sources(self, case_number):
        """وثائق القضية المفهرسة: [{doc_key,title,party,sha}] (sha يتغيّر إذا تغيّر الملف أو نتيجة قراءته)."""
        with self._conn() as c:
            rows = c.execute("SELECT doc_key,title,party,sha256,n_chunks FROM sources WHERE case_number=? "
                             "AND status='ok' ORDER BY id", (str(case_number).strip(),)).fetchall()
        return [{"doc_key": r[0], "title": r[1], "party": r[2], "sha": "%s|%d" % (r[3], r[4])} for r in rows]

    def case_coverage(self, case_number):
        """كل مصادر القضية بحالتها (لا الناجحة فقط): [{doc_key,title,status,n_chunks,ocr_pages,ocr_done}]."""
        with self._conn() as c:
            rows = c.execute("SELECT doc_key,title,status,n_chunks,ocr_pages,ocr_done FROM sources WHERE case_number=? ORDER BY id",
                             (str(case_number).strip(),)).fetchall()
        return [{"doc_key": r[0], "title": r[1], "status": r[2], "n_chunks": r[3], "ocr_pages": r[4], "ocr_done": r[5]}
                for r in rows]

    def ocr_flags(self, doc_key):
        """اختلافات القراءتين المسجّلة لمصدر: [{page,a,b}]."""
        with self._conn() as c:
            rows = c.execute("SELECT f.page,f.a,f.b FROM ocr_flags f JOIN sources s ON s.id=f.source_id "
                             "WHERE s.doc_key=? ORDER BY f.id", (doc_key,)).fetchall()
        return [{"page": r[0], "a": _dec_text(r[1], _AAD_A), "b": _dec_text(r[2], _AAD_B)} for r in rows]

    def full_text(self, title, case_number=None):
        """النص الكامل للوثيقة بترتيبها وبلا تكرار التداخل بين المقاطع (يُستعمل في الاستخراج المنظّم)."""
        where, args = ["s.title=?"], [title]
        if case_number:
            where.append("s.case_number=?")
            args.append(str(case_number).strip())
        with self._conn() as c:
            rows = c.execute("SELECT c.page,c.text FROM chunks c JOIN sources s ON s.id=c.source_id WHERE "
                             + " AND ".join(where) + " ORDER BY c.id", args).fetchall()
        return _join_chunks([(r[0], _dec_text(r[1], _AAD_TEXT)) for r in rows])

    def remove_source(self, doc_key):
        with self._conn() as c:
            c.execute("DELETE FROM sources WHERE doc_key=?", (doc_key,))

    def keys(self):
        with self._conn() as c:
            return {r[0] for r in c.execute("SELECT doc_key FROM sources")}

    def list_sources(self):
        """قائمة المصادر المفهرسة: (doc_key, title, category, n_chunks, ocr_pages, status)."""
        with self._conn() as c:
            return c.execute(
                "SELECT doc_key,title,category,n_chunks,ocr_pages,status FROM sources ORDER BY category,title").fetchall()

    def stats(self):
        with self._conn() as c:
            s = c.execute("SELECT COUNT(*), COALESCE(SUM(n_chunks),0), COALESCE(SUM(ocr_pages),0) FROM sources").fetchone()
        return {"sources": s[0], "chunks": s[1], "ocr_pages_pending": s[2]}

    def document_text(self, title, case_number=None):
        """النص الكامل لكل مقاطع المصدر الذي يحمل هذا العنوان (للتحقق من الأرقام خارج المقتطف)."""
        where, args = ["s.title=?"], [title]
        if case_number:
            where.append("s.case_number=?")
            args.append(str(case_number).strip())
        with self._conn() as c:
            rows = c.execute("SELECT c.text FROM chunks c JOIN sources s ON s.id=c.source_id WHERE "
                             + " AND ".join(where) + " ORDER BY c.id", args).fetchall()
        return "\n".join((_dec_text(x[0], _AAD_TEXT) or "") for x in rows)

    # -- البحث ---------------------------------------------------------------
    def search(self, query, k=6, case_number=None, party=None, category=None):
        where, args = ["1=1"], []
        if case_number:
            where.append("s.case_number=?"); args.append(str(case_number).strip())
        if party:
            where.append("s.party=?"); args.append(party)
        if category:
            where.append("s.category=?"); args.append(category)
        with self._conn() as c:
            rows = c.execute(
                "SELECT c.page,c.text,c.vec,s.title,s.party,s.category,s.case_number FROM chunks c "
                "JOIN sources s ON s.id=c.source_id WHERE " + " AND ".join(where), args).fetchall()
        if not rows:
            return []
        q = self._embed_texts([query], is_query=True)[0]
        rows = [(r[0], _dec_text(r[1], _AAD_TEXT), _dec_bytes(r[2], _AAD_VEC)) + tuple(r[3:]) for r in rows]
        mat = np.vstack([np.frombuffer(r[2], dtype=np.float32) for r in rows])
        if mat.shape[1] != q.shape[0]:
            raise RuntimeError("تغيّر نموذج الـ embeddings. أعد بناء الفهرس.")
        cos = mat @ q
        toks = set(re.findall(r"\w{3,}", query.lower()))
        lex = np.array([sum(t in r[1].lower() for t in toks) / len(toks) if toks else 0.0 for r in rows])
        score = 0.85 * cos + 0.15 * lex          # الكلمات الحرفية (مثل رقم المادة) تُعزّز النتيجة
        out = []
        for i in np.argsort(-score)[:k]:
            r = rows[i]
            out.append({"score": float(score[i]), "text": r[1], "page": r[0], "title": r[3],
                        "party": r[4], "category": r[5], "case_number": r[6]})
        return out


# ---------------------------------------------------------------------------
# الربط ببرنامجك
# ---------------------------------------------------------------------------
def case_index(embed_fn=None):
    import storage
    path = storage._year_path("rag_case_docs.db")
    if app_paths.data_mode() == "shared":
        # SQLite على مجلد شبكي غير موثوق عند تعدد الأجهزة، والفهرس نسخة مشتقة تُعاد من الوثائق:
        # فنُبقيه محلياً لكل جهاز (مفتاحه مشترك فتبقى الأعمدة مشفّرة بالطريقة نفسها).
        import hashlib
        key = hashlib.sha1(os.path.abspath(path).encode("utf-8")).hexdigest()[:20]
        folder = os.path.join(app_paths.machine_dir(), "rag_cache")
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, key + ".db")
    return Index(path, embed_fn)


def reference_index(embed_fn=None):
    import storage
    folder = app_paths.machine_dir() if app_paths.data_mode() == "shared" else storage.APP_DATA_DIR
    return Index(os.path.join(folder, "rag_references.db"), embed_fn)


def _doc_key(d):
    return "doc|%s|%s|%s" % (d.get("case", ""), d.get("party", ""), d.get("filename") or d.get("original_name", ""))


def sync_case_documents(index=None, documents=None, progress=None):
    """يطابق الفهرس مع صفحة الوثائق: يفهرس الجديد والمتغيّر، ويحذف ما حُذف من الصفحة.
    استدعِه بعد كل رفع أو حذف وثيقة (يفضّل في خيط خلفي). progress(i, n, اسم_الملف) اختياري."""
    if index is None:
        index = case_index()
    if documents is None:
        import storage
        documents = storage.load_documents()
    keep, report = set(), []
    docs = [d for d in documents if d.get("full_path") and os.path.exists(d["full_path"])
            and os.path.splitext(d["full_path"])[1].lower() in SUPPORTED]
    for i, d in enumerate(docs):
        key = _doc_key(d)
        keep.add(key)
        if progress:
            progress(i + 1, len(docs), d.get("original_name") or d.get("filename", ""))
        try:
            r = index.add_source(key, d["full_path"], title=d.get("original_name") or d.get("filename", ""),
                                 case_number=d.get("case", ""), party=d.get("party", ""))
        except Exception as e:
            r = {"status": "error", "error": str(e), "chunks": 0, "ocr_pages": 0}
        report.append((key, r))
    for gone in index.keys() - keep:
        index.remove_source(gone)
    return report


def index_case_documents(case_number, index=None, documents=None, progress=None):
    """يفهرس وثائق قضية واحدة فقط (الجديد والمتغيّر) دون المساس بقضايا أخرى (بخلاف sync_case_documents التي تحذف ما ليس
    في القائمة). يرجع (تقرير, ملفات_لم_تُقرأ) حيث الثانية [(اسم, سبب)] لملفات غير مدعومة أو غير موجودة."""
    import storage
    index = index or case_index()
    documents = documents if documents is not None else storage.load_documents()
    n = str(case_number).strip()
    mine = [d for d in documents if str(d.get("case", "")).strip() == n]
    report, skipped = [], []
    for i, d in enumerate(mine):
        name = d.get("original_name") or d.get("filename", "")
        path = d.get("full_path")
        if not path or not os.path.exists(path):
            skipped.append((name, "الملف غير موجود على القرص"))
            continue
        if os.path.splitext(path)[1].lower() not in SUPPORTED:
            skipped.append((name, "نوع الملف غير مدعوم للقراءة الآلية (%s)" % os.path.splitext(path)[1].lower()))
            continue
        if progress:
            progress(i + 1, len(mine), name)
        try:
            r = index.add_source(_doc_key(d), path, title=name, case_number=d.get("case", ""), party=d.get("party", ""))
        except Exception as e:
            r = {"status": "error", "error": str(e), "chunks": 0, "ocr_pages": 0}
            skipped.append((name, "تعذّرت القراءة: %s" % str(e)[:80]))
        report.append((_doc_key(d), r))
    return report, skipped


def add_reference(path, title="", category="", index=None):
    """يضيف قانوناً أو كتاباً إلى فهرس المراجع."""
    index = index or reference_index()
    return index.add_source("ref|" + _sha256(path)[:20], path, title=title or os.path.basename(path), category=category)


# ---------------------------------------------------------------------------
# اختبار ذاتي بلا إنترنت (embeddings مزيّفة من تجزئة الكلمات)
# ---------------------------------------------------------------------------
def _selftest():
    import tempfile
    import zlib
    from docx import Document

    def fake_embed(texts, is_query=False):
        out = []
        for t in texts:
            v = [0.0] * 256
            for w in re.findall(r"\w+", t.lower()):
                v[zlib.crc32(w.encode("utf-8")) % 256] += 1.0
            out.append(v)
        return out

    tmp = tempfile.mkdtemp()
    law = os.path.join(tmp, "law.txt")
    with open(law, "w", encoding="utf-8") as f:
        f.write("المادة 124: كل فعل أياً كان يرتكبه الشخص بخطئه ويسبب ضرراً للغير يلزم من كان سبباً في حدوثه بالتعويض.\n"
                "المادة 176: إذا استحال على المدين أن ينفذ الالتزام عيناً حُكم عليه بالتعويض.\n")
    d1 = os.path.join(tmp, "a.docx")
    doc = Document(); doc.add_paragraph("عقد مقاولة بين الطرف الأول والطرف الثاني بمبلغ مليون دينار وتأخر التسليم ستة أشهر."); doc.save(d1)
    d2 = os.path.join(tmp, "b.docx")
    doc = Document(); doc.add_paragraph("فاتورة شراء معدات مكتبية بمبلغ خمسين ألف دينار لقضية أخرى."); doc.save(d2)

    ref = Index(os.path.join(tmp, "ref.db"), fake_embed)
    print("مرجع:", ref.add_source("ref|1", law, "القانون المدني", category="مدني"))
    print("بحث مرجع 'المادة 176':", [(r["text"][:30], round(r["score"], 2)) for r in ref.search("المادة 176 التعويض", k=1)])

    idx = Index(os.path.join(tmp, "case.db"), fake_embed)
    docs = [{"case": "100", "party": "أحمد", "filename": "a.docx", "original_name": "a.docx", "full_path": d1},
            {"case": "200", "party": "سالم", "filename": "b.docx", "original_name": "b.docx", "full_path": d2}]
    print("مزامنة 1:", [(k.split("|")[-1], r["status"]) for k, r in sync_case_documents(idx, docs)])
    print("مزامنة 2:", [(k.split("|")[-1], r["status"]) for k, r in sync_case_documents(idx, docs)])
    hit = idx.search("تأخر التسليم والمبلغ", k=3, case_number="100")
    print("بحث قضية 100:", [(h["title"], h["case_number"]) for h in hit])
    assert all(h["case_number"] == "100" for h in hit), "تسرّب بين القضايا!"
    sync_case_documents(idx, docs[:1])
    print("بعد حذف وثيقة:", idx.stats())
    print("نجح الاختبار")


if __name__ == "__main__":
    import sys
    if "--selftest" in sys.argv:
        _selftest()
    else:
        print(__doc__)
