# -*- coding: utf-8 -*-
"""Automatic UI translation with persistent cache.

UI text is translated on demand. New labels/buttons do not need dictionary entries.
User-entered data (QLineEdit/QTextEdit contents, database values) is never translated.
"""
import json
import os
import re
import sqlite3
import threading
import urllib.parse
import urllib.request
from PyQt5.QtCore import QObject, QTimer, QCoreApplication, Qt, pyqtSignal, QEvent
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton, QCheckBox, QRadioButton,
    QGroupBox, QToolButton, QComboBox, QTabWidget, QTableWidget,
    QTableWidgetItem, QAction, QMenu, QLineEdit, QTextEdit, QPlainTextEdit,
)

LANGS = {"ar", "fr", "en"}
SOURCE_LANG = "ar"
SOURCE_PROP = "_auto_i18n_source"
SKIP_PROP = "_auto_i18n_skip"


def _cache_path():
    from app_paths import app_base_dir
    base = os.path.join(app_base_dir(), "data")
    if not os.path.isdir(base):
        try:
            os.makedirs(base)
        except OSError:
            base = app_base_dir()
    return os.path.join(base, "translation_cache.sqlite3")


class TranslationCache:
    def __init__(self, path=None):
        self.path = path or _cache_path()
        self.lock = threading.RLock()
        self._init_db()

    def _connect(self):
        con = sqlite3.connect(self.path, timeout=10)
        con.execute("PRAGMA journal_mode=WAL")
        return con

    def _init_db(self):
        with self.lock:
            con = self._connect()
            con.execute("""CREATE TABLE IF NOT EXISTS translations (
                source_lang TEXT NOT NULL,
                target_lang TEXT NOT NULL,
                source_text TEXT NOT NULL,
                translated_text TEXT NOT NULL,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(source_lang, target_lang, source_text)
            )""")
            con.commit()
            con.close()

    def get(self, source, target):
        with self.lock:
            con = self._connect()
            row = con.execute(
                "SELECT translated_text FROM translations WHERE source_lang=? AND target_lang=? AND source_text=?",
                (SOURCE_LANG, target, source),
            ).fetchone()
            con.close()
            return row[0] if row else None

    def put(self, source, target, translated):
        if not translated:
            return
        with self.lock:
            con = self._connect()
            con.execute(
                "INSERT OR REPLACE INTO translations(source_lang,target_lang,source_text,translated_text) VALUES(?,?,?,?)",
                (SOURCE_LANG, target, source, translated),
            )
            con.commit()
            con.close()


class OnlineTranslator:
    """Small REST client using Google's public translation endpoint.

    The endpoint is deliberately isolated so it can be replaced by a licensed
    provider later without changing the UI translation layer.
    """
    def translate(self, text, target):
        if not text or target == SOURCE_LANG:
            return text
        query = urllib.parse.urlencode({
            "client": "gtx", "sl": SOURCE_LANG, "tl": target,
            "dt": "t", "q": text,
        })
        url = "https://translate.googleapis.com/translate_a/single?" + query
        req = urllib.request.Request(url, headers={"User-Agent": "JudicialExpertApp/1.0"})
        with urllib.request.urlopen(req, timeout=6) as response:
            data = json.loads(response.read().decode("utf-8"))
        parts = data[0] if isinstance(data, list) else []
        return "".join(p[0] for p in parts if p and p[0]) or text


class AutoTranslationManager(QObject):
    """Automatically translates visible UI-owned strings and RTL/LTR direction."""
    translation_ready = pyqtSignal(object, str, str)

    def __init__(self, app=None):
        super().__init__(app)
        self.app = app or QApplication.instance()
        self.cache = TranslationCache()
        self.provider = OnlineTranslator()
        self.lang = SOURCE_LANG
        self._in_progress = set()
        self._lock = threading.RLock()
        self.translation_ready.connect(self._apply_result)
        # لا نستخدم Timer دوري لمسح كل الواجهة؛ كان ذلك يسبب بطئًا واضحًا
        # خصوصًا عند تبديل اللغة. نلتقط فقط إنشاء/إظهار عناصر جديدة.
        self._scan_pending = False
        if self.app:
            self.app.installEventFilter(self)

    def eventFilter(self, obj, event):
        if event.type() in (QEvent.Show, QEvent.ChildAdded):
            self._schedule_scan()
        return False

    def _schedule_scan(self):
        if self._scan_pending:
            return
        self._scan_pending = True
        QTimer.singleShot(0, self._run_scheduled_scan)

    def _run_scheduled_scan(self):
        self._scan_pending = False
        self.scan_and_translate()

    def set_language(self, lang):
        self.lang = lang if lang in LANGS else SOURCE_LANG
        if self.app:
            self.app.setLayoutDirection(Qt.RightToLeft if self.lang == "ar" else Qt.LeftToRight)
        self.scan_and_translate()

    def _eligible(self, w):
        return isinstance(w, (QLabel, QPushButton, QCheckBox, QRadioButton,
                              QGroupBox, QToolButton, QComboBox, QTabWidget,
                              QTableWidget)) and not w.property(SKIP_PROP)

    def _clean(self, text):
        if text is None:
            return ""
        text = str(text)
        if not text.strip():
            return ""
        if len(text) > 600:
            return ""  # avoid sending large rich text/documents
        # Pure data/numbers/paths are not UI labels.
        if not re.search(r"[\u0600-\u06FF]", text):
            return "" if self.lang == SOURCE_LANG else text
        return text

    def _source(self, w, current):
        src = w.property(SOURCE_PROP)
        if src is None:
            src = current
            if src:
                w.setProperty(SOURCE_PROP, src)
        return str(src or "")

    def _translate(self, w, source):
        if self.lang == SOURCE_LANG:
            self._set_text(w, source)
            return
        key = (id(w), self.lang, source)
        if key in self._in_progress:
            return
        cached = self.cache.get(source, self.lang)
        if cached:
            self._set_text(w, cached)
            return
        self._in_progress.add(key)
        threading.Thread(target=self._worker, args=(w, source, self.lang, key), daemon=True).start()

    def _worker(self, w, source, target, key):
        try:
            result = self.provider.translate(source, target)
            if result and result != source:
                self.cache.put(source, target, result)
            self.translation_ready.emit(w, source, result or source)
        except Exception:
            # Keep the source text if the internet is unavailable.
            self.translation_ready.emit(w, source, source)
        finally:
            with self._lock:
                self._in_progress.discard(key)

    def _apply_result(self, w, source, result):
        try:
            if w is not None and not w.property(SKIP_PROP) and w.property(SOURCE_PROP) == source:
                self._set_text(w, result)
        except RuntimeError:
            pass

    def _set_text(self, w, text):
        if isinstance(w, QLabel):
            w.setText(text)
        elif isinstance(w, (QPushButton, QCheckBox, QRadioButton, QGroupBox, QToolButton)):
            w.setText(text)
        elif isinstance(w, QComboBox):
            # Items are handled separately.
            pass

    def _translate_combo(self, w):
        for i in range(w.count()):
            item = w.itemText(i)
            prop = "_auto_i18n_item_%d" % i
            shown_prop = "_auto_i18n_shown_%d" % i
            src = w.property(prop)
            shown = w.property(shown_prop)
            # إذا أعاد التطبيق تعبئة القائمة (عناصر جديدة بنفس الفهارس) فالنص الأصلي المخزّن قديم:
            # وإلا أعدنا كتابة نصوص العناصر القديمة فوق الجديدة فيختلف المعروض عن بيانات العنصر.
            replaced = src is None or (item != str(src) and (shown is None or item != str(shown)))
            if replaced:
                src = item
                w.setProperty(prop, src)
            target = item
            if self.lang == SOURCE_LANG:
                target = str(src)
            elif re.search(r"[\u0600-\u06FF]", str(src)):
                cached = self.cache.get(str(src), self.lang)
                if cached:
                    target = cached
                else:
                    self._translate_combo_item(w, i, str(src))
            if target != item:
                w.setItemText(i, target)
            w.setProperty(shown_prop, target)

    def _translate_combo_item(self, w, i, source):
        key = (id(w), i, self.lang, source)
        if key in self._in_progress:
            return
        cached = self.cache.get(source, self.lang)
        if cached:
            w.setItemText(i, cached); return
        self._in_progress.add(key)
        def worker():
            try:
                result = self.provider.translate(source, self.lang)
                if result and result != source: self.cache.put(source, self.lang, result)
                self._combo_ready(w, i, source, result or source)
            except Exception:
                self._combo_ready(w, i, source, source)
            finally:
                self._in_progress.discard(key)
        threading.Thread(target=worker, daemon=True).start()

    def _combo_ready(self, w, i, source, result):
        def apply():
            try:
                if (w.property("_auto_i18n_item_%d" % i) == source and i < w.count()
                        and w.itemText(i) in (source, w.property("_auto_i18n_shown_%d" % i))):
                    w.setItemText(i, result)
                    w.setProperty("_auto_i18n_shown_%d" % i, result)
            except RuntimeError:
                pass
        QTimer.singleShot(0, apply)

    def _translate_tabs(self, w):
        for i in range(w.count()):
            text = w.tabText(i)
            prop = "_auto_i18n_tab_%d" % i
            src = w.property(prop)
            if src is None:
                src = text; w.setProperty(prop, src)
            if self.lang == SOURCE_LANG:
                w.setTabText(i, str(src))
            elif re.search(r"[\u0600-\u06FF]", str(src)):
                cached = self.cache.get(str(src), self.lang)
                if cached: w.setTabText(i, cached)
                else: self._translate_tab(w, i, str(src))

    def _translate_tab(self, w, i, source):
        key = (id(w), "tab", i, self.lang, source)
        if key in self._in_progress: return
        self._in_progress.add(key)
        def worker():
            try:
                result = self.provider.translate(source, self.lang)
                if result and result != source: self.cache.put(source, self.lang, result)
                QTimer.singleShot(0, lambda: self._tab_ready(w, i, source, result or source))
            except Exception:
                QTimer.singleShot(0, lambda: self._tab_ready(w, i, source, source))
            finally: self._in_progress.discard(key)
        threading.Thread(target=worker, daemon=True).start()

    def _tab_ready(self, w, i, source, result):
        try:
            if w.property("_auto_i18n_tab_%d" % i) == source and i < w.count(): w.setTabText(i, result)
        except RuntimeError: pass

    def _translate_table(self, w):
        for col in range(w.columnCount()):
            item = w.horizontalHeaderItem(col)
            if not item: continue
            text = item.text()
            prop = "_auto_i18n_header_%d" % col
            src = w.property(prop)
            if src is None:
                src = text; w.setProperty(prop, src)
            if self.lang == SOURCE_LANG:
                item.setText(str(src))
            elif re.search(r"[\u0600-\u06FF]", str(src)):
                cached = self.cache.get(str(src), self.lang)
                if cached: item.setText(cached)
                else: self._translate_header(w, col, str(src))

    def _translate_header(self, w, col, source):
        key = (id(w), "header", col, self.lang, source)
        if key in self._in_progress: return
        self._in_progress.add(key)
        def worker():
            try:
                result = self.provider.translate(source, self.lang)
                if result and result != source: self.cache.put(source, self.lang, result)
                QTimer.singleShot(0, lambda: self._header_ready(w, col, source, result or source))
            except Exception:
                QTimer.singleShot(0, lambda: self._header_ready(w, col, source, source))
            finally: self._in_progress.discard(key)
        threading.Thread(target=worker, daemon=True).start()

    def _header_ready(self, w, col, source, result):
        try:
            if w.property("_auto_i18n_header_%d" % col) == source and w.horizontalHeaderItem(col):
                w.horizontalHeaderItem(col).setText(result)
        except RuntimeError: pass

    def scan_and_translate(self):
        if not self.app:
            return
        for top in self.app.topLevelWidgets():
            self._scan(top)

    def _scan(self, root):
        if self._eligible(root):
            if isinstance(root, QComboBox):
                self._translate_combo(root)
            elif isinstance(root, QTabWidget):
                self._translate_tabs(root)
            elif isinstance(root, QTableWidget):
                self._translate_table(root)
            else:
                current = root.text() if hasattr(root, "text") else ""
                source = self._source(root, current)
                if source and re.search(r"[\u0600-\u06FF]", source):
                    self._translate(root, source)
        for child in root.findChildren(QWidget):
            if child is root: continue
            if self._eligible(child):
                if isinstance(child, QComboBox):
                    self._translate_combo(child)
                elif isinstance(child, QTabWidget):
                    self._translate_tabs(child)
                elif isinstance(child, QTableWidget):
                    self._translate_table(child)
                else:
                    current = child.text() if hasattr(child, "text") else ""
                    source = self._source(child, current)
                    if source and re.search(r"[\u0600-\u06FF]", source):
                        self._translate(child, source)


_MANAGER = None

def get_auto_translation_manager(app=None):
    global _MANAGER
    app = app or QApplication.instance()
    if _MANAGER is None and app is not None:
        _MANAGER = AutoTranslationManager(app)
    return _MANAGER
