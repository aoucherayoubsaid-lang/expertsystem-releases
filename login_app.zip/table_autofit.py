# -*- coding: utf-8 -*-
"""ضبط تلقائي لأعمدة وصفوف كل الجداول في البرنامج.

المشكلة: أعمدة بعرض ثابت أو متساوٍ (Stretch) وصفوف بارتفاع ثابت => عند تغيير
نوع الخط أو حجمه (من الإعدادات) يُقطع نص بعض الخلايا والعناوين.

الحل (يُطبَّق على كل QTableWidget / QTableView تلقائياً من modern_theme):
  * عرض كل عمود = max(عرض العنوان، عرض أطول نص فيه) بحسب الخط الحالي.
  * النص الطويل يلتف على عدة أسطر (عرض العمود لا يتجاوز MAX_COLUMN_WIDTH)
    وترتفع الصفوف تلقائياً بدل قطع النص.
  * يُعاد الضبط تلقائياً عند: فتح الجدول، تغيير الخط/النمط، تغيير حجم النافذة،
    إضافة/حذف/تعديل الصفوف.
  * أي جدول يمكن استثناؤه بـ:  table.setProperty("_no_autofit", True)
"""
from PyQt5.QtCore import QObject, QEvent, QTimer, Qt
from PyQt5.QtWidgets import QHeaderView, QTableView

MAX_COLUMN_WIDTH = 300      # أقصى عرض لعمود نصي قبل أن يلتف النص (بكسل)
MIN_COLUMN_WIDTH = 60
CELL_PADDING = 24           # هامش إضافي حول النص
MIN_ROW_HEIGHT = 36

_FIT_EVENTS = (
    QEvent.Show, QEvent.Resize, QEvent.FontChange,
    QEvent.ApplicationFontChange, QEvent.StyleChange,
)


class _TableFitter(QObject):
    def __init__(self, table):
        super().__init__(table)
        self.table = table
        self._pending = False
        self._fitting = False

        table.setWordWrap(True)
        table.setTextElideMode(Qt.ElideNone)
        hh = table.horizontalHeader()
        hh.setStretchLastSection(False)
        hh.setMinimumSectionSize(MIN_COLUMN_WIDTH)
        vh = table.verticalHeader()
        vh.setMinimumSectionSize(max(MIN_ROW_HEIGHT, vh.defaultSectionSize()))
        vh.setSectionResizeMode(QHeaderView.ResizeToContents)

        table.installEventFilter(self)
        model = table.model()
        if model is not None:
            for sig in (model.rowsInserted, model.rowsRemoved, model.modelReset,
                        model.dataChanged, model.layoutChanged):
                sig.connect(self.schedule)
        self.schedule()

    def eventFilter(self, obj, event):
        if obj is self.table and event.type() in _FIT_EVENTS and not self._fitting:
            self.schedule()
        return False

    def schedule(self, *args):
        if self._pending:
            return
        self._pending = True
        QTimer.singleShot(40, self.fit)

    def _has_widgets(self, col):
        t = self.table
        model = t.model()
        if model is None:
            return False
        for r in range(min(model.rowCount(), 60)):
            if t.indexWidget(model.index(r, col)) is not None:
                return True
        return False

    def fit(self):
        self._pending = False
        t = self.table
        try:
            if t.property("_no_autofit") or not t.isVisible():
                return
            model = t.model()
            if model is None or model.columnCount() == 0:
                return
        except RuntimeError:        # الجدول حُذف
            return
        self._fitting = True
        try:
            hh = t.horizontalHeader()
            widths = {}
            fixed_total = 0
            for col in range(model.columnCount()):
                if t.isColumnHidden(col):
                    continue
                w = max(hh.sectionSizeHint(col), t.sizeHintForColumn(col) + CELL_PADDING)
                has_widget = self._has_widgets(col)
                if not has_widget:
                    w = min(w, MAX_COLUMN_WIDTH)
                w = max(w, MIN_COLUMN_WIDTH)
                hh.setSectionResizeMode(col, QHeaderView.Interactive)
                widths[col] = (w, has_widget)
                fixed_total += w

            free = t.viewport().width() - fixed_total
            flex = {c: w for c, (w, hw) in widths.items() if not hw}
            if free > 0 and flex:
                base = sum(flex.values())
                for c in flex:
                    w, hw = widths[c]
                    widths[c] = (w + int(free * w / base), hw)

            for col, (w, _hw) in widths.items():
                if hh.sectionSize(col) != w:
                    hh.resizeSection(col, w)
            t.resizeRowsToContents()
        finally:
            self._fitting = False


def install_autofit(table):
    """يثبّت الضبط التلقائي على جدول (مرة واحدة فقط لكل جدول)."""
    if not isinstance(table, QTableView) or table.property("_autofit_installed"):
        return
    if table.property("_no_autofit"):
        return
    table.setProperty("_autofit_installed", True)
    _TableFitter(table)
