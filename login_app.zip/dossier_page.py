from msgbox_ltr import show_warning, show_question, show_confirm
# dossier_page.py
"""
شاشة اختيار tr("dossier_column_name") (Dossier).
تظهر هذه الشاشة بعد نجاح تسجيل الدخول مباشرة، وتمثل نقطة الدخول الحقيقية
لبيانات العمل: كل Dossier يمثّل جهة قضائية عليا (محكمة / مجلس قضائي /
محكمة إدارية ...) وله بياناته الخاصة (قضايا، أطراف، أتعاب...) المعزولة
تماماً عن باقي الملفات.

بعد اختيار المستخدم لملف والضغط على "فتح" (Ouvrir) يتم:
    1) استدعاء storage.set_current_dossier(folder, name)
    2) فتح النافذة الرئيسية MainApp
"""

import qtawesome as qta
from PyQt5.QtCore import Qt, QSize, QRectF, QPointF
from PyQt5.QtGui import QColor, QLinearGradient, QPainter, QPixmap, QPen, QFont, QPainterPath
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QListWidget,
    QListWidgetItem, QDialog, QLineEdit, QMessageBox, QFrame, QAbstractItemView,
    QStackedWidget, QStyledItemDelegate, QStyle, QBoxLayout
)

import storage
from i18n import tr
import theme_tokens as T
from modern_theme import style_button, style_soft_button, style_hero_button
from ui_components import GradientBanner, EmptyState, icon_badge, mix, tint

_SKIP = "_auto_i18n_skip"

_S = {
    "ar": {"sub": "اختر الملف الذي تريد العمل عليه، أو أنشئ ملفاً جديداً",
           "search": "ابحث عن ملف...", "count": "{n} ملف", "selected": "الملف المحدد",
           "none_sel": "لم تختر ملفاً بعد", "pick_hint": "اختر ملفاً من القائمة لفتحه",
           "kind": "ملف عمل", "hello": "مرحباً"},
    "fr": {"sub": "Choisissez le dossier à ouvrir ou créez-en un nouveau",
           "search": "Rechercher un dossier...", "count": "{n} dossier(s)", "selected": "Dossier sélectionné",
           "none_sel": "Aucun dossier choisi", "pick_hint": "Sélectionnez un dossier dans la liste",
           "kind": "Dossier de travail", "hello": "Bonjour"},
    "en": {"sub": "Pick the file you want to work on, or create a new one",
           "search": "Search files...", "count": "{n} file(s)", "selected": "Selected file",
           "none_sel": "No file selected yet", "pick_hint": "Select a file from the list to open it",
           "kind": "Work file", "hello": "Hello"},
}

# ألوان بطاقات الملفات: تتدرّج بينها بالتناوب لتبدو القائمة حيّة دون إجهاد للعين
_CARD_COLORS = (
    (T.ACCENT, T.TINT_INDIGO), (T.TEAL, T.TINT_TEAL), (T.GOLD, T.TINT_AMBER),
    (T.CORAL, T.TINT_ROSE), (T.SUCCESS, T.TINT_GREEN), (T.PURPLE, T.TINT_VIOLET),
)


class AddEditDossierDialog(QDialog):
    def __init__(self, parent=None, current_name=""):
        super().__init__(parent)
        self.setWindowTitle(tr("dossier_form_title"))
        self.resize(460, 190)
        self.setStyleSheet(f"""
            QDialog {{ background-color: {T.BG}; }}
            QLabel {{ font-weight: 600; font-size: 11pt; color: {T.TEXT}; }}
            QLineEdit {{
                padding: 11px 12px; border: 2px solid {T.BORDER_STRONG}; border-radius: 12px;
                font-size: 11pt; background: white;
            }}
            QLineEdit:focus {{ border: 2px solid {T.ACCENT}; }}
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 20, 22, 18)
        layout.setSpacing(10)
        layout.addWidget(QLabel(tr("dossier_name_placeholder")))
        self.name_input = QLineEdit(current_name)
        self.name_input.setPlaceholderText(tr("dossier_name_example"))
        layout.addWidget(self.name_input)
        layout.addStretch(1)

        btn_row = QHBoxLayout()
        btn_row.addStretch()
        save_btn = QPushButton(tr("dossier_save_generic"))
        save_btn.setMinimumHeight(42)
        style_hero_button(save_btn, radius=12, padding="9px 30px")
        save_btn.clicked.connect(self.accept)
        btn_row.addWidget(save_btn)
        layout.addLayout(btn_row)

    def get_name(self):
        return self.name_input.text().strip()


class _DossierDelegate(QStyledItemDelegate):
    """يرسم كل ملف كبطاقة: مربع أيقونة ملوّن + الاسم + وصف صغير + سهم.
    الرسم يدوي (بلا ودجتات داخل القائمة) فيبقى التمرير سريعاً حتى على الأجهزة القديمة."""

    def __init__(self, kind_text, parent=None):
        super().__init__(parent)
        self._kind = kind_text
        self._pix = {}

    def _icon(self, name, color, size):
        key = (name, color, size)
        pm = self._pix.get(key)
        if pm is None:
            pm = qta.icon(name, color=color).pixmap(QSize(size, size))
            self._pix[key] = pm
        return pm

    def sizeHint(self, option, index):
        return QSize(option.rect.width(), 76)

    def paint(self, painter, option, index):
        painter.save()
        painter.setRenderHint(QPainter.Antialiasing)
        rtl = option.direction == Qt.RightToLeft
        selected = bool(option.state & QStyle.State_Selected)
        hover = bool(option.state & QStyle.State_MouseOver)
        card = QRectF(option.rect.adjusted(2, 5, -2, -5))
        fg, card_tint = _CARD_COLORS[index.row() % len(_CARD_COLORS)]

        if selected:
            painter.setBrush(QColor(tint(T.ACCENT, 0.92)))
            painter.setPen(QPen(QColor(T.ACCENT), 2))
        else:
            painter.setBrush(QColor(T.SURFACE_ALT if hover else T.SURFACE))
            painter.setPen(QPen(QColor(T.BORDER_STRONG if hover else T.BORDER), 1))
        painter.drawRoundedRect(card.adjusted(1, 1, -1, -1), 16, 16)

        box = 46.0
        ix = card.right() - 16 - box if rtl else card.left() + 16
        iy = card.center().y() - box / 2
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor(fg if selected else card_tint))
        painter.drawRoundedRect(QRectF(ix, iy, box, box), 14, 14)
        icon = self._icon("fa5s.balance-scale", "#ffffff" if selected else fg, 20)
        painter.drawPixmap(int(ix + (box - 20) / 2), int(iy + (box - 20) / 2), icon)

        chev = self._icon("fa5s.chevron-left" if rtl else "fa5s.chevron-right",
                          T.ACCENT if selected else T.BORDER_STRONG, 13)
        cx = card.left() + 18 if rtl else card.right() - 18 - 13
        painter.drawPixmap(int(cx), int(card.center().y() - 6), chev)

        if rtl:
            tx0, tx1 = cx + 13 + 10, ix - 14
            align = Qt.AlignRight | Qt.AlignVCenter
        else:
            tx0, tx1 = ix + box + 14, cx - 10
            align = Qt.AlignLeft | Qt.AlignVCenter
        width = max(10, int(tx1 - tx0))

        name_font = QFont(option.font)
        name_font.setPointSizeF(12)
        name_font.setBold(True)
        painter.setFont(name_font)
        painter.setPen(QColor(T.PRIMARY_DARK if selected else T.TEXT))
        name = painter.fontMetrics().elidedText(str(index.data(Qt.DisplayRole) or ""), Qt.ElideRight, width)
        painter.drawText(QRectF(tx0, card.top() + 12, width, 26), align, name)

        sub_font = QFont(option.font)
        sub_font.setPointSizeF(9.5)
        painter.setFont(sub_font)
        painter.setPen(QColor(T.TEXT_MUTED))
        painter.drawText(QRectF(tx0, card.top() + 38, width, 22), align, self._kind)
        painter.restore()


class _PageBackground(QWidget):
    """خلفية الصفحة: تدرّج لافندر فاتح + دوائر باستيل كبيرة (تُرسم مرة وتُخزَّن)."""

    def __init__(self):
        super().__init__()
        self._cache = None

    def paintEvent(self, _):
        w, h = self.width(), self.height()
        if self._cache is None or self._cache.size() != self.size():
            pm = QPixmap(w, h)
            p = QPainter(pm)
            p.setRenderHint(QPainter.Antialiasing)
            g = QLinearGradient(0, 0, w, h)
            g.setColorAt(0.0, QColor(T.BG_GRAD[0]))
            g.setColorAt(0.55, QColor(T.BG_GRAD[1]))
            g.setColorAt(1.0, QColor(T.BG_GRAD[2]))
            p.fillRect(pm.rect(), g)
            p.setPen(Qt.NoPen)
            for cx, cy, r, col in ((60, 40, 170, QColor(124, 58, 237, 28)),
                                   (w - 40, 90, 140, QColor(14, 165, 233, 26)),
                                   (w - 120, h - 20, 190, QColor(236, 72, 153, 20)),
                                   (120, h, 120, QColor(255, 200, 87, 38))):
                p.setBrush(col)
                p.drawEllipse(QPointF(cx, cy), r, r)
            p.end()
            self._cache = pm
        p = QPainter(self)
        p.drawPixmap(0, 0, self._cache)
        p.end()


class DossierPage(_PageBackground):
    """شاشة اختيار الملف (Dossier) - تظهر بعد تسجيل الدخول.

    تصميم «قائمة + لوحة تفاصيل»: يمين/يسار القائمة بطاقات ملوّنة قابلة للبحث،
    وفي الجهة الأخرى لوحة بتدرّج بنفسجي تعرض الملف المحدد وزر الفتح الرئيسي وبقية الإجراءات."""

    def __init__(self, current_user=None):
        super().__init__()
        # current_user: قاموس {"username":..., "role": "admin"/"user"}
        self.current_user = current_user or {"username": "admin", "role": "admin"}
        self.is_admin = storage.user_can(self.current_user, "manage_dossiers")
        self._lang = self._app_language_code()
        self._all = []

        self.setWindowTitle(tr("dossier_window_title"))
        from PyQt5.QtWidgets import QApplication
        _scr = QApplication.primaryScreen().availableGeometry()
        _w, _h = 1020, min(680, int(_scr.height() * 0.94))
        self.resize(_w, _h)
        self.setMinimumSize(900, 600)
        self.move(_scr.center().x() - _w // 2, _scr.center().y() - _h // 2)

        # اتجاه الواجهة يتبع لغة البرنامج: العربية = من اليمين إلى اليسار
        self.setLayoutDirection(
            Qt.RightToLeft if self._lang == "ar" else Qt.LeftToRight)

        self._setup_ui()
        self.load_dossiers()

    # ------------------------------------------------------------------
    @staticmethod
    def _app_language_code():
        """لغة البرنامج المحفوظة في الإعدادات (ar / fr / en)، والافتراضي العربية."""
        try:
            from settings_page import AppSettings
            return AppSettings().get_language_code()
        except Exception:
            return "ar"

    def s(self, key, **kw):
        txt = _S.get(self._lang, _S["ar"])[key]
        return txt.format(**kw) if kw else txt

    def _user_display_name(self):
        username = str(self.current_user.get("username", "") or "")
        if self.current_user.get("role") == "admin" or username.lower() == "admin":
            return tr("dossier_system_admin")
        return username

    def _label(self, text="", css=""):
        lbl = QLabel(text)
        lbl.setProperty(_SKIP, True)
        lbl.setStyleSheet("background: transparent; border: none;" + css)
        return lbl

    def _setup_ui(self):
        rtl = self.layoutDirection() == Qt.RightToLeft
        layout = QVBoxLayout(self)
        layout.setContentsMargins(34, 26, 34, 28)
        layout.setSpacing(18)

        # ---------- الترويسة ----------
        header_row = QHBoxLayout()
        header_row.setSpacing(14)
        header_row.addWidget(icon_badge("fa5s.folder-open", "#ffffff", None, 52, 16, 24, gradient=True))
        title_box = QVBoxLayout()
        title_box.setSpacing(1)
        title = QLabel(tr("dossier_files_title"))
        title.setStyleSheet(f"color: {T.INK}; font-size: 21pt; font-weight: 700; background: transparent;")
        title_box.addWidget(title)
        title_box.addWidget(self._label(self.s("sub"), f"color: {T.TEXT_MUTED}; font-size: 10.5pt;"))
        header_row.addLayout(title_box)
        header_row.addStretch()

        from theme_manager import make_theme_button
        header_row.addWidget(make_theme_button(self), alignment=Qt.AlignTop)
        # بطاقة صغيرة للمستخدم الحالي (أفاتار بالحرف الأول)
        user_name = self._user_display_name()
        if user_name:
            chip = QFrame()
            chip.setObjectName("userChip")
            chip.setStyleSheet(
                f"QFrame#userChip {{ background: white; border: 1px solid {T.BORDER}; border-radius: 22px; }}"
                "QFrame#userChip QLabel { background: transparent; border: none; }")
            cl = QHBoxLayout(chip)
            cl.setContentsMargins(6, 6, 18, 6)
            cl.setSpacing(10)
            av = QLabel((user_name.strip() or "?")[0].upper())
            av.setProperty(_SKIP, True)
            av.setFixedSize(34, 34)
            av.setAlignment(Qt.AlignCenter)
            av.setStyleSheet(
                f"background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 {T.GRAD_A}, stop:1 {T.GRAD_C});"
                " color: white; font-weight: bold; font-size: 12pt; border-radius: 17px;")
            cl.addWidget(av)
            cl.addWidget(self._label(user_name, f"color: {T.TEXT}; font-size: 10.5pt; font-weight: 600;"))
            header_row.addWidget(chip, alignment=Qt.AlignTop)
        layout.addLayout(header_row)

        # ---------- الجسم: قائمة الملفات + لوحة التفاصيل ----------
        body = QHBoxLayout()
        body.setSpacing(20)
        body.setDirection(QBoxLayout.RightToLeft if rtl else QBoxLayout.LeftToRight)

        # --- بطاقة القائمة ---
        card = QFrame()
        card.setObjectName("dossierCard")
        card.setStyleSheet(
            f"QFrame#dossierCard {{ background: {T.SURFACE}; border: 1px solid {T.BORDER};"
            " border-radius: 22px; }")
        cl = QVBoxLayout(card)
        cl.setContentsMargins(20, 18, 20, 18)
        cl.setSpacing(12)

        top = QHBoxLayout()
        top.setSpacing(10)
        self.search_input = QLineEdit()
        self.search_input.setProperty(_SKIP, True)
        self.search_input.setPlaceholderText(self.s("search"))
        self.search_input.setClearButtonEnabled(True)
        self.search_input.setMinimumHeight(42)
        self.search_input.addAction(qta.icon("fa5s.search", color=T.TEXT_MUTED), QLineEdit.LeadingPosition)
        self.search_input.setStyleSheet(
            f"QLineEdit {{ background: {T.SURFACE_ALT}; border: 2px solid {T.BORDER}; border-radius: 14px;"
            " padding: 6px 12px; font-size: 11pt; }"
            f"QLineEdit:focus {{ border: 2px solid {T.ACCENT}; background: white; }}")
        self.search_input.textChanged.connect(self._apply_filter)
        top.addWidget(self.search_input, 1)
        self.count_badge = QLabel("0")
        self.count_badge.setProperty(_SKIP, True)
        self.count_badge.setStyleSheet(
            f"background: {T.INFO_BG}; color: {T.INFO_FG}; border-radius: 14px; padding: 6px 16px;"
            " font-weight: 600; font-size: 10pt;")
        top.addWidget(self.count_badge)
        cl.addLayout(top)

        self.list_widget = QListWidget()
        self.list_widget.setFrameShape(QFrame.NoFrame)
        self.list_widget.setMouseTracking(True)
        self.list_widget.setItemDelegate(_DossierDelegate(self.s("kind"), self.list_widget))
        self.list_widget.setStyleSheet(
            "QListWidget { background: transparent; border: none; outline: 0; }"
            "QListWidget::item { background: transparent; border: none; }"
            "QListWidget::item:selected, QListWidget::item:hover { background: transparent; }")
        self.list_widget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.list_widget.itemDoubleClicked.connect(self.open_dossier)
        self.list_widget.currentItemChanged.connect(lambda *_: self._refresh_side())

        self.empty_state = EmptyState(tr("dossier_none_yet"), "", "fa5s.folder-plus")
        self.empty_state.setProperty(_SKIP, True)
        if self.is_admin:
            add_empty = QPushButton(tr("dossier_save_add"))
            add_empty.setIcon(qta.icon("fa5s.plus", color="white"))
            style_hero_button(add_empty, radius=12, padding="9px 24px")
            add_empty.clicked.connect(self.add_dossier)
            self.empty_state.set_action(add_empty)

        self.stack = QStackedWidget()
        self.stack.addWidget(self.list_widget)
        self.stack.addWidget(self.empty_state)
        cl.addWidget(self.stack, 1)
        body.addWidget(card, 1)

        # --- لوحة الملف المحدد ---
        side = QFrame()
        side.setObjectName("sidePanel")
        side.setFixedWidth(310)
        side.setStyleSheet(
            f"QFrame#sidePanel {{ background: {T.SURFACE}; border: 1px solid {T.BORDER}; border-radius: 22px; }}")
        sl = QVBoxLayout(side)
        sl.setContentsMargins(14, 14, 14, 14)
        sl.setSpacing(10)

        banner = GradientBanner(radius=16, margins=(18, 18, 18, 18), spacing=4)
        banner.setMinimumHeight(150)
        cap = self._label(self.s("selected"), f"color: {T.TEXT_ON_DARK_MUTED}; font-size: 9.5pt; font-weight: 600;")
        banner.body.addWidget(cap)
        banner.body.addStretch(1)
        self.sel_icon = QLabel()
        self.sel_icon.setStyleSheet("background: transparent;")
        self.sel_icon.setPixmap(qta.icon("fa5s.folder-open", color="white").pixmap(30, 30))
        banner.body.addWidget(self.sel_icon, 0, Qt.AlignLeading)
        self.sel_name = self._label(self.s("none_sel"), "color: white; font-size: 14pt; font-weight: 700;")
        self.sel_name.setWordWrap(True)
        banner.body.addWidget(self.sel_name)
        sl.addWidget(banner)

        self.sel_hint = self._label(self.s("pick_hint"), f"color: {T.TEXT_MUTED}; font-size: 9.5pt;")
        self.sel_hint.setWordWrap(True)
        self.sel_hint.setContentsMargins(4, 2, 4, 2)
        sl.addWidget(self.sel_hint)

        self.open_btn = QPushButton(tr("dossier_open"))
        self.open_btn.setIcon(qta.icon("fa5s.folder-open", color="white"))
        self.open_btn.setIconSize(QSize(18, 18))
        self.open_btn.setMinimumHeight(52)
        style_hero_button(self.open_btn, radius=14, padding="12px 22px")
        self.open_btn.clicked.connect(self.open_dossier)
        sl.addWidget(self.open_btn)

        if self.is_admin:
            for text_key, icon, kind, handler in (
                ("dossier_save_add", "fa5s.plus", "info", self.add_dossier),
                ("dossier_save_edit", "fa5s.pen", "info", self.edit_dossier),
                ("dossier_delete_button", "fa5s.trash-alt", "danger", self.delete_dossier),
            ):
                b = QPushButton(tr(text_key))
                b.setIcon(qta.icon(icon, color=T.ACCENT if kind == "info" else T.DANGER))
                b.setMinimumHeight(42)
                style_soft_button(b, kind, radius=12, padding="9px 16px")
                b.clicked.connect(handler)
                sl.addWidget(b)

        sl.addStretch(1)
        close_btn = QPushButton(tr("dossier_close"))
        close_btn.setFlat(True)
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.setStyleSheet(
            f"QPushButton {{ border: none; background: transparent; color: {T.TEXT_MUTED}; padding: 6px; }}"
            f"QPushButton:hover {{ color: {T.DANGER}; text-decoration: underline; }}")
        close_btn.clicked.connect(self.close)
        sl.addWidget(close_btn, 0, Qt.AlignHCenter)
        body.addWidget(side)

        layout.addLayout(body, 1)

    # ------------------------------------------------------------------
    def _refresh_side(self):
        sel = self._selected_dossier()
        if sel:
            self.sel_name.setText(sel[1])
            self.sel_hint.setText(self.s("kind"))
            self.open_btn.setEnabled(True)
        else:
            self.sel_name.setText(self.s("none_sel"))
            self.sel_hint.setText(self.s("pick_hint"))
            self.open_btn.setEnabled(False)

    def _apply_filter(self, _text=""):
        self._fill_list(self.search_input.text().strip().lower())

    def _fill_list(self, query=""):
        keep = None
        sel = self._selected_dossier()
        if sel:
            keep = sel[0]
        self.list_widget.blockSignals(True)
        self.list_widget.clear()
        shown = 0
        for d in self._all:
            if query and query not in str(d["name"]).lower():
                continue
            item = QListWidgetItem(f"{d['name']}")
            item.setData(Qt.UserRole, d["folder"])
            item.setData(Qt.UserRole + 1, d["name"])
            self.list_widget.addItem(item)
            if keep is not None and d["folder"] == keep:
                self.list_widget.setCurrentItem(item)
            shown += 1
        if shown and self.list_widget.currentItem() is None:
            self.list_widget.setCurrentRow(0)
        self.list_widget.blockSignals(False)
        self.count_badge.setText(self.s("count", n=len(self._all)))
        self.stack.setCurrentWidget(self.list_widget if shown else self.empty_state)
        self._refresh_side()

    # ------------------------------------------------------------------
    def load_dossiers(self):
        self._all = list(storage.load_dossiers() or [])
        self._fill_list(self.search_input.text().strip().lower() if hasattr(self, "search_input") else "")

    def _selected_dossier(self):
        item = self.list_widget.currentItem()
        if not item or not item.data(Qt.UserRole):
            return None
        return item.data(Qt.UserRole), item.data(Qt.UserRole + 1)

    def add_dossier(self):
        dialog = AddEditDossierDialog(self)
        if dialog.exec_() == QDialog.Accepted:
            name = dialog.get_name()
            if not name:
                show_warning(self, tr("login_error_title"), tr("dossier_empty_name_warning"))
                return
            storage.add_dossier(name)
            self.load_dossiers()

    def edit_dossier(self):
        selected = self._selected_dossier()
        if not selected:
            show_warning(self, tr("forgot_warning_title"), tr("dossier_select_edit_warning"))
            return
        folder, name = selected
        dialog = AddEditDossierDialog(self, name)
        if dialog.exec_() == QDialog.Accepted:
            new_name = dialog.get_name()
            if not new_name:
                return
            storage.update_dossier(folder, new_name)
            self.load_dossiers()

    def delete_dossier(self):
        selected = self._selected_dossier()
        if not selected:
            show_warning(self, tr("forgot_warning_title"), tr("dossier_select_delete_warning"))
            return
        folder, name = selected
        if show_confirm(
            self, tr("dossier_delete_confirm_title"),
            tr("dossier_delete_confirm_message").format(name=name), danger=True
        ):
            storage.delete_dossier(folder)
            self.load_dossiers()

    def open_dossier(self):
        selected = self._selected_dossier()
        if not selected:
            show_warning(self, tr("forgot_warning_title"), tr("dossier_select_open_warning"))
            return
        folder, name = selected

        storage.set_current_dossier(folder, name)

        # الانتقال إلى الصفحة الرئيسية الخاصة بالملف (خارج التبويبات)
        # حيث يتم اختيار/إضافة سنة العمل والمحكمة الافتراضية قبل الدخول لصفحة العمل
        from dossier_home_page import DossierHomePage
        self.home_page = DossierHomePage(current_user=self.current_user)
        self.home_page.showMaximized()
        # نغلق شاشة اختيار الملف حتى لا تبقى مفتوحة خلف الصفحة الرئيسية
        self.close()
        self.close()