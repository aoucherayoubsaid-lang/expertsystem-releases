from jinja2 import Environment, FileSystemLoader
import datetime

import storage
import report_output as ro


def generate_fees_report(data):
    """
    توليد كشف الأتعاب بصيغة PDF (بالإضافة إلى نسخة Excel في excel_reports.py).
    data: expert_name, expert_address, expert_phone, court, case, plaintiff,
          defendant, index_number, session_date, study, vat, transport, admin,
          stamp, reg, total
    """
    env = ro.make_env()
    template = env.get_template("fees_report.html")

    data = dict(data)  # نسخة لتجنب التعديل على القاموس الأصلي
    data.setdefault("font_size", 15)
    data.setdefault("font_family", storage.get_font_family())
    data.setdefault("today", datetime.date.today().strftime("%d/%m/%Y"))

    import doc_signing
    data.update(doc_signing.issue_fields("كشف الأتعاب", data.get("case"), data.get("today")))
    html = template.render(data)
    html_file = ro.write_html("fees_report_result.html", html)

    case_part = ro.safe_name(data.get("case"))
    pdf_file = ro.html_to_pdf(html_file, "fees", f"fees_report_{case_part}.pdf")
    return html_file, pdf_file
