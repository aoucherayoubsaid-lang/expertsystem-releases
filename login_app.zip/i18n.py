# i18n.py
"""
الترجمة المركزية للتطبيق بأكمله.

المبدأ: كل نص يظهر للمستخدم يُكتب كمفتاح إنجليزي بسيط (key)، ويُترجَم عبر
tr(key) إلى اللغة الحالية المحفوظة في الإعدادات. هذا يضمن أنه عند تغيير
اللغة، لا تبقى ولا كلمة من اللغة القديمة، لأن كل نص يُعاد بناؤه من هذا
القاموس وليس مكتوباً حرفياً داخل الصفحات.

لماذا "إعادة تشغيل" عند تغيير اللغة (وليس تحديثاً حيّاً لكل شيء)؟
لأن مئات النصوص منتشرة عبر عشرات الملفات؛ إعادة بناء كل صفحة من الصفر
(بإعادة تشغيل التطبيق) تضمن أن كل نص يُقرأ بالمفتاح الصحيح دفعة واحدة،
بدل الحاجة لكتابة دالة "retranslate" منفصلة لكل صفحة يدوياً (عمل ضخم
ومعرّض للنسيان). هذا هو الأسلوب المعتمد في أغلب برامج سطح المكتب عند
تغيير اللغة.
"""

import os
import sys
import storage

LANGUAGE_CODE_BY_LABEL = {"العربية": "ar", "Français": "fr", "English": "en"}
LANGUAGE_LABELS = ["العربية", "Français", "English"]


def current_language_code() -> str:
    settings = storage.load_settings()
    label = settings.get("language", "العربية")
    return LANGUAGE_CODE_BY_LABEL.get(label, "ar")


def is_rtl(lang_code: str = None) -> bool:
    return (lang_code or current_language_code()) == "ar"


def restart_app():
    """يعيد تشغيل التطبيق بالكامل من نقطة الدخول (تسجيل الدخول)، حتى تُبنى
    كل الصفحات من جديد باللغة والاتجاه الجديدين."""
    python = sys.executable
    os.execl(python, python, *sys.argv)


# ---------------------------------------------------------------------------
# قاموس الترجمة. أضف المفتاح هنا في اللغات الثلاث معاً عند إضافة نص جديد
# في أي صفحة، بدل كتابته حرفياً بالعربية داخل الصفحة.
# ---------------------------------------------------------------------------
TR = {
    # ===== تسجيل الدخول =====
    "login_window_title": {"ar": "تسجيل الدخول - الخبير القضائي", "fr": "Connexion - Expert Judiciaire", "en": "Login - Judicial Expert"},
    "login_app_title": {"ar": "نظام الخبير القضائي", "fr": "Système de l'Expert Judiciaire", "en": "Judicial Expert System"},
    "login_subtitle": {"ar": "سجّل الدخول للمتابعة إلى حسابك", "fr": "Connectez-vous pour continuer", "en": "Sign in to continue to your account"},
    "login_show_password": {"ar": "إظهار / إخفاء كلمة المرور", "fr": "Afficher / masquer le mot de passe", "en": "Show / hide password"},
    "login_username_placeholder": {"ar": "اختر الحساب أو اكتب اسم المستخدم", "fr": "Choisir un compte ou saisir un nom", "en": "Choose an account or type username"},
    "login_password_placeholder": {"ar": "كلمة المرور", "fr": "Mot de passe", "en": "Password"},
    "login_remember_me": {"ar": "تذكرني", "fr": "Se souvenir de moi", "en": "Remember me"},
    "login_forgot_password": {"ar": "نسيت كلمة المرور؟", "fr": "Mot de passe oublié ?", "en": "Forgot password?"},
    "login_button": {"ar": "دخول", "fr": "Connexion", "en": "Log in"},
    "login_error_title": {"ar": "خطأ", "fr": "Erreur", "en": "Error"},
    "login_error_message": {"ar": "اسم المستخدم أو كلمة المرور خاطئة", "fr": "Nom d'utilisateur ou mot de passe incorrect", "en": "Incorrect username or password"},
    "login_disabled_title": {"ar": "الحساب معطّل", "fr": "Compte désactivé", "en": "Account disabled"},
    "login_disabled_message": {
        "ar": "هذا الحساب معطّل حالياً ولا يمكن استعماله لتسجيل الدخول.\nتواصل مع مدير التطبيق (admin) لإعادة تفعيله.",
        "fr": "Ce compte est actuellement désactivé.\nContactez l'administrateur pour le réactiver.",
        "en": "This account is currently disabled.\nContact the administrator to reactivate it.",
    },

    # ===== نافذة إجبار تغيير كلمة المرور (تظهر مرة واحدة عند أول دخول بحساب افتراضي) =====
    "force_change_title": {"ar": "يجب تغيير كلمة المرور", "fr": "Changement de mot de passe requis", "en": "Password change required"},
    "force_change_message": {
        "ar": "هذا حساب بكلمة مرور افتراضية. لأسباب أمنية، يجب تعيين كلمة مرور جديدة وخاصة بك قبل المتابعة.",
        "fr": "Ce compte utilise un mot de passe par défaut. Pour des raisons de sécurité, définissez un nouveau mot de passe avant de continuer.",
        "en": "This account is using a default password. For security reasons, you must set your own new password before continuing.",
    },
    "force_change_new_password_label": {"ar": "كلمة المرور الجديدة", "fr": "Nouveau mot de passe", "en": "New password"},
    "force_change_confirm_password_label": {"ar": "تأكيد كلمة المرور", "fr": "Confirmer le mot de passe", "en": "Confirm password"},
    "force_change_button": {"ar": "تعيين وتأكيد", "fr": "Définir et confirmer", "en": "Set and continue"},
    "force_change_mismatch": {"ar": "كلمتا المرور غير متطابقتين", "fr": "Les mots de passe ne correspondent pas", "en": "Passwords do not match"},
    "force_change_too_short": {"ar": "كلمة المرور ضعيفة (12 حرفاً على الأقل مع أصناف متنوعة)", "fr": "Mot de passe trop faible (12 caractères minimum, variés)", "en": "Password too weak (minimum 12 characters, mixed types)"},
    "force_change_success": {"ar": "تم تعيين كلمة المرور الجديدة بنجاح", "fr": "Nouveau mot de passe défini avec succès", "en": "New password set successfully"},

    # ===== نافذة استرجاع كلمة المرور =====
    "forgot_dialog_title": {"ar": "استرجاع كلمة المرور", "fr": "Récupération du mot de passe", "en": "Password recovery"},
    "forgot_username_label": {"ar": "اسم المستخدم:", "fr": "Nom d'utilisateur :", "en": "Username:"},
    "forgot_show_question": {"ar": "عرض سؤال الأمان", "fr": "Afficher la question de sécurité", "en": "Show security question"},
    "forgot_answer_label": {"ar": "الإجابة:", "fr": "Réponse :", "en": "Answer:"},
    "forgot_new_password_label": {"ar": "كلمة المرور الجديدة:", "fr": "Nouveau mot de passe :", "en": "New password:"},
    "forgot_confirm_password_label": {"ar": "تأكيد كلمة المرور:", "fr": "Confirmer le mot de passe :", "en": "Confirm password:"},
    "forgot_reset_button": {"ar": "استرجاع كلمة المرور", "fr": "Réinitialiser le mot de passe", "en": "Reset password"},
    "forgot_question_prefix": {"ar": "سؤال الأمان:", "fr": "Question de sécurité :", "en": "Security question:"},
    "forgot_warning_title": {"ar": "تنبيه", "fr": "Attention", "en": "Warning"},
    "forgot_enter_username_first": {"ar": "أدخل اسم المستخدم أولاً.", "fr": "Entrez d'abord le nom d'utilisateur.", "en": "Enter the username first."},
    "forgot_not_found_title": {"ar": "غير موجود", "fr": "Introuvable", "en": "Not found"},
    "forgot_not_found_message": {"ar": "لا يوجد حساب بهذا الاسم.", "fr": "Aucun compte avec ce nom.", "en": "No account with this name."},
    "forgot_no_question_title": {"ar": "لا يوجد سؤال أمان", "fr": "Aucune question de sécurité", "en": "No security question"},
    "forgot_no_question_message": {
        "ar": "لم يُحدَّد سؤال أمان لهذا الحساب.\nتواصل مع مدير التطبيق (admin) لتغيير كلمة المرور يدوياً.",
        "fr": "Aucune question de sécurité définie pour ce compte.\nContactez l'administrateur pour changer le mot de passe manuellement.",
        "en": "No security question set for this account.\nContact the administrator to change the password manually.",
    },
    "forgot_fill_all_fields": {"ar": "الرجاء تعبئة كل الحقول.", "fr": "Veuillez remplir tous les champs.", "en": "Please fill in all fields."},
    "forgot_passwords_mismatch": {"ar": "كلمة المرور الجديدة وتأكيدها غير متطابقين.", "fr": "Les mots de passe ne correspondent pas.", "en": "Passwords do not match."},
    "forgot_password_too_short": {"ar": "كلمة المرور ضعيفة (12 حرفاً على الأقل مع أصناف متنوعة).", "fr": "Mot de passe trop faible (12 caractères minimum, variés).", "en": "Password too weak (minimum 12 characters, mixed types)."},
    "forgot_success_title": {"ar": "تم", "fr": "Terminé", "en": "Done"},
    "forgot_success_message": {
        "ar": "تم تغيير كلمة المرور بنجاح. يمكنك الآن الدخول بكلمة المرور الجديدة.",
        "fr": "Mot de passe modifié avec succès. Vous pouvez maintenant vous connecter.",
        "en": "Password changed successfully. You can now log in.",
    },
    "forgot_wrong_answer": {
        "ar": "تعذّر الاسترجاع: البيانات غير صحيحة أو الحساب غير مهيّأ للاسترجاع.\nإن تكرر ذلك فتواصل مع مدير التطبيق.",
        "fr": "Récupération impossible : informations incorrectes ou compte non configuré.\nContactez l'administrateur si cela persiste.",
        "en": "Recovery failed: incorrect details or the account is not set up for recovery.\nContact the administrator if this persists.",
    },
    "login_locked_message": {
        "ar": "أُوقفت المحاولات مؤقتاً بسبب كثرة المحاولات الفاشلة. حاول بعد {m} دقيقة تقريباً.",
        "fr": "Tentatives suspendues temporairement (trop d'échecs). Réessayez dans environ {m} minute(s).",
        "en": "Attempts are temporarily suspended after too many failures. Try again in about {m} minute(s).",
    },
    "tamper_blocked_message": {
        "ar": "اكتُشف تعديل غير مصرّح به على ملفات الأمان المحلية، فتوقّف الدخول حمايةً للبيانات.\nاسترجع نسخة احتياطية سليمة، أو إن كنت المالك وواثقاً من الملفات (مثلاً بعد نقل البرنامج لجهاز جديد) فشغّل البرنامج بالخيار --reseal-integrity.",
        "fr": "Une modification non autorisée des fichiers de sécurité locaux a été détectée ; l'accès est bloqué.\nRestaurez une sauvegarde saine, ou, si vous êtes le propriétaire et sûr des fichiers, lancez le programme avec --reseal-integrity.",
        "en": "Unauthorized modification of local security files was detected; sign-in is blocked.\nRestore a clean backup, or if you own the data and trust the files (e.g. after moving to a new PC) start the program with --reseal-integrity.",
    },
    "recovery_setup_message": {
        "ar": "لا يوجد لحسابك سؤال أمان خاص بك. لأسباب أمنية اضبط الآن سؤالاً وإجابة لا يعرفها غيرك قبل المتابعة.",
        "fr": "Votre compte n'a pas de question de sécurité personnelle. Définissez-en une maintenant avant de continuer.",
        "en": "Your account has no personal security question. Set a question and an answer only you know before continuing.",
    },
    "recovery_question_label": {"ar": "سؤال الأمان", "fr": "Question de sécurité", "en": "Security question"},
    "recovery_question_placeholder": {"ar": "سؤال تعرف إجابته وحدك", "fr": "Une question dont vous seul connaissez la réponse", "en": "A question only you can answer"},
    "recovery_answer_label": {"ar": "الإجابة", "fr": "Réponse", "en": "Answer"},
    "recovery_answer_hint": {
        "ar": "اختر إجابة لا يمكن تخمينها ولا العثور عليها في معلومات عامة عنك (6 أحرف على الأقل). تُحفظ مجزّأة ولا يمكن استرجاعها.",
        "fr": "Choisissez une réponse impossible à deviner (6 caractères minimum). Elle est stockée hachée.",
        "en": "Choose an answer nobody can guess (minimum 6 characters). It is stored hashed.",
    },
    "recovery_question_too_short": {"ar": "اكتب سؤال أمان واضحاً (8 أحرف على الأقل).", "fr": "Saisissez une question claire (8 caractères minimum).", "en": "Enter a clear question (minimum 8 characters)."},


    # ===== اختيار الملف (Dossier) =====
    "dossier_window_title": {"ar": "اختيار الملف - نظام الخبير القضائي", "fr": "Choix du dossier - Système Expert Judiciaire", "en": "Choose Dossier - Judicial Expert System"},
    "dossier_page_title": {"ar": "اختيار الملف للعمل عليه", "fr": "Choisissez le dossier à ouvrir", "en": "Choose the dossier to open"},
    "dossier_welcome": {"ar": "مرحبًا،", "fr": "Bienvenue,", "en": "Welcome,"},
    "dossier_add_button": {"ar": "+ إضافة ملف جديد", "fr": "+ Ajouter un dossier", "en": "+ Add new dossier"},
    "dossier_edit_button": {"ar": "تعديل", "fr": "Modifier", "en": "Edit"},
    "dossier_delete_button": {"ar": "حذف", "fr": "Supprimer", "en": "Delete"},
    "dossier_open_button": {"ar": "فتح", "fr": "Ouvrir", "en": "Open"},
    "dossier_logout_button": {"ar": "تسجيل الخروج", "fr": "Déconnexion", "en": "Log out"},

    # ===== الصفحة الرئيسية للملف =====
    "home_office_title": {"ar": "مكتب المحاسبة و الخبرة القضائية", "fr": "Cabinet de comptabilité et d'expertise judiciaire", "en": "Accounting & Judicial Expertise Office"},
    "home_name_label": {"ar": "الاسم و اللقب :", "fr": "Nom et prénom :", "en": "Full name:"},
    "home_job_label": {"ar": "الصفة :", "fr": "Fonction :", "en": "Title:"},
    "home_address_label": {"ar": "العنوان :", "fr": "Adresse :", "en": "Address:"},
    "home_phone_label": {"ar": "الهاتف :", "fr": "Téléphone :", "en": "Phone:"},
    "home_fax_label": {"ar": "الفاكس :", "fr": "Fax :", "en": "Fax:"},
    "home_email_label": {"ar": "البريد الإلكتروني :", "fr": "E-mail :", "en": "Email:"},
    "home_edit_info_button": {"ar": "تعديل المعلومات", "fr": "Modifier les informations", "en": "Edit information"},
    "home_switch_dossier": {"ar": "تبديل الملف", "fr": "Changer de dossier", "en": "Switch dossier"},
    "home_years_title": {"ar": "سنوات العمل", "fr": "Années de travail", "en": "Working years"},
    "home_year_placeholder": {"ar": "السنة", "fr": "Année", "en": "Year"},
    "home_add_year": {"ar": "إضافة سنة", "fr": "Ajouter une année", "en": "Add year"},
    "home_close_year": {"ar": "إقفال السنة المختارة", "fr": "Clôturer l'année sélectionnée", "en": "Close selected year"},
    "home_reopen_year": {"ar": "إعادة فتح السنة المختارة", "fr": "Rouvrir l'année sélectionnée", "en": "Reopen selected year"},
    "home_default_court_label": {"ar": "المحكمة الافتراضية لهذه السنة :", "fr": "Tribunal par défaut pour cette année :", "en": "Default court for this year:"},
    "home_save_court": {"ar": "حفظ المحكمة", "fr": "Enregistrer le tribunal", "en": "Save court"},
    "home_stats_title": {"ar": "إحصائيات القضايا", "fr": "Statistiques des affaires", "en": "Case statistics"},
    "home_stats_filter_label": {"ar": "عرض إحصائيات المحكمة :", "fr": "Afficher les statistiques du tribunal :", "en": "Show statistics for court:"},
    "home_all_courts": {"ar": "جميع المحاكم", "fr": "Tous les tribunaux", "en": "All courts"},
    "home_card_cases": {"ar": "عدد القضايا في هذه السنة", "fr": "Nombre d'affaires cette année", "en": "Cases this year"},
    "home_card_near": {"ar": "قريبة الإيداع (30 يوم أو أقل)", "fr": "Dépôt proche (30 jours ou moins)", "en": "Deadline soon (30 days or less)"},
    "home_card_near_dynamic": {"ar": "قريبة الإيداع ({n} يوم أو أقل)", "fr": "Dépôt proche ({n} jour(s) ou moins)", "en": "Deadline soon ({n} day(s) or less)"},
    "home_card_late": {"ar": "متأخرة عن الإيداع", "fr": "En retard de dépôt", "en": "Overdue"},
    "home_card_done": {"ar": "أُودع تقريرها فعلاً", "fr": "Rapport déjà déposé", "en": "Report already filed"},
    "home_card_hint": {"ar": "انقر لعرض التفاصيل", "fr": "Cliquez pour voir les détails", "en": "Click for details"},
    "home_enter_workspace": {"ar": "الدخول إلى صفحة العمل", "fr": "Accéder à l'espace de travail", "en": "Enter workspace"},
    "home_window_title": {"ar": "الصفحة الرئيسية — الملف: {name}", "fr": "Page d'accueil — Dossier : {name}", "en": "Home Page — Dossier: {name}"},
    "home_unnamed_dossier": {"ar": "بدون اسم", "fr": "Sans nom", "en": "Unnamed"},
    "home_default_job": {"ar": "خبير قضائي لدى المجالس و المحاكم", "fr": "Expert judiciaire près les cours et tribunaux", "en": "Judicial expert before courts and tribunals"},
    "home_edit_expert_title": {"ar": "تعديل معلومات الخبير", "fr": "Modifier les informations de l'expert", "en": "Edit expert information"},
    "home_warning_title": {"ar": "تنبيه", "fr": "Attention", "en": "Warning"},
    "home_done_title": {"ar": "تم", "fr": "Terminé", "en": "Done"},
    "home_enter_year_warning": {"ar": "الرجاء إدخال السنة.", "fr": "Veuillez saisir l'année.", "en": "Please enter the year."},
    "home_select_year_warning": {"ar": "الرجاء اختيار سنة أولاً.", "fr": "Veuillez d'abord sélectionner une année.", "en": "Please select a year first."},
    "home_close_year_confirm_title": {"ar": "تأكيد الإقفال", "fr": "Confirmer la clôture", "en": "Confirm closing"},
    "home_close_year_confirm_message": {
        "ar": "هل أنت متأكد من إقفال سنة {year}؟\nستبقى بياناتها محفوظة، لكن يُفضّل عدم إضافة قضايا جديدة إليها بعد الإقفال.",
        "fr": "Voulez-vous vraiment clôturer l'année {year} ?\nSes données resteront conservées, mais il est préférable de ne plus y ajouter de nouvelles affaires après la clôture.",
        "en": "Are you sure you want to close year {year}?\nIts data will remain saved, but it's best not to add new cases to it after closing.",
    },
    "home_select_work_year_warning": {"ar": "الرجاء اختيار سنة العمل أولاً.", "fr": "Veuillez d'abord sélectionner l'année de travail.", "en": "Please select the working year first."},
    "home_default_court_set_message": {"ar": "تم ضبط المحكمة الافتراضية: {court}", "fr": "Le tribunal par défaut a été défini : {court}", "en": "Default court has been set: {court}"},
    "home_select_or_add_year_warning": {
        "ar": "الرجاء اختيار أو إضافة سنة عمل أولاً من القائمة أعلاه.",
        "fr": "Veuillez sélectionner ou ajouter une année de travail depuis la liste ci-dessus.",
        "en": "Please select or add a working year from the list above first.",
    },
    "home_year_open_status": {"ar": "مفتوحة", "fr": "Ouverte", "en": "Open"},
    "home_year_closed_status": {"ar": "مُقفلة", "fr": "Clôturée", "en": "Closed"},
    "home_col_case_number": {"ar": "رقم القضية", "fr": "N° d'affaire", "en": "Case No."},
    "home_col_index_number": {"ar": "رقم الفهرس", "fr": "N° de répertoire", "en": "Index No."},
    "home_col_court": {"ar": "المحكمة", "fr": "Tribunal", "en": "Court"},
    "home_col_section": {"ar": "القسم", "fr": "Section", "en": "Section"},
    "home_col_plaintiff": {"ar": "المدعي", "fr": "Demandeur", "en": "Plaintiff"},
    "home_col_defendant": {"ar": "المدعى عليه", "fr": "Défendeur", "en": "Defendant"},
    "home_col_receive_date": {"ar": "تاريخ الاستلام", "fr": "Date de réception", "en": "Receive date"},
    "home_col_duration_months": {"ar": "المدة (أشهر)", "fr": "Durée (mois)", "en": "Duration (months)"},
    "home_col_deposit_date": {"ar": "تاريخ الإيداع", "fr": "Date de dépôt", "en": "Deposit date"},
    "home_col_status": {"ar": "الحالة", "fr": "Statut", "en": "Status"},
    "home_no_matching_cases": {"ar": "لا توجد قضايا مطابقة لهذا التصنيف.", "fr": "Aucune affaire ne correspond à cette catégorie.", "en": "No cases match this category."},
    "home_close_button": {"ar": "إغلاق", "fr": "Fermer", "en": "Close"},
    "home_status_deposited": {"ar": "أُودعت — وصل رقم {n}", "fr": "Déposé — reçu n° {n}", "en": "Filed — receipt No. {n}"},
    "home_status_undetermined": {"ar": "غير محدد", "fr": "Indéterminé", "en": "Undetermined"},
    "home_status_overdue": {"ar": "متأخرة بـ {n} يوم", "fr": "En retard de {n} jour(s)", "en": "Overdue by {n} day(s)"},
    "home_status_remaining": {"ar": "باقي {n} يوم", "fr": "Reste {n} jour(s)", "en": "{n} day(s) left"},
    "home_cases_count_suffix": {"ar": "({n} قضية)", "fr": "({n} affaire(s))", "en": "({n} case(s))"},
    "home_dialog_late_title": {"ar": "القضايا المتأخرة عن الإيداع — {court} — سنة {year}", "fr": "Affaires en retard de dépôt — {court} — année {year}", "en": "Overdue cases — {court} — year {year}"},
    "home_dialog_near_title": {"ar": "القضايا القريبة من الإيداع — {court} — سنة {year}", "fr": "Affaires proches du dépôt — {court} — année {year}", "en": "Cases nearing deadline — {court} — year {year}"},
    "home_dialog_done_title": {"ar": "القضايا المُودَع تقريرها فعلاً — {court} — سنة {year}", "fr": "Affaires déjà déposées — {court} — année {year}", "en": "Cases already filed — {court} — year {year}"},
    "home_dialog_all_title": {"ar": "جميع قضايا السنة — {court} — سنة {year}", "fr": "Toutes les affaires de l'année — {court} — année {year}", "en": "All cases this year — {court} — year {year}"},

    # ===== اختيار الملف: نموذج الإضافة/التعديل =====
    "dossier_save_generic": {"ar": "حفظ", "fr": "Enregistrer", "en": "Save"},
    "dossier_form_title": {"ar": "إضافة / تعديل ملف (Dossier)", "fr": "Ajouter / modifier un dossier", "en": "Add / edit dossier"},
    "dossier_name_placeholder": {"ar": "اسم الجهة القضائية (محكمة / مجلس قضائي / محكمة إدارية...):", "fr": "Nom de la juridiction (tribunal / cour...) :", "en": "Court name (tribunal / court of appeal...):"},
    "dossier_name_example": {"ar": "مثال: المجلس القضائي ببومرداس", "fr": "Exemple : Cour de Boumerdès", "en": "Example: Boumerdès Court of Appeal"},
    "dossier_save_add": {"ar": "إضافة (Nouveau)", "fr": "Ajouter (Nouveau)", "en": "Add (New)"},
    "dossier_save_edit": {"ar": "تعديل (Mise à jour)", "fr": "Modifier (Mise à jour)", "en": "Edit (Update)"},
    "dossier_close": {"ar": "إغلاق (Fermer)", "fr": "Fermer", "en": "Close"},
    "dossier_open": {"ar": "فتح (Ouvrir)", "fr": "Ouvrir", "en": "Open"},
    "dossier_empty_name_warning": {"ar": "الرجاء إدخال اسم الملف.", "fr": "Veuillez saisir le nom du dossier.", "en": "Please enter the dossier name."},
    "dossier_system_admin": {"ar": "مسؤول النظام", "fr": "Administrateur système", "en": "System administrator"},
    "dossier_files_title": {"ar": "الملفات القضائية", "fr": "Dossiers judiciaires", "en": "Judicial dossiers"},
    "dossier_column_name": {"ar": "الملف", "fr": "Dossier", "en": "Dossier"},
    "dossier_none_yet": {"ar": "لا توجد ملفات بعد. استخدم زر (إضافة) لإنشاء أول ملف.", "fr": "Aucun dossier pour l'instant. Utilisez le bouton (Ajouter).", "en": "No dossiers yet. Use the (Add) button to create the first one."},
    "dossier_select_open_warning": {"ar": "الرجاء اختيار ملف أولاً ثم الضغط على فتح.", "fr": "Veuillez sélectionner un dossier puis cliquer sur Ouvrir.", "en": "Please select a dossier then click Open."},
    "dossier_select_edit_warning": {"ar": "الرجاء اختيار ملف لتعديله.", "fr": "Veuillez sélectionner un dossier à modifier.", "en": "Please select a dossier to edit."},
    "dossier_select_delete_warning": {"ar": "الرجاء اختيار ملف لحذفه.", "fr": "Veuillez sélectionner un dossier à supprimer.", "en": "Please select a dossier to delete."},
    "dossier_delete_confirm_title": {"ar": "تأكيد الحذف", "fr": "Confirmer la suppression", "en": "Confirm deletion"},
    "dossier_delete_confirm_message": {
        "ar": "هل أنت متأكد من حذف الملف: {name}؟\n(بيانات الملف تبقى محفوظة على القرص ولن تُحذف فعلياً)",
        "fr": "Voulez-vous vraiment supprimer le dossier : {name} ?\n(Les données restent sur le disque et ne seront pas réellement supprimées)",
        "en": "Are you sure you want to delete the dossier: {name}?\n(The data stays on disk and won't actually be deleted)",
    },
}


def tr(key: str, lang_code: str = None) -> str:
    """يُرجع ترجمة المفتاح للغة الحالية (أو المحدَّدة)، أو المفتاح نفسه
    إن لم توجد ترجمة (حتى لا يختفي أي نص بالخطأ لمجرد نسيان الترجمة)."""
    lang_code = lang_code or current_language_code()
    entry = TR.get(key)
    if not entry:
        return key
    return entry.get(lang_code, entry.get("ar", key))
