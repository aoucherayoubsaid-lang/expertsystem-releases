# -*- coding: utf-8 -*-
"""نافذتان: «أسعار الصرف» و«قاموس المصطلحات المعتمدة».

    from reference_data_page import FxRatesDialog, GlossaryDialog
"""
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (QDialog, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QPlainTextEdit,
                             QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout)

import fx_rates
import report_engine
from msgbox_ltr import show_info, show_warning


class FxRatesDialog(QDialog):
    """ملخص جدول الأسعار (لا يعرض عشرات الآلاف من الصفوف) + استيراد + إضافة يدوية + استعلام."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("أسعار الصرف")
        self.setLayoutDirection(Qt.RightToLeft)
        self.resize(680, 600)
        self.rates = fx_rates.load()
        lay = QVBoxLayout(self)
        note = QLabel("استورد أرشيف الأسعار الرسمي مرة واحدة، فيبحث البرنامج بعدها وحده عن سعر يوم كل واقعة.\n"
                      "السعر = كم دينار جزائري مقابل وحدة واحدة من العملة (أسعار «100 ين» تُقسَّم تلقائياً).\n"
                      "إن لم يوجد سعر ليوم الواقعة يؤخذ آخر سعر قبلها بحد أقصى %d أيام ويُذكر ذلك في التقرير، "
                      "وإن لم يوجد يفشل الحساب ولا يُخمَّن. النموذج لا يذكر أي سعر من عنده." % fx_rates.MAX_GAP_DAYS)
        note.setWordWrap(True)
        lay.addWidget(note)

        row = QHBoxLayout()
        row.addWidget(QLabel("مصدر الأسعار (يُذكر في التقرير) :"))
        self.source = QLineEdit(fx_rates.get_source(self.rates))
        self.source.setPlaceholderText("مثال: بنك الجزائر - الكوتاسيون اليومية")
        row.addWidget(self.source, 1)
        lay.addLayout(row)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["العملة", "من تاريخ", "إلى تاريخ", "عدد الأيام"])
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.horizontalHeader().setStretchLastSection(True)
        lay.addWidget(self.table, 1)

        self.warn = QLabel("")
        self.warn.setWordWrap(True)
        lay.addWidget(self.warn)

        q = QHBoxLayout()
        q.addWidget(QLabel("استعلام :"))
        self.q_cur, self.q_date = QLineEdit(), QLineEdit()
        self.q_cur.setPlaceholderText("EUR")
        self.q_date.setPlaceholderText("YYYY-MM-DD")
        b_q = QPushButton("ابحث عن السعر")
        b_q.clicked.connect(self._lookup)
        for w in (self.q_cur, self.q_date, b_q):
            q.addWidget(w)
        lay.addLayout(q)
        self.q_out = QLabel("")
        self.q_out.setWordWrap(True)
        lay.addWidget(self.q_out)

        m = QHBoxLayout()
        m.addWidget(QLabel("إضافة سعر يدوي :"))
        self.m_cur, self.m_date, self.m_rate = QLineEdit(), QLineEdit(), QLineEdit()
        self.m_cur.setPlaceholderText("EUR")
        self.m_date.setPlaceholderText("YYYY-MM-DD")
        self.m_rate.setPlaceholderText("السعر")
        b_m = QPushButton("إضافة")
        b_m.clicked.connect(self._add_manual)
        for w in (self.m_cur, self.m_date, self.m_rate, b_m):
            m.addWidget(w)
        lay.addLayout(m)

        btns = QHBoxLayout()
        for text, fn in (("استيراد ملف (Excel/CSV)...", self._import), ("حفظ المصدر", self._save), ("إغلاق", self.close)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            btns.addWidget(b)
        lay.addLayout(btns)
        self.status = QLabel("")
        self.status.setWordWrap(True)
        lay.addWidget(self.status)
        self._refresh()

    def _refresh(self):
        cov = fx_rates.coverage(self.rates)
        self.table.setRowCount(0)
        for cur, a, b, n in cov:
            r = self.table.rowCount()
            self.table.insertRow(r)
            for j, v in enumerate((cur, a, b, n)):
                self.table.setItem(r, j, QTableWidgetItem(str(v)))
        last = fx_rates.last_date(self.rates)
        if not last:
            self.warn.setText("الجدول فارغ. استورد ملف الأسعار أولاً.")
        else:
            from datetime import date, timedelta
            stale = date.fromisoformat(last) < date.today() - timedelta(days=fx_rates.MAX_GAP_DAYS)
            self.warn.setText("آخر تاريخ في الجدول: %s.%s" % (
                last, " الوقائع بعد هذا التاريخ لن تُحسب حتى تستورد بيانات أحدث." if stale else ""))

    def _persist(self):
        fx_rates.set_source(self.rates, self.source.text())
        fx_rates.save(self.rates)

    def _import(self):
        path, _ = QFileDialog.getOpenFileName(self, "ملف الأسعار", "", "جداول (*.xlsx *.csv *.txt)")
        if not path:
            return
        self.status.setText("جارٍ الاستيراد...")
        self.repaint()
        try:
            added, errors = fx_rates.import_table(path, self.rates)
        except Exception as e:
            self.status.setText("")
            show_warning(self, "أسعار الصرف", "تعذّرت قراءة الملف: %s" % e)
            return
        if added:
            self._persist()
        self._refresh()
        msg = "استُوردت %d قيمة وحُفظت." % added if added else "لم تُستورد أي قيمة."
        if errors:
            msg += "\nتجاهلت %d سطراً:\n" % len(errors) + "\n".join(errors[:8])
        self.status.setText(msg)
        (show_warning if (errors and not added) else show_info)(self, "أسعار الصرف", msg)

    def _add_manual(self):
        try:
            d = fx_rates.parse_date(self.m_date.text())
            fx_rates.set_rate(self.rates, self.m_cur.text(), d, fx_rates._num(self.m_rate.text()))
        except Exception as e:
            show_warning(self, "أسعار الصرف", "تعذّرت الإضافة: %s" % e)
            return
        self._persist()
        self._refresh()
        self.status.setText("أُضيف السعر وحُفظ.")

    def _lookup(self):
        try:
            d = fx_rates.parse_date(self.q_date.text())
            rate, used = fx_rates.get_rate(self.rates, self.q_cur.text(), d)
        except ValueError as e:
            self.q_out.setText(str(e))
            return
        extra = "" if used == d else " (آخر سعر متاح قبل التاريخ المطلوب)"
        self.q_out.setText("1 %s = %s دج بتاريخ %s%s" % (
            fx_rates.norm_currency(self.q_cur.text()), ("%.4f" % rate).rstrip("0").rstrip("."), used.isoformat(), extra))

    def _save(self):
        self._persist()
        self.status.setText("تم حفظ المصدر.")


class GlossaryDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("قاموس المصطلحات المعتمدة")
        self.setLayoutDirection(Qt.RightToLeft)
        self.resize(620, 520)
        lay = QVBoxLayout(self)
        note = QLabel("اكتب في كل سطر المصطلح الفرنسي ثم مقابله العربي المعتمد عندك، بهذا الشكل:\n"
                      "mise en demeure = الإعذار\n"
                      "عند إعداد المسودة يُلزَم النموذج بمقابلاتك، ويُنبَّه إن ورد مصطلح في المصادر ولم يظهر مقابله في المسودة.\n"
                      "لا أضع لك مصطلحات جاهزة: المقابل الصحيح يقرره الخبير.")
        note.setWordWrap(True)
        lay.addWidget(note)
        self.edit = QPlainTextEdit()
        self.edit.setLayoutDirection(Qt.LeftToRight)
        self.edit.setPlainText("\n".join("%s = %s" % (p["fr"], p["ar"]) for p in report_engine.load_glossary()))
        lay.addWidget(self.edit, 1)
        row = QHBoxLayout()
        b1, b2 = QPushButton("حفظ"), QPushButton("إغلاق")
        b1.clicked.connect(self._save)
        b2.clicked.connect(self.close)
        row.addWidget(b1)
        row.addWidget(b2)
        lay.addLayout(row)

    def _save(self):
        pairs, bad = report_engine.parse_glossary_text(self.edit.toPlainText())
        report_engine.save_glossary(pairs)
        msg = "تم حفظ %d مصطلحاً." % len(pairs)
        if bad:
            msg += "\nأسطر لم أفهمها (تجاهلتها):\n" + "\n".join(bad[:8])
            show_warning(self, "المصطلحات", msg)
        else:
            show_info(self, "المصطلحات", msg)
