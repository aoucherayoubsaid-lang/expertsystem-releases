# -*- coding: utf-8 -*-
"""أدوات مشتركة لكل مولّدات التقارير (PDF).

- القوالب تُقرأ من القوالب المرفقة مع البرنامج (تعمل أيضاً بعد التحويل إلى .exe).
- ملفات HTML الوسيطة تُكتب في المجلد المؤقت لويندوز وتُنظَّف تلقائياً (القوالب تبقى للقراءة فقط).
- ملف PDF النهائي يُحفظ داخل مجلد الملف (Dossier) الحالي، في مجلد خاص بكل نوع:
    dossiers_data/<الملف>/years/<السنة>/courts/<المحكمة>/التقارير/<النوع>/
"""
import datetime
import os
import re
import shutil
import time
import uuid

import pdfkit

import storage
from app_paths import temp_dir
from resource_path import resource_path
from wkhtmltopdf_locator import require_wkhtmltopdf

# القوالب في مجلد templates وفي جذر المشروع (بعضها موضوع في الجذر)
TEMPLATE_SEARCH_PATHS = [resource_path("templates"), resource_path("")]


def make_env():
    """بيئة Jinja2 آمنة: تهريب HTML تلقائي لكل متغيّر (يمنع حقن وسوم من أسماء/عناوين/ملاحظات)."""
    from jinja2 import Environment, FileSystemLoader
    return Environment(loader=FileSystemLoader(TEMPLATE_SEARCH_PATHS), autoescape=True)


def secure_options(options):
    """يمنع wkhtmltopdf من قراءة ملفات الجهاز إلا مجلدي المؤقت والموارد المرفقة."""
    opts = dict(options or {})
    opts["disable-local-file-access"] = None
    opts["allow"] = [temp_dir(), resource_path("")]
    return opts


def default_options(page_size="A4"):
    return {
        "zoom": "1.0",
        "disable-smart-shrinking": None,
        "page-size": page_size,
        "encoding": "UTF-8",
    }


def safe_name(text, default="غير_محدد"):
    cleaned = re.sub(r'[\/\\:\*\?"<>\|]', "_", str(text or "")).strip()
    return cleaned or default


def stamp():
    return datetime.datetime.now().strftime("%Y%m%d_%H%M%S")


def _cleanup_temp(max_age_hours=24):
    """يحذف ملفات HTML/PDF المؤقتة القديمة حتى لا تتراكم."""
    limit = time.time() - max_age_hours * 3600
    folder = temp_dir()
    for name in os.listdir(folder):
        path = os.path.join(folder, name)
        try:
            if os.path.isfile(path) and os.path.getmtime(path) < limit:
                os.remove(path)
        except OSError:
            pass


def write_html(name, html_text):
    """يكتب HTML الوسيط في المجلد المؤقت لويندوز ويعيد مساره (للمعاينة والتحويل فقط)."""
    _cleanup_temp()
    html_file = os.path.join(temp_dir(), name)
    with open(html_file, "w", encoding="utf-8") as f:
        f.write(html_text)
    return html_file


def html_to_pdf(html_file, kind, pdf_name, options=None):
    """يحوّل HTML إلى PDF ويحفظه في مجلد النوع داخل الملف (Dossier) الحالي.

    نولّد PDF أولاً باسم لاتيني مؤقت ثم ننقله، لأن wkhtmltopdf على ويندوز
    قد يفشل أحياناً مع مسارات فيها أحرف عربية.
    """
    tmp_pdf = os.path.join(temp_dir(), uuid.uuid4().hex + ".pdf")
    config = pdfkit.configuration(wkhtmltopdf=require_wkhtmltopdf())
    pdfkit.from_file(html_file, tmp_pdf, configuration=config,
                     options=secure_options(options or default_options()))

    dest_dir = storage.reports_dir(kind)
    final_pdf = os.path.join(dest_dir, pdf_name)
    if os.path.exists(final_pdf):
        os.remove(final_pdf)
    shutil.move(tmp_pdf, final_pdf)
    return final_pdf
