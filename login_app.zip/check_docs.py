# -*- coding: utf-8 -*-
"""تشخيص Réf/QR: شغّله من مجلد البرنامج:   python check_docs.py
يعرض أين يتوقف الأمر بالضبط (إعداد، مكتبات، اتصال، مفتاح، تسجيل)."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def step(name, fn):
    try:
        r = fn()
        print("[OK]    " + name + ((" -> " + str(r)) if r else ""))
        return True
    except Exception as e:
        print("[خطأ]   " + name + " -> " + str(e))
        return False

import doc_signing as d
from app_paths import app_base_dir
print("مجلد البرنامج (هنا يجب أن يوجد docs_api.json):", app_base_dir(), "\n")

ok = step("قراءة docs_api.json أو المتغيرات", lambda: d._config())
step("مكتبة qrcode", lambda: ("مثبتة" if d.qrcode else (_ for _ in ()).throw(RuntimeError('غير مثبتة: pip install "qrcode[pil]"'))))
step("مكتبة PyMuPDF (للنسخ المختومة)", lambda: __import__("fitz") and "مثبتة")
if ok:
    step("الاتصال بالخادم /check", lambda: d._call("/check/2026/1/0/1"))
    step("تسجيل وثيقة تجريبية /documents", lambda: (lambda f: f["ref"] + "  " + f["verify_url"])(
        d.register("issued", "اختبار", "TEST-1", None)))
print("\nآخر خطأ:", d.LAST_ERROR or "لا يوجد")
