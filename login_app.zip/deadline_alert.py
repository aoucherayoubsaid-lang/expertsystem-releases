"""نافذة تنبيه آجال إيداع الخبرات (تظهر عند الدخول إلى صفحة العمل إن وُجدت قضايا متأخرة/قريبة)."""
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont
from PyQt5.QtWidgets import (
    QAbstractItemView, QDialog, QFrame, QHBoxLayout, QHeaderView, QLabel,
    QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout
)
import qtawesome as qta

TEXTS = {
    "ar": {
        "title": "تنبيه آجال إيداع الخبرات",
        "late": "متأخرة", "near": "قريبة الإيداع",
        "cols": ["الحالة", "رقم القضية", "الأطراف", "آخر أجل", "المتبقي"],
        "st_late": "متأخرة", "st_near": "قريبة",
        "late_days": "متأخرة {n} يوم", "left_days": "باقي {n} يوم", "today": "آخر يوم اليوم",
        "vs": "ضد", "view": "عرض القضايا", "close": "إغلاق",
        "sub": "لم يصدر وصل إيداع تقرير الخبرة لهذه القضايا بعد.",
    },
    "fr": {
        "title": "Alerte : délais de dépôt des rapports",
        "late": "En retard", "near": "Échéance proche",
        "cols": ["Statut", "N° d'affaire", "Parties", "Échéance", "Restant"],
        "st_late": "En retard", "st_near": "Proche",
        "late_days": "Retard de {n} j", "left_days": "Reste {n} j", "today": "Dernier jour aujourd'hui",
        "vs": "contre", "view": "Voir les affaires", "close": "Fermer",
        "sub": "Aucun reçu de dépôt du rapport n'a encore été émis pour ces affaires.",
    },
    "en": {
        "title": "Report deposit deadline alert",
        "late": "Overdue", "near": "Due soon",
        "cols": ["Status", "Case No.", "Parties", "Deadline", "Remaining"],
        "st_late": "Overdue", "st_near": "Due soon",
        "late_days": "{n} days overdue", "left_days": "{n} days left", "today": "Last day is today",
        "vs": "vs", "view": "View cases", "close": "Close",
        "sub": "No report deposit receipt has been issued for these cases yet.",
    },
}


class DeadlineAlertDialog(QDialog):
    def __init__(self, items, lang="ar", parent=None):
        """items: قائمة (case, status_dict) للقضايا المتأخرة/القريبة فقط."""
        super().__init__(parent)
        self.lang = lang if lang in TEXTS else "ar"
        t = TEXTS[self.lang]
        self.setLayoutDirection(Qt.RightToLeft if self.lang == "ar" else Qt.LeftToRight)
        self.setWindowTitle(t["title"])
        self.resize(760, 520)
        self.setModal(True)

        late = [x for x in items if x[1]["state"] == "late"]
        near = [x for x in items if x[1]["state"] == "near"]
        late.sort(key=lambda x: x[1]["days_left"])
        near.sort(key=lambda x: x[1]["days_left"])
        accent = "#d03a50" if late else "#b05c00"

        self.setStyleSheet("QDialog{background:#f1f2ff;} QLabel{background:transparent;}")
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        header = QFrame()
        header.setStyleSheet(f"QFrame{{background:{accent};}}")
        hl = QHBoxLayout(header)
        hl.setContentsMargins(22, 16, 22, 16)
        icon = QLabel()
        icon.setPixmap(qta.icon("fa5s.exclamation-triangle", color="white").pixmap(38, 38))
        hl.addWidget(icon)
        box = QVBoxLayout()
        title = QLabel(t["title"])
        title.setStyleSheet("color:white; font-size:16pt; font-weight:bold;")
        sub = QLabel(t["sub"])
        sub.setStyleSheet("color:rgba(255,255,255,0.92); font-size:10pt;")
        box.addWidget(title)
        box.addWidget(sub)
        hl.addLayout(box)
        hl.addStretch()
        for label, count, color in ((t["late"], len(late), "#b1243c"), (t["near"], len(near), "#c2410c")):
            if not count:
                continue
            chip = QLabel(f" {label}: {count} ")
            chip.setStyleSheet(f"background:white; color:{color}; border-radius:12px; "
                               "padding:5px 12px; font-weight:bold; font-size:11pt;")
            hl.addWidget(chip)
        root.addWidget(header)

        table = QTableWidget(0, 5)
        table.setHorizontalHeaderLabels(t["cols"])
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setSelectionMode(QAbstractItemView.NoSelection)
        table.verticalHeader().setVisible(False)
        table.setStyleSheet("""
            QTableWidget { background:white; border:none; font-size:11pt; gridline-color:#f1f2ff; }
            QTableWidget::item { padding:6px; }
            QHeaderView::section { background:#4338ca; color:white; padding:8px; border:none; font-weight:bold; }
        """)
        hdr = table.horizontalHeader()
        hdr.setSectionResizeMode(QHeaderView.ResizeToContents)
        hdr.setSectionResizeMode(2, QHeaderView.Stretch)

        for case, st in late + near:
            r = table.rowCount()
            table.insertRow(r)
            is_late = st["state"] == "late"
            bg = QColor("#ffe8ec" if is_late else "#fff6e0")
            fg = QColor("#b1243c" if is_late else "#c2410c")
            days = st["days_left"]
            if is_late:
                remaining = t["late_days"].format(n=abs(days))
            else:
                remaining = t["today"] if days == 0 else t["left_days"].format(n=days)
            values = [
                t["st_late"] if is_late else t["st_near"],
                str(case.get("case_number", "")),
                f"{case.get('plaintiff') or '؟'}  {t['vs']}  {case.get('defendant') or '؟'}",
                st["deadline"].strftime("%d/%m/%Y"),
                remaining,
            ]
            for c, v in enumerate(values):
                it = QTableWidgetItem(v)
                it.setBackground(bg)
                it.setForeground(fg)
                if c in (0, 4):
                    it.setFont(QFont("Segoe UI", 10, QFont.Bold))
                if c != 2:
                    it.setTextAlignment(Qt.AlignCenter)
                table.setItem(r, c, it)
        root.addWidget(table, stretch=1)

        footer = QFrame()
        footer.setStyleSheet("QFrame{background:white; border-top:1px solid #eef0ff;}")
        fl = QHBoxLayout(footer)
        fl.setContentsMargins(20, 12, 20, 12)
        self.view_clicked = False
        view_btn = QPushButton(t["view"])
        view_btn.setIcon(qta.icon("fa5s.folder-open", color="white"))
        view_btn.setStyleSheet("QPushButton{background:#4338ca;color:white;padding:9px 24px;border-radius:6px;"
                               "font-weight:bold;} QPushButton:hover{background:#4338ca;}")
        view_btn.clicked.connect(self._view)
        close_btn = QPushButton(t["close"])
        close_btn.setStyleSheet("QPushButton{background:#f1f2ff;color:#1f2347;padding:9px 24px;border-radius:6px;}"
                                "QPushButton:hover{background:#eef0ff;}")
        close_btn.clicked.connect(self.accept)
        fl.addWidget(view_btn)
        fl.addWidget(close_btn)
        fl.addStretch()
        root.addWidget(footer)

    def _view(self):
        self.view_clicked = True
        self.accept()
