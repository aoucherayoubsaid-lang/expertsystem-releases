# -*- coding: utf-8 -*-
"""النسخ الاحتياطي المشفّر بكلمة مرور + الاسترجاع الآمن.

الصيغة EJBF2 (الجديدة): تشفير على دفعات (4 ميغابايت) فلا يُحمَّل الملف كله في
الذاكرة، ولا يُكتب ملف ZIP غير مشفّر على القرص أثناء إنشاء النسخة.
    EJBF2 | ملح 16 بايت | { طول 4 بايت | رمز Fernet }...
كل دفعة تحمل داخل التشفير رقمها وعلامة "آخر دفعة"، فأي حذف أو تبديل لترتيب
الدفعات يُكتشف عند الاسترجاع.

الصيغة EJBF1 (القديمة، ملف واحد) ما زال الاسترجاع يدعمها.

أسماء الملفات داخل النسخة ثابتة ونسبية لمجلد البرنامج: app_data/... و
dossiers_data/... (لا تعتمد على مجلد العمل الحالي).
"""
import base64
import datetime
import os
import shutil
import struct
import tempfile
import zipfile

try:
    from cryptography.fernet import Fernet, InvalidToken
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
except Exception:  # المكتبة غير متوفرة أو لا تعمل على هذا الجهاز
    Fernet = None
    InvalidToken = Exception

MAGIC_V1 = b"EJBF1"
MAGIC_V2 = b"EJBF2"
MAGIC_V3 = b"EJBF3"          # نفس بنية V2 لكن بتكرار PBKDF2 أعلى (الجديد افتراضياً)
SALT_LEN = 16
ITERATIONS = 200000        # للنسخ القديمة V1/V2 (يلزم للاسترجاع)
ITERATIONS_V3 = 600000
CHUNK_SIZE = 4 * 1024 * 1024
DATA_FOLDERS = ("app_data", "dossiers_data")


class BackupError(Exception):
    """خطأ مفهوم للمستخدم (كلمة سر خاطئة، ملف تالف...)."""


def _key(password, salt, iterations=None):
    if Fernet is None:
        raise BackupError("مكتبة cryptography غير متوفرة، لا يمكن استعمال النسخ المشفّر.")
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=iterations or ITERATIONS)
    return base64.urlsafe_b64encode(kdf.derive(password.encode("utf-8")))


# ---------------------------------------------------------------------------
# كاتب مشفّر على دفعات (يُستعمل كملف وجهة لـ zipfile مباشرة)
# ---------------------------------------------------------------------------
class _EncryptingWriter:
    def __init__(self, out_fp, fernet):
        self._out = out_fp
        self._f = fernet
        self._buf = bytearray()
        self._index = 0
        self._closed = False

    def write(self, data):
        self._buf += data
        while len(self._buf) > CHUNK_SIZE:
            chunk = bytes(self._buf[:CHUNK_SIZE])
            del self._buf[:CHUNK_SIZE]
            self._emit(chunk, last=False)
        return len(data)

    def flush(self):
        pass

    def _emit(self, chunk, last):
        payload = struct.pack(">QB", self._index, 1 if last else 0) + chunk
        token = self._f.encrypt(payload)
        self._out.write(struct.pack(">I", len(token)) + token)
        self._index += 1

    def finish(self):
        if self._closed:
            return
        self._emit(bytes(self._buf), last=True)
        self._buf = bytearray()
        self._closed = True


def _iter_plain_chunks(in_fp, fernet):
    """يفك تشفير الدفعات بالترتيب ويتحقق من الترقيم ومن وجود الدفعة الأخيرة."""
    expected = 0
    saw_last = False
    while True:
        head = in_fp.read(4)
        if not head:
            break
        if saw_last or len(head) < 4:
            raise BackupError("الملف تالف أو مبتور.")
        (length,) = struct.unpack(">I", head)
        token = in_fp.read(length)
        if len(token) < length:
            raise BackupError("الملف تالف أو مبتور.")
        try:
            payload = fernet.decrypt(token)
        except InvalidToken:
            raise BackupError("كلمة المرور غير صحيحة، أو أن الملف تالف.")
        idx, last = struct.unpack(">QB", payload[:9])
        if idx != expected:
            raise BackupError("الملف تالف (ترتيب الأجزاء غير سليم).")
        expected += 1
        saw_last = bool(last)
        yield payload[9:]
    if not saw_last:
        raise BackupError("الملف تالف أو مبتور.")


# ---------------------------------------------------------------------------
# واجهة قديمة (للتوافق): تشفير/فك ملف واحد
# ---------------------------------------------------------------------------
def encrypt_file(src, dst, password):
    salt = os.urandom(SALT_LEN)
    f = Fernet(_key(password, salt, ITERATIONS_V3))
    with open(src, "rb") as r, open(dst, "wb") as out:
        out.write(MAGIC_V3 + salt)
        w = _EncryptingWriter(out, f)
        while True:
            block = r.read(CHUNK_SIZE)
            if not block:
                break
            w.write(block)
        w.finish()
    return dst


def decrypt_file(src, dst, password):
    with open(src, "rb") as h:
        magic = h.read(5)
        if magic == MAGIC_V1:
            salt = h.read(SALT_LEN)
            f = Fernet(_key(password, salt))
            try:
                data = f.decrypt(h.read())
            except InvalidToken:
                raise BackupError("كلمة المرور غير صحيحة، أو أن الملف تالف.")
            with open(dst, "wb") as out:
                out.write(data)
            return dst
        if magic not in (MAGIC_V2, MAGIC_V3):
            raise BackupError("هذا الملف ليس نسخة احتياطية من هذا البرنامج.")
        salt = h.read(SALT_LEN)
        f = Fernet(_key(password, salt, ITERATIONS_V3 if magic == MAGIC_V3 else ITERATIONS))
        with open(dst, "wb") as out:
            for plain in _iter_plain_chunks(h, f):
                out.write(plain)
    return dst


# ---------------------------------------------------------------------------
# إنشاء النسخة
# ---------------------------------------------------------------------------
def create_backup(dest_dir, password, app_data_dir, dossiers_dir, progress=None):
    """ينشئ نسخة مشفّرة داخل dest_dir ويعيد مسارها. لا يُكتب أي ZIP عادي على القرص."""
    if Fernet is None:
        raise BackupError("مكتبة cryptography غير متوفرة، لا يمكن استعمال النسخ المشفّر.")
    if not password:
        raise BackupError("كلمة المرور فارغة.")
    os.makedirs(dest_dir, exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    final_path = os.path.join(dest_dir, "ExpertJudicial_Backup_%s.ejbackup" % stamp)
    tmp_path = final_path + ".part"

    sources = []
    for folder_name, root in (("app_data", app_data_dir), ("dossiers_data", dossiers_dir)):
        if not root or not os.path.isdir(root):
            continue
        for base, dirs, files in os.walk(root):
            dirs[:] = [d for d in dirs if d != "__pycache__"]
            for name in files:
                full = os.path.join(base, name)
                rel = os.path.relpath(full, root).replace("\\", "/")
                sources.append((full, folder_name + "/" + rel))

    salt = os.urandom(SALT_LEN)
    f = Fernet(_key(password, salt, ITERATIONS_V3))
    try:
        with open(tmp_path, "wb") as out:
            out.write(MAGIC_V3 + salt)
            writer = _EncryptingWriter(out, f)
            with zipfile.ZipFile(writer, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
                for i, (full, arc) in enumerate(sources, 1):
                    try:
                        zf.write(full, arc)
                    except OSError:
                        continue  # ملف مقفل أو اختفى أثناء النسخ
                    if progress:
                        progress(i, len(sources))
            writer.finish()
        os.replace(tmp_path, final_path)
    except BaseException:
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except OSError:
            pass
        raise
    return final_path


# ---------------------------------------------------------------------------
# الاسترجاع
# ---------------------------------------------------------------------------
def _safe_parts(name):
    """يعيد أجزاء المسار إن كان الاسم آمناً ويبدأ بأحد مجلدي البيانات، وإلا None."""
    n = name.replace("\\", "/")
    if n.startswith("/") or (len(n) > 1 and n[1] == ":"):
        return None
    parts = [p for p in n.split("/") if p not in ("", ".")]
    if not parts or ".." in parts or parts[0] not in DATA_FOLDERS:
        return None
    return parts


def restore_backup(src_file, password, base_dir, progress=None):
    """يسترجع النسخة إلى base_dir.

    الخطوات: فك التشفير إلى مجلد مؤقت -> فحص الـ ZIP وأسماء ملفاته -> الاستخراج إلى
    مجلد تجهيز -> نقل البيانات الحالية إلى مجلد أمان _before_restore_* -> وضع
    المسترجَعة مكانها. إن فشل أي شيء بعد بدء الاستبدال تُعاد البيانات الحالية.
    يعيد dict فيه عدد الملفات ومسار مجلد الأمان.
    """
    if Fernet is None:
        raise BackupError("مكتبة cryptography غير متوفرة، لا يمكن استعمال النسخ المشفّر.")
    base_dir = os.path.abspath(base_dir)
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    work = tempfile.mkdtemp(prefix="expert_restore_", dir=base_dir)
    staging = os.path.join(work, "staging")
    plain_zip = os.path.join(work, "plain.zip")
    safety = os.path.join(base_dir, "_before_restore_%s" % stamp)
    moved = []  # (الأصل، مجلد الأمان) للتراجع عند الفشل
    try:
        decrypt_file(src_file, plain_zip, password)
        try:
            zf = zipfile.ZipFile(plain_zip)
        except zipfile.BadZipFile:
            raise BackupError("محتوى النسخة تالف.")
        with zf:
            if zf.testzip() is not None:
                raise BackupError("محتوى النسخة تالف.")
            members = []
            for info in zf.infolist():
                if info.filename.endswith("/"):
                    continue
                parts = _safe_parts(info.filename)
                if parts is None:
                    raise BackupError(
                        "النسخة تحتوي مسارات غير مقبولة (%s). لم يُغيَّر شيء." % info.filename)
                members.append((info, parts))
            if not members:
                raise BackupError("النسخة فارغة أو ليست من هذا البرنامج.")
            os.makedirs(staging)
            for i, (info, parts) in enumerate(members, 1):
                target = os.path.join(staging, *parts)
                if os.path.commonpath([staging, os.path.abspath(target)]) != staging:
                    raise BackupError("مسار غير آمن داخل النسخة. لم يُغيَّر شيء.")
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with zf.open(info) as r, open(target, "wb") as w:
                    shutil.copyfileobj(r, w)
                if progress:
                    progress(i, len(members))

        # --- نقطة اللاعودة: استبدال البيانات الحالية (مع إمكانية التراجع) ---
        os.makedirs(safety, exist_ok=True)
        try:
            for folder in DATA_FOLDERS:
                cur = os.path.join(base_dir, folder)
                if os.path.exists(cur):
                    shutil.move(cur, os.path.join(safety, folder))
                    moved.append(folder)
            for folder in DATA_FOLDERS:
                new = os.path.join(staging, folder)
                if os.path.isdir(new):
                    shutil.move(new, os.path.join(base_dir, folder))
        except BaseException:
            for folder in DATA_FOLDERS:  # تراجع كامل
                cur = os.path.join(base_dir, folder)
                if os.path.exists(cur):
                    shutil.rmtree(cur, ignore_errors=True)
                back = os.path.join(safety, folder)
                if folder in moved and os.path.exists(back):
                    shutil.move(back, cur)
            raise
        return {"files": len(members), "safety_dir": safety}
    finally:
        shutil.rmtree(work, ignore_errors=True)
        try:
            os.rmdir(safety)  # يُحذف فقط إن بقي فارغاً
        except OSError:
            pass
