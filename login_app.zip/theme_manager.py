# -*- coding: utf-8 -*-
"""زر تبديل المظهر (فاتح ⇄ ليلي) وإعادة تشغيل البرنامج لتطبيقه.

لماذا إعادة تشغيل؟ أنماط الواجهة تُبنى مرة واحدة عند فتح كل نافذة؛ إعادة التشغيل تضمن أن كل الصفحات
(حتى المفتوحة في الخلفية) تستعمل نفس اللوحة بلا بقايا ألوان قديمة. التفضيل يُحفظ في ui_theme.txt.
"""
import os
import sys
import subprocess

import qtawesome as qta
from PyQt5.QtCore import Qt, QTimer, QSize
from PyQt5.QtWidgets import QApplication, QPushButton

import theme_tokens as T

_SKIP = "_auto_i18n_skip"

_S = {
    "ar": {"to_dark": "الوضع الليلي", "to_light": "الوضع الفاتح",
           "title": "تغيير المظهر",
           "msg": "سيُعاد تشغيل البرنامج الآن لتطبيق «{name}».\nتأكد من حفظ عملك الحالي. هل تريد المتابعة؟",
           "tip_dark": "التبديل إلى الوضع الليلي", "tip_light": "التبديل إلى الوضع الفاتح"},
    "fr": {"to_dark": "Mode sombre", "to_light": "Mode clair",
           "title": "Changer l'apparence",
           "msg": "Le programme va redémarrer pour appliquer « {name} ».\nAssurez-vous d'avoir enregistré votre travail. Continuer ?",
           "tip_dark": "Passer en mode sombre", "tip_light": "Passer en mode clair"},
    "en": {"to_dark": "Dark mode", "to_light": "Light mode",
           "title": "Change appearance",
           "msg": "The app will restart now to apply \"{name}\".\nMake sure your work is saved. Continue?",
           "tip_dark": "Switch to dark mode", "tip_light": "Switch to light mode"},
}


def _lang():
    try:
        from settings_page import AppSettings
        code = AppSettings().get_language_code()
        return code if code in _S else "ar"
    except Exception:
        return "ar"


def restart_app():
    """يشغّل نسخة جديدة من البرنامج ثم يغلق الحالية."""
    exe = sys.executable
    if getattr(sys, "frozen", False):
        args = [exe] + sys.argv[1:]
    else:
        args = [exe] + sys.argv
    try:
        subprocess.Popen(args, cwd=os.getcwd())
    except Exception:
        return False
    app = QApplication.instance()
    if app is not None:
        app.quit()
    QTimer.singleShot(400, lambda: os._exit(0))
    return True


def toggle_theme(parent=None):
    """يسأل المستخدم ثم يحفظ المظهر الجديد ويعيد التشغيل."""
    s = _S[_lang()]
    target = "light" if T.IS_DARK else "dark"
    name = s["to_light"] if target == "light" else s["to_dark"]
    from msgbox_ltr import show_confirm
    if not show_confirm(parent, s["title"], s["msg"].format(name=name)):
        return
    if T.save_theme(target):
        restart_app()


def make_theme_button(parent=None, variant="soft"):
    """زر شمس/قمر. variant: soft (على خلفية عادية) أو glass (فوق لوحة بتدرّج)."""
    s = _S[_lang()]
    dark = T.IS_DARK
    btn = QPushButton()
    btn.setProperty(_SKIP, True)
    btn.setProperty("_mt_styled", True)
    btn.setProperty("_mt_setup", True)
    btn.setCursor(Qt.PointingHandCursor)
    btn.setFixedSize(40, 40)
    btn.setIconSize(QSize(18, 18))
    btn.setToolTip(s["tip_light"] if dark else s["tip_dark"])
    if variant == "glass":
        icon_color = "#ffffff"
        btn.setStyleSheet(
            "QPushButton{background:rgba(255,255,255,40);border:1px solid rgba(255,255,255,90);border-radius:20px;}"
            "QPushButton:hover{background:rgba(255,255,255,85);}")
    else:
        icon_color = T.ACCENT
        btn.setStyleSheet(
            f"QPushButton{{background:{T.SURFACE};border:1px solid {T.BORDER};border-radius:20px;}}"
            f"QPushButton:hover{{background:{T.HOVER_BG};border:1px solid {T.ACCENT};}}")
    btn.setIcon(qta.icon("fa5s.sun" if dark else "fa5s.moon", color=icon_color))
    btn.clicked.connect(lambda: toggle_theme(btn.window()))
    return btn
