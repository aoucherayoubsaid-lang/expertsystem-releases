# -*- coding: utf-8 -*-
"""Local security/audit layer for Expert Judicial.

This protects the application's local login flow and records security events.
It is not a network firewall; remote access must additionally be restricted by
Windows/network permissions when the data directory is shared.

القفل (يشمل الدخول واسترجاع كلمة المرور وكلمة بدء التشغيل):
  * لكل اسم (مفتاح): MAX_FAILURES محاولات ثم قفل LOCK_MINUTES دقائق، ويتضاعف زمن القفل مع كل قفل
    متتالٍ (حتى MAX_LOCK_MINUTES) ولا يُصفَّر إلا بنجاح.
  * عدّاد عام للجهاز (GLOBAL_MAX_FAILURES) يغلق كل المحاولات، فلا يُفلت المخمّن بتبديل أسماء
    المستخدمين أو بتغيير حالة الأحرف.
  * security.json موقَّع (local_protect): حذفه أو تعديله لتصفير العدّاد يُعدّ عبثاً ويُفعّل قفلاً
    عاماً بدل أن يمنح محاولات جديدة.
  * سجل التدقيق مسلسل بـ HMAC (كل سطر يحمل تجزئة السابق)، فحذف سطر أو تعديله يُكتشف.
"""
import hashlib, hmac, json, os, platform, socket, uuid
from datetime import datetime, timedelta

import local_protect
import app_paths
BASE = app_paths.machine_dir()          # عدّاد القفل وسجل التدقيق لكل جهاز على حدة (سلسلة HMAC لا تقبل كتّاباً متزامنين)
SECURITY_FILE = os.path.join(BASE, "security.json")
AUDIT_FILE = os.path.join(BASE, "security_audit.jsonl")
LOCK_MINUTES = 5
MAX_LOCK_MINUTES = 24 * 60
MAX_FAILURES = 5
GLOBAL_KEY = "__global__"
GLOBAL_MAX_FAILURES = 25
_MAX_TRACKED = 300


def _empty():
    return {"trusted_devices": {}, "failed": {}}


def _norm(key):
    return (key or "").strip().casefold()


def _load():
    os.makedirs(BASE, exist_ok=True)
    try:
        raw = local_protect.read_verified(SECURITY_FILE)
    except local_protect.IntegrityError:
        # عبث بعدّاد القفل: لا نمنح محاولات جديدة، نبدأ بقفل عام مؤقت
        d = _empty()
        d["failed"][GLOBAL_KEY] = {"count": 0, "locks": 1, "tampered": True,
                                   "locked_until": (datetime.now() + timedelta(minutes=LOCK_MINUTES)).isoformat(timespec="seconds")}
        return d
    if raw is None:
        return _empty()
    try:
        d = json.loads(raw.decode("utf-8"))
        d.setdefault("trusted_devices", {}); d.setdefault("failed", {})
        return d
    except Exception:
        return _empty()


def _save(d):
    if local_protect.tamper_detected():
        return                                            # لا نُشفي الملف المعبوث به بصمت؛ يلزم مسار الاسترداد الصريح
    os.makedirs(BASE, exist_ok=True)
    failed = d.get("failed", {})
    if len(failed) > _MAX_TRACKED:                       # لا نترك أسماء عشوائية تضخّم الملف
        for k in [k for k, v in failed.items() if k != GLOBAL_KEY and not v.get("locked_until")][: len(failed) - _MAX_TRACKED]:
            failed.pop(k, None)
    tmp = SECURITY_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
    os.replace(tmp, SECURITY_FILE)
    try:
        local_protect.sign_file(SECURITY_FILE)
    except local_protect.IntegrityError:
        pass

def machine_id():
    raw = [platform.node(), platform.system(), platform.release()]
    if os.name == "nt":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\\Microsoft\\Cryptography") as k:
                raw.append(str(winreg.QueryValueEx(k, "MachineGuid")[0]))
        except Exception:
            pass
    raw.append(str(uuid.getnode()))
    return hashlib.sha256("|".join(raw).encode("utf-8", "ignore")).hexdigest()[:32]

def device_info():
    try: ip = socket.gethostbyname(socket.gethostname())
    except Exception: ip = "unknown"
    return {"device_id": machine_id(), "hostname": socket.gethostname(), "ip": ip,
            "os": "%s %s" % (platform.system(), platform.release())}


# ---------------------------------------------------------------------------
# سجل التدقيق المسلسل
# ---------------------------------------------------------------------------
def _last_mac():
    try:
        with open(AUDIT_FILE, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - 8192))
            lines = [l for l in f.read().splitlines() if l.strip()]
        if lines:
            return json.loads(lines[-1].decode("utf-8")).get("mac") or ""
    except Exception:
        pass
    return ""


def _event_mac(event, prev):
    body = json.dumps(event, ensure_ascii=False, sort_keys=True)
    return hmac.new(local_protect.derived_key("audit"), (prev + "|" + body).encode("utf-8"), hashlib.sha256).hexdigest()


def audit(action, username="", result="success", extra=None):
    event = {"time": datetime.now().isoformat(timespec="seconds"), "action": action,
             "username": username, "result": result, "device": device_info()}
    if extra: event["details"] = extra
    os.makedirs(BASE, exist_ok=True)
    try:
        prev = _last_mac()
        event["prev"] = prev
        event["mac"] = _event_mac({k: v for k, v in event.items() if k not in ("prev", "mac")}, prev)
    except Exception:
        event["prev"] = ""; event["mac"] = ""            # مفتاح التوقيع غير متاح: يُسجَّل الحدث بلا سلسلة
    with open(AUDIT_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")


def verify_audit_chain():
    """يرجع (سليم؟، رقم أول سطر مشبوه أو None)."""
    prev = ""
    try:
        with open(AUDIT_FILE, "r", encoding="utf-8") as f:
            for n, line in enumerate(f, 1):
                if not line.strip():
                    continue
                ev = json.loads(line)
                if not ev.get("mac"):
                    continue                              # أحداث كُتبت بلا مفتاح (قبل التحديث أو أثناء عطل)
                body = {k: v for k, v in ev.items() if k not in ("prev", "mac")}
                if ev.get("prev") != prev or not hmac.compare_digest(ev["mac"], _event_mac(body, prev)):
                    return False, n
                prev = ev["mac"]
    except FileNotFoundError:
        return True, None
    except Exception:
        return False, 0
    return True, None


def ensure_device_approved():
    info = device_info(); d = _load(); did = info["device_id"]
    if did not in d["trusted_devices"]:
        d["trusted_devices"][did] = dict(info, approved=True, approved_at=datetime.now().isoformat(timespec="seconds"))
        _save(d)
    return True


# ---------------------------------------------------------------------------
# القفل
# ---------------------------------------------------------------------------
def _locked(rec):
    until = rec.get("locked_until")
    if until:
        try:
            return datetime.fromisoformat(until) > datetime.now()
        except Exception:
            return True                                   # قيمة تالفة: نفترض القفل
    return False


def is_locked(username):
    d = _load(); key = _norm(username)
    return _locked(d["failed"].get(GLOBAL_KEY, {})) or _locked(d["failed"].get(key, {}))


def lock_remaining_minutes(username):
    d = _load(); best = 0
    for k in (GLOBAL_KEY, _norm(username)):
        until = d["failed"].get(k, {}).get("locked_until")
        if until:
            try:
                best = max(best, int((datetime.fromisoformat(until) - datetime.now()).total_seconds() // 60) + 1)
            except Exception:
                pass
    return best


def _bump(d, key, limit):
    rec = d["failed"].get(key, {"count": 0, "locks": 0})
    rec["count"] = int(rec.get("count", 0)) + 1
    locked_now = False
    if rec["count"] >= limit:
        rec["locks"] = int(rec.get("locks", 0)) + 1
        minutes = min(LOCK_MINUTES * (2 ** (rec["locks"] - 1)), MAX_LOCK_MINUTES)
        rec["locked_until"] = (datetime.now() + timedelta(minutes=minutes)).isoformat(timespec="seconds")
        rec["count"] = 0
        locked_now = True
    d["failed"][key] = rec
    return locked_now


def record_failure(username, action="LOGIN_FAILED"):
    d = _load(); key = _norm(username)
    locked = _bump(d, key, MAX_FAILURES)
    _bump(d, GLOBAL_KEY, GLOBAL_MAX_FAILURES)
    _save(d)
    audit(action, username, "blocked" if locked else "failed")


def record_success(username, action="LOGIN"):
    d = _load(); key = _norm(username)
    d["failed"].pop(key, None)
    g = d["failed"].get(GLOBAL_KEY)
    if g and not g.get("tampered"):
        g["count"] = 0
    _save(d)
    audit(action, username, "success")
