# -*- coding: utf-8 -*-
"""صفحة «التقرير بالذكاء الاصطناعي» — مساحة عمل متكاملة لإعداد تقرير الخبرة.

الفكرة: اختر القضية فقط، والبرنامج يقرأ نبذتها ومهامها ووثائقها بنفسه (لا إدخال يدوي للعناوين ولا قاموس مصطلحات).
مسار العمل بالتبويبات (من اليمين إلى اليسار):
  ملف القضية           : النبذة والمهام والوثائق وحالة قراءتها (OCR وتحسين الصور تلقائياً).
  المراجع والنماذج     : مراجعك (قوانين وكتب) ونماذج الغلاف والتقرير.
  هيكل التقرير         : عناوين يقترحها الذكاء الاصطناعي حسب المهام؛ تعتمد ما يعجبك فيُدرج في نموذج التقرير.
  الجداول والحسابات    : يدرس الذكاء الاصطناعي القضية ويصمّم جداولها (عددها وأعمدتها وصفوفها يختلف من قضية لأخرى)
                         وحساباتها؛ الخلايا المشتقة صيغ تبدأ بـ = يحسبها الكود. «تحديث» يعيد النظر فيها عند تغيّر المعطيات.
  المراجعة والتحقق     : التعارضات والأرقام غير المطابقة والنواقص + الأدلة المعتمدة (للقراءة والمعالجة).
  المعاينة والتصدير    : التقرير كاملاً (غلاف + عناوين + جداولها) ثم تصدير Word.
"""
import copy
import html as _html
import os
import re

from PyQt5.QtCore import QSize, Qt, QThread, pyqtSignal
from PyQt5.QtGui import QColor, QFont
from PyQt5.QtWidgets import (
    QAbstractItemView, QApplication, QCheckBox, QComboBox, QDialog, QFileDialog, QFrame, QGridLayout, QHBoxLayout,
    QHeaderView, QInputDialog, QLabel, QLineEdit, QListWidget, QListWidgetItem, QPlainTextEdit, QProgressBar,
    QPushButton, QScrollArea, QSizePolicy, QSplitter, QStackedWidget, QTableWidget, QTableWidgetItem, QTabWidget, QTextBrowser,
    QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget,
)

import storage
import theme_tokens as T
from msgbox_ltr import show_confirm, show_info, show_warning

try:
    import qtawesome as qta
except Exception:                                       # الأيقونات اختيارية
    qta = None

try:
    from modern_theme import style_button, style_soft_button
except Exception:                                       # لا نُسقط الصفحة إن تغيّر الثيم
    def style_button(btn, kind="primary", **kw):
        pass

    def style_soft_button(btn, kind="info", **kw):
        pass

CARD_QSS = "QFrame#card { background: %s; border: 1px solid %s; border-radius: 14px; }" % (T.SURFACE, T.BORDER)
BADGE = {"approved": ("معتمد", T.OK_BG, T.OK_FG), "suggested": ("مقترح", T.WARN_BG, T.WARN_FG)}


def _icon(name, color):
    if qta is None:
        return None
    try:
        return qta.icon(name, color=color)
    except Exception:
        return None


def make_button(text, kind="primary", icon=None, soft=False):
    b = QPushButton(text)
    b.setAutoDefault(False)
    b.setDefault(False)
    (style_soft_button if soft else style_button)(b, kind)
    ic = _icon(icon, T.PRIMARY_DARK if soft else "#ffffff") if icon else None
    if ic is not None:
        b.setIcon(ic)
    b.setMinimumHeight(40)
    b.setCursor(Qt.PointingHandCursor)
    return b


def card():
    f = QFrame()
    f.setObjectName("card")
    f.setStyleSheet(CARD_QSS)
    return f


def heading(text, size=12):
    l = QLabel(text)
    l.setStyleSheet("font-size:%dpt; font-weight:bold; color:%s; background:transparent;" % (size, T.PRIMARY_DARK))
    return l


def muted(text=""):
    l = QLabel(text)
    l.setWordWrap(True)
    l.setStyleSheet("color:%s; background:transparent;" % T.TEXT_MUTED)
    return l


TAB_QSS = """
QTabWidget::pane { border: none; background: transparent; }
QTabBar { background: transparent; }
QTabBar::tab { background: transparent; color: %(muted)s; padding: 11px 24px; margin: 0 3px 8px 3px;
               border: none; border-bottom: 3px solid transparent; font-weight: bold; }
QTabBar::tab:hover:!selected { color: %(primary)s; background: %(hover)s; border-radius: 10px; }
QTabBar::tab:selected { color: %(dark)s; border-bottom: 3px solid %(accent)s; }
""" % {"muted": T.TEXT_MUTED, "primary": T.PRIMARY, "hover": T.HOVER_BG, "dark": T.PRIMARY_DARK, "accent": T.ACCENT}

_RTL_OPEN = '<div dir="rtl" style="line-height:165%;">'


def chip(text, bg, fg):
    """شارة صغيرة ملوّنة (إحصاءات وحالات)."""
    l = QLabel(text)
    l.setAlignment(Qt.AlignCenter)
    l.setStyleSheet("background:%s; color:%s; border-radius:11px; padding:3px 12px; font-weight:bold;" % (bg, fg))
    return l


def _airy(root):
    """مسافات داخلية أرحب لكل البطاقات حتى لا تبدو الصفحة مزدحمة."""
    for f in root.findChildren(QFrame):
        lay = f.layout()
        if lay is None:
            continue
        if f.objectName() == "card":
            lay.setContentsMargins(20, 18, 20, 18)
            lay.setSpacing(12)
        elif f.objectName() == "aiBox":
            lay.setContentsMargins(18, 14, 18, 14)
            lay.setSpacing(10)


def _clear_layout(lay):
    while lay.count():
        it = lay.takeAt(0)
        w = it.widget()
        if w is not None:
            w.setParent(None)
            w.deleteLater()


def _scaled(w, factor=1.0, bold=None):
    """يكبّر/يصغّر خط عنصر نسبةً إلى خط البرنامج الحالي (فيتبع إعداد حجم الخط)."""
    f = QFont(w.font())
    ps = f.pointSizeF()
    if ps > 0:
        f.setPointSizeF(ps * factor)
    if bold is not None:
        f.setBold(bold)
    w.setFont(f)
    return w


def _center_host(w, max_width=1320):
    """يحصر المحتوى في عمود مركزي مريح بدل تمدّده من حافة إلى حافة."""
    host = QWidget()
    h = QHBoxLayout(host)
    h.setContentsMargins(0, 0, 0, 0)
    h.addStretch(1)
    w.setMaximumWidth(max_width)
    w.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
    h.addWidget(w, 100)
    h.addStretch(1)
    return host


def _scroll(inner, max_width=None):
    """يلفّ صفحة كاملة بمنطقة تمرير عمودي سلس: لا شيء يُضغط أو يختفي عند صغر النافذة."""
    sa = QScrollArea()
    sa.setWidgetResizable(True)
    sa.setFrameShape(QFrame.NoFrame)
    sa.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    sa.setLayoutDirection(Qt.RightToLeft)
    sa.setStyleSheet("QScrollArea { background: transparent; border: none; }")
    sa.setWidget(_center_host(inner, max_width) if max_width else inner)
    return sa


def _centered_row(widget):
    """يضع عنصراً (جدولاً مثلاً) في وسط الصف مهما كان عرضه."""
    host = QWidget()
    h = QHBoxLayout(host)
    h.setContentsMargins(0, 0, 0, 0)
    h.addStretch(1)
    h.addWidget(widget, 100)
    h.addStretch(1)
    return host


def _section_head(text, icon=None, factor=1.15):
    """عنوان قسم: أيقونة + نص عريض ملوّن (يتبع حجم خط البرنامج)."""
    host = QWidget()
    h = QHBoxLayout(host)
    h.setContentsMargins(0, 0, 0, 0)
    h.setSpacing(8)
    if icon:
        ic = QLabel()
        pm = _icon(icon, T.ACCENT)
        if pm is not None:
            ic.setPixmap(pm.pixmap(20, 20))
            h.addWidget(ic)
    l = QLabel(text)
    l.setWordWrap(True)
    l.setStyleSheet("color:%s; background:transparent; font-weight:bold;" % T.PRIMARY_DARK)
    _scaled(l, factor)
    h.addWidget(l, 1)
    return host


def _clamp_cols(tbl, mn=110, mx=380, pad=26):
    tbl.resizeColumnsToContents()
    total = 0
    for j in range(tbl.columnCount()):
        if tbl.isColumnHidden(j):
            continue
        w = max(mn, min(mx, tbl.columnWidth(j) + pad))
        tbl.setColumnWidth(j, w)
        total += w
    return total


def _autofit(tbl, mn=100, mx=360):
    """جدول للعرض فقط: أعمدة بعرض مناسب، وارتفاعه بقدر صفوفه (فيتولّى تمرير الصفحة التمرير)، ويُعرض في الوسط."""
    hh = tbl.horizontalHeader()
    hh.setSectionResizeMode(QHeaderView.Interactive)
    hh.setStretchLastSection(False)
    hh.setDefaultAlignment(Qt.AlignCenter)
    total = _clamp_cols(tbl, mn, mx)
    tbl.resizeRowsToContents()
    head_h = hh.height() if hh.height() > 0 else hh.sizeHint().height()
    body_h = sum(tbl.rowHeight(i) for i in range(tbl.rowCount()))
    fw = tbl.frameWidth() * 2
    tbl.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    tbl.setFixedHeight(max(120, head_h + body_h + fw + 26))          # + مساحة لشريط تمرير أفقي إن لزم
    vh = tbl.verticalHeader().width() if tbl.verticalHeader().isVisible() else 0
    tbl.setMaximumWidth(max(380, total + vh + fw + 4))
    tbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)


def _style_view_table(tbl):
    tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
    tbl.setSelectionMode(QAbstractItemView.NoSelection)
    tbl.verticalHeader().setVisible(False)
    tbl.setAlternatingRowColors(True)
    tbl.setWordWrap(True)
    tbl.setTextElideMode(Qt.ElideNone)
    tbl.setStyleSheet("QTableWidget::item { padding: 7px 10px; }")


def _cell_item(text, bad=False):
    it = QTableWidgetItem(str(text))
    it.setTextAlignment(Qt.AlignCenter)
    if bad:
        it.setForeground(QColor(T.BAD_FG))
    return it


def _steps_html(res):
    """طريقة الحساب بخطواتها ونتيجتها بشكل واضح (يتبع حجم خط البرنامج ولا يثبّت حجماً)."""
    import report_engine
    if res.get("error"):
        return '<div dir="rtl" style="color:%s;">تعذّر الحساب: %s</div>' % (T.BAD_FG, _html.escape(str(res["error"])))
    steps = _html.escape(str(res.get("steps", "")))
    total = _html.escape(report_engine.fmt_num(res.get("result")))
    detail = res.get("inputs_detail") or []
    extra = ""
    if any(str(x).strip() for x in detail):
        extra = '<p style="margin:6px 0 0 0; color:%s;">%s</p>' % (T.TEXT_MUTED, _html.escape(" ، ".join(str(x) for x in detail)))
    return ('<div dir="rtl" style="line-height:175%%;">'
            '<p style="margin:0; color:%s;">الخطوات الحسابية</p>'
            '<p dir="ltr" align="center" style="margin:8px 0; font-family:Consolas,monospace; color:%s;">%s</p>'
            '<p align="center" style="margin:10px 0 0 0;">النتيجة النهائية: '
            '<span style="color:%s; font-weight:bold; font-size:x-large;">%s</span></p>%s</div>'
            % (T.TEXT_MUTED, T.TEXT, steps, T.PRIMARY_DARK, total, extra))


def _elide(text, limit):
    """يقصّ النص عند آخر كلمة كاملة قبل الحد. يرجع (النص، هل قُصّ؟)."""
    t = " ".join(str(text or "").split())
    if len(t) <= limit:
        return t, False
    cut = t[:limit].rsplit(" ", 1)[0]
    return cut.rstrip(" ,;:،؛.-") + " …", True


def _split_items(text):
    """يفصل نصاً متعدد الأسطر إلى بنود نظيفة (يزيل الرموز والترقيم في أول السطر)."""
    out = []
    for ln in str(text or "").replace("\r", "").split("\n"):
        ln = re.sub(r"^\s*(?:[-•*·▪●■◦–—]+|\(?\d+[\)\.\-])\s*", "", ln).strip()
        if ln:
            out.append(ln)
    return out


class _ReadDialog(QDialog):
    """نافذة قراءة مريحة للنصوص الطويلة (النبذة، كل المهام)."""

    def __init__(self, title, body_html, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setLayoutDirection(Qt.RightToLeft)
        self.setMinimumSize(620, 440)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 20, 24, 18)
        lay.setSpacing(12)
        lay.addWidget(heading(title, 14))
        tb = QTextBrowser()
        tb.setOpenLinks(False)
        tb.setHtml(body_html)
        tb.setStyleSheet("QTextBrowser { background:%s; border:1px solid %s; border-radius:12px; padding:16px; }"
                         % (T.SURFACE_ALT, T.BORDER))
        lay.addWidget(tb, 1)
        row = QHBoxLayout()
        row.addStretch(1)
        b = make_button("إغلاق", "primary")
        b.setMinimumWidth(140)
        b.clicked.connect(self.accept)
        row.addWidget(b)
        lay.addLayout(row)
        self.resize(820, 600)


class _EditorDialog(QDialog):
    """نافذة تحرير كبيرة: المحتوى في منطقة تمرير، والعنوان والزر السفلي ثابتان فلا يختلطان بالجدول."""

    def __init__(self, parent):
        super().__init__(parent)
        self.setLayoutDirection(Qt.RightToLeft)
        self.setWindowFlags(self.windowFlags() | Qt.WindowMaximizeButtonHint | Qt.WindowMinimizeButtonHint)
        self.setSizeGripEnabled(True)
        self.setMinimumSize(900, 640)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(30, 22, 30, 18)
        lay.setSpacing(14)
        self.head = QLabel("")
        self.head.setWordWrap(True)
        self.head.setStyleSheet("color:%s; background:transparent; font-weight:bold;" % T.PRIMARY_DARK)
        _scaled(self.head, 1.4)
        lay.addWidget(self.head)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        holder = QWidget()
        holder.setObjectName("dlgHolder")
        holder.setStyleSheet("QWidget#dlgHolder { background: transparent; }")
        self.host = QVBoxLayout(holder)
        self.host.setContentsMargins(2, 2, 12, 2)
        self.scroll.setWidget(holder)
        lay.addWidget(self.scroll, 1)

        foot = QHBoxLayout()
        foot.addWidget(muted("تُحفظ تعديلاتك تلقائياً عند الإغلاق."), 1)
        self.btn_done = make_button("تم — حفظ والعودة", "success", "fa5s.check")
        self.btn_done.setMinimumWidth(200)
        self.btn_done.clicked.connect(self.accept)
        foot.addWidget(self.btn_done)
        lay.addLayout(foot)

    def run(self, title):
        self.head.setText(title)
        scr = QApplication.desktop().availableGeometry(self)
        self.resize(int(scr.width() * 0.88), int(scr.height() * 0.88))
        self.move(scr.x() + (scr.width() - self.width()) // 2, scr.y() + (scr.height() - self.height()) // 2)
        self.scroll.verticalScrollBar().setValue(0)
        self.exec_()


class _NotesDialog(QDialog):
    """نافذة قراءة بنود المراجعة: كل بند في بطاقة مقروءة كاملة بلا اقتطاع، مع زر «تمت المعالجة» لكل بند."""
    resolved = pyqtSignal(str, str)

    def __init__(self, key, title, hint, icon, items, parent=None):
        super().__init__(parent)
        self.key = key
        self._left = len(items)
        self.setWindowTitle(title)
        self.setLayoutDirection(Qt.RightToLeft)
        self.setMinimumSize(780, 540)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(30, 22, 30, 18)
        lay.setSpacing(12)
        head = QHBoxLayout()
        head.addWidget(_section_head(title, icon, 1.4), 1)
        self.count = QLabel("")
        head.addWidget(self.count)
        lay.addLayout(head)
        lay.addWidget(muted(hint))

        sa = QScrollArea()
        sa.setWidgetResizable(True)
        sa.setFrameShape(QFrame.NoFrame)
        sa.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        sa.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        holder = QWidget()
        holder.setObjectName("notesHolder")
        holder.setStyleSheet("QWidget#notesHolder { background: transparent; }")
        self.box = QVBoxLayout(holder)
        self.box.setContentsMargins(2, 6, 12, 6)
        self.box.setSpacing(12)
        for n, txt in enumerate(items, 1):
            self.box.addWidget(self._make_card(n, txt))
        self.empty = QLabel("لا يوجد ما يحتاج معالجة هنا.")
        self.empty.setAlignment(Qt.AlignCenter)
        self.empty.setStyleSheet("color:%s; background:transparent;" % T.TEXT_MUTED)
        _scaled(self.empty, 1.2)
        self.box.addWidget(self.empty)
        self.box.addStretch(1)
        sa.setWidget(holder)
        lay.addWidget(sa, 1)

        foot = QHBoxLayout()
        foot.addStretch(1)
        b = make_button("إغلاق", "primary")
        b.setMinimumWidth(150)
        b.clicked.connect(self.accept)
        foot.addWidget(b)
        lay.addLayout(foot)
        self._refresh()
        scr = QApplication.desktop().availableGeometry(self)
        self.resize(min(1000, int(scr.width() * 0.8)), int(scr.height() * 0.82))

    def _make_card(self, n, txt):
        f = QFrame()
        f.setObjectName("noteCard")
        f.setStyleSheet("QFrame#noteCard { background:%s; border:1px solid %s; border-radius:14px; }" % (T.SURFACE, T.BORDER))
        h = QHBoxLayout(f)
        h.setContentsMargins(18, 16, 18, 16)
        h.setSpacing(16)
        num = QLabel(str(n))
        num.setFixedSize(36, 36)
        num.setAlignment(Qt.AlignCenter)
        num.setStyleSheet("background:%s; color:%s; border-radius:18px; font-weight:bold;" % (T.INFO_BG, T.INFO_FG))
        lab = QLabel(txt)
        lab.setWordWrap(True)
        lab.setTextInteractionFlags(Qt.TextSelectableByMouse)
        lab.setMinimumWidth(320)
        lab.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        lab.setStyleSheet("background:transparent; color:%s;" % T.TEXT)
        btn = make_button("تمت المعالجة", "success", "fa5s.check", soft=True)
        btn.setMinimumWidth(150)
        btn.clicked.connect(lambda _=False, fr=f, t=txt: self._done(fr, t))
        h.addWidget(num, 0, Qt.AlignTop)
        h.addWidget(lab, 1)
        h.addWidget(btn, 0, Qt.AlignVCenter)
        return f

    def _done(self, frame, txt):
        self.resolved.emit(self.key, txt)
        frame.setParent(None)
        frame.deleteLater()
        self._left -= 1
        self._refresh()

    def _refresh(self):
        self.count.setText("%d بند" % self._left if self._left else "لا بنود")
        bg, fg = (T.WARN_BG, T.WARN_FG) if self._left else (T.OK_BG, T.OK_FG)
        self.count.setStyleSheet("background:%s; color:%s; border-radius:12px; padding:4px 16px; font-weight:bold;" % (bg, fg))
        self.empty.setVisible(self._left <= 0)


class _EvidenceDialog(QDialog):
    """نافذة الأدلة المعتمدة: قائمة المقاطع بجانب نص المقطع كاملاً."""

    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("الأدلة المعتمدة")
        self.setLayoutDirection(Qt.RightToLeft)
        self.setMinimumSize(880, 580)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(30, 22, 30, 18)
        lay.setSpacing(12)
        lay.addWidget(_section_head("الأدلة المعتمدة", "fa5s.quote-right", 1.4))
        lay.addWidget(muted("المقاطع من وثائق القضية ومراجعك التي استند إليها الذكاء الاصطناعي. "
                            "الأرقام [D1] و[R1] في العناوين والجداول تحيل إليها. اختر مقطعاً لقراءة نصه كاملاً."))
        row = QHBoxLayout()
        row.setSpacing(16)
        self.ev_list = QListWidget()
        self.ev_list.setWordWrap(True)
        self.ev_list.setSpacing(4)
        self.ev_list.setMinimumWidth(300)
        self.ev_list.setStyleSheet("QListWidget::item { padding: 10px 8px; }")
        self.ev_text = QPlainTextEdit()
        self.ev_text.setReadOnly(True)
        self.ev_text.setStyleSheet("QPlainTextEdit { padding: 16px; }")
        row.addWidget(self.ev_list, 2)
        row.addWidget(self.ev_text, 3)
        lay.addLayout(row, 1)
        foot = QHBoxLayout()
        foot.addStretch(1)
        b = make_button("إغلاق", "primary")
        b.setMinimumWidth(150)
        b.clicked.connect(self.accept)
        foot.addWidget(b)
        lay.addLayout(foot)
        scr = QApplication.desktop().availableGeometry(self)
        self.resize(min(1100, int(scr.width() * 0.82)), int(scr.height() * 0.82))


class _Task(QThread):
    progress = pyqtSignal(str)
    done = pyqtSignal(object, str)

    def __init__(self, fn, parent=None):
        super().__init__(parent)
        self.fn = fn

    def run(self):
        try:
            self.done.emit(self.fn(self.progress.emit), "")
        except Exception as e:
            self.done.emit(None, str(e))


def _cell(tbl, r, c):
    it = tbl.item(r, c)
    return it.text().strip() if it else ""


class AIReportPage(QWidget):
    def __init__(self, case_page=None, main_app=None, parent=None):
        super().__init__(parent)
        self.case_page = case_page
        self.main_app = main_app
        self.setLayoutDirection(Qt.RightToLeft)
        self.draft = None
        self._task = None
        self._loading = False
        self._cur_sec = -1
        self._cur_item = None            # ("calc"|"table", id)
        self._consented = set()
        self._build()
        self.reload()

    # ------------------------------------------------------------------ البناء
    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(26, 18, 26, 14)
        root.setSpacing(10)

        head = QHBoxLayout()
        head.setSpacing(12)
        title_col = QVBoxLayout()
        title_col.setSpacing(2)
        title_col.addWidget(heading("التقرير والغلاف بالذكاء الاصطناعي", 16))
        title_col.addWidget(muted("اختر القضية ثم تنقّل بين التبويبات من اليمين إلى اليسار؛ كل تبويب يبني على ما قبله."))
        head.addLayout(title_col, 1)
        lbl = QLabel("القضية")
        lbl.setStyleSheet("font-weight:bold; background:transparent;")
        head.addWidget(lbl)
        self.case_box = QComboBox()
        self.case_box.setMinimumWidth(420)
        self.case_box.setMinimumHeight(38)
        head.addWidget(self.case_box)
        root.addLayout(head)

        self.progress = QProgressBar()
        self.progress.setTextVisible(False)
        self.progress.setFixedHeight(4)
        self.progress.setRange(0, 1)
        root.addWidget(self.progress)
        self.status = muted("اختر قضية للبدء.")
        root.addWidget(self.status)

        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.setStyleSheet(TAB_QSS)
        self.tabs.tabBar().setExpanding(False)
        self.tabs.tabBar().setDrawBase(False)
        self.tabs.tabBar().setCursor(Qt.PointingHandCursor)
        self.tabs.setIconSize(QSize(18, 18))
        root.addWidget(self.tabs, 1)
        self._tab_case()
        self._tab_refs()
        self._tab_outline()
        self._tab_calcs()
        self._tab_review()
        self._tab_preview()
        for i, name in enumerate(("fa5s.folder-open", "fa5s.book", "fa5s.list-ul", "fa5s.table",
                                  "fa5s.check-double", "fa5s.file-export")):
            ic = _icon(name, T.PRIMARY)
            if ic is not None and i < self.tabs.count():
                self.tabs.setTabIcon(i, ic)
        _airy(self)

        self.case_box.currentIndexChanged.connect(self._case_changed)
        self.tabs.currentChanged.connect(self._tab_changed)

    @staticmethod
    def _centered(w, max_width=1320):
        return _center_host(w, max_width)

    # ---- ملف القضية
    def _preview_card(self, title, icon, on_more):
        """بطاقة قراءة مختصرة: عنوان + مقتطف مرتّب + زر «قراءة كاملة» يفتح نافذة قراءة مريحة."""
        c = card()
        l = QVBoxLayout(c)
        hr = QHBoxLayout()
        ic = QLabel()
        pm = _icon(icon, T.ACCENT)
        if pm is not None:
            ic.setPixmap(pm.pixmap(18, 18))
        hr.addWidget(ic)
        hr.addWidget(heading(title, 11))
        hr.addStretch(1)
        more = QPushButton("قراءة كاملة")
        more.setCursor(Qt.PointingHandCursor)
        more.setFlat(True)
        more.setStyleSheet("QPushButton { color:%s; font-weight:bold; border:none; background:transparent; padding:2px 6px; }"
                           "QPushButton:hover { color:%s; text-decoration:underline; }" % (T.ACCENT, T.PRIMARY_DARK))
        more.clicked.connect(on_more)
        hr.addWidget(more)
        l.addLayout(hr)
        body = QLabel()
        body.setWordWrap(True)
        body.setTextFormat(Qt.RichText)
        body.setAlignment(Qt.AlignTop)
        body.setMinimumHeight(112)
        body.setStyleSheet("color:%s; background:transparent; font-size:10.5pt;" % T.TEXT)
        l.addWidget(body, 1)
        return c, body, more

    def _tab_case(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 8, 0, 0)
        lay.setSpacing(14)

        top = card()
        tl = QHBoxLayout(top)
        info = QVBoxLayout()
        info.setSpacing(4)
        self.case_title = heading("", 16)
        self.case_meta = muted()
        info.addWidget(self.case_title)
        info.addWidget(self.case_meta)
        tl.addLayout(info, 1)
        b_open = make_button("فتح القضية للتعديل", "secondary", "fa5s.folder-open", soft=True)
        b_open.setToolTip("تعديل النبذة والمهام من صفحة القضايا")
        b_open.clicked.connect(self._open_case_page)
        tl.addWidget(b_open)
        lay.addWidget(top)

        row = QHBoxLayout()
        row.setSpacing(14)
        c1, self.case_summary, self.btn_more_sum = self._preview_card(
            "نبذة عن القضية", "fa5s.align-right", lambda: self._read_full("summary"))
        c2, self.case_tasks, self.btn_more_tasks = self._preview_card(
            "المهام المطلوبة من الخبير", "fa5s.tasks", lambda: self._read_full("tasks"))
        row.addWidget(c1, 1)
        row.addWidget(c2, 1)
        lay.addLayout(row)
        self._full_summary = self._full_tasks = ""

        docs = card()
        dl = QVBoxLayout(docs)
        hr = QHBoxLayout()
        hr.setSpacing(10)
        hr.addWidget(heading("وثائق القضية", 12))
        self.docs_stats = QHBoxLayout()
        self.docs_stats.setSpacing(6)
        hr.addLayout(self.docs_stats)
        hr.addStretch(1)
        self.auto = QCheckBox("تحليل الوثائق تلقائياً عند رفعها")
        try:
            import index_sync
            self.auto.setChecked(index_sync.get_auto_index())
            self.auto.toggled.connect(index_sync.set_auto_index)
        except Exception:
            self.auto.setVisible(False)
        hr.addWidget(self.auto)
        self.btn_sync = make_button("تحليل الوثائق وقراءتها", "primary", "fa5s.search")
        self.btn_sync.clicked.connect(self._sync_docs)
        hr.addWidget(self.btn_sync)
        dl.addLayout(hr)
        dl.addWidget(muted("يقرأ الذكاء الاصطناعي ملفات PDF والصور والوثائق الممسوحة ضوئياً بالعربية والفرنسية، "
                           "ويحسّن الصور غير الواضحة تلقائياً قبل قراءتها."))
        self.docs_tbl = QTableWidget(0, 4)
        self.docs_tbl.setHorizontalHeaderLabels(["الوثيقة", "الطرف", "الحالة", "المقاطع"])
        self.docs_tbl.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        for j in (1, 2, 3):
            self.docs_tbl.horizontalHeader().setSectionResizeMode(j, QHeaderView.ResizeToContents)
        self.docs_tbl.verticalHeader().setVisible(False)
        self.docs_tbl.verticalHeader().setDefaultSectionSize(40)
        self.docs_tbl.setAlternatingRowColors(True)
        self.docs_tbl.setShowGrid(False)
        self.docs_tbl.setTextElideMode(Qt.ElideMiddle)
        self.docs_tbl.setStyleSheet("QTableWidget::item { padding: 6px 10px; }")
        self.docs_tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.docs_tbl.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.docs_tbl.setMinimumHeight(190)
        dl.addWidget(self.docs_tbl)
        lay.addWidget(docs)
        lay.addStretch(1)
        self.tabs.addTab(_scroll(w, 1320), "ملف القضية")

    # ---- هيكل التقرير
    def _tab_outline(self):
        w = QWidget()
        lay = QHBoxLayout(w)
        lay.setContentsMargins(0, 8, 0, 0)
        lay.setSpacing(14)
        side = card()
        sl = QVBoxLayout(side)
        sl.addWidget(heading("عناوين التقرير", 11))
        self.sec_list = QListWidget()
        sl.addWidget(self.sec_list, 1)
        self.btn_outline = make_button("اقتراح العناوين بالذكاء الاصطناعي", "purple", "fa5s.magic")
        self.btn_outline.clicked.connect(self._suggest_outline)
        sl.addWidget(self.btn_outline)
        r1 = QHBoxLayout()
        b_ok = make_button("اعتماد وإدراج في التقرير", "success", "fa5s.check")
        b_all = make_button("اعتماد الكل", "success", "fa5s.check-double", soft=True)
        r1.addWidget(b_ok)
        r1.addWidget(b_all)
        sl.addLayout(r1)
        r2 = QHBoxLayout()
        b_up = make_button("أعلى", "secondary", "fa5s.arrow-up", soft=True)
        b_dn = make_button("أسفل", "secondary", "fa5s.arrow-down", soft=True)
        b_add = make_button("إضافة", "info", "fa5s.plus", soft=True)
        b_del = make_button("حذف", "danger", "fa5s.trash", soft=True)
        for b in (b_up, b_dn, b_add, b_del):
            r2.addWidget(b)
        sl.addLayout(r2)
        lay.addWidget(side, 2)

        ed = card()
        el = QVBoxLayout(ed)
        hr = QHBoxLayout()
        hr.addWidget(heading("محتوى العنوان", 11))
        hr.addStretch(1)
        self.sec_badge = QLabel("")
        hr.addWidget(self.sec_badge)
        el.addLayout(hr)
        el.addWidget(QLabel("العنوان :"))
        self.sec_title = QLineEdit()
        el.addWidget(self.sec_title)
        el.addWidget(QLabel("النص :"))
        self.sec_body = QPlainTextEdit()
        el.addWidget(self.sec_body, 1)
        self.sec_src = muted()
        el.addWidget(self.sec_src)
        lay.addWidget(ed, 3)
        self._outline_tab = w
        self.tabs.addTab(w, "هيكل التقرير")

        self.sec_list.currentRowChanged.connect(self._sec_row_changed)
        b_ok.clicked.connect(lambda: self._sec_approve(False))
        b_all.clicked.connect(lambda: self._sec_approve(True))
        b_up.clicked.connect(lambda: self._sec_move(-1))
        b_dn.clicked.connect(lambda: self._sec_move(1))
        b_add.clicked.connect(self._sec_add)
        b_del.clicked.connect(self._sec_del)

    # ---- الجداول والحسابات
    def _tab_calcs(self):
        w = QWidget()
        outer = QVBoxLayout(w)
        outer.setContentsMargins(0, 8, 0, 0)
        outer.setSpacing(14)
        self.fx_banner = QFrame()
        self.fx_banner.setObjectName("card")
        self.fx_banner.setStyleSheet("QFrame#card { background:%s; border:1px solid %s; border-radius:12px; }"
                                     % (T.WARN_BG, T.WARN_FG))
        fl = QHBoxLayout(self.fx_banner)
        self.fx_label = QLabel("")
        self.fx_label.setWordWrap(True)
        self.fx_label.setStyleSheet("color:%s; font-weight:bold; background:transparent;" % T.WARN_FG)
        fl.addWidget(self.fx_label, 1)
        b_fx = make_button("إدخال أسعار الصرف المطلوبة", "warning", "fa5s.exchange-alt")
        b_fx.clicked.connect(self._open_fx)
        fl.addWidget(b_fx)
        self.fx_banner.setVisible(False)
        outer.addWidget(self.fx_banner)

        # ---- شريط مساعد الذكاء الاصطناعي (أفقي ومضغوط ليترك المساحة للقائمة والمعاينة)
        ai = QFrame()
        ai.setObjectName("aiBox")
        ai.setStyleSheet("QFrame#aiBox { background:%s; border:1px solid %s; border-radius:14px; }"
                         % (T.TINT_INDIGO, T.BORDER))
        al = QVBoxLayout(ai)
        ar = QHBoxLayout()
        ar.setSpacing(10)
        txt = QVBoxLayout()
        txt.setSpacing(2)
        txt.addWidget(heading("مساعد الجداول", 12))
        txt.addWidget(muted("يدرس نبذة القضية ومهامها ووثائقها ومراجعك، ثم يقترح الجداول والحسابات المناسبة. "
                            "كل ما يقترحه قابل للتعديل."))
        ar.addLayout(txt, 1)
        self.btn_note = QPushButton("＋ توجيه للمساعد")
        self.btn_note.setCursor(Qt.PointingHandCursor)
        self.btn_note.setFlat(True)
        self.btn_note.setStyleSheet("QPushButton { color:%s; font-weight:bold; border:none; background:transparent; padding:4px 8px; }"
                                    "QPushButton:hover { color:%s; text-decoration:underline; }" % (T.ACCENT, T.PRIMARY_DARK))
        self.btn_note.clicked.connect(self._toggle_note)
        ar.addWidget(self.btn_note)
        self.btn_alt = make_button("طريقة حساب بديلة", "info", "fa5s.sync-alt", soft=True)
        self.btn_alt.setToolTip("اقتراح طريقة حساب أخرى للحساب المحدد في القائمة")
        self.btn_alt.clicked.connect(lambda: self._suggest_calcs(True))
        ar.addWidget(self.btn_alt)
        self.btn_calcs = make_button("إنشاء الجداول والحسابات", "purple", "fa5s.magic")
        self.btn_calcs.clicked.connect(lambda: self._suggest_calcs(False))
        ar.addWidget(self.btn_calcs)
        al.addLayout(ar)
        self.ai_note = QPlainTextEdit()
        self.ai_note.setFixedHeight(66)
        self.ai_note.setPlaceholderText("توجيه اختياري (يقرّر الذكاء الاصطناعي بنفسه إن تركته فارغاً). "
                                        "مثال: أضف جدولاً يوضّح كذا، أو لا تُدرج جدول كذا.")
        self.ai_note.setVisible(False)
        al.addWidget(self.ai_note)
        outer.addWidget(ai)

        body = QHBoxLayout()
        body.setSpacing(14)
        outer.addLayout(body, 1)

        # ---- العمود الأيمن: قائمة العناصر مجمّعة حسب عناوين التقرير
        side = card()
        side.setMinimumWidth(330)
        side.setMaximumWidth(440)
        side.setMinimumHeight(540)
        sl = QVBoxLayout(side)
        hr = QHBoxLayout()
        hr.addWidget(heading("محتوى التقرير", 12))
        hr.addStretch(1)
        self.items_count = muted("")
        hr.addWidget(self.items_count)
        sl.addLayout(hr)
        sl.addWidget(muted("انقر على عنصر لمعاينته كاملاً، ونقراً مزدوجاً لفتحه في نافذة التحرير."))
        self.item_list = QTreeWidget()
        self.item_list.setHeaderHidden(True)
        self.item_list.setIndentation(14)
        self.item_list.setWordWrap(True)
        self.item_list.setUniformRowHeights(False)
        self.item_list.setStyleSheet("QTreeWidget::item { padding: 8px 4px; }")
        sl.addWidget(self.item_list, 1)
        r = QHBoxLayout()
        r.setSpacing(8)
        b_tab = make_button("جدول", "info", "fa5s.table", soft=True)
        b_tab.setToolTip("إضافة جدول فارغ تملؤه يدوياً")
        b_calc = make_button("حساب", "info", "fa5s.calculator", soft=True)
        b_calc.setToolTip("إضافة حساب بمعادلة")
        b_copy = make_button("نسخ", "secondary", "fa5s.copy", soft=True)
        b_del = make_button("حذف", "danger", "fa5s.trash", soft=True)
        grid = QGridLayout()
        grid.setSpacing(8)
        for n_, b in enumerate((b_tab, b_calc, b_copy, b_del)):
            grid.addWidget(b, n_ // 2, n_ % 2)
        sl.addLayout(grid)
        body.addWidget(side, 2)

        # ---- معاينة العنصر المحدد كاملاً (للقراءة) — التحرير في نافذة كبيرة مستقلة
        self.detail = QStackedWidget()
        self.detail.addWidget(self._items_empty())
        self.detail.addWidget(self._summary_card())
        self.detail.setMinimumHeight(540)
        body.addWidget(self.detail, 5)

        self.stack = QStackedWidget()
        self.stack.addWidget(self._calc_editor())
        self.stack.addWidget(self._table_editor())
        self.stack.addWidget(QWidget())
        self.stack.setCurrentIndex(2)
        self._dlg = _EditorDialog(self)
        self._dlg.host.addWidget(self.stack)
        self._calcs_tab = w
        self.tabs.addTab(_scroll(w, 1560), "الجداول والحسابات")

        self.item_list.currentItemChanged.connect(self._item_changed)
        self.item_list.itemDoubleClicked.connect(self._item_activated)
        self.item_list.itemActivated.connect(self._item_activated)
        b_copy.clicked.connect(self._item_copy)
        b_calc.clicked.connect(lambda: self._item_add("calc"))
        b_tab.clicked.connect(lambda: self._item_add("table"))
        b_del.clicked.connect(self._item_del)

    def _toggle_note(self):
        show = self.ai_note.isHidden()
        self.ai_note.setVisible(show)
        self.btn_note.setText("－ إخفاء التوجيه" if show else "＋ توجيه للمساعد")
        if show:
            self.ai_note.setFocus()

    def _items_empty(self):
        c = card()
        l = QVBoxLayout(c)
        l.addStretch(1)
        ic = QLabel()
        pm = _icon("fa5s.table", T.ACCENT)
        if pm is not None:
            ic.setPixmap(pm.pixmap(48, 48))
        ic.setAlignment(Qt.AlignCenter)
        l.addWidget(ic)
        t = heading("لا يوجد عنصر محدد", 13)
        t.setAlignment(Qt.AlignCenter)
        l.addWidget(t)
        self.empty_hint = muted("")
        self.empty_hint.setAlignment(Qt.AlignCenter)
        l.addWidget(self.empty_hint)
        b = make_button("إنشاء الجداول والحسابات بالذكاء الاصطناعي", "purple", "fa5s.magic")
        b.clicked.connect(lambda: self._suggest_calcs(False))
        l.addWidget(b, 0, Qt.AlignCenter)
        l.addStretch(2)
        return c

    # ---- بطاقة المعاينة الكاملة للعنصر المحدد
    def _summary_card(self):
        c = card()
        c.setMinimumHeight(540)
        l = QVBoxLayout(c)
        top = QHBoxLayout()
        self.s_kind = QLabel()
        top.addWidget(self.s_kind)
        top.addStretch(1)
        self.s_open = make_button("فتح وتحرير", "primary", "fa5s.expand-arrows-alt")
        self.s_open.setMinimumWidth(170)
        self.s_open.setToolTip("فتح العنصر في نافذة كبيرة للتحرير الكامل")
        self.s_open.clicked.connect(self._open_editor)
        top.addWidget(self.s_open)
        l.addLayout(top)
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setStyleSheet("color:%s;" % T.BORDER)
        l.addWidget(line)

        sa = QScrollArea()
        sa.setWidgetResizable(True)
        sa.setFrameShape(QFrame.NoFrame)
        sa.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        sa.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        inner = QWidget()
        inner.setObjectName("viewInner")
        inner.setStyleSheet("QWidget#viewInner { background: transparent; }")
        il = QVBoxLayout(inner)
        il.setContentsMargins(8, 12, 12, 12)
        il.setSpacing(18)

        self.s_title = QLabel()
        self.s_title.setWordWrap(True)
        self.s_title.setAlignment(Qt.AlignCenter)
        self.s_title.setStyleSheet("color:%s; background:transparent; font-weight:bold;" % T.PRIMARY_DARK)
        _scaled(self.s_title, 1.35)
        il.addWidget(self.s_title)
        self.s_section = muted()
        self.s_section.setAlignment(Qt.AlignCenter)
        il.addWidget(self.s_section)

        # صفحة الجدول: الجدول في الوسط ثم الملاحظة
        self.s_page_table = QWidget()
        tl = QVBoxLayout(self.s_page_table)
        tl.setContentsMargins(0, 0, 0, 0)
        tl.setSpacing(12)
        self.s_tbl = QTableWidget(0, 0)
        _style_view_table(self.s_tbl)
        tl.addWidget(_centered_row(self.s_tbl))
        self.s_note = QLabel("")
        self.s_note.setWordWrap(True)
        self.s_note.setAlignment(Qt.AlignCenter)
        self.s_note.setStyleSheet("background:transparent;")
        tl.addWidget(self.s_note)
        il.addWidget(self.s_page_table)

        # صفحة الحساب: الأساس القانوني، ثم الأرقام في جدول، ثم طريقة الحساب بنتيجتها
        self.s_page_calc = QWidget()
        cl = QVBoxLayout(self.s_page_calc)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(16)
        b1 = card()
        v1 = QVBoxLayout(b1)
        v1.addWidget(_section_head("طريقة الحساب والأساس القانوني", "fa5s.balance-scale"))
        self.s_method = QLabel()
        self.s_method.setWordWrap(True)
        self.s_method.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.s_method.setStyleSheet("background:%s; border-radius:12px; padding:14px 16px; color:%s;"
                                    % (T.SURFACE_ALT, T.TEXT))
        v1.addWidget(self.s_method)
        cl.addWidget(b1)
        b2 = card()
        v2 = QVBoxLayout(b2)
        v2.addWidget(_section_head("الأرقام المدخلة", "fa5s.list-ol"))
        self.s_inputs = QTableWidget(0, 4)
        self.s_inputs.setHorizontalHeaderLabels(["البند", "القيمة", "العملة", "المصدر"])
        _style_view_table(self.s_inputs)
        v2.addWidget(_centered_row(self.s_inputs))
        cl.addWidget(b2)
        b3 = card()
        v3 = QVBoxLayout(b3)
        v3.addWidget(_section_head("طريقة الحساب والنتيجة", "fa5s.calculator"))
        self.s_result = QLabel()
        self.s_result.setWordWrap(True)
        self.s_result.setTextFormat(Qt.RichText)
        self.s_result.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.s_result.setStyleSheet("background:%s; border-radius:12px; padding:14px 16px; color:%s;"
                                    % (T.TINT_INDIGO, T.TEXT))
        v3.addWidget(self.s_result)
        cl.addWidget(b3)
        il.addWidget(self.s_page_calc)
        il.addStretch(1)
        sa.setWidget(inner)
        l.addWidget(sa, 1)
        return c

    @staticmethod
    def _set_chip(label, text, bg, fg):
        label.setText(text)
        label.setAlignment(Qt.AlignCenter)
        label.setStyleSheet("background:%s; color:%s; border-radius:11px; padding:3px 14px; font-weight:bold;" % (bg, fg))

    def _show_summary(self, kind, it):
        import report_engine
        d = self.draft or {}
        titles = {x["id"]: x["title"] for x in d.get("sections", [])}
        sec = titles.get(it.get("section", ""))
        self.s_title.setText(it.get("title", ""))
        self.s_section.setText(("مرتبط بعنوان التقرير: " + sec) if sec else "غير مرتبط بعنوان — يُدرج في آخر التقرير")
        if kind == "table":
            self._set_chip(self.s_kind, "جدول", T.INFO_BG, T.INFO_FG)
            try:
                ev = report_engine.evaluate_table(it)
            except Exception:
                ev = {"columns": list(it.get("columns", [])),
                      "rows": [[str(v) for v in r] for r in it.get("rows", [])], "errors": []}
            cols, rows = ev["columns"], ev["rows"]
            t = self.s_tbl
            t.clear()
            t.setColumnCount(len(cols))
            t.setHorizontalHeaderLabels(cols)
            t.setRowCount(len(rows))
            for i, row in enumerate(rows):
                for j in range(len(cols)):
                    v = str(row[j]) if j < len(row) else ""
                    t.setItem(i, j, _cell_item(v, v == "#خطأ"))
            _autofit(t)
            errs = "\n".join(ev.get("errors", []))
            note = (it.get("note") or "").strip()
            if errs:
                self.s_note.setStyleSheet("color:%s; background:transparent;" % T.BAD_FG)
                self.s_note.setText(errs)
            else:
                self.s_note.setStyleSheet("color:%s; background:transparent;" % T.TEXT_MUTED)
                self.s_note.setText(("ملاحظة: " + note) if note else "")
            self.s_page_calc.setVisible(False)
            self.s_page_table.setVisible(True)
        else:
            self._set_chip(self.s_kind, "حساب بمعادلة", T.TINT_VIOLET, T.PURPLE)
            self.s_method.setText(it.get("method") or "— لم تُسجَّل طريقة الحساب بعد —")
            inputs = it.get("inputs", [])
            t = self.s_inputs
            t.clear()
            t.setHorizontalHeaderLabels(["البند", "القيمة", "العملة", "المصدر"])
            t.setRowCount(len(inputs))
            for i, inp in enumerate(inputs):
                val = inp.get("value", "")
                try:
                    if isinstance(val, (int, float)) and not isinstance(val, bool):
                        val = report_engine.fmt_num(val)
                except Exception:
                    pass
                vals = (inp.get("label") or inp.get("name", ""), val, inp.get("currency", ""), inp.get("source", ""))
                for j, v in enumerate(vals):
                    t.setItem(i, j, _cell_item(v))
            t.setColumnHidden(2, not any(str(i_.get("currency", "")).strip() for i_ in inputs))
            _autofit(t)
            try:
                self.s_result.setText(_steps_html(report_engine.compute_calc(it)))
            except Exception as e:
                self.s_result.setText("تعذّر الحساب: %s" % e)
            self.s_page_table.setVisible(False)
            self.s_page_calc.setVisible(True)

    def _show_empty(self):
        self.stack.setCurrentIndex(2)
        self.detail.setCurrentIndex(0)

    def _item_activated(self, li, _col=0):
        if li is not None and li.data(0, Qt.UserRole) is not None:
            self._open_editor()

    def _open_editor(self, *_):
        """يفتح العنصر المحدد في نافذة كبيرة للتحرير الكامل، ثم يحدّث القائمة والمعاينة عند الإغلاق."""
        ref = self._cur_item
        it = self._find_item(ref)
        if it is None:
            return
        ref = tuple(ref)
        self.stack.setCurrentIndex(0 if ref[0] == "calc" else 1)
        self._dlg.run(it.get("title", ""))
        self._commit_item()
        self._cur_item = None
        self._fill_items(ref)
        self._update_fx_banner()

    def _field(self, text):
        l = QLabel(text)
        l.setStyleSheet("font-weight:bold; color:%s; background:transparent;" % T.TEXT)
        return l

    def _collapsible(self, text):
        """زرّ يفتح/يطوي صندوق خيارات متقدمة (مطوي افتراضياً كي لا يزدحم المحرّر)."""
        btn = QPushButton("＋ " + text)
        btn.setCheckable(True)
        btn.setFlat(True)
        btn.setCursor(Qt.PointingHandCursor)
        btn.setStyleSheet("QPushButton { color:%s; font-weight:bold; border:none; background:transparent; padding:6px 10px; }"
                          "QPushButton:hover { color:%s; text-decoration:underline; }" % (T.ACCENT, T.PRIMARY_DARK))
        box = QFrame()
        box.setObjectName("advBox")
        box.setStyleSheet("QFrame#advBox { background:%s; border:1px dashed %s; border-radius:12px; }"
                          % (T.SURFACE_ALT, T.BORDER_STRONG))
        box.setVisible(False)
        lay = QVBoxLayout(box)
        lay.setContentsMargins(18, 14, 18, 14)
        lay.setSpacing(8)

        def tog(on):
            box.setVisible(on)
            btn.setText(("－ " if on else "＋ ") + text)
        btn.toggled.connect(tog)
        return btn, box, lay

    def _calc_editor(self):
        page = QWidget()
        l = QVBoxLayout(page)
        l.setContentsMargins(2, 2, 2, 2)
        l.setSpacing(16)

        # 1) طريقة الحساب والأساس القانوني
        c1 = card()
        v1 = QVBoxLayout(c1)
        v1.addWidget(_section_head("طريقة الحساب والأساس القانوني", "fa5s.balance-scale"))
        self.c_method = QPlainTextEdit()
        self.c_method.setMinimumHeight(130)
        v1.addWidget(self.c_method)
        l.addWidget(c1)

        # 2) الأرقام المدخلة: شريط الأزرار في صف مستقل فوق الجدول فلا يختلط به
        c2 = card()
        v2 = QVBoxLayout(c2)
        v2.addWidget(_section_head("الأرقام المدخلة", "fa5s.list-ol"))
        bar = QHBoxLayout()
        bar.setSpacing(10)
        b1 = make_button("إضافة رقم", "info", "fa5s.plus", soft=True)
        b2 = make_button("حذف الرقم المحدد", "danger", "fa5s.minus", soft=True)
        b3 = make_button("احسب", "success", "fa5s.calculator")
        bar.addWidget(b1)
        bar.addWidget(b2)
        bar.addStretch(1)
        bar.addWidget(b3)
        v2.addLayout(bar)
        v2.addWidget(muted("انقر نقراً مزدوجاً على أي خلية لتعديلها. الأرقام المنقولة من الوثائق تُكتب كما وردت."))
        self.c_tbl = QTableWidget(0, 7)
        self.c_tbl.setHorizontalHeaderLabels(["الاسم (لاتيني)", "الوصف", "القيمة", "المصدر (D1/R1)", "العملة",
                                              "تاريخ الواقعة", "سعر التحويل (إن ورد في وثيقة)"])
        self.c_tbl.setAlternatingRowColors(True)
        self.c_tbl.setWordWrap(True)
        self.c_tbl.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.c_tbl.horizontalHeader().setStretchLastSection(True)
        self.c_tbl.setMinimumHeight(290)
        v2.addWidget(self.c_tbl)
        l.addWidget(c2)

        # 3) طريقة الحساب بخطواتها ونتيجتها (تحت الجدول مباشرة)
        c3 = card()
        v3 = QVBoxLayout(c3)
        v3.addWidget(_section_head("طريقة الحساب والنتيجة", "fa5s.calculator"))
        self.c_result = QLabel("")
        self.c_result.setWordWrap(True)
        self.c_result.setTextFormat(Qt.RichText)
        self.c_result.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.c_result.setMinimumHeight(110)
        self.c_result.setStyleSheet("background:%s; border-radius:12px; padding:14px 16px; color:%s;" % (T.TINT_INDIGO, T.TEXT))
        v3.addWidget(self.c_result)
        l.addWidget(c3)

        # 4) خيارات متقدمة مطوية: اسم الحساب والعنوان المرتبط والمعادلة
        adv_btn, adv_box, al = self._collapsible("خيارات متقدمة: اسم الحساب، العنوان المرتبط، المعادلة")
        al.addWidget(self._field("اسم الحساب"))
        self.c_title = QLineEdit()
        al.addWidget(self.c_title)
        al.addWidget(self._field("العنوان المرتبط في التقرير"))
        self.c_section = QComboBox()
        al.addWidget(self.c_section)
        al.addWidget(self._field("المعادلة"))
        al.addWidget(muted("استعمل أسماء المتغيرات من جدول الأرقام مع العمليات + - * / ** والأقواس."))
        self.c_formula = QLineEdit()
        self.c_formula.setLayoutDirection(Qt.LeftToRight)
        al.addWidget(self.c_formula)
        l.addWidget(adv_btn, 0, Qt.AlignRight)
        l.addWidget(adv_box)
        l.addStretch(1)

        b1.clicked.connect(lambda: self._input_row("", "", "", "", "", "", ""))
        b2.clicked.connect(lambda: self.c_tbl.removeRow(self.c_tbl.currentRow()) if self.c_tbl.currentRow() >= 0 else None)
        b3.clicked.connect(self._calc_now)
        return page

    def _table_editor(self):
        page = QWidget()
        l = QVBoxLayout(page)
        l.setContentsMargins(2, 2, 2, 2)
        l.setSpacing(16)

        c1 = card()
        v1 = QVBoxLayout(c1)
        v1.addWidget(_section_head("بيانات الجدول", "fa5s.table"))
        bar = QHBoxLayout()
        bar.setSpacing(10)
        for text, kind, icon, fn in (("إضافة صف", "info", "fa5s.plus", self._t_add_row),
                                     ("إضافة عمود", "info", "fa5s.columns", self._t_add_col),
                                     ("حذف الصف", "danger", "fa5s.minus", self._t_del_row),
                                     ("حذف العمود", "danger", "fa5s.minus", self._t_del_col)):
            b = make_button(text, kind, icon, soft=True)
            b.clicked.connect(fn)
            bar.addWidget(b)
        bar.addStretch(1)
        v1.addLayout(bar)
        v1.addWidget(muted("حدّد خلية ثم أضف أو احذف صفاً أو عموداً عندها، وانقر نقراً مزدوجاً على عنوان عمود لتغيير اسمه. "
                           "الخلية التي تبدأ بـ = تُحسب تلقائياً، مثال: =C2*D2 أو =SUM(E1:E12) (A أول عمود، 1 أول صف بيانات). "
                           "للتحويل من عملة أجنبية: =FX(B2,\"EUR\",\"2020-03-01\")."))
        self.t_tbl = QTableWidget(0, 0)
        self.t_tbl.setMinimumHeight(340)
        self.t_tbl.setAlternatingRowColors(True)
        self.t_tbl.horizontalHeader().sectionDoubleClicked.connect(self._t_rename_col)
        v1.addWidget(self.t_tbl)
        l.addWidget(c1)

        # النتيجة بعد حساب الصيغ (تظهر تحت الجدول فقط إن وُجدت صيغ)
        self.t_prev_box = card()
        pl = QVBoxLayout(self.t_prev_box)
        self.t_prev_head = _section_head("النتيجة بعد الحساب (كما ستظهر في التقرير)", "fa5s.eye")
        pl.addWidget(self.t_prev_head)
        self.t_prev = QTableWidget(0, 0)
        _style_view_table(self.t_prev)
        pl.addWidget(_centered_row(self.t_prev))
        self.t_prev_err = QLabel("")
        self.t_prev_err.setWordWrap(True)
        self.t_prev_err.setStyleSheet("color:%s; background:transparent;" % T.BAD_FG)
        pl.addWidget(self.t_prev_err)
        l.addWidget(self.t_prev_box)

        c3 = card()
        v3 = QVBoxLayout(c3)
        v3.addWidget(_section_head("ملاحظة", "fa5s.sticky-note"))
        self.t_note = QLineEdit()
        v3.addWidget(self.t_note)
        l.addWidget(c3)

        adv_btn, adv_box, al = self._collapsible("خيارات متقدمة: عنوان الجدول، العنوان المرتبط في التقرير")
        al.addWidget(self._field("عنوان الجدول"))
        self.t_title = QLineEdit()
        al.addWidget(self.t_title)
        al.addWidget(self._field("العنوان المرتبط في التقرير"))
        self.t_section = QComboBox()
        al.addWidget(self.t_section)
        l.addWidget(adv_btn, 0, Qt.AlignRight)
        l.addWidget(adv_box)
        l.addStretch(1)

        self.t_tbl.itemChanged.connect(self._refresh_t_preview)
        return page

    def _refresh_t_preview(self, *_):
        """يعرض الجدول بعد حساب صيغه (الخلايا التي تبدأ بـ =)، ويُخفي المعاينة إن لم توجد صيغ."""
        if self._loading:
            return
        import report_engine
        raw = self._read_table({})
        has = any(str(v).startswith("=") for row in raw["rows"] for v in row)
        self.t_prev_box.setVisible(has)
        if not has:
            return
        ev = report_engine.evaluate_table(raw)
        self.t_prev.clear()
        self.t_prev.setColumnCount(len(ev["columns"]))
        self.t_prev.setHorizontalHeaderLabels(ev["columns"])
        self.t_prev.setRowCount(len(ev["rows"]))
        for i, row in enumerate(ev["rows"]):
            for j, v in enumerate(row):
                self.t_prev.setItem(i, j, _cell_item(v, v == "#خطأ"))
        _autofit(self.t_prev, 90, 340)
        self.t_prev_err.setText("\n".join(ev["errors"]))

    # ---- 4) المراجع والنماذج
    def _tab_refs(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 8, 0, 0)
        lay.setSpacing(14)
        c1 = card()
        l1 = QVBoxLayout(c1)
        l1.addWidget(heading("المراجع (قوانين وكتب)", 11))
        l1.addWidget(muted("يبحث الذكاء الاصطناعي في مراجعك أولاً ويستشهد بموادها، ويتحقق بنفسه من ترجمة المصطلحات "
                           "القانونية دون قاموس تدخله أنت."))
        self.ref_list = QListWidget()
        l1.addWidget(self.ref_list, 1)
        b = make_button("إضافة وإدارة المراجع", "primary", "fa5s.book")
        b.clicked.connect(self._open_refs)
        l1.addWidget(b, 0, Qt.AlignRight)
        lay.addWidget(c1, 2)
        c2 = card()
        l2 = QVBoxLayout(c2)
        l2.addWidget(heading("نماذج الغلاف والتقرير", 11))
        self.tpl_label = muted()
        l2.addWidget(self.tpl_label)
        b = make_button("إدارة النماذج", "primary", "fa5s.file-word")
        b.clicked.connect(self._open_templates)
        l2.addWidget(b, 0, Qt.AlignRight)
        lay.addWidget(c2, 1)
        self._refs_tab = self._centered(w, 1100)
        self.tabs.addTab(self._refs_tab, "المراجع والنماذج")

    # ---- 5) المراجعة والتحقق (النواقص + التعارضات + تنبيهات الأرقام + الأدلة)
    _NOTE_KINDS = (
        ("conflicts", "تعارضات وبدائل", "fa5s.random",
         "مواضع تعارضت فيها المصادر أو توجد فيها أكثر من طريقة مقبولة. اقرأ كل بند ثم قرّر أي الطرفين تعتمد "
         "وعدّل الجدول أو العنوان المعني."),
        ("audit", "تدقيق الوثائق (فحص حسابي)", "fa5s.calculator",
         "أخطاء حسابية داخل الوثائق نفسها (كمية×سعر، مجموع البنود، الرسم، الإجمالي)، وتعارض بين نسخ الوثيقة الواحدة، "
         "واختلاف قراءتَي صورة في رقم. افتح «تدقيق الوثائق وتأكيد المبالغ» وقارن بالأصل: ما كان خطأ قراءة صحّحه، "
         "وما كان خطأً في الوثيقة نفسها فهو من نتائج خبرتك."),
        ("legal", "الأساس القانوني (قرارك)", "fa5s.balance-scale",
         "المواد والنسب التي بنى عليها الذكاء الاصطناعي حساباته. يتحقق البرنامج أن المادة موجودة في المرجع وأن الرقم وارد فيه "
         "ومستعمل في الحساب، لكنه لا يحكم بانطباقها على قضيتك: اقرأ نص المادة في المرجع، فإن انطبقت اضغط «تمت المعالجة»، "
         "وإن لم تنطبق فعدّل الحساب أو اطلب طريقة بديلة."),
        ("warnings", "أرقام لم تُطابَق بمصدرها", "fa5s.exclamation-triangle",
         "رقم ورد في حساب أو جدول ولم يعثر البرنامج عليه في نص الوثيقة المذكورة كمصدر. افتح الوثيقة وتحقق منه "
         "وصحّحه أو غيّر مصدره."),
        ("missing", "نواقص يجب توفيرها", "fa5s.folder-open",
         "معلومة أو وثيقة لم يجدها الذكاء الاصطناعي ولا يمكنه التخمين بها. ارفع الوثيقة الناقصة أو أضف المرجع "
         "ثم أعد الاقتراح من خطوة الجداول."),
    )

    def _review_card(self, key, title, icon, hint):
        c = card()
        c.setMinimumHeight(240)
        v = QVBoxLayout(c)
        v.addWidget(_section_head(title, icon, 1.2))
        count = QLabel("0")
        count.setAlignment(Qt.AlignCenter)
        _scaled(count, 2.6, True)
        v.addWidget(count)
        v.addWidget(muted(hint))
        v.addStretch(1)
        btn = make_button("عرض التفاصيل", "primary", "fa5s.eye")
        btn.clicked.connect(lambda _=False, k=key: self._open_notes(k))
        v.addWidget(btn)
        self.note_heads[key] = (count, btn)
        return c

    def _evidence_card(self):
        c = card()
        c.setMinimumHeight(240)
        v = QVBoxLayout(c)
        v.addWidget(_section_head("الأدلة المعتمدة", "fa5s.quote-right", 1.2))
        self.ev_count = QLabel("0")
        self.ev_count.setAlignment(Qt.AlignCenter)
        self.ev_count.setStyleSheet("color:%s; background:transparent; font-weight:bold;" % T.ACCENT)
        _scaled(self.ev_count, 2.6, True)
        v.addWidget(self.ev_count)
        v.addWidget(muted("المقاطع من وثائق القضية ومراجعك التي استند إليها الذكاء الاصطناعي، وتحيل إليها الأرقام [D1] و[R1]."))
        v.addStretch(1)
        self.ev_btn = make_button("عرض الأدلة", "primary", "fa5s.eye")
        self.ev_btn.clicked.connect(self._open_evidence)
        v.addWidget(self.ev_btn)
        return c

    def _tab_review(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 8, 0, 0)
        lay.setSpacing(16)
        info = card()
        il = QHBoxLayout(info)
        il.addWidget(muted("هذه الصفحة للمراجعة فقط: يملؤها البرنامج تلقائياً عند اقتراح العناوين والجداول. "
                           "افتح كل بطاقة لقراءة بنودها كاملة، وعالج كل بند ثم اضغط «تمت المعالجة» ليختفي."), 1)
        b_audit = make_button("تدقيق الوثائق وتأكيد المبالغ", "primary", "fa5s.file-invoice-dollar")
        b_audit.clicked.connect(self._open_audit)
        il.addWidget(b_audit)
        b_verify = make_button("إعادة التحقق من الأرقام", "info", "fa5s.check-double", soft=True)
        b_verify.clicked.connect(self._reverify)
        il.addWidget(b_verify)
        lay.addWidget(info)

        grid = QGridLayout()
        grid.setSpacing(16)
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1)
        self.note_heads = {}
        for n_, (key, title, icon, hint) in enumerate(self._NOTE_KINDS):
            grid.addWidget(self._review_card(key, title, icon, hint), n_ // 2, n_ % 2)
        k = len(self._NOTE_KINDS)
        grid.addWidget(self._evidence_card(), k // 2, k % 2)
        lay.addLayout(grid)
        lay.addStretch(1)

        self._notes = {}
        self._ev_dlg = _EvidenceDialog(self)
        self.ev_list = self._ev_dlg.ev_list
        self.ev_text = self._ev_dlg.ev_text
        self.ev_list.currentRowChanged.connect(self._ev_row_changed)
        self._review_tab = _scroll(w, 1250)
        self.tabs.addTab(self._review_tab, "المراجعة والتحقق")

    # ---- 7) المعاينة والتصدير
    def _tab_preview(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 8, 0, 0)
        lay.setSpacing(12)
        bar = QHBoxLayout()
        bar.setSpacing(10)
        b_ref = make_button("تحديث المعاينة", "secondary", "fa5s.sync-alt", soft=True)
        b_cov = make_button("تصدير الغلاف (Word)", "info", "fa5s.file-word")
        b_rep = make_button("تصدير التقرير (Word)", "success", "fa5s.file-export")
        bar.addWidget(b_ref)
        bar.addStretch(1)
        bar.addWidget(b_cov)
        bar.addWidget(b_rep)
        lay.addLayout(bar)
        self.preview = QTextBrowser()
        self.preview.setStyleSheet("QTextBrowser { background:%s; border:1px solid %s; border-radius:12px; padding:18px; }"
                                   % (T.SURFACE, T.BORDER))
        lay.addWidget(self.preview, 1)
        b_ref.clicked.connect(self._refresh_preview)
        b_cov.clicked.connect(self._make_cover)
        b_rep.clicked.connect(self._make_report)
        self.tabs.addTab(self._centered(w, 1250), "المعاينة والتصدير")

    # ------------------------------------------------------------------ حالة عامة
    def _set_status(self, msg):
        self.status.setText(msg)

    def _set_busy(self, busy, msg=""):
        self.progress.setRange(0, 0 if busy else 1)
        for b in (self.btn_sync, self.btn_outline, self.btn_calcs, self.btn_alt, self.case_box, self.ai_note):
            b.setEnabled(not busy)
        if msg:
            self.status.setText(msg)

    def _run(self, fn, on_done, msg):
        if self._task is not None:
            return
        self._commit()
        self._set_busy(True, msg)
        t = _Task(fn, self)
        self._task = t
        t.progress.connect(self._set_status)
        t.done.connect(lambda res, err: self._finished(on_done, res, err))
        t.start()

    def _finished(self, on_done, res, err):
        self._task = None
        self._set_busy(False)
        if err:
            self.status.setText("تعذّرت العملية.")
            show_warning(self, "الذكاء الاصطناعي", err)
            return
        try:
            on_done(res)
        except Exception as e:
            show_warning(self, "خطأ", str(e))

    def _confirm_ai(self):
        n = self._case_number()
        if n in self._consented:
            return True
        ok = show_confirm(self, "الذكاء الاصطناعي",
                          "سيُرسل نص النبذة والمهام ونصوص وثائق القضية كاملة (للاستخراج والتدقيق) ومقاطع من المراجع إلى خدمة الذكاء "
                          "الاصطناعي، وتُرسل صور الوثائق الممسوحة لقراءتها (مرتين). أسماء الأطراف تُخفى في النصوص "
                          "ولا يمكن إخفاؤها داخل الصور. أتابع؟")
        if ok:
            self._consented.add(n)
        return ok

    # ------------------------------------------------------------------ القضايا
    def _case_number(self):
        return self.case_box.currentData() or ""

    def reload(self):
        """يُستدعى عند فتح التبويب: يحدّث قائمة القضايا ويحافظ على المحددة."""
        new, labels = [], {}
        for c in storage.load_cases():
            n = str(c.get("case_number", "")).strip()
            if n:
                new.append(n)
                labels[n] = "%s — %s / %s" % (n, c.get("plaintiff", ""), c.get("defendant", ""))
        old = [self.case_box.itemData(i) for i in range(self.case_box.count())]
        if old == new:
            return
        cur = self.case_box.currentData()
        self.case_box.blockSignals(True)
        self.case_box.clear()
        for n in new:
            self.case_box.addItem(labels[n], n)
        i = self.case_box.findData(cur)
        self.case_box.setCurrentIndex(i if i >= 0 else 0)
        self.case_box.blockSignals(False)
        self._case_changed()

    def select_case(self, case_number):
        """يفتح الصفحة على قضية محددة (من زر في صفحة القضايا)."""
        self.reload()
        if case_number is None:
            return
        i = self.case_box.findData(str(case_number).strip())
        if i >= 0:
            self.case_box.setCurrentIndex(i)

    def _case_changed(self):
        import report_engine
        self._save()
        n = self._case_number()
        d = report_engine.load_draft(n) if n else None
        self.draft = report_engine.ensure_ids(d) if d else None
        self._fill_case_file()
        self._populate()
        self.status.setText("مسودة محفوظة لهذه القضية." if self.draft else
                            "لا توجد مسودة بعد: ابدأ من تبويب «هيكل التقرير» ثم اقتراح العناوين.")

    def _ensure_draft(self):
        import report_engine
        if self.draft is None:
            self.draft = report_engine.new_draft(self._case_number())
        return self.draft

    def _tab_changed(self, i):
        self._commit()
        if i == self.tabs.count() - 1:
            self._refresh_preview()
        elif self.tabs.widget(i) is self._refs_tab:
            self._fill_refs()

    def _open_case_page(self):
        try:
            self.main_app.tabs.setCurrentWidget(self.case_page)
        except Exception:
            show_info(self, "القضايا", "افتح صفحة «القضايا» من القائمة الجانبية لتعديل النبذة والمهام.")

    # ------------------------------------------------------------------ تبويب ملف القضية
    def _read_full(self, kind):
        """نافذة قراءة مريحة للنص الكامل (النبذة أو كل المهام)."""
        if kind == "summary":
            title = "نبذة عن القضية"
            paras = [p.strip() for p in self._full_summary.replace("\r", "").split("\n") if p.strip()]
            body = "".join('<p style="margin:0 0 14px 0;">%s</p>' % _html.escape(p) for p in paras)
        else:
            title = "المهام المطلوبة من الخبير"
            body = "".join('<p style="margin:0 0 14px 0;"><span style="color:%s;">●</span>&nbsp; %s</p>'
                           % (T.ACCENT, _html.escape(x)) for x in _split_items(self._full_tasks))
        if not body:
            return
        _ReadDialog(title, '<div dir="rtl" style="line-height:175%; font-size:11pt;">' + body + "</div>", self).exec_()

    def _set_case_texts(self, summary, tasks):
        self._full_summary = (summary or "").strip()
        self._full_tasks = (tasks or "").strip()
        muted_css = '<span style="color:%s;">%s</span>'
        # النبذة: مقتطف نظيف بدل جدار نص
        if self._full_summary:
            txt, cut_ = _elide(self._full_summary, 420)
            self.case_summary.setText(_RTL_OPEN + _html.escape(txt) + "</div>")
            self.btn_more_sum.setVisible(cut_ or "\n" in self._full_summary)
        else:
            self.case_summary.setText(_RTL_OPEN + muted_css % (T.TEXT_MUTED, "لا توجد نبذة لهذه القضية بعد. أضفها من صفحة القضايا.") + "</div>")
            self.btn_more_sum.setVisible(False)
        # المهام: أول أربع مهام كنقاط مرتّبة + عدّاد الباقي
        items = _split_items(self._full_tasks)
        if items:
            shown, any_cut = items[:4], False
            html_rows = []
            for x in shown:
                t, c_ = _elide(x, 130)
                any_cut = any_cut or c_
                html_rows.append('<div style="margin-bottom:8px;"><span style="color:%s;">●</span>&nbsp; %s</div>'
                                 % (T.ACCENT, _html.escape(t)))
            if len(items) > len(shown):
                html_rows.append(muted_css % (T.TEXT_MUTED, "+ %d مهام أخرى" % (len(items) - len(shown))))
            self.case_tasks.setText(_RTL_OPEN + "".join(html_rows) + "</div>")
            self.btn_more_tasks.setText("عرض كل المهام (%d)" % len(items))
            self.btn_more_tasks.setVisible(len(items) > len(shown) or any_cut)
        else:
            self.case_tasks.setText(_RTL_OPEN + muted_css % (T.TEXT_MUTED, "لا توجد مهام مسجّلة بعد. أضفها من صفحة القضايا.") + "</div>")
            self.btn_more_tasks.setVisible(False)

    def _fill_case_file(self):
        n = self._case_number()
        self.docs_tbl.setRowCount(0)
        _clear_layout(self.docs_stats)
        if not n:
            self.case_title.setText("")
            self.case_meta.setText("")
            self._set_case_texts("", "")
            return
        try:
            import word_cover
            ctx = word_cover.build_case_context(n)
        except Exception as e:
            self.case_title.setText("القضية رقم %s" % n)
            self.case_meta.setText("تعذّرت قراءة بيانات القضية: %s" % e)
            return
        self.case_title.setText("القضية رقم %s" % n)
        self.case_meta.setText("%s / %s" % (ctx.get("plaintiff", ""), ctx.get("defendant", "")))
        self._set_case_texts(ctx.get("summary"), ctx.get("tasks"))
        self._fill_docs()

    def _fill_docs(self):
        n = self._case_number()
        self.docs_tbl.setRowCount(0)
        _clear_layout(self.docs_stats)
        try:
            import rag_index
            docs = [d for d in storage.load_documents() if str(d.get("case", "")).strip() == n]
            idx = {r[0]: r for r in rag_index.case_index().list_sources()}
            keyf = rag_index._doc_key
        except Exception as e:
            self.docs_tbl.setRowCount(1)
            self.docs_tbl.setItem(0, 0, QTableWidgetItem("تعذّر قراءة الوثائق: %s" % e))
            self._fit_docs()
            return
        if not docs:
            self.docs_tbl.setRowCount(1)
            self.docs_tbl.setSpan(0, 0, 1, 4)
            it = QTableWidgetItem("لا توجد وثائق مرفوعة لهذه القضية بعد.")
            it.setFlags(Qt.NoItemFlags)
            it.setTextAlignment(Qt.AlignCenter)
            it.setForeground(QColor(T.TEXT_MUTED))
            self.docs_tbl.setItem(0, 0, it)
            self._fit_docs()
            return
        ok = todo = bad = 0
        for d in docs:
            r = self.docs_tbl.rowCount()
            self.docs_tbl.insertRow(r)
            row = idx.get(keyf(d))
            tip = ""
            if row is None:
                st, chunks, col = "●  لم تُحلَّل بعد", "—", T.WARN_FG
                todo += 1
            elif row[5] == "ok":
                st, chunks, col = "●  مقروءة ومفهرسة", str(row[3]), T.OK_FG
                ok += 1
            else:
                st, chunks, col = "●  تعذّرت القراءة", "0", T.BAD_FG
                tip = "تعذّرت قراءة النص: صورة غير واضحة أو لا يوجد اتصال بخدمة الذكاء الاصطناعي. أعد التحليل لاحقاً."
                bad += 1
            name = d.get("original_name") or d.get("filename", "")
            vals = (name, d.get("party", ""), st, chunks)
            for j, v in enumerate(vals):
                it = QTableWidgetItem(str(v))
                if j == 0:
                    it.setToolTip(str(name))
                if j == 2:
                    it.setForeground(QColor(col))
                    if tip:
                        it.setToolTip(tip)
                self.docs_tbl.setItem(r, j, it)
        self._fit_docs()
        self.docs_stats.addWidget(chip("%d وثيقة" % len(docs), T.NEUTRAL_BG, T.NEUTRAL_FG))
        if ok:
            self.docs_stats.addWidget(chip("%d مقروءة" % ok, T.OK_BG, T.OK_FG))
        if todo:
            self.docs_stats.addWidget(chip("%d بانتظار التحليل" % todo, T.WARN_BG, T.WARN_FG))
        if bad:
            self.docs_stats.addWidget(chip("%d تعذّرت" % bad, T.BAD_BG, T.BAD_FG))

    def _fit_docs(self):
        """يضبط ارتفاع جدول الوثائق على عدد صفوفه ليظهر دائماً كاملاً، ويتولّى تمرير الصفحة التمرير."""
        t = self.docs_tbl
        hh = t.horizontalHeader()
        head_h = hh.height() if hh.height() > 0 else hh.sizeHint().height()
        rows_h = sum(t.rowHeight(i) for i in range(t.rowCount()))
        t.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        t.setFixedHeight(max(190, head_h + rows_h + t.frameWidth() * 2 + 8))

    def _sync_docs(self):
        if not self._confirm_ai():
            return

        def work(say):
            import rag_index
            return rag_index.sync_case_documents(
                progress=lambda i, n, name: say("قراءة الوثيقة %d من %d: %s" % (i, n, name)))

        def done(rep):
            bad = sum(1 for _, r in rep if r["status"] in ("no_text", "error"))
            self._fill_docs()
            self.status.setText("تم تحليل %d وثيقة%s." % (len(rep), ("، تعذّرت قراءة %d منها" % bad) if bad else ""))
        self._run(work, done, "جارٍ تحليل الوثائق وقراءتها...")

    # ------------------------------------------------------------------ تعبئة الواجهة
    def _populate(self):
        d = self.draft or {}
        self._cur_sec, self._cur_item = -1, None
        self._fill_sections()
        self._fill_items()
        self.ev_list.clear()
        for e in d.get("evidence", []):
            self.ev_list.addItem("[%s] %s%s" % (e["id"], e["title"], (" ص %s" % e["page"]) if e["page"] else ""))
        self.ev_text.setPlainText("")
        self._update_ev_card()
        self._fill_notes()
        self._clear_sec()
        self._show_empty()
        self._fill_section_combos()
        self._update_fx_banner()
        self._fill_refs()
        if self.sec_list.count():
            self.sec_list.setCurrentRow(0)

    def _fill_notes(self):
        d = self.draft or {}
        if d.get("case_number"):
            try:
                import report_engine
                d["audit"] = report_engine.audit_notes(d)      # من نتائج الفحص المخزّنة (دون ما عالجه الخبير)
                d["legal"] = report_engine.legal_notes(d)      # فحص الأساس القانوني لكل حساب وجدول
            except Exception:
                pass
        total = 0
        self._notes = {}
        for key, title, icon, _hint in self._NOTE_KINDS:
            items = [str(x) for x in d.get(key, [])]
            self._notes[key] = items
            count, btn = self.note_heads[key]
            count.setText(str(len(items)))
            col = (T.ACCENT if key == "conflicts" else T.WARN_FG) if items else T.OK_FG
            count.setStyleSheet("color:%s; background:transparent; font-weight:bold;" % col)
            btn.setEnabled(bool(items))
            btn.setText("عرض التفاصيل" if items else "لا يوجد ما يحتاج معالجة")
            total += len(items)
        idx = self.tabs.indexOf(self._review_tab)
        if idx >= 0:
            self.tabs.setTabText(idx, "المراجعة والتحقق" + ((" (%d)" % total) if total else ""))

    def _open_notes(self, key):
        meta = next(m for m in self._NOTE_KINDS if m[0] == key)
        items = list(self._notes.get(key, []))
        if not items:
            return
        dlg = _NotesDialog(key, meta[1], meta[3], meta[2], items, self)
        dlg.resolved.connect(self._note_resolved)
        dlg.exec_()
        self._fill_notes()

    def _note_resolved(self, key, txt):
        d = self.draft
        if d and txt in d.get(key, []):
            d[key].remove(txt)
            if key in ("audit", "legal"):
                d.setdefault(key + "_resolved", []).append(txt)
            self.status.setText("أُزيل البند بعد معالجته.")
        self._fill_notes()

    def _open_audit(self):
        """يشغّل تدقيق وثائق القضية (المخزَّن لا يُعاد) ثم يفتح شاشة المطابقة والتأكيد."""
        import report_engine
        n = self._case_number()
        if not n:
            show_info(self, "تدقيق الوثائق", "اختر قضية أولاً.")
            return
        if not self._confirm_ai():
            return
        self._ensure_draft()

        def work(say):
            import doc_audit
            import word_cover
            import rag_index
            ctx = word_cover.build_case_context(n)
            anon = report_engine._Anonymizer([ctx.get("plaintiff"), ctx.get("defendant")])
            idx = rag_index.case_index()
            skipped = report_engine._index_case(n, idx, say)      # يفهرس ما لم يُفهرس بعد ويُبلّغ عمّا تعذّرت قراءته
            return doc_audit.audit_case(n, idx, None, anon, say, skipped=skipped)

        def done(r):
            d = self._ensure_draft()
            d["warnings"] = report_engine.verify_inputs(d)
            self._fill_notes()
            if r.get("failed"):
                show_warning(self, "وثائق لم تُستخرج", "تعذّر استخراج:\n• " + "\n• ".join(r["failed"]) +
                             "\nيمكنك إعادة المحاولة لاحقاً (الوثائق الناجحة محفوظة).")
            self.status.setText("دُقّقت %d وثيقة مالية؛ ما زال %d بنداً بحاجة إلى مراجعتك." % (r.get("docs", 0), len(r.get("issues", []))))
            if r.get("docs"):
                from audit_dialog import AuditDialog
                AuditDialog(n, self).exec_()
                d["warnings"] = report_engine.verify_inputs(d)
                self._fill_notes()
            else:
                show_info(self, "تدقيق الوثائق", "لا توجد في وثائق هذه القضية وثيقة مالية مقروءة (فواتير، كشوف، تصريحات...).\n"
                          "إن كانت الوثائق صوراً فتأكد من تفعيل الفهرسة ومن اكتمال قراءتها في تبويب «ملف القضية».")
        self._run(work, done, "جارٍ تدقيق وثائق القضية (استخراج الأرقام وفحصها حسابياً)...")

    def _open_evidence(self):
        if self.ev_list.count() and self.ev_list.currentRow() < 0:
            self.ev_list.setCurrentRow(0)
        self._ev_dlg.exec_()

    def _update_ev_card(self):
        n = self.ev_list.count()
        self.ev_count.setText(str(n))
        self.ev_btn.setEnabled(n > 0)
        self.ev_btn.setText("عرض الأدلة" if n else "لا توجد أدلة بعد")

    def _reverify(self):
        import report_engine
        if not self.draft:
            return
        self._commit()
        self.draft["warnings"] = report_engine.verify_inputs(self.draft)
        self._fill_notes()
        n = len(self.draft["warnings"])
        self.status.setText("أرقام غير مطابقة لمصدرها: %d." % n if n else "كل الأرقام مطابقة لنص مصادرها.")

    def _ev_row_changed(self, row):
        ev = (self.draft or {}).get("evidence", [])
        self.ev_text.setPlainText(ev[row]["text"] if 0 <= row < len(ev) else "")

    # ------------------------------------------------------------------ العناوين
    @staticmethod
    def _sec_text(s):
        return ("✔  " if s.get("status", "approved") == "approved" else "○  ") + s["title"]

    def _fill_sections(self, keep=-1):
        self._loading = True
        self.sec_list.clear()
        for s in (self.draft or {}).get("sections", []):
            ok = s.get("status", "approved") == "approved"
            it = QListWidgetItem(self._sec_text(s))
            it.setForeground(QColor(T.OK_FG if ok else T.WARN_FG))
            self.sec_list.addItem(it)
        self._loading = False
        if 0 <= keep < self.sec_list.count():
            self.sec_list.setCurrentRow(keep)

    def _clear_sec(self):
        self.sec_title.clear()
        self.sec_body.clear()
        self.sec_src.setText("")
        self.sec_badge.setText("")
        self.sec_badge.setStyleSheet("")

    def _sec_row_changed(self, row):
        if self._loading:
            return
        self._commit_sec()
        self._cur_sec = row
        secs = (self.draft or {}).get("sections", [])
        if 0 <= row < len(secs):
            import report_engine
            s = secs[row]
            self.sec_title.setText(s["title"])
            self.sec_body.setPlainText(s.get("body", ""))
            labels = "؛ ".join(report_engine.source_label(self.draft, x) for x in s.get("sources", []))
            self.sec_src.setText("المصادر: " + labels if labels else "")
            txt, bg, fg = BADGE.get(s.get("status", "approved"), BADGE["approved"])
            self.sec_badge.setText(txt)
            self.sec_badge.setStyleSheet("background:%s; color:%s; border-radius:10px; padding:3px 12px; font-weight:bold;"
                                         % (bg, fg))
        else:
            self._clear_sec()

    def _commit_sec(self):
        secs = (self.draft or {}).get("sections", [])
        if 0 <= self._cur_sec < len(secs):
            s = secs[self._cur_sec]
            s["title"] = self.sec_title.text().strip() or s["title"]
            s["body"] = self.sec_body.toPlainText()
            it = self.sec_list.item(self._cur_sec)
            if it:
                it.setText(self._sec_text(s))

    def _sec_add(self):
        import report_engine
        self._commit_sec()
        d = self._ensure_draft()
        d["sections"].append({"id": report_engine._next_id(d["sections"], "S"), "title": "عنوان جديد", "body": "",
                              "sources": [], "status": "approved", "section": ""})
        self._cur_sec = -1
        self._fill_sections(len(d["sections"]) - 1)
        self._fill_section_combos()

    def _sec_del(self):
        row = self.sec_list.currentRow()
        secs = (self.draft or {}).get("sections", [])
        if 0 <= row < len(secs):
            sid = secs[row]["id"]
            del secs[row]
            for coll in ("calculations", "tables"):
                for it in self.draft[coll]:
                    if it.get("section") == sid:
                        it["section"] = ""
            self._cur_sec = -1
            self._clear_sec()
            self._fill_sections(min(row, len(secs) - 1))
            self._fill_section_combos()
            self._fill_items(self._cur_item)

    def _sec_move(self, delta):
        self._commit_sec()
        row = self.sec_list.currentRow()
        secs = (self.draft or {}).get("sections", [])
        j = row + delta
        if 0 <= row < len(secs) and 0 <= j < len(secs):
            secs[row], secs[j] = secs[j], secs[row]
            self._cur_sec = -1
            self._fill_sections(j)
            self._fill_section_combos()

    def _sec_approve(self, everything):
        self._commit_sec()
        secs = (self.draft or {}).get("sections", [])
        rows = range(len(secs)) if everything else [self.sec_list.currentRow()]
        n = 0
        for r in rows:
            if 0 <= r < len(secs) and secs[r].get("status") != "approved":
                secs[r]["status"] = "approved"
                n += 1
        cur = self.sec_list.currentRow()
        self._cur_sec = -1
        self._fill_sections(cur)
        self._fill_section_combos()
        self.status.setText("تم اعتماد %d عنوان وإدراجها في هيكل التقرير؛ يمكنك الآن طلب الحسابات المرتبطة بها." % n
                            if n else "لا توجد عناوين مقترحة للاعتماد.")

    def _suggest_outline(self):
        n = self._case_number()
        if not n or not self._confirm_ai():
            return
        self._commit()
        keep_ev = bool(self.draft and self.draft.get("evidence") and
                       (self.draft.get("calculations") or self.draft.get("tables")))
        old_ev = copy.deepcopy(self.draft["evidence"]) if keep_ev else None
        old_plan = copy.deepcopy(self.draft.get("plan", {})) if keep_ev else None

        def work(say):
            import report_engine
            import word_cover
            if keep_ev:                                   # المعرّفات مرتبطة بالأدلة الحالية: لا نغيّرها
                ctx = word_cover.build_case_context(n)
                evidence, plan = old_ev, old_plan
                anon = report_engine._Anonymizer([ctx.get("plaintiff"), ctx.get("defendant")])
            else:
                ctx, plan, evidence, anon = report_engine.prepare_evidence(n, progress=say)
            say("كتابة العناوين المقترحة حسب المهام ونبذة القضية...")
            secs, missing, conflicts = report_engine.suggest_outline(ctx, evidence, anon=anon)
            return {"plan": plan, "evidence": evidence, "sections": secs, "missing": missing, "conflicts": conflicts}

        def done(r):
            import report_engine
            d = self._ensure_draft()
            d["plan"], d["evidence"] = r["plan"], r["evidence"]
            d["sections"] = [s for s in d["sections"] if s.get("status", "approved") == "approved"]
            for s in r["sections"]:
                s["id"] = report_engine._next_id(d["sections"], "S")
                s["section"] = ""
                d["sections"].append(s)
            d["missing"] = list(dict.fromkeys(d.get("missing", []) + r["missing"]))
            d["conflicts"] = list(dict.fromkeys(d.get("conflicts", []) + r["conflicts"]))
            report_engine.save_draft(d)
            self._populate()
            self.status.setText("اقترح الذكاء الاصطناعي %d عنواناً. راجعها واعتمد ما يناسبك (✔ معتمد، ○ مقترح)." % len(r["sections"]))
            self.tabs.setCurrentWidget(self._outline_tab)
        self._run(work, done, "جارٍ إعداد هيكل التقرير...")

    # ------------------------------------------------------------------ الحسابات والجداول
    def _fill_section_combos(self):
        secs = (self.draft or {}).get("sections", [])
        for cb in (self.c_section, self.t_section):
            cur = cb.currentData()
            cb.blockSignals(True)
            cb.clear()
            cb.addItem("— غير مرتبط بعنوان (يُدرج في آخر التقرير) —", "")
            for s in secs:
                cb.addItem(s["title"] + ("" if s.get("status", "approved") == "approved" else " (غير معتمد)"), s["id"])
            cb.setCurrentIndex(max(cb.findData(cur), 0))
            cb.blockSignals(False)

    def _items(self):
        d = self.draft or {}
        return [("calc", c) for c in d.get("calculations", [])] + [("table", t) for t in d.get("tables", [])]

    def _item_text(self, kind, it):
        return it["title"]

    def _fill_items(self, select=None):
        """القائمة شجرة: عناوين التقرير كمجموعات، وتحت كل عنوان جداوله وحساباته بأيقونة النوع."""
        d = self.draft or {}
        self._loading = True
        self.item_list.clear()
        sel_item = None
        groups = {}

        def group(sec_id, title):
            if sec_id not in groups:
                g = QTreeWidgetItem([title])
                g.setFlags(Qt.ItemIsEnabled)
                f = g.font(0)
                f.setBold(True)
                g.setFont(0, f)
                g.setForeground(0, QColor(T.PRIMARY_DARK))
                self.item_list.addTopLevelItem(g)
                groups[sec_id] = g
            return groups[sec_id]

        titles = {s["id"]: s["title"] for s in d.get("sections", [])}
        for s_ in d.get("sections", []):               # ترتيب العناوين كما في التقرير
            if any(x.get("section") == s_["id"] for _k, x in self._items()):
                group(s_["id"], s_["title"])
        n = 0
        for kind, it in self._items():
            sec = it.get("section") if it.get("section") in titles else ""
            g = group(sec, titles.get(sec, "غير مرتبط بعنوان (يُدرج في آخر التقرير)"))
            li = QTreeWidgetItem([it["title"]])
            li.setData(0, Qt.UserRole, (kind, it["id"]))
            ic = _icon("fa5s.table" if kind == "table" else "fa5s.calculator", T.ACCENT)
            if ic is not None:
                li.setIcon(0, ic)
            li.setToolTip(0, "جدول" if kind == "table" else "حساب بمعادلة")
            g.addChild(li)
            n += 1
            if select == (kind, it["id"]):
                sel_item = li
        self.item_list.expandAll()
        self._loading = False
        self.items_count.setText("%d عنصر" % n if n else "")
        self.btn_calcs.setText("تحديث حسب المستجدات" if n else "إنشاء الجداول والحسابات")
        self.empty_hint.setText(
            "اختر جدولاً أو حساباً من القائمة لتعديله، أو اطلب من المساعد تحديثها بعد تغيير النبذة أو المهام أو الوثائق."
            if n else
            "لا توجد جداول بعد. اضغط الزر ليدرس الذكاء الاصطناعي القضية ويصمّم جداولها وحساباتها، أو أضف جدولاً يدوياً "
            "من الأسفل. (يلزم أولاً اعتماد عناوين التقرير من تبويب «هيكل التقرير».)")
        if sel_item is not None:
            self.item_list.setCurrentItem(sel_item)
        else:
            self._show_empty()

    def _find_item(self, ref):
        if not ref or not self.draft:
            return None
        coll = self.draft["calculations" if ref[0] == "calc" else "tables"]
        return next((x for x in coll if x["id"] == ref[1]), None)

    def _item_changed(self, cur, _prev):
        if self._loading:
            return
        self._commit_item()
        ref = cur.data(0, Qt.UserRole) if cur is not None else None
        self._cur_item = ref
        it = self._find_item(ref)
        if it is None:
            self._show_empty()
            return
        if ref[0] == "calc":
            self._show_calc(it)
            self.stack.setCurrentIndex(0)
        else:
            self._show_table(it)
            self.stack.setCurrentIndex(1)
        self._show_summary(ref[0], it)
        self.detail.setCurrentIndex(1)

    @staticmethod
    def _plain(v):
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            return "%d" % v if float(v).is_integer() else repr(float(v))
        return v

    def _input_row(self, name, label, value, source, currency="", date="", rate=""):
        r = self.c_tbl.rowCount()
        self.c_tbl.insertRow(r)
        for j, v in enumerate((name, label, value, source, currency, date, rate)):
            self.c_tbl.setItem(r, j, QTableWidgetItem(str(v)))

    def _show_calc(self, c):
        self.c_title.setText(c["title"])
        self.c_section.setCurrentIndex(max(self.c_section.findData(c.get("section", "")), 0))
        self.c_method.setPlainText(c.get("method", ""))
        self.c_formula.setText(c["formula"])
        self.c_tbl.setRowCount(0)
        for i in c["inputs"]:
            self._input_row(i["name"], i.get("label", ""), self._plain(i["value"]), i.get("source", ""),
                            i.get("currency", ""), i.get("rate_date", ""), self._plain(i.get("rate", "")))
        _clamp_cols(self.c_tbl, 120, 380)
        self.c_tbl.horizontalHeader().setStretchLastSection(True)
        self._render_c_result(c)

    def _render_c_result(self, c):
        import report_engine
        try:
            self.c_result.setText(_steps_html(report_engine.compute_calc(c)))
        except Exception as e:
            self.c_result.setText("تعذّر الحساب: %s" % e)

    def _read_calc(self, base):
        import report_engine
        valid = {e["id"] for e in (self.draft or {}).get("evidence", [])}
        prev = {i["name"]: i for i in base.get("inputs", [])}
        inputs = []
        for r in range(self.c_tbl.rowCount()):
            if not _cell(self.c_tbl, r, 0):
                continue
            try:
                value = report_engine.to_number(_cell(self.c_tbl, r, 2))
            except ValueError:
                value = _cell(self.c_tbl, r, 2)
            src = _cell(self.c_tbl, r, 3)
            item = {"name": _cell(self.c_tbl, r, 0), "label": _cell(self.c_tbl, r, 1) or _cell(self.c_tbl, r, 0),
                    "value": value, "source": src if src in valid else "",
                    "currency": _cell(self.c_tbl, r, 4), "rate_date": _cell(self.c_tbl, r, 5)}
            rate_txt = _cell(self.c_tbl, r, 6)
            if rate_txt:                                  # سعر تحويل وارد في وثيقة: يُعتمد بدل جدول الأسعار
                try:
                    item["rate"] = report_engine.to_number(rate_txt)
                except ValueError:
                    item["rate"] = rate_txt
            p = prev.get(item["name"])
            if p and "verified" in p and p.get("value") == value and p.get("source") == item["source"]:
                item["verified"] = p["verified"]
            inputs.append(item)
        return {"title": self.c_title.text().strip() or base.get("title", "حساب"),
                "section": self.c_section.currentData() or "", "method": self.c_method.toPlainText().strip(),
                "formula": self.c_formula.text().strip(), "inputs": inputs}

    def _show_table(self, t):
        self.t_title.setText(t["title"])
        self.t_section.setCurrentIndex(max(self.t_section.findData(t.get("section", "")), 0))
        self.t_note.setText(t.get("note", ""))
        cols = t["columns"]
        self._loading = True                           # لا نحسب المعاينة أثناء التعبئة خلية خلية
        self.t_tbl.setColumnCount(len(cols))
        self.t_tbl.setHorizontalHeaderLabels(cols)
        self.t_tbl.setRowCount(len(t["rows"]))
        for i, row in enumerate(t["rows"]):
            for j in range(len(cols)):
                self.t_tbl.setItem(i, j, QTableWidgetItem(str(row[j]) if j < len(row) else ""))
        _clamp_cols(self.t_tbl, 100, 360)
        self._loading = False
        self._refresh_t_preview()

    def _read_table(self, base):
        cols = []
        for j in range(self.t_tbl.columnCount()):
            h = self.t_tbl.horizontalHeaderItem(j)
            cols.append(h.text() if h else "عمود %d" % (j + 1))
        rows = [[_cell(self.t_tbl, i, j) for j in range(len(cols))] for i in range(self.t_tbl.rowCount())]
        return {"title": self.t_title.text().strip() or base.get("title", "جدول"),
                "section": self.t_section.currentData() or "", "columns": cols, "rows": rows,
                "note": self.t_note.text().strip()}

    def _t_add_row(self):
        r = self.t_tbl.currentRow()
        self.t_tbl.insertRow(r + 1 if r >= 0 else self.t_tbl.rowCount())     # بعد الصف المحدد، وإلا في النهاية
        self._refresh_t_preview()

    def _t_add_col(self):
        name, ok = QInputDialog.getText(self, "عمود جديد", "اسم العمود :")
        if ok and name.strip():
            c = self.t_tbl.currentColumn()
            j = c + 1 if c >= 0 else self.t_tbl.columnCount()                 # بعد العمود المحدد، وإلا في النهاية
            self.t_tbl.insertColumn(j)
            self.t_tbl.setHorizontalHeaderItem(j, QTableWidgetItem(name.strip()))
            self._refresh_t_preview()

    def _t_rename_col(self, j):
        h = self.t_tbl.horizontalHeaderItem(j)
        name, ok = QInputDialog.getText(self, "اسم العمود", "اسم العمود :", text=h.text() if h else "")
        if ok and name.strip():
            self.t_tbl.setHorizontalHeaderItem(j, QTableWidgetItem(name.strip()))
            self._refresh_t_preview()

    def _t_del_row(self):
        if self.t_tbl.currentRow() >= 0:
            self.t_tbl.removeRow(self.t_tbl.currentRow())
            self._refresh_t_preview()

    def _t_del_col(self):
        if self.t_tbl.currentColumn() >= 0:
            self.t_tbl.removeColumn(self.t_tbl.currentColumn())
            self._refresh_t_preview()

    def _commit_item(self):
        it = self._find_item(self._cur_item)
        if it is None:
            return
        it.update(self._read_calc(it) if self._cur_item[0] == "calc" else self._read_table(it))
        li = self.item_list.currentItem()
        if li is not None and li.data(0, Qt.UserRole) == tuple(self._cur_item):
            li.setText(0, self._item_text(self._cur_item[0], it))

    def _commit(self):
        self._commit_sec()
        self._commit_item()

    def _item_add(self, kind):
        import report_engine
        self._commit()
        d = self._ensure_draft()
        if kind == "calc":
            it = {"id": report_engine._next_id(d["calculations"], "C"), "title": "حساب جديد", "section": "",
                  "method": "", "method_sources": [], "inputs": [], "formula": "", "note": ""}
            d["calculations"].append(it)
        else:
            it = {"id": report_engine._next_id(d["tables"], "T"), "title": "جدول جديد", "section": "",
                  "columns": ["البيان", "القيمة"], "rows": [["", ""]], "sources": [], "note": ""}
            d["tables"].append(it)
        self._cur_item = None
        self._fill_items((kind, it["id"]))

    def _item_del(self):
        it = self._find_item(self._cur_item)
        if it is None:
            return
        self.draft["calculations" if self._cur_item[0] == "calc" else "tables"].remove(it)
        self._cur_item = None
        self._fill_items()
        self._show_empty()
        self._update_fx_banner()

    def _item_copy(self):
        import report_engine
        self._commit_item()
        it = self._find_item(self._cur_item)
        if it is None:
            return
        kind = self._cur_item[0]
        coll = self.draft["calculations" if kind == "calc" else "tables"]
        dup = report_engine.copy_item(coll, coll.index(it))
        self._cur_item = None
        self._fill_items((kind, dup["id"]))

    def _calc_now(self):
        self._commit_item()
        it = self._find_item(self._cur_item)
        if it is None or self._cur_item[0] != "calc":
            return
        self._render_c_result(it)
        self._update_fx_banner()

    def _update_fx_banner(self):
        """أسعار الصرف لا تُطلب إلا إن وُجدت عملة أجنبية في الحسابات ولا سعر لها في الجدول."""
        import report_engine
        d = self.draft or {}
        miss = report_engine.missing_rates(d) if report_engine.uses_foreign_currency(d) else []
        if miss:
            self.fx_label.setText("الحسابات تتضمن مبالغ بعملة أجنبية ولا توجد أسعار صرف لـ: " +
                                  "، ".join("%s (%s)" % m for m in miss))
        self.fx_banner.setVisible(bool(miss))

    def _open_fx(self):
        from reference_data_page import FxRatesDialog
        FxRatesDialog(self).exec_()
        self._update_fx_banner()

    def _suggest_calcs(self, alternative):
        import report_engine
        n = self._case_number()
        if not n:
            return
        self._commit()
        d = self.draft
        if d is None or not d.get("sections"):
            show_info(self, "الجداول والحسابات", "أنشئ هيكل التقرير واعتمد عناوينه أولاً (تبويب «هيكل التقرير»)، لترتبط الجداول "
                      "والحسابات بالعناوين المناسبة.")
            self.tabs.setCurrentWidget(self._outline_tab)
            return
        avoid = None
        if alternative:
            it = self._find_item(self._cur_item)
            if it is None or self._cur_item[0] != "calc":
                show_info(self, "طريقة بديلة", "اختر حساباً (وليس جدولاً) من القائمة أولاً.")
                return
            avoid = [copy.deepcopy(it)]
        update = (not alternative) and bool(d.get("tables") or d.get("calculations"))
        if update and not show_confirm(
                self, "تحديث الجداول والحسابات",
                "سيراجع الذكاء الاصطناعي الجداول والحسابات الحالية على ضوء النبذة والمهام والوثائق والمراجع المحدّثة؛ "
                "قد يعدّل بعضها أو يستبدله أو يحذفه أو يضيف جداول جديدة.\nتعديلاتك اليدوية على العناصر التي يستبدلها ستضيع. أتابع؟"):
            return
        if not self._confirm_ai():
            return
        note = self.ai_note.toPlainText().strip()
        secs = [s for s in d["sections"] if s.get("status", "approved") == "approved"] or d["sections"]
        secs_c, evidence = copy.deepcopy(secs), copy.deepcopy(d.get("evidence", []))
        existing = copy.deepcopy({"tables": d.get("tables", []), "calculations": d.get("calculations", [])}) if update else None

        def work(say):
            import word_cover
            ctx = word_cover.build_case_context(n)
            new_ev = None
            if evidence and not update:
                ev = evidence
                anon = report_engine._Anonymizer([ctx.get("plaintiff"), ctx.get("defendant")])
            elif update:                                    # التحديث: نعيد قراءة الوثائق والمراجع (قد تغيّرت)
                ctx, _plan, ev, anon = report_engine.prepare_evidence(n, progress=say)
                new_ev = ev
            else:
                ctx, _plan, ev, anon = report_engine.prepare_evidence(n, progress=say)
                new_ev = ev
            say("دراسة القضية وتصميم جداولها وحساباتها وربطها بالعناوين...")
            calcs, tables, missing, conflicts, remove = report_engine.suggest_calculations(
                ctx, ev, secs_c, anon=anon, avoid=avoid, instructions=note, existing=existing)
            return {"calcs": calcs, "tables": tables, "missing": missing, "conflicts": conflicts,
                    "remove": remove, "evidence": new_ev}

        def done(r):
            d2 = self._ensure_draft()
            if r["evidence"] is not None:
                d2["evidence"] = r["evidence"]
            counts = {"new": 0, "replaced": 0}
            last = [None]

            def put(coll, prefix, kind, item, alt_suffix=""):
                rep = item.pop("replaces", "")
                if alt_suffix:
                    item["title"] += alt_suffix
                idx = next((k for k, x in enumerate(coll) if x["id"] == rep), -1) if rep else -1
                if idx >= 0:
                    item["id"] = rep                         # نحافظ على المعرّف فتبقى الإحالات سليمة
                    coll[idx] = item
                    counts["replaced"] += 1
                else:
                    item["id"] = report_engine._next_id(coll, prefix)
                    coll.append(item)
                    counts["new"] += 1
                last[0] = last[0] or (kind, item["id"])

            for c in r["calcs"]:
                put(d2["calculations"], "C", "calc", c, " — طريقة بديلة" if alternative else "")
            for t in r["tables"]:
                put(d2["tables"], "T", "table", t)
            removed = 0
            for rid in r["remove"]:
                for coll in (d2["calculations"], d2["tables"]):
                    for x in list(coll):
                        if x["id"] == rid:
                            coll.remove(x)
                            removed += 1
            d2["missing"] = list(dict.fromkeys(d2.get("missing", []) + r["missing"]))
            d2["conflicts"] = list(dict.fromkeys(d2.get("conflicts", []) + r["conflicts"]))
            d2["warnings"] = report_engine.verify_inputs(d2)
            report_engine.save_draft(d2)
            self._cur_item = None
            self._fill_items(last[0])
            self._fill_notes()
            self._update_fx_banner()
            parts = ["أُضيف %d" % counts["new"]]
            if counts["replaced"]:
                parts.append("حُدّث %d" % counts["replaced"])
            if removed:
                parts.append("حُذف %d" % removed)
            self.status.setText("الجداول والحسابات: " + "، ".join(parts) +
                                ". راجع الأرقام ومصادرها (تبويب «المراجعة والتحقق») قبل الاعتماد.")
        self._run(work, done, "جارٍ دراسة القضية وإعداد الجداول والحسابات..." if not update else
                  "جارٍ تحديث الجداول والحسابات...")

    # ------------------------------------------------------------------ المراجع والنماذج
    def _fill_refs(self):
        self.ref_list.clear()
        try:
            import rag_index
            for _key, title, cat, nchunks, _ocr, status in rag_index.reference_index().list_sources():
                import report_engine
                kind = "  [منهج/أمثلة: للشكل والخطوات فقط]" if report_engine.is_method_category(cat) else ""
                self.ref_list.addItem("%s%s%s — %s" % (title, (" (%s)" % cat) if cat else "", kind,
                                                       ("%d مقطع" % nchunks) if status == "ok" else "لم تُقرأ"))
        except Exception as e:
            self.ref_list.addItem("تعذّر قراءة المراجع: %s" % e)
        try:
            import templates_page
            p = templates_page.get_template_paths()
            row = lambda k, name: "%s: %s" % (name, os.path.basename(p[k]) if p.get(k) else "لم يُرفع بعد")
            self.tpl_label.setText(row("cover", "نموذج الغلاف") + "\n" + row("report", "نموذج التقرير"))
        except Exception:
            self.tpl_label.setText("")

    def _open_refs(self):
        from references_page import ReferencesDialog
        ReferencesDialog(self).exec_()
        self._fill_refs()

    def _open_templates(self):
        from templates_page import TemplatesDialog
        TemplatesDialog(self).exec_()
        self._fill_refs()

    # ------------------------------------------------------------------ المعاينة والتصدير
    def _refresh_preview(self):
        import report_engine
        import report_render
        import word_cover
        self._commit()
        n = self._case_number()
        if not (n and self.draft):
            self.preview.setHtml('<p dir="rtl">لا يوجد محتوى بعد: أنشئ العناوين واعتمدها أولاً.</p>')
            return
        try:
            report_engine.compute_all(self.draft)
            ctx = word_cover.build_case_context(n)
            self.preview.setHtml(report_render.render_html_preview(ctx, self.draft))
        except Exception as e:
            self.preview.setHtml('<p dir="rtl">تعذّرت المعاينة: %s</p>' % e)

    def _out_path(self, default_name):
        safe = re.sub(r"[^\w\-]+", "_", default_name, flags=re.UNICODE)
        path, _ = QFileDialog.getSaveFileName(self, "حفظ الملف", safe + ".docx", "Word (*.docx)")
        return path

    def _need_template(self, kind):
        import templates_page
        p = templates_page.get_template_paths().get(kind, "")
        if not p:
            show_warning(self, "النماذج", "ارفع النموذج أولاً من تبويب «المراجع والنماذج».")
        return p

    def _make_cover(self):
        import word_cover
        n = self._case_number()
        tpl = n and self._need_template("cover")
        if not tpl:
            return
        out = self._out_path("غلاف_" + n)
        if not out:
            return
        try:
            missing = word_cover.generate_cover(n, tpl, out)
        except Exception as e:
            show_warning(self, "الغلاف", "تعذّر إنشاء الغلاف: %s" % e)
            return
        msg = "تم إنشاء الغلاف."
        if missing:
            msg += "\nعلامات لم أجد لها قيمة وبقيت كما هي:\n" + "  ".join("{{%s}}" % k for k in sorted(missing))
        show_info(self, "الغلاف", msg)

    def _make_report(self):
        import report_engine
        import report_render
        import word_cover
        n = self._case_number()
        self._commit()
        d = self.draft
        if not (n and d and (d.get("sections") or d.get("calculations") or d.get("tables"))):
            show_warning(self, "التقرير", "لا يوجد محتوى بعد: اقترح العناوين واعتمدها أولاً.")
            return
        pending = [s for s in d["sections"] if s.get("status") == "suggested"]
        if pending and not show_confirm(self, "عناوين غير معتمدة",
                                        "يوجد %d عنوان مقترح لم تعتمده، ولن يدخل في التقرير. أتابع؟" % len(pending)):
            return
        tpl = self._need_template("report")
        if not tpl:
            return
        report_engine.compute_all(d)
        failed = [c["title"] for c, r in zip(d["calculations"], d["results"]) if r["error"]]
        if failed and not show_confirm(self, "حسابات متعذّرة",
                                       "تعذّر حساب: " + "، ".join(failed) + "\nستظهر في التقرير كأخطاء. أتابع؟", danger=True):
            return
        audit_err = [x for x in (d.get("audit") or []) if str(x).startswith("❌")]
        if audit_err and not show_confirm(self, "أخطاء في تدقيق الوثائق",
                                          "يوجد %d خطأ حسابي أو تعارض في الوثائق لم تعالجه (تبويب «المراجعة والتحقق» ← تدقيق الوثائق). "
                                          "إن كان الخطأ في الوثيقة نفسها فاذكره في التقرير. أتابع؟" % len(audit_err), danger=True):
            return
        legal_open = list(d.get("legal") or [])
        if legal_open and not show_confirm(self, "أساس قانوني لم تعتمده",
                                           "يوجد %d بند في «الأساس القانوني» لم تعالجه (مواد لم تقرّر انطباقها على قضيتك، أو أسس لم يجدها "
                                           "البرنامج في المراجع). التقرير يحمل توقيعك. أتابع؟" % len(legal_open), danger=True):
            return
        inputs = [i for c in d["calculations"] for i in c["inputs"]]
        unverified = sum(1 for i in inputs if i.get("verified") is False)
        derived = sum(1 for i in inputs if i.get("status") == "derived")
        if (unverified or derived) and not show_confirm(
                self, "أرقام لم يُتحقق منها",
                "%d رقماً لم يُعثر عليه في نص مصدره، و%d رقماً مشتقاً وليس منقولاً حرفياً (راجع تبويب «المراجعة والتحقق»). أتابع؟"
                % (unverified, derived)):
            return
        out = self._out_path("تقرير_" + n)
        if not out:
            return
        try:
            report_engine.save_draft(d)
            report_render.render_report(tpl, out, word_cover.build_case_context(n), d)
        except Exception as e:
            show_warning(self, "التقرير", "تعذّر إنشاء التقرير: %s" % e)
            return
        show_info(self, "التقرير", "تم إنشاء التقرير.\nراجعه بالكامل قبل اعتماده، فالمسؤولية المهنية عليك.")

    # ------------------------------------------------------------------ حفظ
    def _save(self):
        import report_engine
        if self.draft and self.draft.get("case_number"):
            self._commit()
            try:
                report_engine.save_draft(self.draft)
            except Exception:
                pass

    def hideEvent(self, e):
        self._save()
        super().hideEvent(e)
