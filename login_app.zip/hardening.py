# -*- coding: utf-8 -*-
"""كشف التتبّع/الحقن أثناء التشغيل (نسخة exe فقط). يرفع كلفة الاختراق ولا يمنعه تماماً.

عند الاكتشاف: يتحوّل البرنامج إلى القراءة فقط بصمت (بلا رسالة تدلّ المهاجم على مكان الفحص)،
ويُرسَل تنبيه غير حاجز إلى تيليغرام (telegram_alert.py) إن كان مضبوطاً -- التنبيه نفسه لا
يظهر محلياً بأي شكل، فلا يكشف للمهاجم أن الفحص اكتُشف أو أُبلغ عنه.

مهم: هذه الطبقة وحدها تُكسر بسهولة إن بقي الكود بايثون عادياً؛ فائدتها الحقيقية مع تجميع
وحدات الترخيص إلى ملفات أصلية (انظر tools/protect_build.py).

عمداً لا يوجد هنا: كشف بيئات افتراضية (VM) عبر اسم الشركة المصنّعة أو حجم الذاكرة/القرص،
ولا قراءة سجلات معالج (Debug Registers Dr0-Dr3). كلاهما يعطي نتائج إيجابية خاطئة كثيرة على
أجهزة حقيقية لعملاء شرعيين (حواسيب شركات تُدار افتراضياً، أو لوحات أم تُعيد "Microsoft
Corporation" كاسم مصنّع افتراضياً -- بالضبط نفس فخ القيم الوهمية الذي يتجنبه device_fingerprint.
_JUNK)، وقد تحجب برنامجك عن عميل دافع حقيقي بدل مهاجم. إن أردتها رغم ذلك لاحقاً، فعّلها
كتسجيل (log) فقط لا كحجب تلقائي، وراجعها يدوياً أولاً على عدة أجهزة حقيقية.
"""
import os
import subprocess
import sys
import time

_SUSPECT_MODULES = ("frida", "pydevd", "debugpy", "_pydevd_bundle", "pdb", "bdb", "uncompyle6", "decompyle3")
_SUSPECT_PROCESSES = ("x64dbg.exe", "x32dbg.exe", "ida64.exe", "ida.exe", "ollydbg.exe",
                       "scylla.exe", "scylla_x64.exe", "cheatengine", "dnspy.exe")
_PROC_CACHE = {"t": 0.0, "hit": False}
_PROC_CHECK_EVERY = 8.0   # ثوانٍ: tasklist يستدعي عملية خارجية، لا يُنفَّذ في كل استدعاء


def _suspect_process_running():
    """فحص خفيف بالاسم فقط (tasklist) -- يُعاد كل _PROC_CHECK_EVERY ثانية، لا في كل نداء."""
    now = time.monotonic()
    if now - _PROC_CACHE["t"] < _PROC_CHECK_EVERY:
        return _PROC_CACHE["hit"]
    _PROC_CACHE["t"] = now
    hit = False
    if os.name == "nt":
        try:
            out = subprocess.run(["tasklist"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                 timeout=10, creationflags=0x08000000).stdout.decode("utf-8", "replace").lower()   # بلا نافذة CMD
            hit = any(p in out for p in _SUSPECT_PROCESSES)
        except Exception:
            hit = False
    _PROC_CACHE["hit"] = hit
    return hit


def _native_debugger():
    if os.name != "nt":
        return False
    try:
        import ctypes
        k = ctypes.windll.kernel32
        if k.IsDebuggerPresent():
            return True
        flag = ctypes.c_int(0)
        k.CheckRemoteDebuggerPresent(k.GetCurrentProcess(), ctypes.byref(flag))
        return bool(flag.value)
    except Exception:
        return False


def _alert(reason):
    try:
        import telegram_alert
        telegram_alert.alert(reason)
    except Exception:
        pass           # التنبيه غير حرج أبداً: لا يُسقط فحص التلاعب ولا يُظهر شيئاً محلياً


def tampered_runtime():
    """True إن بدا أن البرنامج يُتتبَّع أو يُحقَن فيه. لا يعمل في وضع التطوير."""
    if not getattr(sys, "frozen", False):
        return False
    try:
        if sys.gettrace() is not None or sys.getprofile() is not None:
            _alert("tracer-attached")
            return True
        if any(m in sys.modules for m in _SUSPECT_MODULES):
            _alert("suspect-module-loaded")
            return True
        if os.environ.get("PYTHONINSPECT") or os.environ.get("PYTHONSTARTUP") or os.environ.get("PYTHONPATH"):
            _alert("suspect-env-var")
            return True
        if _native_debugger():
            _alert("native-debugger")
            return True
        if _suspect_process_running():
            _alert("suspect-process")
            return True
        return False
    except Exception:
        _alert("hardening-exception")
        return True
