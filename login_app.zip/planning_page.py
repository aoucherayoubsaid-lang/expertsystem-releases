# -*- coding: utf-8 -*-
"""صفحة التخطيط والآجال (Planning): نظرة واحدة على أولويات العمل.

تعتمد حصراً على بيانات موجودة: القضايا (storage.load_cases) ومنطق الحالة الموحّد
(case_status) الذي تستعمله صفحة القضايا والصفحة الرئيسية والتنبيهات، فلا تظهر هنا
حالة تخالف بقية البرنامج. الصفحة للقراءة والتنقل فقط: لا تكتب أي بيانات.

المحتوى: بطاقات مؤشرات قابلة للنقر، مرشّحات حالة + بحث، خط زمني مجمّع
(متأخرة / هذا الأسبوع / هذا الشهر / لاحقاً / أُودعت / بدون أجل)، وتقويم يلوّن
أيام الآجال مع بطاقة "أقرب أجل". النقر على يوم في التقويم يصفّي القائمة بذلك اليوم.
"""

import datetime

import qtawesome as qta
from PyQt5.QtCore import Qt, QDate, QSize
from PyQt5.QtGui import QColor, QTextCharFormat, QBrush
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFrame, QLabel, QPushButton, QScrollArea,
    QCalendarWidget, QButtonGroup, QSizePolicy,
)

import storage
import case_status
import theme_tokens as T
from modern_theme import style_soft_button, style_white_button
from ui_components import (Card, Badge, KpiCard, SearchField, EmptyState, GradientBanner,
                           RingGauge, StackedBar, icon_badge, mix, tint, figure, lead_align,
                           CollapsibleCard)

_SKIP = "_auto_i18n_skip"   # النصوص هنا تُترجم من القاموس أدناه، لا من مترجم الواجهة التلقائي

STRINGS = {
    "ar": {
        "title": "التخطيط والآجال", "sub": "متابعة آجال إيداع تقارير الخبرة وأولويات العمل",
        "refresh": "تحديث", "late": "متأخرة", "near": "قريبة الإيداع", "ok": "في الأجل",
        "done": "أُودع تقريرها", "all": "الكل", "search": "بحث برقم القضية أو اسم الطرف",
        "g_late": "متأخرة", "g_week": "هذا الأسبوع", "g_month": "هذا الشهر", "g_later": "لاحقاً",
        "g_done": "أُودعت", "g_none": "بدون أجل محدد", "open": "فتح القضية", "vs": "ضد",
        "d_late": "متأخرة {n} يوماً", "d_left": "بعد {n} يوماً", "today": "اليوم", "d_done": "أُودعت",
        "deadline": "الأجل", "empty": "لا توجد قضايا مطابقة", "empty_hint": "غيّر المرشّح أو امسح البحث",
        "calendar": "التقويم", "next": "أقرب أجل", "no_next": "لا توجد آجال قادمة",
        "date_filter": "اليوم المحدد: {d}", "clear": "إلغاء تحديد اليوم",
        "progress": "نسبة الإيداع", "done_caption": "{a} من {b} قضية", "total": "إجمالي {n} قضية", "case": "قضية",
    },
    "fr": {
        "title": "Planning et échéances", "sub": "Suivi des délais de dépôt des rapports d'expertise",
        "refresh": "Actualiser", "late": "En retard", "near": "Dépôt proche", "ok": "Dans les délais",
        "done": "Rapport déposé", "all": "Tout", "search": "Rechercher par n° d'affaire ou partie",
        "g_late": "En retard", "g_week": "Cette semaine", "g_month": "Ce mois-ci", "g_later": "Plus tard",
        "g_done": "Déposées", "g_none": "Sans échéance", "open": "Ouvrir l'affaire", "vs": "c/",
        "d_late": "En retard de {n} j", "d_left": "Dans {n} j", "today": "Aujourd'hui", "d_done": "Déposée",
        "deadline": "Échéance", "empty": "Aucune affaire correspondante", "empty_hint": "Modifiez le filtre ou effacez la recherche",
        "calendar": "Calendrier", "next": "Prochaine échéance", "no_next": "Aucune échéance à venir",
        "date_filter": "Jour sélectionné : {d}", "clear": "Désélectionner le jour",
        "progress": "Taux de dépôt", "done_caption": "{a} sur {b} affaires", "total": "{n} affaires au total", "case": "affaire",
    },
    "en": {
        "title": "Planning & deadlines", "sub": "Track expert-report filing deadlines and work priorities",
        "refresh": "Refresh", "late": "Overdue", "near": "Due soon", "ok": "On track",
        "done": "Report filed", "all": "All", "search": "Search by case number or party",
        "g_late": "Overdue", "g_week": "This week", "g_month": "This month", "g_later": "Later",
        "g_done": "Filed", "g_none": "No deadline", "open": "Open case", "vs": "v.",
        "d_late": "{n} days overdue", "d_left": "In {n} days", "today": "Today", "d_done": "Filed",
        "deadline": "Deadline", "empty": "No matching cases", "empty_hint": "Change the filter or clear the search",
        "calendar": "Calendar", "next": "Next deadline", "no_next": "No upcoming deadlines",
        "date_filter": "Selected day: {d}", "clear": "Clear selected day",
        "progress": "Filing rate", "done_caption": "{a} of {b} cases", "total": "{n} cases in total", "case": "case",
    },
}

# حالة -> (لون الشريط، نوع الشارة)
_STATE_STYLE = {
    "late": (T.DANGER, "bad"), "near": (T.GOLD, "warn"), "ok": (T.ACCENT, "info"),
    "deposited": (T.SUCCESS, "ok"), "unknown": (T.SECONDARY, "neutral"),
}
_CHIP_QSS = (
    f"QPushButton {{ background: {T.SURFACE}; color: {T.TEXT_MUTED}; border: 2px solid {T.BORDER};"
    f" border-radius: 18px; padding: 7px 18px; font-size: 10pt; font-weight: 600; }}"
    f"QPushButton:hover {{ background: {T.HOVER_BG}; color: {T.PRIMARY_DARK}; border-color: {T.BORDER_STRONG}; }}"
    f"QPushButton:checked {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 {T.GRAD_A}, stop:1 {T.GRAD_B});"
    f" color: white; border: 2px solid {T.GRAD_A}; }}"
)
_CAL_QSS = f"""
    QCalendarWidget QWidget#qt_calendar_navigationbar {{ background: {T.TINT_INDIGO}; border-radius: 10px; }}
    QCalendarWidget QToolButton {{ color: {T.PRIMARY_DARK}; background: transparent; border: none;
        padding: 6px 8px; font-weight: 700; border-radius: 8px; }}
    QCalendarWidget QToolButton:hover {{ background: {T.ACTIVE_BG}; }}
    QCalendarWidget QSpinBox {{ color: {T.PRIMARY_DARK}; background: transparent; border: none; }}
    QCalendarWidget QMenu {{ background: white; color: {T.TEXT}; }}
    QCalendarWidget QAbstractItemView:enabled {{ color: {T.TEXT}; background: white; outline: 0;
        selection-background-color: {T.ACCENT}; selection-color: white; }}
    QCalendarWidget QAbstractItemView:disabled {{ color: #9199b8; }}
"""


_MONTHS = {
    "ar": ["جانفي", "فيفري", "مارس", "أفريل", "ماي", "جوان", "جويلية", "أوت", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"],
    "fr": ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."],
    "en": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
}


def _lang():
    try:
        from settings_page import AppSettings
        code = AppSettings().get_language_code()
        return code if code in STRINGS else "ar"
    except Exception:
        return "ar"


def _label(text="", css=""):
    lbl = QLabel(text)
    lbl.setProperty(_SKIP, True)
    lbl.setStyleSheet("background: transparent; border: none;" + css)
    lbl.setAlignment(lead_align())
    return lbl


class PlanningPage(QWidget):
    """صفحة التخطيط. main_window اختياري: يُستعمل لفتح القضية في تبويب القضايا."""

    def __init__(self, case_page=None, main_window=None, parent=None):
        super().__init__(parent)
        self.case_page = case_page
        self.main_window = main_window
        self._lang = _lang()
        self._rows = []            # [(case, status)] كل قضايا السنة/المحكمة الحالية
        self._filter = "all"
        self._query = ""
        self._date = None          # datetime.date أو None
        self.setObjectName("planningPage")
        self.setStyleSheet(f"QWidget#planningPage {{ background: {T.BG}; }}")
        self._build()
        self.reload()

    # ------------------------------------------------------------------ بناء الواجهة
    def tr_(self, key, **kw):
        s = STRINGS[self._lang][key]
        return s.format(**kw) if kw else s

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 22, 28, 22)
        root.setSpacing(16)

        # --- لوحة العنوان بتدرّج بنفسجي: العنوان + شريط توزيع الحالات + زر التحديث ---
        self.hero = GradientBanner(radius=22, margins=(28, 20, 28, 20), spacing=10)
        top = QHBoxLayout()
        top.setSpacing(14)
        top.addWidget(icon_badge("fa5s.calendar-check", T.PRIMARY_DARK, "#ffffff", 50, 16, 22))
        tcol = QVBoxLayout()
        tcol.setSpacing(0)
        self.title_label = _label(self.tr_("title"), "color: white; font-size: 20pt; font-weight: 700;")
        self.subtitle_label = _label(self.tr_("sub"), f"color: {T.TEXT_ON_DARK_MUTED}; font-size: 10.5pt;")
        self.subtitle_label.setWordWrap(True)
        tcol.addWidget(self.title_label)
        tcol.addWidget(self.subtitle_label)
        top.addLayout(tcol, 1)
        self.refresh_btn = QPushButton(self.tr_("refresh"))
        self.refresh_btn.setProperty(_SKIP, True)
        self.refresh_btn.setIcon(qta.icon("fa5s.sync-alt", color=T.PRIMARY_DARK))
        self.refresh_btn.setMinimumHeight(40)
        style_white_button(self.refresh_btn, radius=13, padding="8px 20px")
        self.refresh_btn.clicked.connect(self.reload)
        top.addWidget(self.refresh_btn, 0, Qt.AlignTop)
        self.hero.body.addLayout(top)

        self.dist_bar = StackedBar(height=12)
        self.hero.body.addSpacing(4)
        self.hero.body.addWidget(self.dist_bar)
        self.dist_caption = _label("", f"color: {T.TEXT_ON_DARK_MUTED}; font-size: 9.5pt;")
        self.hero.body.addWidget(self.dist_caption)
        root.addWidget(self.hero)

        # مؤشرات
        kpi_row = QHBoxLayout()
        kpi_row.setSpacing(16)
        self.kpis = {}
        for key, color, flt, icon in (("late", T.DANGER, "late", "fa5s.exclamation-triangle"),
                                      ("near", T.GOLD, "near", "fa5s.hourglass-half"),
                                      ("ok", T.TEAL, "ok", "fa5s.stream"),
                                      ("done", T.SUCCESS, "deposited", "fa5s.check-double")):
            card = KpiCard(self.tr_(key), color, "0", icon=icon)
            card.text_label.setProperty(_SKIP, True)
            card.clicked.connect(lambda f=flt: self._set_filter(f))
            kpi_row.addWidget(card)
            self.kpis[key] = card
        root.addLayout(kpi_row)

        # مرشّحات + بحث
        bar = QHBoxLayout()
        bar.setSpacing(8)
        self._chip_group = QButtonGroup(self)
        self._chip_group.setExclusive(True)
        self._chips = {}
        for flt, key in (("all", "all"), ("late", "late"), ("near", "near"),
                         ("ok", "ok"), ("deposited", "done")):
            b = QPushButton(self.tr_(key))
            b.setProperty(_SKIP, True)
            b.setProperty("_mt_setup", True)
            b.setProperty("_mt_styled", True)
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.setStyleSheet(_CHIP_QSS)
            b.clicked.connect(lambda _c=False, f=flt: self._set_filter(f))
            self._chip_group.addButton(b)
            self._chips[flt] = b
            bar.addWidget(b)
        self._chips["all"].setChecked(True)
        bar.addStretch(1)
        self.search = SearchField(self.tr_("search"))
        self.search.setProperty(_SKIP, True)
        self.search.setMinimumWidth(280)
        self.search.textChanged.connect(self._on_search)
        bar.addWidget(self.search)
        root.addLayout(bar)

        self.date_bar = QHBoxLayout()
        self.date_label = _label("", f"color: {T.ACCENT}; font-weight: 600;")
        self.date_clear = QPushButton(self.tr_("clear"))
        self.date_clear.setProperty(_SKIP, True)
        self.date_clear.setFlat(True)
        self.date_clear.setCursor(Qt.PointingHandCursor)
        self.date_clear.setStyleSheet(
            f"QPushButton {{ border: none; background: transparent; color: {T.DANGER}; }}"
            "QPushButton:hover { text-decoration: underline; }")
        self.date_clear.clicked.connect(lambda: self._set_date(None))
        self.date_bar.addWidget(self.date_label)
        self.date_bar.addWidget(self.date_clear)
        self.date_bar.addStretch(1)
        self._date_holder = QWidget()
        self._date_holder.setLayout(self.date_bar)
        self._date_holder.setVisible(False)
        root.addWidget(self._date_holder)

        # المحتوى: قائمة زمنية + عمود جانبي
        body = QHBoxLayout()
        body.setSpacing(16)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }"
                                  "QScrollArea > QWidget > QWidget { background: transparent; }")
        self.list_host = QWidget()
        self.list_layout = QVBoxLayout(self.list_host)
        self.list_layout.setContentsMargins(0, 0, 4, 0)
        self.list_layout.setSpacing(8)
        self.scroll.setWidget(self.list_host)
        body.addWidget(self.scroll, 1)

        side = QVBoxLayout()
        side.setSpacing(16)

        # --- التقويم: بطاقة قابلة للطي بسهم، مفتوحة افتراضياً وبارتفاع كافٍ لرؤية كل أسابيع الشهر ---
        self.cal_card = CollapsibleCard(self.tr_("calendar"), "fa5s.calendar-alt", T.ACCENT, expanded=True)
        self.calendar = QCalendarWidget()
        self.calendar.setStyleSheet(_CAL_QSS)
        self.calendar.setGridVisible(False)
        self.calendar.setVerticalHeaderFormat(QCalendarWidget.NoVerticalHeader)
        self.calendar.setNavigationBarVisible(True)
        self.calendar.setMinimumHeight(256)
        self.calendar.clicked.connect(self._on_calendar_clicked)
        self.cal_card.inner.addWidget(self.calendar)
        self.today_btn = QPushButton(self.tr_("today"))
        self.today_btn.setProperty(_SKIP, True)
        self.today_btn.setIcon(qta.icon("fa5s.crosshairs", color=T.ACCENT))
        self.today_btn.setCursor(Qt.PointingHandCursor)
        style_soft_button(self.today_btn, "info", radius=10, padding="5px 14px")
        self.today_btn.clicked.connect(lambda: self.calendar.setSelectedDate(QDate.currentDate()))
        self.cal_card.inner.addWidget(self.today_btn, 0, Qt.AlignHCenter)
        side.addWidget(self.cal_card)

        # --- أقرب أجل ---
        self.next_card = CollapsibleCard(self.tr_("next"), "fa5s.bell", T.GOLD, expanded=True)
        self.next_body = _label("", f"color: {T.TEXT}; font-size: {T.FONT_SIZE_LABEL}pt;")
        self.next_body.setWordWrap(True)
        self.next_card.inner.addWidget(self.next_body)
        side.addWidget(self.next_card)

        # --- نسبة الإيداع (حلقة) ---
        self.prog_card = CollapsibleCard(self.tr_("progress"), "fa5s.chart-pie", T.SUCCESS, expanded=True)
        self.ring = RingGauge(T.SUCCESS, 118)
        self.prog_card.inner.addWidget(self.ring, 0, Qt.AlignHCenter)
        side.addWidget(self.prog_card)
        side.addStretch(1)
        side_host = QWidget()
        side_host.setObjectName("planSide")
        side_host.setStyleSheet("QWidget#planSide { background: transparent; }")
        side_host.setLayout(side)
        # العمود الجانبي داخل منطقة تمرير: لا يُقصّ على الشاشات الصغيرة (1366x768)
        side_scroll = QScrollArea()
        side_scroll.setWidgetResizable(True)
        side_scroll.setFrameShape(QFrame.NoFrame)
        side_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        side_scroll.setFixedWidth(352)
        side_scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        side_scroll.setWidget(side_host)
        body.addWidget(side_scroll)
        root.addLayout(body, 1)

    # ------------------------------------------------------------------ بيانات
    def reload(self):
        """يعيد قراءة القضايا والحالات (للقراءة فقط) ثم يرسم الصفحة."""
        try:
            cases = storage.load_cases() or []
            court = ""
            try:
                court = (storage.get_current_court() or "").strip()
            except Exception:
                court = ""
            if court:
                cases = [c for c in cases if (c.get("court") or "").strip() == court]
            receipts = case_status.deposit_receipts()
            near = case_status.near_days()
            self._rows = [(c, case_status.case_status(c, receipts, near)) for c in cases]
        except Exception:
            self._rows = []
        self._paint_calendar()
        self._update_kpis()
        self._update_next()
        self._render()

    def apply_language(self, code):
        self._lang = code if code in STRINGS else "ar"
        self.title_label.setText(self.tr_("title"))
        self.subtitle_label.setText(self.tr_("sub"))
        self.refresh_btn.setText(self.tr_("refresh"))
        for key, card in self.kpis.items():
            card.text_label.setText(self.tr_(key))
        for flt, key in (("all", "all"), ("late", "late"), ("near", "near"), ("ok", "ok"), ("deposited", "done")):
            self._chips[flt].setText(self.tr_(key))
        self.search.setPlaceholderText(self.tr_("search"))
        self.date_clear.setText(self.tr_("clear"))
        self.cal_card.set_title(self.tr_("calendar"))
        self.next_card.set_title(self.tr_("next"))
        self.prog_card.set_title(self.tr_("progress"))
        self.today_btn.setText(self.tr_("today"))
        self.reload()

    # ------------------------------------------------------------------ تفاعل
    def _set_filter(self, flt):
        self._filter = flt
        chip = self._chips.get(flt)
        if chip:
            chip.setChecked(True)
        self._render()

    def _on_search(self, text):
        self._query = (text or "").strip().lower()
        self._render()

    def _on_calendar_clicked(self, qdate):
        self._set_date(datetime.date(qdate.year(), qdate.month(), qdate.day()))

    def _set_date(self, d):
        self._date = d
        self._date_holder.setVisible(d is not None)
        if d is not None:
            self.date_label.setText(self.tr_("date_filter", d=d.strftime(case_status.DATE_FMT)))
        self._render()

    def _open_case(self, number):
        mw = self.main_window
        if mw is None:
            return
        try:
            mw.tabs.setCurrentWidget(mw.case_page)
            table = getattr(mw.case_page, "table", None)
            if table is not None:
                for r in range(table.rowCount()):
                    item = table.item(r, 0)
                    if item and item.text().strip() == number:
                        table.selectRow(r)
                        table.scrollToItem(item)
                        break
        except Exception:
            pass

    # ------------------------------------------------------------------ عرض
    def _update_kpis(self):
        counts = {"late": 0, "near": 0, "ok": 0, "deposited": 0}
        for _c, st in self._rows:
            if st["state"] in counts:
                counts[st["state"]] += 1
        self.kpis["late"].set_value(counts["late"])
        self.kpis["near"].set_value(counts["near"])
        self.kpis["ok"].set_value(counts["ok"])
        self.kpis["done"].set_value(counts["deposited"])
        total = len(self._rows)
        # شريط التوزيع (ألوان زاهية تظهر فوق التدرّج البنفسجي)
        self.dist_bar.set_segments([(counts["late"], "#ff6b81"), (counts["near"], "#ffb020"),
                                    (counts["ok"], "#38bdf8"), (counts["deposited"], "#34d399")])
        self.dist_caption.setText(self.tr_("total", n=total))
        pct = (100.0 * counts["deposited"] / total) if total else 0.0
        self.ring.set_value(pct)
        self.ring.set_caption(self.tr_("done_caption", a=counts["deposited"], b=total))

    def _paint_calendar(self):
        blank = QTextCharFormat()
        self.calendar.setDateTextFormat(QDate(), blank)       # يمسح التنسيقات السابقة
        prio = {"late": 3, "near": 2, "ok": 1}
        best = {}
        for _c, st in self._rows:
            d = st["deadline"]
            if d and st["state"] in prio and prio[st["state"]] > best.get(d, (0, ""))[0]:
                best[d] = (prio[st["state"]], st["state"])
        colors = {"late": (T.BAD_BG, T.BAD_FG), "near": (T.WARN_BG, T.WARN_FG), "ok": (T.INFO_BG, T.INFO_FG)}
        for d, (_p, state) in best.items():
            fmt = QTextCharFormat()
            bg, fg = colors[state]
            fmt.setBackground(QBrush(QColor(bg)))
            fmt.setForeground(QBrush(QColor(fg)))
            fmt.setFontWeight(75)
            self.calendar.setDateTextFormat(QDate(d.year, d.month, d.day), fmt)

    def _update_next(self):
        today = datetime.date.today()
        upcoming = [(st["deadline"], c) for c, st in self._rows
                    if st["state"] in ("near", "ok") and st["deadline"] and st["deadline"] >= today]
        if not upcoming:
            self.next_body.setText(self.tr_("no_next"))
            return
        d, c = min(upcoming, key=lambda x: x[0])
        days = (d - today).days
        when = self.tr_("today") if days == 0 else self.tr_("d_left", n=days)
        self.next_body.setText("%s\n%s — %s" % (str(c.get("case_number", "")), d.strftime(case_status.DATE_FMT), when))

    def _matches(self, case, st):
        if self._filter != "all" and st["state"] != self._filter:
            return False
        if self._date is not None and st["deadline"] != self._date:
            return False
        if self._query:
            hay = " ".join(str(case.get(k, "") or "") for k in
                           ("case_number", "index_number", "plaintiff", "defendant", "court", "section")).lower()
            if self._query not in hay:
                return False
        return True

    def _group_of(self, st):
        if st["state"] == "deposited":
            return "g_done"
        if st["state"] == "late":
            return "g_late"
        if st["state"] == "unknown":
            return "g_none"
        d = st["days_left"]
        return "g_week" if d <= 7 else "g_month" if d <= 30 else "g_later"

    def _clear_list(self):
        while self.list_layout.count():
            item = self.list_layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()

    def _render(self):
        self._clear_list()
        groups = {k: [] for k in ("g_late", "g_week", "g_month", "g_later", "g_none", "g_done")}
        for case, st in self._rows:
            if self._matches(case, st):
                groups[self._group_of(st)].append((case, st))
        shown = 0
        accents = {"g_late": T.DANGER, "g_week": T.GOLD, "g_month": T.ACCENT, "g_later": T.SECONDARY,
                   "g_none": T.SECONDARY, "g_done": T.SUCCESS}
        for gkey, items in groups.items():
            if not items:
                continue
            items.sort(key=lambda x: (x[1]["deadline"] or datetime.date.max))
            self.list_layout.addWidget(self._group_header(self.tr_(gkey), len(items), accents[gkey]))
            for case, st in items:
                self.list_layout.addWidget(self._case_card(case, st))
                shown += 1
        if shown == 0:
            self.list_layout.addWidget(EmptyState(self.tr_("empty"), self.tr_("empty_hint"), "fa5s.calendar-check"))
        self.list_layout.addStretch(1)

    def _group_header(self, text, count, color):
        host = QWidget()
        host.setStyleSheet("background: transparent;")
        row = QHBoxLayout(host)
        row.setContentsMargins(2, 10, 2, 2)
        row.setSpacing(10)
        dot = QFrame()
        dot.setFixedSize(12, 12)
        dot.setStyleSheet(f"background: {color}; border: none; border-radius: 6px;")
        row.addWidget(dot)
        row.addWidget(_label(text, f"color: {T.INK}; font-size: {T.FONT_SIZE_SECTION}pt; font-weight: 700;"))
        pill = _label(str(count), f"color: {color}; background: {tint(color, 0.86)};"
                                  " border-radius: 11px; padding: 2px 11px; font-weight: 700; font-size: 9.5pt;")
        row.addWidget(pill)
        row.addStretch(1)
        return host

    def _date_tile(self, st, color):
        """مربع التاريخ: اليوم + الشهر (أو أيقونة عند عدم وجود أجل / عند الإيداع)."""
        tile = QFrame()
        tile.setObjectName("dateTile")
        tile.setFixedSize(62, 66)
        tile.setStyleSheet(
            f"QFrame#dateTile {{ background: {tint(color, 0.88)}; border: none; border-radius: 16px; }}"
            "QFrame#dateTile QLabel { background: transparent; border: none; }")
        v = QVBoxLayout(tile)
        v.setContentsMargins(0, 6, 0, 6)
        v.setSpacing(0)
        v.setAlignment(Qt.AlignCenter)
        d = st["deadline"]
        if st["state"] == "deposited" or d is None:
            ic = QLabel()
            ic.setAlignment(Qt.AlignCenter)
            ic.setPixmap(qta.icon("fa5s.check-double" if st["state"] == "deposited" else "fa5s.minus",
                                  color=color).pixmap(QSize(22, 22)))
            v.addWidget(ic)
            if d is not None:
                v.addWidget(_label("%02d/%02d" % (d.day, d.month),
                                   f"color: {color}; font-size: 8.5pt; font-weight: 600;"), 0, Qt.AlignHCenter)
            return tile
        day = _label("%d" % d.day, f"color: {figure(color)}; font-size: 18pt; font-weight: 800;")
        day.setAlignment(Qt.AlignCenter)
        mon = _label(_MONTHS.get(self._lang, _MONTHS["ar"])[d.month - 1],
                     f"color: {color}; font-size: 8.5pt; font-weight: 700;")
        mon.setAlignment(Qt.AlignCenter)
        v.addWidget(day)
        v.addWidget(mon)
        return tile

    def _case_card(self, case, st):
        state = st["state"]
        color, kind = _STATE_STYLE.get(state, _STATE_STYLE["unknown"])
        card = QFrame()
        card.setObjectName("planCard")
        card.setStyleSheet(
            f"QFrame#planCard {{ background: {T.SURFACE}; border: 1px solid {T.BORDER}; border-radius: 16px; }}"
            f"QFrame#planCard:hover {{ border: 1px solid {color}; background: {T.SURFACE_ALT}; }}"
            "QFrame#planCard QLabel { background: transparent; border: none; }")
        row = QHBoxLayout(card)
        row.setContentsMargins(12, 10, 16, 10)
        row.setSpacing(14)
        row.addWidget(self._date_tile(st, color))

        number = str(case.get("case_number", "") or "")
        plaintiff = str(case.get("plaintiff", "") or "")
        defendant = str(case.get("defendant", "") or "")
        parties = ("%s %s %s" % (plaintiff, self.tr_("vs"), defendant)) if (plaintiff or defendant) else ""
        col = QVBoxLayout()
        col.setSpacing(2)
        col.setContentsMargins(0, 2, 0, 2)
        col.addWidget(_label(number, f"color: {T.PRIMARY_DARK}; font-size: 11.5pt; font-weight: 700;"))
        if parties:
            lbl = _label(parties, f"color: {T.TEXT}; font-size: {T.FONT_SIZE_BASE}pt;")
            lbl.setWordWrap(True)
            col.addWidget(lbl)
        meta = [x for x in (str(case.get("court", "") or ""), str(case.get("section", "") or "")) if x]
        if st["deadline"]:
            meta.append("%s: %s" % (self.tr_("deadline"), st["deadline"].strftime(case_status.DATE_FMT)))
        if meta:
            col.addWidget(_label("  ·  ".join(meta), f"color: {T.TEXT_MUTED}; font-size: {T.FONT_SIZE_SMALL + 0.5}pt;"))
        row.addLayout(col, 1)

        if state == "deposited":
            text = self.tr_("d_done")
        elif st["days_left"] is None:
            text = "—"
        elif st["days_left"] < 0:
            text = self.tr_("d_late", n=abs(st["days_left"]))
        elif st["days_left"] == 0:
            text = self.tr_("today")
        else:
            text = self.tr_("d_left", n=st["days_left"])
        badge = Badge(text, kind)
        badge.setProperty(_SKIP, True)
        row.addWidget(badge, 0, Qt.AlignVCenter)

        if self.main_window is not None and number:
            btn = QPushButton(self.tr_("open"))
            btn.setProperty(_SKIP, True)
            btn.setCursor(Qt.PointingHandCursor)
            style_soft_button(btn, "info", radius=11, padding="7px 16px")
            btn.clicked.connect(lambda _c=False, n=number: self._open_case(n))
            row.addWidget(btn, 0, Qt.AlignVCenter)
        return card
