# -*- coding: utf-8 -*-
"""اختبار ذاتي بلا إنترنت ولا واجهة: تدقيق الوثائق، محرّك الحساب، التحقق من الأرقام، القراءة المزدوجة.
التشغيل من مجلد البرنامج:   python selftest_audit.py
أي إخفاق يطبع سطراً يبدأ بـ FAIL ويُنهي البرنامج برمز 1."""
import json
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import doc_audit as A
import rag_index as RI
import report_engine as R

FAILS = []


def check(name, cond, extra=""):
    print(("ok    " if cond else "FAIL  ") + name + ((" -> " + str(extra)) if (extra and not cond) else ""))
    if not cond:
        FAILS.append(name)


def codes(issues):
    return sorted({i["code"] for i in issues})


# ---- 1) محرّك الحساب: تقريب محاسبي ودوال مالية وتواريخ ------------------------------------------------
check("تقريب 2.5 -> 3", R.round_half_up(2.5) == 3.0)
check("تقريب 2.675 -> 2.68", R.round_half_up(2.675, 2) == 2.68)
check("تقريب سالب -2.5 -> -3", R.round_half_up(-2.5) == -3.0)
check("عرض 2.675", R.fmt_num(2.675) == "2.68")
t = {"columns": ["من", "إلى", "أيام", "أشهر", "مبلغ", "غرامة", "مجموع"],
     "rows": [["2020-01-15", "2020-03-14", "=DAYS(A1,B1)", "=MONTHS_STARTED(A1,B1)", "1000", "=ROUND(E1*3/100*C1,2)", ""],
              ["2020-02-01", "2020-02-29", "=DAYS(A2,B2)", "=MONTHS(A2,B2)", "333.33", "=ROUND(E2*0.015,2)", ""],
              ["", "", "", "", "=SUM(E1:E2)", "=SUM(F1:F2)", "=IF(F3>E3,1,0)"]]}
ev = R.evaluate_table(t)
check("DAYS", ev["rows"][0][2] == "59", ev["rows"][0])
check("MONTHS_STARTED (شهر بدأ يُحتسب)", ev["rows"][0][3] == "2", ev["rows"][0])
check("MONTHS كاملة", ev["rows"][1][3] == "0", ev["rows"][1])
check("غرامة = 1000×3%×59", ev["rows"][0][5] == "1,770", ev["rows"][0])
check("مجموع الأعمدة", ev["rows"][2][4] == "1,333.33" and not ev["errors"], ev)
amb = R.evaluate_table({"columns": ["a"], "rows": [["1,000"], ["500"], ["=SUM(A1:A2)"]]})
check("SUM لا يتجاهل رقماً ملتبساً بصمت", amb["rows"][2][0] == "#خطأ" and amb["errors"], amb)
check("قسمة على صفر في معادلة", R.compute_calc({"inputs": [{"name": "a", "label": "a", "value": 1}], "formula": "a/0"})["error"] != "")
r = R.compute_calc({"inputs": [{"name": "a", "label": "a", "value": 1250.5}], "formula": "round(pct(a,19),2)"})
check("معادلة round+pct", r["result"] == 237.6, r)

# ---- 2) الفحص الحسابي للوثيقة ----------------------------------------------------------------------------
good = {"doc_type": "invoice", "number": "F-001", "date": "2021-03-01", "currency": "DZD",
        "lines": [{"desc": "أ", "qty": 2, "unit_price": 500, "amount": 1000},
                  {"desc": "ب", "qty": 1, "unit_price": 250.5, "amount": 250.5}],
        "totals": {"ht": 1250.5, "vat_rate": 19, "vat": 237.6, "ttc": 1488.1}}
d, bad = A.normalize_doc(good)
check("وثيقة سليمة بلا أخطاء", not [i for i in A.audit_doc(d, bad) if i["sev"] == "error"], A.audit_doc(d, bad))
broken = json.loads(json.dumps(good))
broken["lines"][0]["amount"] = 1100          # 2×500 ≠ 1100
broken["totals"]["ttc"] = 1500               # ≠ ht+vat
d2, bad2 = A.normalize_doc(broken)
c2 = codes(A.audit_doc(d2, bad2))
check("يكشف كمية×سعر", "line_mul" in c2, c2)
check("يكشف مجموع البنود", "sum_lines" in c2, c2)
check("يكشف الإجمالي", "ttc" in c2, c2)
vat_bad = json.loads(json.dumps(good)); vat_bad["totals"]["vat"] = 300
check("يكشف الرسم", "vat" in codes(A.audit_doc(*A.normalize_doc(vat_bad))))
amb_doc = json.loads(json.dumps(good)); amb_doc["totals"]["ht"] = "1,250"
dd, bb = A.normalize_doc(amb_doc)
check("رقم ملتبس لا يُخمَّن", "ambiguous" in codes(A.audit_doc(dd, bb)))
other = json.loads(json.dumps(good)); other["totals"]["ttc"] = 1999
cx = A.cross_check([("نسخة الطرف أ", A.normalize_doc(good)[0]), ("نسخة الطرف ب", A.normalize_doc(other)[0])])
check("تعارض نسختين لنفس الفاتورة", len(cx) == 1 and "F-001" in cx[0], cx)

# ---- 3) القراءة المزدوجة والتقاط التداخل --------------------------------------------------------------------
check("1 250,00 = 1.250,00", not RI.ocr_number_diff("Total 1 250,00", "Total 1.250,00"))
df = RI.ocr_number_diff("Total 1 250,00 TVA 237,50", "Total 1 280,00 TVA 237,50")
check("اختلاف رقم بين قراءتين", df == [{"a": "1 250,00", "b": "1 280,00"}], df)
check("رقم ناقص في قراءة", RI.ocr_number_diff("مبلغ 45 000,00", "مبلغ")[0]["b"] == "")
words = ["w%d" % i for i in range(600)]
ch = RI.chunk_text("المادة 1 " + " ".join(words))
joined = RI._join_chunks([("1", c) for c in ch]).split()
check("إعادة الوصل بلا تكرار ولا نقص", joined[2:] == words and len(ch) > 2, (len(ch), len(joined)))

# ---- 4) تدقيق قضية كاملة بمفهرس وذكاء مزيّفين ----------------------------------------------------------------
tmp = tempfile.mkdtemp()
A._path = lambda case: os.path.join(tmp, "audit_%s.json" % case)


class FakeIdx(object):
    def __init__(self):
        self.texts = {"فاتورة.pdf": "Facture F-001 total 1488,10 DA " * 5, "عقد.pdf": "عقد إيجار 2021 لا مبالغ", "قديم.pdf": "Facture F-001 TTC 1999,00 DA " * 5}

    def case_sources(self, case):
        return [{"doc_key": "k|" + t, "title": t, "party": "", "sha": "sha-" + t} for t in self.texts]

    def full_text(self, title, case=None):
        return self.texts[title]

    def ocr_flags(self, key):
        return [{"page": "2", "a": "1 250,00", "b": "1 280,00"}] if "فاتورة" in key else []


calls = []


def fake_ai(prompt, system=None, as_json=False, search=False):
    calls.append(1)
    return json.dumps(broken if "قديم" not in prompt else other)


idx = FakeIdx()
res = A.audit_case("100", idx, fake_ai)
check("العقد بلا مبالغ لا يُستخرج", res["docs"] == 2 and len(calls) == 2, (res["docs"], len(calls)))
txt = "\n".join(res["issues"])
check("تظهر أخطاء الحساب والتعارض وخلاف القراءة", "❌" in txt and "اختلفت قراءتا" in txt and "تعارض بين نسخ" in txt, txt)
A.audit_case("100", idx, fake_ai)
check("التخزين: لا إعادة استخراج لوثيقة لم تتغيّر", len(calls) == 2, len(calls))
fe = A.facts_evidence("100")
check("الأدلة المنظّمة تحمل نتيجة الفحص", fe and "أخطاء" in fe[0]["text"] and fe[0]["title"].startswith(R.FACTS_PREFIX))
key = "k|فاتورة.pdf"
fields = dict((fp, v) for fp, _l, v in A.doc_fields(A.load("100")["docs"][key]["doc"]))
A.set_confirmed("100", key, {"lines.0.amount": 1000.0, "totals.ttc": None})
st = A.load("100")["docs"][key]
check("التصحيح يُعاد فحصه حسابياً", not any(i["code"] == "line_mul" for i in st["issues"]), codes(st["issues"]))
check("التأكيد يحفظ القيمة الأصلية", st["original"]["lines.0.amount"] == 1100.0)
txt2 = "\n".join(A.issues_text("100"))
check("تأكيد قراءة خاطئة حسابياً لا يخفي تناقض الوثيقة", "القراءة مؤكَّدة" in txt2 and "المبلغ الإجمالي" in txt2, txt2)

# ---- 5) التحقق من الأرقام: ثلاث حالات ----------------------------------------------------------------------
draft = {"case_number": "100",
         "evidence": [{"id": "D1", "kind": "doc", "title": R.FACTS_PREFIX + "فاتورة.pdf", "page": "", "text": "الإجمالي: 1500"},
                      {"id": "D2", "kind": "doc", "title": "x.pdf", "page": "1", "text": "المبلغ 1 250 000 دج ورقم 7"}],
         "calculations": [{"title": "حساب", "formula": "a+b+c+d", "inputs": [
             {"name": "a", "label": "إجمالي", "value": 1500, "source": "D1"},
             {"name": "b", "label": "مبلغ", "value": 1250000, "source": "D2"},
             {"name": "c", "label": "جزء من رقم مجزّأ", "value": 250, "source": "D2"},
             {"name": "d", "label": "غير موجود", "value": 987654, "source": "D2"}]}]}
w = R.verify_inputs(draft)
st = [i["status"] for i in draft["calculations"][0]["inputs"]]
check("الحالات: مؤكَّد/حرفي/مفقود/مفقود", st == ["confirmed", "literal", "missing", "missing"], st)
check("250 لا تُعتبر موجودة لأنها جزء من 1 250 000", st[2] == "missing")
A.set_confirmed("100", key, {"totals.ttc": 1488.1})
draft["evidence"][0]["text"] = "x"
draft["calculations"][0]["inputs"][0]["value"] = 1488.1
R.verify_inputs(draft)
check("رقم أكّده الخبير لنفس الوثيقة", draft["calculations"][0]["inputs"][0]["status"] == "confirmed",
      draft["calculations"][0]["inputs"][0])


# ---- 6) استخراج صحيح: وثيقة طويلة، أرقام مختلقة، حقل خاطئ، بند فائت ----------------------------------------------
long_lines = ["بند %d: صنف %d الكمية 1 السعر %d,00 المبلغ %d,00" % (i, i, 1000 + i, 1000 + i) for i in range(1, 700)]
long_text = "\n".join(long_lines) + "\nالمجموع خارج الرسم HT 999999,00\nTVA 19% 189999,81\nTotal TTC 1189998,81"
segs = A._segments(long_text)
check("الوثيقة الطويلة تُقسَّم لا تُقتطع", len(segs) > 1 and "".join(segs).count("بند ") == 699 and "TTC 1189998,81" in segs[-1], len(segs))
seen_calls = []


def seg_ai(prompt, system=None, as_json=False, search=False):
    seen_calls.append(1)
    if "TTC 1189998,81" in prompt:
        return json.dumps({"doc_type": "invoice", "number": "L-9", "totals": {"ht": 999999, "vat": 189999.81, "vat_rate": 19, "ttc": 1189998.81}})
    return json.dumps({"lines": [{"desc": "x", "qty": 1, "unit_price": 1, "amount": 1}], "number": ""})


dl, _b = A.extract_document(long_text, "طويلة", seg_ai)
check("الدمج يأخذ المجاميع من الجزء الأخير", dl["totals"]["ttc"] == 1189998.81 and dl["number"] == "L-9" and len(seen_calls) == len(segs))

txt = "فاتورة رقم F-77\nالمجموع HT 1 000,00\nTVA 19% 190,00\nTotal TTC 1 190,00\nبند إضافي فات 3 450,00\nالرصيد المتبقي 400,00\nتاريخ 12/03/2021"
doc = {"doc_type": "invoice", "number": "F-77", "currency": "DZD", "lines": [],
       "totals": {"ht": 1000.0, "vat_rate": 19.0, "vat": 190.0, "ttc": 1190.0, "paid": 777.0, "balance": 400.0}}
dd, _ = A.normalize_doc(doc)
tc = {i["code"]: i for i in A.text_checks(dd, txt)}
check("رقم مختلق غير وارد في النص", "not_in_text" in tc and "777" in tc["not_in_text"]["msg"], list(tc))
check("بند فات الاستخراج يُكشف", "uncovered" in tc and "3 450,00" in tc["uncovered"]["msg"], tc.get("uncovered"))
swapped = json.loads(json.dumps(doc)); swapped["totals"]["paid"] = 400.0; swapped["totals"]["balance"] = 777.0
sw, _ = A.normalize_doc(swapped)
check("رقم بحقل لا يناسب كلمته (400 ليس «مدفوعاً»)", any(i["code"] == "label_far" and "المدفوع" in i["msg"] for i in A.text_checks(sw, txt)),
      [i["msg"] for i in A.text_checks(sw, txt)])
check("التاريخ لا يُحسب رقماً فائتاً", "12" not in tc.get("uncovered", {"msg": ""})["msg"].replace("3 450,00", ""))

# التغطية
class CovIdx(FakeIdx):
    def case_coverage(self, case):
        return [{"doc_key": "a", "title": "ممسوحة.pdf", "status": "no_text", "n_chunks": 0, "ocr_pages": 3, "ocr_done": 0},
                {"doc_key": "b", "title": "جزئية.pdf", "status": "ok", "n_chunks": 4, "ocr_pages": 2, "ocr_done": 1},
                {"doc_key": "c", "title": "سليمة.pdf", "status": "ok", "n_chunks": 9, "ocr_pages": 0, "ocr_done": 1}]


cv = A.coverage_issues("100", CovIdx(), [("ملف.rar", "نوع الملف غير مدعوم")])
check("التغطية: غير مدعوم + بلا نص + صفحات ناقصة", len(cv) == 3 and cv[0].startswith("❌") and "ملف.rar" in cv[0] and cv[2].startswith("⚠"), cv)

# الإحالات إلى وثائق غير موجودة
ref_doc = {"title": "فاتورة", "doc": dict(good, refs=[{"type": "أمر شراء", "number": "BC-2020/15"}, {"type": "عقد", "number": "CT-5"}])}
other_doc = {"title": "عقد", "doc": dict(good, number="CT-5", refs=[])}


class RefIdx(FakeIdx):
    def full_text(self, title, case=None):
        return "نص عام بلا ذكر للأمر"


rf = A.unresolved_refs({"docs": {"k1": ref_doc, "k2": other_doc}}, RefIdx(), "100")
check("إحالة إلى أمر شراء غير موجود فقط", len(rf) == 1 and "BC-2020/15" in rf[0], rf)

# ---- 7) الأساس القانوني --------------------------------------------------------------------------------------
ref_text = "المادة 124 مكرر: يُحسب الرسم بنسبة 19% من المبلغ.\nالمادة 125: غرامة التأخير 3% شهرياً."
dr = {"case_number": "100",
      "evidence": [{"id": "R1", "kind": "ref", "title": "قانون الرسم 2018", "page": "3", "text": ref_text},
                   {"id": "D1", "kind": "doc", "title": "x", "page": "", "text": "..."}],
      "calculations": [
          {"title": "سليم", "formula": "a*19/100", "inputs": [{"name": "a", "value": 1000}], "law_dependent": True,
           "basis": [{"ref": "R1", "article": "المادة 124", "figure": "19", "applies": "فاتورة بيع بعد صدور النص", "as_of": "2020-03-01"}]},
          {"title": "مادة وهمية", "formula": "a*5/100", "inputs": [{"name": "a", "value": 1000}], "law_dependent": True,
           "basis": [{"ref": "R1", "article": "المادة 999", "figure": "5", "applies": "x", "as_of": "2020-03-01"}]},
          {"title": "نسبة وهمية", "formula": "a*7/100", "inputs": [{"name": "a", "value": 1000}], "law_dependent": True,
           "basis": [{"ref": "R1", "article": "المادة 125", "figure": "7", "applies": "x", "as_of": "2020-03-01"}]},
          {"title": "بلا أساس", "formula": "a*3/100", "inputs": [{"name": "a", "value": 1000}], "law_dependent": True, "basis": []},
          {"title": "إحالة لدليل غير مرجع", "formula": "a", "inputs": [{"name": "a", "value": 1}], "law_dependent": True,
           "basis": [{"ref": "D1", "article": "المادة 1", "figure": "", "applies": "x"}]},
          {"title": "مرجع لاحق", "formula": "a*19/100", "inputs": [{"name": "a", "value": 1}], "law_dependent": True,
           "basis": [{"ref": "R1", "article": "المادة 124", "figure": "19", "applies": "x", "as_of": "2015-01-01"}]},
          {"title": "نسبة لا تُستعمل", "formula": "a*3/100", "inputs": [{"name": "a", "value": 1000}], "law_dependent": True,
           "basis": [{"ref": "R1", "article": "المادة 124", "figure": "19", "applies": "x", "as_of": "2020-03-01"}]}],
      "tables": []}
ln = R.legal_notes(dr)
by = {t: [x for x in ln if "«%s»" % t in x] for t in ("سليم", "مادة وهمية", "نسبة وهمية", "بلا أساس", "إحالة لدليل غير مرجع", "مرجع لاحق", "نسبة لا تُستعمل")}
check("أساس سليم يُعرض للاعتماد لا يُعتمد تلقائياً", len(by["سليم"]) == 1 and by["سليم"][0].startswith("⚖"), by["سليم"])
check("مادة غير موجودة في المرجع", "999" in by["مادة وهمية"][0] and by["مادة وهمية"][0].startswith("❌"), by["مادة وهمية"])
check("نسبة غير واردة في المرجع", "الرقم 7 لا يرد" in by["نسبة وهمية"][0], by["نسبة وهمية"])
check("حساب قانوني بلا أساس", by["بلا أساس"][0].startswith("❌") and "بلا أساس موثّق" in by["بلا أساس"][0])
check("الإحالة إلى غير مرجع", "ليس مرجعاً" in by["إحالة لدليل غير مرجع"][0])
check("مرجع صادر بعد الواقعة", "بعد تاريخ الواقعة" in by["مرجع لاحق"][0], by["مرجع لاحق"])
check("رقم أساسي لا يستعمله الحساب", "لا يُستعمل" in by["نسبة لا تُستعمل"][0], by["نسبة لا تُستعمل"])
dr["legal_resolved"] = [by["سليم"][0]]
check("المعالَج يختفي", not any("«سليم»" in x for x in R.legal_notes(dr)))


# ---- 8) مراجع المنهج والتمارين: تُستلهم ولا تُنقل منها أرقام -------------------------------------------------------
book = {"id": "R2", "kind": "ref", "title": "محاسبة الخبرة القضائية", "category": "كتب ومنهج", "page": "40",
        "text": "حل: يبلغ الربح 45000 دج والتكلفة 120000 دج."}
ex_nocat = {"id": "R3", "kind": "ref", "title": "مرجع", "category": "", "page": "9",
            "text": "تمرين 3: شركة بلغت مبيعاتها 870000 دج. الحل: ..."}
law = {"id": "R1", "kind": "ref", "title": "قانون الرسم 2018", "category": "ضرائب", "page": "3",
       "text": "المادة 124: الرسم بنسبة 19% ويُحدَّد الحد الأدنى بـ 100000 دج."}
docev = {"id": "D1", "kind": "doc", "title": "فاتورة", "page": "1", "text": "المبلغ 250000 دج"}
check("تصنيف الكتاب بالتصنيف", R.is_method_ref(book))
check("تصنيف تمرين بلا تصنيف من علاماته", R.is_method_ref(ex_nocat))
check("القانون ليس منهجاً", not R.is_method_ref(law) and not R.is_method_ref(docev))
blk = R._evidence_block([book, law])
check("الكتاب يُوسم للنموذج", "مرجع منهجي/أمثلة" in blk.split("[R1]")[0] and "أرقامه محجوبة عمداً" in blk and "مرجع منهجي" not in blk.split("[R1]")[1])
dm = {"case_number": "100", "evidence": [book, ex_nocat, law, docev],
      "calculations": [{"title": "ح", "formula": "a+b+c+d", "inputs": [
          {"name": "a", "label": "ربح من الكتاب", "value": 45000, "source": "R2"},
          {"name": "b", "label": "مبيعات التمرين", "value": 870000, "source": "R3"},
          {"name": "c", "label": "حد قانوني", "value": 100000, "source": "R1"},
          {"name": "d", "label": "فاتورة", "value": 250000, "source": "D1"}]}]}
wn = R.verify_inputs(dm)
st = [i["status"] for i in dm["calculations"][0]["inputs"]]
check("أرقام الكتاب والتمرين مرفوضة والقانون والوثيقة مقبولان", st == ["rejected", "rejected", "literal", "literal"], st)
check("الرفض يُحسب غير متحقَّق منه (يوقف التصدير بسؤال)", [i["verified"] for i in dm["calculations"][0]["inputs"]] == [False, False, True, True])
dl2 = {"case_number": "100", "evidence": [book, law, docev],
       "calculations": [
           {"title": "مستلهم", "formula": "a", "inputs": [{"name": "a", "value": 250000}], "method_sources": ["R2"], "law_dependent": False, "basis": []},
           {"title": "أساس كتاب", "formula": "a", "inputs": [{"name": "a", "value": 1}], "law_dependent": True,
            "basis": [{"ref": "R2", "article": "المادة 1", "figure": "", "applies": "x"}]},
           {"title": "نظيف", "formula": "a", "inputs": [{"name": "a", "value": 250000}], "method_sources": ["R1"], "law_dependent": False, "basis": []}],
       "tables": [{"title": "جدول", "columns": ["أ", "ب"], "rows": [["ربح", "45000"], ["من فاتورة", "250000"], ["قانوني", "100000"], ["مجموع", "=SUM(B1:B3)"]],
                   "sources": [], "law_dependent": False, "basis": []}]}
lg = R.legal_notes(dl2)
check("استلهام من كتاب يصير بند اعتماد للخبير", any("«مستلهم»" in x and x.startswith("⚖") and "معمول بها عندنا" in x for x in lg), lg)
check("الكتاب لا يصلح أساساً قانونياً", any("«أساس كتاب»" in x and x.startswith("❌") and "كتاب أو أمثلة" in x for x in lg), lg)
check("تسرّب رقم مثال إلى جدول", any("«جدول»" in x and x.startswith("❌") and "45,000" in x and "250,000" not in x for x in lg), lg)
check("الحساب المستند إلى قانون فقط لا ملاحظات عليه", not any("«نظيف»" in x for x in lg), lg)


# ---- 9) المنع من المنبع: أرقام الأمثلة لا تصل إلى النموذج أصلاً ------------------------------------------------------
ex = "تمرين 3: بلغت المبيعات 1 250 000,00 دج بتاريخ 12/03/2019 ونسبة الرسم ١٩٪.\n1) نحسب الربح = 45000 - 12000\n2- نُعدّ جدول المطابقة"
mk = R.mask_numbers(ex)
body = mk.replace("⟦م⟧", "")
check("حجب كل الأرقام عدا ترقيم الخطوات", "1) نحسب" in mk and "2- نُعدّ" in mk and not any(ch.isdigit() for ch in body.replace("1) ", "").replace("2- ", "")), mk)
blk2 = R._evidence_block([dict(book, text=ex), dict(law)])
book_part = blk2.split("[R1]")[0]
check("نص الكتاب المرسل للنموذج بلا أرقام", "1 250 000" not in book_part and "45000" not in book_part and "⟦م⟧" in book_part, book_part)
check("القانون يُرسل كما هو", "19%" in blk2.split("[R1]")[1] and "100000" in blk2.split("[R1]")[1])
check("التمرين المكتشف من علاماته يُحجب أيضاً", "870000" not in R._evidence_block([ex_nocat]))
check("النسخة المحفوظة للخبير لا تتغيّر", "45000" in book["text"])

print("\n" + ("نجحت كل الاختبارات" if not FAILS else "إخفاقات: %d" % len(FAILS)))
sys.exit(1 if FAILS else 0)
