# -*- coding: utf-8 -*-
"""
ui_style.py
-----------
تنسيق الواجهة العام (الخط + اتجاه RTL) -- يستورده login_app.py و settings_page.py و main_app.py:

    apply_global_font(app, family, size)   -> تطبيق الخط على كل البرنامج
    install_rtl_button_style(app)          -> أزرار (نص + أيقونة): الجملة في وسط الزر ثم الأيقونة بعدها
    install_rtl_field_alignment(app)       -> محاذاة يمين لكل حقول الإدخال (والنص التوضيحي)
    install_rtl_text_alignment(app)        -> مؤشر الكتابة من اليمين في QTextEdit / QPlainTextEdit
    refresh_rtl(app)                       -> إعادة تطبيق/إلغاء ما سبق بعد تغيير اللغة أثناء التشغيل

ملاحظة: كل المرشّحات تفحص اتجاه التطبيق الحالي عند كل إظهار؛ فإذا صارت اللغة
غير عربية تعود الحقول والأزرار لسلوك Qt الافتراضي (محاذاة يسار).
"""
from PyQt5.QtCore import QObject, QEvent, QRect, Qt
from PyQt5.QtGui import QFont, QFontMetrics, QIcon, QTextOption
from PyQt5.QtWidgets import (QApplication, QLineEdit, QPlainTextEdit, QPushButton,
                             QStyle, QStyleOptionButton, QStylePainter, QTextEdit)

_FONT_START = "/* ui_style:font:start */"
_FONT_END = "/* ui_style:font:end */"

_RTL_ABS = Qt.AlignRight | Qt.AlignAbsolute | Qt.AlignVCenter   # AlignAbsolute ضروري: بدونه ينعكس إلى اليسار في RTL
_LEAD = Qt.AlignLeading | Qt.AlignVCenter


def _is_rtl():
    return QApplication.layoutDirection() == Qt.RightToLeft


# ---------------------------------------------------------------- الخط
def apply_global_font(app, family, size):
    """يطبّق الخط على كل الواجهة، ويمكن استدعاؤه أكثر من مرة (من الإعدادات)."""
    family = (family or "Arial").strip() or "Arial"
    try:
        size = int(size)
    except (TypeError, ValueError):
        size = 13
    size = max(8, min(size, 40))

    # حجم الخط في إعدادات البرنامج بالبكسل (13 ≈ 10pt مثل FONT_SIZE_BASE في الثيم)
    f = QFont(family)
    f.setPixelSize(size)
    app.setFont(f)

    # قاعدة Stylesheet للعائلة فقط (تتجاوز setFont الصريح في النوافذ)، ولا نفرض الحجم
    # كي تحتفظ العناصر بأحجامها المضبوطة في الصفحات (عناوين، بطاقات، أزرار...).
    existing = app.styleSheet() or ""
    start, end = existing.find(_FONT_START), existing.find(_FONT_END)
    if start != -1 and end > start:
        existing = existing[:start] + existing[end + len(_FONT_END):]
    block = (f'\n{_FONT_START}\n'
             f'* {{ font-family: "{family}"; }}\n'
             f'{_FONT_END}\n')
    app.setStyleSheet(block + existing)    # في البداية: لقواعد modern_theme الأفضلية عند التعارض


# ---------------------------------------------------------------- رسم الأزرار
# هامش أدنى مضمون بين حافة الزر ومحتواه (بكسل) من كل جهة: المحتوى في الوسط ولا يلتصق بالحدّ
EDGE_MARGIN = 16
ICON_TEXT_GAP = 8          # المسافة بين النص والأيقونة (تُستعمل في القياس والرسم)
ICON_GAP = ICON_TEXT_GAP


def _group_width(btn):
    """عرض المجموعة (نص + أيقونة) كما سيرسمها Qt بخط الزر الفعلي (بعد تطبيق الـ stylesheet)."""
    btn.ensurePolished()
    f = QFont(btn.font())
    f.setBold(True)                            # نقيس بالخط العريض: أعرض حالة، فلا يُقصّ النص أبداً
    fm = QFontMetrics(f)
    text = btn.text().replace("&", "")
    try:
        tw = fm.horizontalAdvance(text)
    except AttributeError:                     # Qt أقدم من 5.11
        tw = fm.width(text)
    if btn.icon().isNull():
        return tw
    return tw + ICON_TEXT_GAP + btn.iconSize().width()


class RtlButtonPainter(QObject):
    """يُركَّب على كل QPushButton فيه نص (مع أيقونة أو بدونها): النص في وسط الزر، وتتبعه الأيقونة يساره."""

    def eventFilter(self, obj, event):
        if event.type() != QEvent.Paint or not isinstance(obj, QPushButton):
            return False
        fit_button(obj)
        if not _is_rtl() or not obj.text():
            return False                       # الرسم الافتراضي (بلا نص/لغة LTR)
        try:
            self._paint(obj)
        except Exception:
            return False
        return True

    def _paint(self, btn):
        opt = QStyleOptionButton()
        opt.initFrom(btn)
        opt.rect = btn.rect()
        opt.iconSize = btn.iconSize()
        opt.features = QStyleOptionButton.ButtonFeatures()
        if btn.isFlat():
            opt.features |= QStyleOptionButton.Flat
        if btn.menu() is not None:
            opt.features |= QStyleOptionButton.HasMenu
        if btn.isDefault():
            opt.features |= QStyleOptionButton.DefaultButton
        if btn.isDown():
            opt.state |= QStyle.State_Sunken
        if btn.isChecked():
            opt.state |= QStyle.State_On
        if not btn.isFlat() and not btn.isDown():
            opt.state |= QStyle.State_Raised

        p = QStylePainter(btn)
        # 1) الخلفية والإطار (تحترم الـ stylesheet) بلا نص ولا أيقونة
        p.drawControl(QStyle.CE_PushButtonBevel, opt)

        # 2) نرسم المجموعة بأنفسنا: [أيقونة][فراغ][نص] متوسّطة في الزر. (رسم Qt للنص مع الأيقونة داخل
        #    الـ stylesheet لا يوسّطهما: يضع الأيقونة في المنتصف والنص عند الحافة.) النص وحده يُرسم عبر
        #    Qt (فيحتفظ بلونه وحالاته من الـ stylesheet)، والأيقونة نرسمها يدوياً بمحاذاة النص.
        full = btn.rect()
        fm = btn.fontMetrics()
        text = btn.text()
        try:
            tw = fm.horizontalAdvance(text)
        except AttributeError:
            tw = fm.width(text)
        has_icon = not btn.icon().isNull()
        isz = btn.iconSize()
        iw, ih = (isz.width(), isz.height()) if has_icon else (0, 0)
        gap = ICON_GAP if has_icon else 0
        group = iw + gap + tw
        left = full.left() + (full.width() - group) / 2.0     # حافة المجموعة اليسرى (إن ضاقت: تتوسّط)
        icon_x = int(round(left))
        text_center = left + iw + gap + tw / 2.0

        inner = btn.style().subElementRect(QStyle.SE_PushButtonContents, opt, btn)
        pad_l = inner.left() - full.left()
        pad_r = full.right() - inner.right()
        rc = text_center - (pad_l - pad_r) / 2.0               # يعوّض اختلاف الـ padding بين الجهتين

        lab = QStyleOptionButton(opt)
        lab.rect = QRect(int(round(rc - full.width() / 2.0)), full.top(), full.width(), full.height())
        lab.text = text
        lab.direction = Qt.LeftToRight
        p.drawControl(QStyle.CE_PushButtonLabel, lab)

        if not has_icon:
            p.end()
            return
        mode = QIcon.Normal if btn.isEnabled() else QIcon.Disabled
        state = QIcon.On if btn.isChecked() else QIcon.Off
        icon_y = full.top() + (full.height() - ih) // 2
        btn.icon().paint(p, QRect(icon_x, icon_y, iw, ih), Qt.AlignCenter, mode, state)
        p.end()


def _apply_limits(btn, prop, lo, hi, set_lo, set_hi, need):
    """يرفع الحدّ الأدنى/الأقصى (عرضاً أو ارتفاعاً) ليتسع لـ need، ويعيده لقيمته الأصلية إذا صغر المطلوب
    (تصغير الخط أو تقصير النص). القيم الأصلية تُحفظ، ويُعاد حفظها إن غيّرها الكود لاحقاً عمداً."""
    cur = (lo, hi)
    mine = btn.property(prop + "_mine")
    if mine is None or tuple(mine) != cur:
        orig = cur                              # قيم جديدة وضعها الكود (أو أول مرة)
    else:
        orig = tuple(btn.property(prop + "_orig"))
    btn.setProperty(prop + "_orig", list(orig))
    new_lo = max(orig[0], need)
    new_hi = max(orig[1], need) if orig[1] < 16777215 else orig[1]
    if new_lo != lo:
        set_lo(new_lo)
    if new_hi != hi:
        set_hi(new_hi)
    btn.setProperty(prop + "_mine", [new_lo, new_hi])


def fit_button(btn):
    """يجعل كل زر فيه نص يتسع تلقائياً لنصه وأيقونته (عرضاً وارتفاعاً) مع هامش من الجهتين، ويُعاد الحساب
    عند تغيير الخط (النوع/الحجم/السماكة) أو النص أو الأيقونة، فلا يلتصق النص بالحدّ ولا يُقصّ أبداً."""
    try:
        if not btn.text().strip() or btn.property("_no_fit"):
            return
        key = (btn.text(), btn.icon().isNull(), btn.iconSize().width(),
               btn.font().pixelSize(), btn.font().pointSizeF(), btn.font().bold(),
               btn.font().family(), btn.styleSheet())
        if btn.property("_fit_key") == str(key):
            return
        btn.setProperty("_fit_key", str(key))
        btn.ensurePolished()
        need_w = max(btn.sizeHint().width(), _group_width(btn) + 2 * EDGE_MARGIN) + 2
        if btn.menu() is not None:
            need_w += 22                       # مكان سهم القائمة (يرسمه الـ style مرة واحدة)
        need_h = QFontMetrics(btn.font()).height() + 10
        _apply_limits(btn, "_fit_w", btn.minimumWidth(), btn.maximumWidth(),
                      btn.setMinimumWidth, btn.setMaximumWidth, need_w)
        _apply_limits(btn, "_fit_h", btn.minimumHeight(), btn.maximumHeight(),
                      btn.setMinimumHeight, btn.setMaximumHeight, need_h)
        btn.updateGeometry()
    except RuntimeError:
        pass


# ---------------------------------------------------------------- مرشّح عام (يُطبَّق عند الإظهار)
class _RtlFilter(QObject):
    def __init__(self, parent=None, buttons=False, fields=False, texts=False):
        super().__init__(parent)
        self.buttons, self.fields, self.texts = buttons, fields, texts
        self._painter = RtlButtonPainter(self)

    def eventFilter(self, obj, event):
        if self.buttons and event.type() in (QEvent.FontChange, QEvent.StyleChange) \
                and isinstance(obj, QPushButton) and obj.property("_ui_style_btn"):
            fit_button(obj)                    # تغيّر الخط/التنسيق: أعد ملاءمة الزر لنصه
        if event.type() == QEvent.Show:
            try:
                if self.buttons and isinstance(obj, QPushButton):
                    self.apply_button(obj)
                elif self.fields and isinstance(obj, QLineEdit):
                    apply_line(obj)
                elif self.texts and isinstance(obj, (QTextEdit, QPlainTextEdit)):
                    apply_text(obj)
            except RuntimeError:
                pass                           # الودجت حُذف
        return False

    def apply_button(self, btn):
        if not btn.property("_ui_style_btn"):
            btn.installEventFilter(self._painter)
            btn.setProperty("_ui_style_btn", True)
        fit_button(btn)
        btn.update()


def _explicit_ltr(w):
    """حقل ضُبط اتجاهه LTR عمداً (مفاتيح الترخيص، البريد...) فلا نغيّره."""
    return w.testAttribute(Qt.WA_SetLayoutDirection) and w.layoutDirection() == Qt.LeftToRight


def apply_line(edit):
    if _explicit_ltr(edit):
        return
    edit.setAlignment(_RTL_ABS if _is_rtl() else _LEAD)


def apply_text(edit):
    doc = edit.document()
    opt = doc.defaultTextOption()
    if _is_rtl():
        opt.setTextDirection(Qt.RightToLeft)
        opt.setAlignment(Qt.AlignRight | Qt.AlignAbsolute)
    else:
        opt.setTextDirection(Qt.LeftToRight)
        opt.setAlignment(Qt.AlignLeft | Qt.AlignAbsolute)
    doc.setDefaultTextOption(opt)


# ---------------------------------------------------------------- واجهة الاستخدام
def _install(app, **kw):
    flt = _RtlFilter(app, **kw)
    app.installEventFilter(flt)
    if not hasattr(app, "_ui_style_filters"):
        app._ui_style_filters = []
    app._ui_style_filters.append(flt)
    # الودجات المعروضة أصلاً قبل التركيب
    for w in app.allWidgets():
        if w.isVisible():
            try:
                if kw.get("buttons") and isinstance(w, QPushButton):
                    flt.apply_button(w)
                elif kw.get("fields") and isinstance(w, QLineEdit):
                    apply_line(w)
                elif kw.get("texts") and isinstance(w, (QTextEdit, QPlainTextEdit)):
                    apply_text(w)
            except RuntimeError:
                pass
    return flt


def install_rtl_button_style(app):
    return _install(app, buttons=True)


def install_rtl_field_alignment(app):
    return _install(app, fields=True)


def install_rtl_text_alignment(app):
    return _install(app, texts=True)


def refresh_rtl(app=None):
    """يُستدعى بعد تغيير لغة الواجهة: يعيد ضبط كل الحقول والأزرار الموجودة حسب الاتجاه الجديد."""
    app = app or QApplication.instance()
    if app is None:
        return
    flts = getattr(app, "_ui_style_filters", [])
    has_fields = any(f.fields for f in flts)
    has_texts = any(f.texts for f in flts)
    for w in app.allWidgets():
        try:
            if has_fields and isinstance(w, QLineEdit):
                apply_line(w)
            elif has_texts and isinstance(w, (QTextEdit, QPlainTextEdit)):
                apply_text(w)
            elif isinstance(w, QPushButton) and w.property("_ui_style_btn"):
                w.update()
        except RuntimeError:
            pass
