from jinja2 import Environment, FileSystemLoader

import storage
import report_output as ro


def generate_attendance_report(data):
    env = ro.make_env()
    template = env.get_template("attendance_report.html")

    # حجم الخط قابل للتحكم عبر الإعدادات (القيمة الافتراضية 18px)
    data.setdefault("font_size", 18)
    data.setdefault("font_family", storage.get_font_family())

    import doc_signing
    data.update(doc_signing.issue_fields("محضر حضور", data.get("case_number"), data.get("date")))
    html = template.render(data)
    html_file = ro.write_html("attendance_report_result.html", html)

    case_part = ro.safe_name(data.get("case_number"))
    pdf_file = ro.html_to_pdf(html_file, "attendance", f"attendance_report_{case_part}.pdf")
    return html_file, pdf_file
