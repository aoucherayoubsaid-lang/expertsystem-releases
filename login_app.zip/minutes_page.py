# minutes_page.py
"""
تبويب "محاضر" الموحّد: يجمع محضر الحضور ومحضر الانتقال في تبويبات فرعية (Menu Tabs)
داخل تبويب علوي واحد بدلاً من تبويبين منفصلين.
"""

from PyQt5.QtWidgets import QWidget, QVBoxLayout, QTabWidget
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
import qtawesome as qta
from modern_theme import SUB_TAB_QSS

from attendanceRap_app import AttendanceReportPage
from visit_Page import AttendanceVisitPage


class MinutesPage(QWidget):
    def __init__(self, case_page, document_page, party_page, main_app=None):
        super().__init__()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.sub_tabs = QTabWidget()
        # ضبط الخط عبر setFont (لا داخل stylesheet) حتى يحسب Qt عرض
        # التبويبات بشكل صحيح فلا تُقصّ أسماؤها.
        self.sub_tabs.tabBar().setFont(QFont("Segoe UI", 11, QFont.Bold))
        self.sub_tabs.tabBar().setElideMode(Qt.ElideNone)
        self.sub_tabs.tabBar().setExpanding(False)
        self.sub_tabs.tabBar().setUsesScrollButtons(True)
        self.sub_tabs.setStyleSheet(SUB_TAB_QSS)

        self.attendance_page = AttendanceReportPage(case_page, document_page, party_page, main_app)
        self.sub_tabs.addTab(self.attendance_page, qta.icon("fa5s.sticky-note", color="#4338ca"), "محضر الحضور")

        self.visit_page = AttendanceVisitPage(case_page, document_page)
        self.sub_tabs.addTab(self.visit_page, qta.icon("fa5s.car", color="#4338ca"), "محضر الانتقال")

        layout.addWidget(self.sub_tabs)

    def reload(self):
        """إعادة تحميل بيانات التبويبين الفرعيين معاً."""
        if hasattr(self.attendance_page, "reload"):
            self.attendance_page.reload()
        if hasattr(self.visit_page, "reload"):
            self.visit_page.reload()