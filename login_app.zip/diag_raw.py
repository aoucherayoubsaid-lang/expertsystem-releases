# -*- coding: utf-8 -*-
"""يرسل طلبًا مباشرًا إلى expert-ai ويطبع رد الخادم الخام (رمز HTTP + النص)."""
import json
import ssl
import urllib.error
import urllib.request

import license_manager
import ai_client

body = {
    "prompt": "write one word: done",
    "json": False,
    "key": license_manager.current_license_key() or "",
    "machine_id": license_manager.machine_code(),
}
req = urllib.request.Request(
    ai_client.AI_URL.rstrip("/") + "/generate",
    data=json.dumps(body).encode("utf-8"),
    headers={"Content-Type": "application/json", "User-Agent": "ExpertSystem/1.0"})
out = []
try:
    with urllib.request.urlopen(req, timeout=120, context=ai_client._ssl_context()) as r:
        out.append("HTTP %s" % r.status)
        out.append(r.read().decode("utf-8", "replace"))
except urllib.error.HTTPError as e:
    out.append("HTTP %s" % e.code)
    out.append(e.read().decode("utf-8", "replace")[:1500])
except BaseException as e:
    out.append("ERROR %s: %s" % (type(e).__name__, e))

text = "\n".join(out)
print(text.encode("ascii", "backslashreplace").decode("ascii"))
with open("diag_raw_out.txt", "w", encoding="utf-8") as f:
    f.write(text)
print("\n(saved to diag_raw_out.txt)")
