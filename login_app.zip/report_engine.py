# -*- coding: utf-8 -*-
"""محرّك تقرير الخبرة: يجمع المصادر، يطلب مسودة من الذكاء الاصطناعي، ويحسب الأرقام بالكود.

التسلسل:  plan_queries -> retrieve -> draft_report -> (مراجعة الخبير) -> compute_all
- النموذج يقترح العناوين والنصوص والمعادلات فقط، أما الحساب فتنفذه safe_eval (كود).
- لكل معلومة رقم مصدر [R#] مرجع أو [D#] وثيقة، ويُحذف أي مصدر لا وجود له في الأدلة.
- يمكن إخفاء أسماء الأطراف قبل الإرسال واسترجاعها بعد الرد (anonymize=True).
"""
import ast
import json
import math
import operator
import os
import re
from datetime import datetime
from decimal import Decimal, ROUND_DOWN, ROUND_HALF_UP, ROUND_UP

import fx_rates

MAX_EVIDENCE_CHARS = 60000
FACTS_PREFIX = "بيانات مستخرجة: "      # عنوان أدلة doc_audit (الأرقام المستخرجة والمفحوصة حسابياً)

SYSTEM = (
    "أنت مساعد لخبير محاسب قضائي. اعتمد على المصادر المعطاة فقط ولا تخترع معلومة أو رقماً. "
    "إن لم تجد في المصادر ما يكفي فاذكره في حقل missing بدل التخمين. "
    "لا تُجرِ أي عملية حسابية بنفسك: اكتب المعادلة فقط. أعد JSON صالحاً فقط بدون أي شرح خارجه."
)

LANG_RULES = (
    "\n\nقواعد اللغة والمصطلحات: قد تكون الوثائق بالفرنسية أو الإنجليزية أو العربية، وقد تكون نصوصاً مقروءة بالـ OCR فيها "
    "أخطاء قراءة طفيفة: افهمها كاملة واكتب التقرير بالعربية القانونية الرسمية. عند ترجمة مصطلح قانوني أو محاسبي أو جمركي "
    "ابحث عن مقابله العربي المعتمد (في القوانين والنصوص الرسمية الجزائرية أولاً) ولا تترجم حرفياً، وأبقِ المصطلح "
    "الأصلي بين قوسين عند أول ورود. لا تستعمل قاموساً من المستخدم: المصطلحات تتحقق منها أنت."
)


# ---------------------------------------------------------------------------
# أدوات عامة
# ---------------------------------------------------------------------------
def _parse_json(text):
    t = (text or "").strip()
    t = re.sub(r"^```(?:json)?|```$", "", t, flags=re.MULTILINE).strip()
    a, b = t.find("{"), t.rfind("}")
    if a < 0 or b <= a:
        raise ValueError("رد الذكاء الاصطناعي ليس JSON")
    return json.loads(t[a:b + 1])


_AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩٫٬", "0123456789.,")


def to_number(v):
    """يحوّل رقماً مكتوباً بصيغ عربية/فرنسية/إنجليزية إلى float:
    '1 000 000,50 DA' و '1.234.567,89' و '1,234,567.89' و '12,5%' و '١٢٣٫٥'.
    الصيغة الملتبسة (مثل '1,000' أو '1.500' التي قد تكون آلافاً أو عشرية) تُرفض بدل التخمين."""
    if isinstance(v, bool):
        raise ValueError("ليس رقماً")
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).translate(_AR_DIGITS)
    s = re.sub(r"[\s\u00a0\u202f\u2009']", "", s)       # مسافات الآلاف (الفرنسية تستعمل nbsp)
    s = re.sub(r"[^\d.,\-+]", "", s)                       # رموز العملة والنسبة والحروف
    if not re.search(r"\d", s):
        raise ValueError("ليس رقماً: %s" % v)
    unsigned = s.lstrip("+-")
    amb = ValueError("رقم ملتبس (%s): قد تكون الفاصلة أو النقطة آلافاً أو عشرية. اكتبه بنقطة عشرية وبدون فواصل آلاف." % v)
    if "." in s and "," in s:
        dec = "." if s.rfind(".") > s.rfind(",") else ","
        thou = "," if dec == "." else "."
        s = s.replace(thou, "").replace(dec, ".")
    elif "," in s:
        if s.count(",") > 1:
            s = s.replace(",", "")
        else:
            head, tail = unsigned.split(",")
            if len(tail) == 3 and head.isdigit() and 1 <= len(head) <= 3:
                raise amb
            s = s.replace(",", ".")
    elif "." in s:
        if s.count(".") > 1:
            s = s.replace(".", "")
        else:
            head, tail = unsigned.split(".")
            if len(tail) == 3 and head.isdigit() and 1 <= len(head) <= 3 and head != "0":
                raise amb
    return float(s)


def _quant(x, nd, mode):
    """تقريب عشري دقيق: Decimal(repr(x)) يمنع أخطاء الفاصلة العائمة (2.675 تبقى 2.675 لا 2.67499...)."""
    if not math.isfinite(x):
        raise ValueError("نتيجة غير منتهية (لا نهاية أو غير رقم)")
    return float(Decimal(repr(float(x))).quantize(Decimal(1).scaleb(-int(nd)), rounding=mode))


def round_half_up(x, nd=0):
    """التقريب المحاسبي المعتاد: النصف يُقرَّب بعيداً عن الصفر (2.5 → 3، 2.675 → 2.68).
    دالة round في بايثون تقرّب النصف إلى الزوج (2.5 → 2) وهو غير مقبول في الحسابات."""
    return _quant(x, nd, ROUND_HALF_UP)


def round_up(x, nd=0):
    return _quant(x, nd, ROUND_UP)


def round_down(x, nd=0):
    return _quant(x, nd, ROUND_DOWN)


def fmt_num(x):
    if not math.isfinite(x):
        return str(x)
    if abs(x - round(x)) < 1e-9:
        return "{:,}".format(int(round(x)))
    q = Decimal(repr(float(x))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    if q == 0:
        return "0"
    return "{:,.2f}".format(q)


# ---------------------------------------------------------------------------
# دوال مالية مشتركة بين محرّك المعادلات ومحرّك الجداول (أرقام فقط)
# ---------------------------------------------------------------------------
def _pct(x, rate):
    """rate نسبة مئوية: PCT(1000, 19) = 190"""
    return x * rate / 100.0


def _simple_interest(principal, rate_pct, days, basis=365):
    """فائدة بسيطة: الأصل × النسبة% × الأيام ÷ الأساس (365 أو 360 حسب العقد أو المرجع)."""
    if basis <= 0:
        raise ValueError("أساس الأيام يجب أن يكون موجباً")
    return principal * rate_pct / 100.0 * days / basis


def _compound_int(principal, rate_pct, periods):
    """فوائد مركّبة فقط (دون الأصل): الأصل × ((1+r)^n − 1)."""
    if abs(periods) > 600:
        raise ValueError("عدد فترات كبير جداً")
    return principal * ((1.0 + rate_pct / 100.0) ** periods - 1.0)


def _pmt(rate_pct, n, pv):
    """القسط الدوري الثابت لقرض: rate_pct نسبة الفترة الواحدة، n عدد الفترات، pv أصل القرض."""
    n = int(n)
    if n <= 0:
        raise ValueError("عدد الأقساط يجب أن يكون موجباً")
    r = rate_pct / 100.0
    if r == 0:
        return pv / n
    return pv * r / (1.0 - (1.0 + r) ** (-n))


def _months_between(d1, d2):
    """الأشهر الكاملة المنقضية من d1 إلى d2."""
    if d2 < d1:
        raise ValueError("تاريخ النهاية قبل تاريخ البداية")
    m = (d2.year - d1.year) * 12 + (d2.month - d1.month)
    if d2.day < d1.day:
        m -= 1
    return m


def _months_started(d1, d2):
    """عدد الأشهر مع احتساب كل شهر بدأ ولو بيوم واحد («عن كل شهر أو جزء منه»)."""
    import calendar
    full = _months_between(d1, d2)
    y, mo = d1.year + (d1.month - 1 + full) // 12, (d1.month - 1 + full) % 12 + 1
    anchor = d1.replace(year=y, month=mo, day=min(d1.day, calendar.monthrange(y, mo)[1]))
    return full + (1 if d2 > anchor else 0)


def _days_between(d1, d2):
    if d2 < d1:
        raise ValueError("تاريخ النهاية قبل تاريخ البداية")
    return (d2 - d1).days


class _Anonymizer:
    """يستبدل أسماء الأطراف برموز قبل الإرسال ويعيدها بعد الرد."""

    def __init__(self, names):
        names = sorted({n.strip() for n in names if n and len(n.strip()) >= 3}, key=len, reverse=True)
        self.fwd = {n: "[الطرف_%d]" % (i + 1) for i, n in enumerate(names)}
        self.back = {v: k for k, v in self.fwd.items()}

    def hide(self, text):
        for n, tok in self.fwd.items():
            text = text.replace(n, tok)
        return text

    def show(self, obj):
        if isinstance(obj, str):
            for tok, n in self.back.items():
                obj = obj.replace(tok, n)
            return obj
        if isinstance(obj, list):
            return [self.show(x) for x in obj]
        if isinstance(obj, dict):
            return {k: self.show(v) for k, v in obj.items()}
        return obj


# ---------------------------------------------------------------------------
# الحساب الآمن (لا eval)
# ---------------------------------------------------------------------------
_BIN = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
        ast.Div: operator.truediv, ast.Pow: operator.pow, ast.Mod: operator.mod}
_UN = {ast.USub: operator.neg, ast.UAdd: operator.pos}
_FUNCS = {"min": min, "max": max, "abs": abs, "round": round_half_up, "roundup": round_up, "rounddown": round_down,
          "pct": _pct, "simple_interest": _simple_interest, "compound_int": _compound_int, "pmt": _pmt}


def safe_eval(expr, variables):
    def ev(n):
        if isinstance(n, ast.Expression):
            return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)) and not isinstance(n.value, bool):
            return n.value
        if isinstance(n, ast.Name):
            if n.id in variables:
                return variables[n.id]
            raise ValueError("متغير غير معرّف في المعادلة: %s" % n.id)
        if isinstance(n, ast.BinOp) and type(n.op) in _BIN:
            a, b = ev(n.left), ev(n.right)
            if isinstance(n.op, ast.Pow) and abs(b) > 100:
                raise ValueError("أس كبير جداً")
            return _BIN[type(n.op)](a, b)
        if isinstance(n, ast.UnaryOp) and type(n.op) in _UN:
            return _UN[type(n.op)](ev(n.operand))
        if (isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in _FUNCS
                and not n.keywords):
            try:
                return _FUNCS[n.func.id](*[ev(a) for a in n.args])
            except TypeError:
                raise ValueError("عدد معاملات الدالة %s غير صحيح" % n.func.id)
        raise ValueError("عنصر غير مسموح في المعادلة")
    try:
        tree = ast.parse(str(expr).strip(), mode="eval")
    except SyntaxError:
        raise ValueError("صياغة المعادلة غير صحيحة")
    return ev(tree)


def _fmt_rate(r):
    return ("%.4f" % r).rstrip("0").rstrip(".")


def _convert_input(i, rates):
    """يرجع (القيمة_بالدينار, نص_العرض). المبلغ الأجنبي يُحوَّل بسعر جدول الأسعار بتاريخ الواقعة."""
    import fx_rates
    value = to_number(i["value"])
    cur = fx_rates.norm_currency(i.get("currency", ""))
    if cur in ("", "DZD"):
        return value, fmt_num(value) + (" DZD" if cur == "DZD" else "")
    if str(i.get("rate", "") or "").strip():                  # سعر ورد في وثيقة: يُعتمد كما هو ولا نبحث في الجدول
        rate = to_number(i["rate"])
        dzd = value * rate
        return dzd, "%s %s × %s (سعر وارد في وثيقة الأطراف) = %s DZD" % (fmt_num(value), cur, _fmt_rate(rate), fmt_num(dzd))
    d = fx_rates.parse_date(i.get("rate_date", ""))
    rate, used = fx_rates.get_rate(rates, cur, d)
    dzd = value * rate
    when = used.isoformat() + ((" بدل %s" % d.isoformat()) if used != d else "")
    src = fx_rates.get_source(rates)
    if src:
        when += "، المصدر: " + src
    return dzd, "%s %s × %s (سعر %s) = %s DZD" % (fmt_num(value), cur, _fmt_rate(rate), when, fmt_num(dzd))


def compute_calc(calc, rates=None):
    """يحسب معادلة واحدة. يرجع {'result','steps','error','inputs_detail'} دون أن يرفع استثناءً.
    rates: جدول الأسعار (يُحمَّل تلقائياً إن وُجد مبلغ بعملة أجنبية ولم يُمرَّر)."""
    try:
        import fx_rates
        inputs = calc.get("inputs", [])
        if rates is None and any(fx_rates.norm_currency(i.get("currency", "")) not in ("", "DZD")
                                 and not str(i.get("rate", "") or "").strip() for i in inputs):
            rates = fx_rates.load()
        variables, details = {}, []
        for i in inputs:
            try:
                v, text = _convert_input(i, rates)
            except ValueError as e:
                raise ValueError("%s: %s" % (i.get("label") or i.get("name"), e))
            variables[i["name"]] = v
            details.append(text)
        result = safe_eval(calc.get("formula", ""), variables)
        if not isinstance(result, (int, float)) or not math.isfinite(result):
            raise ValueError("نتيجة غير صالحة (ليست رقماً منتهياً)")
        shown = str(calc["formula"])
        for name in sorted(variables, key=len, reverse=True):
            shown = re.sub(r"\b%s\b" % re.escape(name), fmt_num(variables[name]), shown)
        shown = shown.replace("*", " × ").replace("/", " ÷ ")
        return {"result": float(result), "steps": "%s = %s" % (shown, fmt_num(result)),
                "error": "", "inputs_detail": details}
    except ZeroDivisionError:
        return {"result": None, "steps": "", "error": "قسمة على صفر", "inputs_detail": []}
    except Exception as e:
        return {"result": None, "steps": "", "error": str(e), "inputs_detail": []}


def compute_all(draft, rates=None):
    """يحسب كل معادلات المسودة ويخزّن النتائج في draft['results'] (يستدعى بعد مراجعة الخبير)."""
    import fx_rates
    if rates is None:
        rates = fx_rates.load()
    draft["results"] = [compute_calc(c, rates) for c in draft.get("calculations", [])]
    return draft["results"]


# ---------------------------------------------------------------------------
# الجداول المحسوبة: خلية تبدأ بـ "=" تُحسب بالكود (النموذج يكتب الصيغة فقط، لا النتيجة)
#   مراجع الخلايا بنمط الجداول: عمود بحرف (A = أول عمود) + رقم الصف (1 = أول صف بيانات): C2، SUM(E2:E9)
#   الدوال: SUM AVG MIN MAX ROUND ABS و FX(المبلغ, "EUR", "YYYY-MM-DD") للتحويل بسعر جدول الأسعار فقط.
# ---------------------------------------------------------------------------
_CMP = {ast.Lt: operator.lt, ast.LtE: operator.le, ast.Gt: operator.gt, ast.GtE: operator.ge,
        ast.Eq: operator.eq, ast.NotEq: operator.ne}
_CELL_REF = re.compile(r"^([A-Z]{1,2})(\d{1,4})$")
_RANGE_RE = re.compile(r"\b([A-Z]{1,2})(\d{1,4}):([A-Z]{1,2})(\d{1,4})\b")
_FX_USE = re.compile(r'FX\s*\((?:[^"]*?),\s*"([^"]+)"\s*,\s*"([^"]+)"\s*\)', re.I)


def _col_letters(i):
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def _col_index(letters):
    n = 0
    for ch in letters:
        n = n * 26 + ord(ch) - 64
    return n - 1


def evaluate_table(table, rates=None):
    """يحسب خلايا الجدول التي تبدأ بـ «=». يرجع {'columns','rows','errors'}؛ rows نصوص جاهزة للعرض.
    خطأ في خلية لا يُسقط الجدول: تظهر «#خطأ» ويُذكر السبب في errors."""
    cols = [str(c) for c in table.get("columns", [])]
    src = table.get("rows", [])
    num_cache, txt_cache, stack, errors = {}, {}, [], []
    state = {"rates": rates}

    def name(r, c):
        return "%s%d" % (_col_letters(c), r + 1)

    def raw(r, c):
        return str(src[r][c]).strip() if 0 <= r < len(src) and 0 <= c < len(src[r]) else ""

    def num(r, c):
        key = (r, c)
        if key in num_cache:
            return num_cache[key]
        if not (0 <= r < len(src) and 0 <= c < len(cols)):
            raise ValueError("إحالة خارج الجدول: %s" % name(r, c))
        t = raw(r, c)
        if t.startswith("="):
            if key in stack:
                raise ValueError("إحالة دائرية عند %s" % name(r, c))
            stack.append(key)
            try:
                v = float(ev_expr(t[1:]))
            finally:
                stack.pop()
        elif t == "":
            v = 0.0
        else:
            try:
                v = to_number(t)
            except ValueError:
                raise ValueError("الخلية %s ليست رقماً: «%s»" % (name(r, c), t))
        num_cache[key] = v
        return v

    def rng(a, b):
        m1, m2 = _CELL_REF.match(a), _CELL_REF.match(b)
        if not (m1 and m2):
            raise ValueError("نطاق غير صحيح")
        c1, c2 = sorted((_col_index(m1.group(1)), _col_index(m2.group(1))))
        r1, r2 = sorted((int(m1.group(2)) - 1, int(m2.group(2)) - 1))
        out = []
        for r in range(r1, r2 + 1):
            for c in range(c1, c2 + 1):
                t = raw(r, c)
                if t == "":
                    continue
                if not t.startswith("="):
                    try:
                        to_number(t)
                    except ValueError as e:
                        if str(e).startswith("رقم ملتبس"):
                            raise ValueError("الخلية %s: %s (لن يُجمع بصمت)" % (name(r, c), e))
                        continue                 # نص داخل النطاق (عنوان فرعي مثلاً): يُتجاهل كما في Excel
                out.append(num(r, c))
        return out

    def fx(amount, cur, d):
        import fx_rates
        if state["rates"] is None:
            state["rates"] = fx_rates.load()
        v, _ = _convert_input({"value": amount, "currency": cur, "rate_date": d}, state["rates"])
        return v

    def flat(args):
        out = []
        for a in args:
            out.extend(a if isinstance(a, list) else [a])
        return out

    def _guard(fn):
        def run(*a):
            try:
                return fn(*a)
            except TypeError:
                raise ValueError("عدد معاملات الدالة أو أنواعها غير صحيحة")
        return run

    funcs = {"SUM": lambda *a: sum(flat(a)), "AVG": lambda *a: (sum(flat(a)) / len(flat(a))) if flat(a) else 0.0,
             "MIN": lambda *a: min(flat(a)), "MAX": lambda *a: max(flat(a)),
             "ROUND": _guard(lambda x, n=0: round_half_up(x, int(n))),
             "ROUNDUP": _guard(lambda x, n=0: round_up(x, int(n))),
             "ROUNDDOWN": _guard(lambda x, n=0: round_down(x, int(n))),
             "ABS": abs, "FX": fx, "RNG": rng,
             "PCT": _guard(_pct), "INTEREST": _guard(_simple_interest), "COMPOUND": _guard(_compound_int),
             "PMT": _guard(_pmt), "IF": _guard(lambda c, a, b: a if c else b)}
    date_funcs = {"DAYS": _days_between, "MONTHS": _months_between, "MONTHS_STARTED": _months_started}

    def date_arg(n):
        """وسيط تاريخ: نص بين علامتي اقتباس أو إحالة إلى خلية فيها تاريخ مكتوب (لا صيغة)."""
        import fx_rates
        if isinstance(n, ast.Constant) and isinstance(n.value, str):
            return fx_rates.parse_date(n.value)
        if isinstance(n, ast.Name):
            m = _CELL_REF.match(n.id)
            if m:
                t = raw(int(m.group(2)) - 1, _col_index(m.group(1)))
                if t.startswith("="):
                    raise ValueError("خلية التاريخ %s يجب أن تحوي تاريخاً مكتوباً لا صيغة" % n.id)
                return fx_rates.parse_date(t)
        raise ValueError("وسيط التاريخ يجب أن يكون نصاً مثل \"2020-03-01\" أو إحالة إلى خلية فيها تاريخ")

    def ev_expr(expr):
        e = str(expr).strip().replace("×", "*").replace("÷", "/").replace("،", ",").upper()
        e = _RANGE_RE.sub(lambda m: 'RNG("%s%s","%s%s")' % m.groups(), e)
        try:
            tree = ast.parse(e, mode="eval")
        except SyntaxError:
            raise ValueError("صياغة الصيغة غير صحيحة: =%s" % expr)

        def ev(n):
            if isinstance(n, ast.Expression):
                return ev(n.body)
            if isinstance(n, ast.Constant):
                if isinstance(n.value, bool):
                    raise ValueError("قيمة غير مسموحة")
                if isinstance(n.value, (int, float, str)):
                    return n.value
            if isinstance(n, ast.Name):
                m = _CELL_REF.match(n.id)
                if m:
                    return num(int(m.group(2)) - 1, _col_index(m.group(1)))
                raise ValueError("اسم غير معروف في الصيغة: %s" % n.id)
            if isinstance(n, ast.BinOp) and type(n.op) in _BIN:
                a, b = ev(n.left), ev(n.right)
                if isinstance(a, (list, str)) or isinstance(b, (list, str)):
                    raise ValueError("عملية غير صالحة على نص أو نطاق")
                if isinstance(n.op, ast.Pow) and abs(b) > 100:
                    raise ValueError("أس كبير جداً")
                return _BIN[type(n.op)](a, b)
            if isinstance(n, ast.UnaryOp) and type(n.op) in _UN:
                return _UN[type(n.op)](ev(n.operand))
            if isinstance(n, ast.Compare) and len(n.ops) == 1 and type(n.ops[0]) in _CMP:
                a, b = ev(n.left), ev(n.comparators[0])
                if isinstance(a, (list, str)) or isinstance(b, (list, str)):
                    raise ValueError("المقارنة تقبل أرقاماً فقط")
                return 1.0 if _CMP[type(n.ops[0])](a, b) else 0.0
            if (isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in date_funcs
                    and not n.keywords and len(n.args) == 2):
                return float(date_funcs[n.func.id](date_arg(n.args[0]), date_arg(n.args[1])))
            if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in funcs and not n.keywords:
                return funcs[n.func.id](*[ev(a) for a in n.args])
            raise ValueError("عنصر غير مسموح في الصيغة")
        res = ev(tree)
        if isinstance(res, (list, str)):
            raise ValueError("الصيغة لا تعطي رقماً")
        if not math.isfinite(res):
            raise ValueError("نتيجة غير منتهية")
        return res

    out_rows = []
    for r in range(len(src)):
        row = []
        for c in range(len(cols)):
            t = raw(r, c)
            if t.startswith("="):
                try:
                    row.append(fmt_num(num(r, c)))
                except ZeroDivisionError:
                    row.append("#خطأ")
                    errors.append("%s: قسمة على صفر" % name(r, c))
                except Exception as e:
                    row.append("#خطأ")
                    errors.append("%s: %s" % (name(r, c), e))
            else:
                row.append(t)
        out_rows.append(row)
    return {"columns": cols, "rows": out_rows, "errors": errors}


# ---------------------------------------------------------------------------
# فحص آلي: هل كل رقم موجود فعلاً في نص مصدره؟  +  تطبيق قاموس المصطلحات
# ---------------------------------------------------------------------------
def _candidates(token):
    out = set()
    try:
        out.add(to_number(token))
        return out
    except ValueError:
        pass
    t = re.sub(r"[\s\u00a0\u202f]", "", token)
    for f in (lambda x: x.replace(",", ""), lambda x: x.replace(",", "."), lambda x: x.replace(".", "")):
        try:
            out.add(float(f(t)))
        except ValueError:
            pass
    return out


_GROUPED = re.compile(r"^\d{1,3}(?:[\s\u00a0\u202f]\d{3})+(?:[.,]\d{1,2})?$")


def evidence_numbers(text):
    """كل الأرقام الواردة في نص (بصيغها العربية والفرنسية) كمجموعة قيم."""
    text = (text or "").translate(_AR_DIGITS)
    nums = set()
    for m in re.finditer(r"\d[\d\s\u00a0\u202f.,]*\d|\d", text):
        tok = m.group(0).strip(" .,")
        nums |= _candidates(tok)
        if _GROUPED.match(tok):                  # «1 250 000» رقم واحد: لا نقطّعه فيصير 250 «موجوداً» بالخطأ
            continue
        for piece in re.split(r"[\s\u00a0\u202f]+", tok):
            if piece:
                nums |= _candidates(piece)
    return nums


_RATES = (1, 2, 3, 5, 7, 9, 10, 15, 17, 19, 20, 24, 25, 26, 30, 35, 50)


def _near(a, b):
    return abs(a - b) <= max(0.011, 1e-6 * max(abs(a), abs(b)))


def _derive(v, pool, hints=()):
    """يبحث عن طريقة تُنتج الرقم v من أرقام المصدر: نسبة مئوية، مجموع رقمين أو ثلاثة، أو فرق.
    hints: نسب وردت في وصف الرقم (مثل 10%) تُجرَّب أولاً. يرجع وصفاً عربياً قصيراً أو None.
    الأرقام المحسوبة (حقوق، غرامات، مجاميع) لا تُكتب حرفياً في الوثائق عادةً."""
    nums = sorted({round(x, 2) for x in pool if 100 <= abs(x) < 1e13})   # أرقام صغيرة (تواريخ، كميات) تصنع صدفاً
    if not nums or abs(v) < 100:
        return None
    nums = nums[-700:]                                   # الأكبر أهم في المبالغ
    lookup = set(nums)

    def percent(rates):
        for x in reversed(nums):                         # الأكبر أولاً: الوعاء عادةً أكبر الأرقام
            if x <= v:
                continue
            for r in rates:
                if _near(x * r / 100.0, v):
                    return "%d%% من %s" % (r, fmt_num(x))
        return None

    hit = percent(tuple(hints)) if hints else None      # النسبة المذكورة في الوصف أولاً
    if hit:
        return hit
    for x in nums:                                       # مجموع رقمين / فرق رقمين
        if x < v and round(v - x, 2) in lookup:
            return "مجموع %s + %s" % (fmt_num(x), fmt_num(round(v - x, 2)))
        if x > v and round(x - v, 2) in lookup:
            return "فرق %s − %s" % (fmt_num(x), fmt_num(round(x - v, 2)))
    big = [x for x in nums if 100 <= x < v][-120:]       # مجموع ثلاثة أرقام (نطاق أضيق لتقليل الصدف)
    for i, x in enumerate(big):
        for y in big[i:]:
            z = round(v - x - y, 2)
            if z >= 100 and z in lookup:
                return "مجموع %s + %s + %s" % (fmt_num(x), fmt_num(y), fmt_num(z))
    return percent(_RATES)


def _document_text(e, case_number):
    """النص الكامل للوثيقة المقتبس منها الدليل (المقتطف وحده قد لا يحوي الرقم)."""
    try:
        import rag_index
        ref = e.get("kind") == "ref"
        idx = rag_index.reference_index() if ref else rag_index.case_index()
        return idx.document_text(e.get("title", ""), None if ref else case_number)
    except Exception:
        return ""


def verify_inputs(draft):
    """يعلّم كل رقم input['verified'] و input['status'] ويرجع تنبيهات الأرقام التي لم يُتحقق منها كما يجب.
    الحالات (من الأقوى):
      confirmed : أكّده الخبير في شاشة تدقيق الوثائق لنفس الوثيقة المذكورة كمصدر.
      literal   : موجود حرفياً في مقتطف المصدر أو في نص الوثيقة كاملاً (لكن النص نفسه ناتج قراءة آلية؛ فالمطابقة
                  تثبت الوجود لا الصحة، ولذلك يبقى تأكيد الخبير هو الأقوى).
      derived   : ليس مكتوباً حرفياً لكنه مجموع أو فرق أو نسبة من أرقام المصدر (يُنبَّه إليه: الأرقام المنقولة يجب أن تكون حرفية).
      missing   : لم يُعثر عليه (verified=False).
    """
    ev = {e["id"]: e for e in draft.get("evidence", [])}
    excerpt_nums, full_nums, warns = {}, {}, []
    case_number = draft.get("case_number", "")
    tol = lambda x: 1e-6 * max(1.0, abs(x))
    # الضرب ×100 مقبول فقط للنسب الكسرية (0.19 مقابل 19) لا لأي رقم صغير
    hit = lambda v, nums: any(abs(v - x) <= tol(v) or (abs(v) < 1 and abs(v * 100 - x) <= tol(v * 100)) for x in nums)
    try:
        import doc_audit
        confirmed = doc_audit.confirmed_by_title(case_number) if case_number else {}
    except Exception:
        confirmed = {}
    for c in draft.get("calculations", []):
        values = []
        for i in c.get("inputs", []):
            try:
                values.append(to_number(i["value"]))
            except (ValueError, KeyError):
                pass
        for i in c.get("inputs", []):
            i.pop("derived_from", None)
            sid = i.get("source", "")
            try:
                v = to_number(i["value"])
            except (ValueError, KeyError):
                continue
            if not sid:
                i["verified"], i["status"] = False, "missing"
                warns.append("حساب «%s»: الرقم «%s» بلا مصدر محدد." % (c["title"], i.get("label")))
                continue
            e = ev.get(sid, {})
            if is_method_ref(e):                      # أرقام الأمثلة والتمارين لا تدخل حساباً مهما وُجدت في مصدرها
                i["verified"], i["status"] = False, "rejected"
                warns.append("حساب «%s»: الرقم %s («%s») مصدره «%s» وهو مرجع منهجي أو مثال محلول؛ أرقام الأمثلة لا تُقبل "
                             "مدخلاً. خذه من وثيقة القضية أو من نص قانوني." % (c["title"], fmt_num(v), i.get("label"), e.get("title", sid)))
                continue
            title = str(e.get("title", "")).replace(FACTS_PREFIX, "", 1)
            if any(abs(v - x) <= 0.005 for x in confirmed.get(title, ())):
                i["verified"], i["status"] = True, "confirmed"
                continue
            if sid not in excerpt_nums:
                excerpt_nums[sid] = evidence_numbers(e.get("text", ""))
            if hit(v, excerpt_nums[sid]):
                i["verified"], i["status"] = True, "literal"
                continue
            if sid not in full_nums:
                full_nums[sid] = evidence_numbers(_document_text(e, case_number)) if e else set()
            if hit(v, full_nums[sid]):
                i["verified"], i["status"] = True, "literal"
                continue
            others = [x for x in values if x != v]
            hints = tuple(int(h) for h in re.findall(r"(\d{1,2})\s*%", str(i.get("label", ""))))
            how = _derive(v, set(others), hints) or _derive(v, set(excerpt_nums[sid]) | set(full_nums[sid]) | set(others), hints)
            if how:
                i["verified"], i["status"], i["derived_from"] = True, "derived", how
                warns.append("حساب «%s»: الرقم %s («%s») ليس منقولاً حرفياً من المصدر %s بل يطابق %s؛ "
                             "إن كان المبلغ مكتوباً في الوثيقة فصحّحه، وإن كان ناتج حساب فأدخل أصله وصغ العملية في المعادلة."
                             % (c["title"], fmt_num(v), i.get("label"), sid, how))
                continue
            i["verified"], i["status"] = False, "missing"
            warns.append("حساب «%s»: لم أجد الرقم %s («%s») في المصدر %s (لا في المقتطف ولا في نص الوثيقة)، "
                         "ولا يظهر أنه مجموع أو نسبة من أرقامها. قد يكون مكتوباً بالحروف أو ناتجاً عن حساب خارجي، "
                         "فتحقق منه بنفسك." % (c["title"], fmt_num(v), i.get("label"), sid))
    return warns


_DIACRITICS = re.compile("[\u064b-\u0652\u0640]")


def _norm_text(s):
    import unicodedata
    s = unicodedata.normalize("NFD", str(s).lower())
    s = "".join(ch for ch in s if unicodedata.category(ch) != "Mn")
    s = _DIACRITICS.sub("", s)
    return re.sub(r"\s+", " ", s).strip()


def glossary_path():
    import storage
    return os.path.join(storage.APP_DATA_DIR, "glossary.json")


def load_glossary():
    try:
        with open(glossary_path(), "r", encoding="utf-8") as f:
            return [p for p in json.load(f) if p.get("fr") and p.get("ar")]
    except Exception:
        return []


def save_glossary(pairs):
    os.makedirs(os.path.dirname(glossary_path()), exist_ok=True)
    with open(glossary_path(), "w", encoding="utf-8") as f:
        json.dump(pairs, f, ensure_ascii=False, indent=1)


def parse_glossary_text(text):
    """كل سطر:  mise en demeure = الإعذار   (يقبل = أو ⇒ أو -> أو :). يرجع (أزواج, أسطر_مرفوضة)."""
    pairs, bad = [], []
    for line in text.splitlines():
        if not line.strip():
            continue
        parts = re.split(r"\s*(?:=>|->|⇒|=|:)\s*", line.strip(), maxsplit=1)
        if len(parts) == 2 and parts[0].strip() and parts[1].strip():
            pairs.append({"fr": parts[0].strip(), "ar": parts[1].strip()})
        else:
            bad.append(line.strip())
    return pairs, bad


def relevant_glossary(pairs, *texts):
    blob = _norm_text(" ".join(texts))
    return [p for p in pairs if _norm_text(p["fr"]) in blob]


def check_glossary(draft, pairs):
    """تنبيه لكل مصطلح معتمد ورد في المصادر ولم يظهر مقابله العربي المعتمد في نص المسودة."""
    ev = _norm_text(" ".join(e["text"] for e in draft.get("evidence", [])))
    out = _norm_text(" ".join(s["title"] + " " + s["body"] for s in draft.get("sections", [])))
    warns = []
    for p in pairs:
        if _norm_text(p["fr"]) in ev and _norm_text(p["ar"]) not in out:
            warns.append("المصطلح «%s» ورد في المصادر ولم يظهر مقابله المعتمد «%s» في المسودة. راجع الصياغة."
                         % (p["fr"], p["ar"]))
    return warns


# ---------------------------------------------------------------------------
# الخطوات
# ---------------------------------------------------------------------------
def _ai_default(prompt, system=None, as_json=False, search=False):
    import ai_client
    return ai_client.generate(prompt, system=system, as_json=as_json, search=search)


def _call(ai, prompt, system=None, as_json=False, search=False):
    """يستدعي دالة الذكاء الاصطناعي؛ إن كانت مخصّصة ولا تقبل search نعيد المحاولة بدونها."""
    try:
        return ai(prompt, system, as_json, search=search)
    except TypeError:
        return ai(prompt, system, as_json)


def plan_queries(ctx, categories, ai=None, anon=None):
    ai = ai or _ai_default
    hide = anon.hide if anon else (lambda t: t)
    prompt = (
        "نبذة القضية:\n%s\n\nالمهام المطلوبة من الخبير:\n%s\n\n"
        "تصنيفات المراجع المتاحة: %s\n\n"
        "حوّل المهام إلى استفسارات بحث قصيرة ودقيقة، واكتب كل استفسار بالعربية ثم ما يقابله بالفرنسية "
        "(لأن بعض الوثائق والمراجع بالفرنسية). أعد JSON بهذا الشكل فقط:\n"
        '{"reference_queries":[{"category":"أحد التصنيفات المتاحة أو فارغ","query":"..."}],'
        '"document_queries":["استفسار للبحث في وثائق القضية عن وقائع وأرقام"]}\n'
        "بحد أقصى 8 استفسارات لكل قائمة."
    ) % (hide(ctx.get("summary", "") or "(لا توجد نبذة)"), hide(ctx.get("tasks", "") or "(لا توجد مهام)"),
         "، ".join(categories) or "(لا توجد تصنيفات)")
    plan = _parse_json(_call(ai, prompt, SYSTEM, True))
    rq = [q for q in plan.get("reference_queries", []) if isinstance(q, dict) and q.get("query")][:8]
    dq = [q for q in plan.get("document_queries", []) if isinstance(q, str) and q.strip()][:8]
    return {"reference_queries": rq, "document_queries": dq}


def retrieve(case_number, plan, ref_index, case_idx, categories, k_ref=4, k_doc=5):
    """يرجع قائمة أدلة: {id:'R1'|'D1', kind, title, page, text, category/party}."""
    evidence, seen = [], set()

    def add(kind, hit):
        key = (hit["title"], hit["page"], hit["text"][:80])
        if key in seen:
            return
        seen.add(key)
        n = sum(1 for e in evidence if e["kind"] == kind) + 1
        evidence.append({"id": ("R%d" if kind == "ref" else "D%d") % n, "kind": kind,
                         "title": hit["title"], "page": hit["page"], "text": hit["text"],
                         "category": hit.get("category", ""), "party": hit.get("party", "")})

    for q in plan["reference_queries"]:
        cat = q.get("category") if q.get("category") in categories else None
        for h in ref_index.search(q["query"], k=k_ref, category=cat):
            add("ref", h)
    for q in plan["document_queries"]:
        for h in case_idx.search(q, k=k_doc, case_number=case_number):
            add("doc", h)

    total = 0
    trimmed = []
    for e in evidence:                       # سقف لحجم ما يُرسل
        total += len(e["text"])
        if total > MAX_EVIDENCE_CHARS:
            break
        trimmed.append(e)
    return trimmed


# ---------------------------------------------------------------------------
# المراجع المنهجية (كتب وأمثلة وتمارين محلولة) تختلف عن النصوص القانونية: تُستلهم ولا تُنقل منها أرقام
# ---------------------------------------------------------------------------
METHOD_CATEGORY_WORDS = ("منهج", "نماذج", "نموذج", "تمارين", "تمرين", "أمثلة", "امثلة", "كتب", "كتاب", "فقه", "شرح", "دروس",
                         "méthode", "methode", "exercice", "exemple", "manuel", "cas pratique", "corrigé", "corrige")
METHOD_TITLE_WORDS = ("تمارين", "تمرين", "أمثلة", "امثلة", "نماذج", "حالات", "exercice", "corrigé", "corrige", "manuel", "méthode", "cas pratique")
_EXAMPLE_RE = re.compile(r"تمرين\s*(?:رقم\s*)?\d|حل\s+التمرين|مثال\s*(?:رقم\s*)?\d|التطبيق\s+العددي|exercice\s*\d|corrig[ée]|application\s+num[ée]rique", re.I)


def is_method_category(cat):
    c = str(cat or "").lower()
    return any(w in c for w in METHOD_CATEGORY_WORDS)


def is_method_ref(e):
    """مرجع منهجي أو مثال محلول: تصنيفه أو عنوانه يدل عليه، أو يحوي مقطعه علامات التمارين (تمرين 3، حل التمرين، exercice 2...).
    الفحص على المقطع نفسه يلتقط كتاباً رُفع بلا تصنيف أو بتصنيف لا يدل عليه."""
    if e.get("kind") != "ref":
        return False
    return (is_method_category(e.get("category", "")) or any(w in str(e.get("title", "")).lower() for w in METHOD_TITLE_WORDS)
            or bool(_EXAMPLE_RE.search(e.get("text", ""))))


_NUM_ANY = re.compile(r"[\d٠-٩]+(?:[ \u00a0\u202f.,٫٬][\d٠-٩]+)*\s?%?")
_STEP_NO = re.compile(r"^(\s*[\d٠-٩]{1,2}[).\-:،]\s)")


def mask_numbers(text):
    """يحجب كل رقم في نص مرجع منهجي (مبالغ، نسب، تواريخ، سنوات) ويُبقي ترقيم الخطوات (1) 2) ...) وحده.
    النموذج لا يرى أرقام الأمثلة أصلاً، فلا يستطيع نقلها: المنع من المنبع لا الكشف بعد الوقوع.
    المنهج (الخطوات وترتيب الجداول والمصطلحات وطريقة المعالجة) يبقى كاملاً."""
    out = []
    for line in str(text or "").split("\n"):
        m = _STEP_NO.match(line)
        head = m.group(1) if m else ""
        out.append(head + _NUM_ANY.sub("⟦م⟧", line[len(head):]))
    return "\n".join(out)


def _evidence_block(evidence, anon=None):
    parts = []
    for e in evidence:
        label = "مرجع" if e["kind"] == "ref" else "وثيقة القضية"
        method = is_method_ref(e)
        if method:
            label = ("مرجع منهجي/أمثلة — أرقامه محجوبة عمداً (⟦م⟧) فلا تحاول استنتاجها؛ استفد من الخطوات وهيكل الجداول وطريقة "
                     "المعالجة فقط، ولا يُستشهد به أساساً قانونياً")
        page = " ص %s" % e["page"] if e["page"] else ""
        text = mask_numbers(e["text"]) if method else e["text"]
        text = anon.hide(text) if anon else text
        parts.append("[%s] (%s: %s%s)\n%s" % (e["id"], label, e["title"], page, text))
    return "\n\n".join(parts) or "(لا توجد مصادر)"


def draft_report(ctx, evidence, ai=None, anon=None, glossary=None):
    ai = ai or _ai_default
    hide = anon.hide if anon else (lambda t: t)
    prompt = (
        "نبذة القضية:\n%s\n\nالمهام:\n%s\n\nالمصادر (استعمل أرقامها فقط عند الإحالة):\n%s\n\n"
        "اكتب مسودة تقرير الخبرة. أعد JSON بهذا الشكل فقط:\n"
        '{"sections":[{"title":"عنوان مقترح","body":"نص الفقرات","sources":["R1","D2"]}],\n'
        ' "calculations":[{"title":"اسم الحساب","method_sources":["R2"],\n'
        '   "inputs":[{"name":"amount","label":"وصف الرقم","value":0,"source":"D1"}],\n'
        '   "formula":"amount*rate*months","note":"ملاحظة اختيارية"}],\n'
        ' "missing":["معلومات ناقصة يجب على الخبير توفيرها"],\n'
        ' "conflicts":["أي تعارض بين مصدرين (مثل عقد يخالف القانون) أو طرق حساب بديلة، مع أرقام المصادر"]}\n'
        "القواعد: قسم أو أكثر لكل مهمة. أسماء المتغيرات حروف لاتينية وشرطة سفلية فقط. "
        "قد تكون المصادر بالعربية أو الفرنسية أو غيرها: افهمها واكتب التقرير بالعربية، وأبقِ المصطلح الأصلي بين قوسين عند الحاجة. "
        "قيم value أرقام JSON عادية بنقطة عشرية وبدون فواصل آلاف أو رموز عملة، محوّلة بدقة من صيغة المصدر "
        "(مثلاً «1 000 000,50 DA» تصبح 1000000.5). "
        "كل رقم في inputs يجب أن يوجد حرفياً في مصدر ويُذكر رقمه في source، وإلا فلا تُنشئ الحساب "
        "واذكر النقص في missing. المعادلة بالعمليات + - * / ** وأقواس فقط. "
        "الإحالات بأرقام المصادر الموجودة أعلاه فقط."
    ) % (hide(ctx.get("summary", "") or "(لا توجد نبذة)"), hide(ctx.get("tasks", "") or "(لا توجد مهام)"),
         _evidence_block(evidence, anon))
    prompt += (
        "\n\nقواعد العملات: كل مبلغ بغير الدينار الجزائري اكتب value بمبلغه الأصلي دون تحويل، وcurrency برمز ISO "
        "(مثل EUR وUSD)، وrate_date بتاريخ الواقعة التي يُعتمد سعر صرفها بصيغة YYYY-MM-DD (تاريخ الفاتورة أو التصريح "
        "الجمركي أو الدفع أو غيرها حسب المرجع أو الوثيقة)، واذكر في label سبب اختيار هذا التاريخ. لا تذكر ولا تفترض "
        "أي سعر صرف من عندك أبداً: الأسعار تؤخذ من جدول الأسعار في البرنامج. المبالغ بالدينار وغير النقدية "
        "(أشهر، نسب) بلا currency."
    )
    prompt += LANG_RULES
    raw = _parse_json(_call(ai, prompt, SYSTEM, True, search=True))
    if anon:
        raw = anon.show(raw)

    valid_ids = {e["id"] for e in evidence}
    clean_src = lambda lst: [s for s in (lst or []) if s in valid_ids]
    missing = [str(m) for m in raw.get("missing", [])]

    sections = []
    for s in raw.get("sections", []):
        if isinstance(s, dict) and s.get("title"):
            sections.append({"title": str(s["title"]), "body": str(s.get("body", "")),
                             "sources": clean_src(s.get("sources"))})
    calcs = []
    for c in raw.get("calculations", []):
        if not (isinstance(c, dict) and c.get("formula")):
            continue
        inputs, ok = [], True
        for i in c.get("inputs", []):
            try:
                cur = fx_rates.norm_currency(i.get("currency", ""))
                rd = str(i.get("rate_date", "") or "").strip()
                if cur not in ("", "DZD") and not str(i.get("rate", "") or "").strip():
                    try:
                        rd = fx_rates.parse_date(rd).isoformat()
                    except ValueError as e:
                        missing.append("حساب «%s»: %s يحتاج تاريخاً صحيحاً لسعر الصرف. %s" % (c.get("title", ""), i.get("label", i["name"]), e))
                        rd = ""
                inputs.append({"name": str(i["name"]), "label": str(i.get("label", i["name"])),
                               "value": to_number(i["value"]),
                               "source": i.get("source", "") if i.get("source") in valid_ids else "",
                               "currency": cur if cur != "DZD" else "", "rate_date": rd})
            except Exception as e:
                ok = False
                missing.append("حساب «%s»: قيمة غير صالحة للمتغير %s (%s)" % (c.get("title", ""), i.get("name", "?"), e))
        if ok:
            calcs.append({"title": str(c.get("title", "حساب")), "method_sources": clean_src(c.get("method_sources")),
                          "inputs": inputs, "formula": str(c["formula"]), "note": str(c.get("note", ""))})
    conflicts = [str(c) for c in raw.get("conflicts", []) if str(c).strip()]
    return {"sections": sections, "calculations": calcs, "missing": missing, "conflicts": conflicts}


def build_draft(case_number, ai=None, ref_idx=None, case_idx=None, anonymize=True, progress=None):
    """الدالة الرئيسية: تجمع كل شيء وترجع مسودة قابلة للمراجعة والحفظ."""
    import rag_index
    import word_cover
    say = progress or (lambda m: None)
    ctx = word_cover.build_case_context(case_number)
    ref_idx = ref_idx or rag_index.reference_index()
    case_idx = case_idx or rag_index.case_index()
    categories = sorted({r[2] for r in ref_idx.list_sources() if r[2]})
    anon = _Anonymizer([ctx.get("plaintiff"), ctx.get("defendant")]) if anonymize else None

    skipped = _index_case(case_number, case_idx, say)
    say("تحليل النبذة والمهام...")
    plan = plan_queries(ctx, categories, ai, anon)
    say("البحث في المراجع ووثائق القضية...")
    evidence = retrieve(case_number, plan, ref_idx, case_idx, categories)
    evidence = _add_audited_facts(case_number, evidence, case_idx, ai or _ai_default, anon, say, skipped)
    say("كتابة المسودة...")
    draft = draft_report(ctx, evidence, ai, anon)
    draft.update({"case_number": str(case_number), "created": datetime.now().isoformat(timespec="seconds"),
                  "plan": plan, "evidence": evidence})
    draft["warnings"] = verify_inputs(draft)
    return draft


# ---------------------------------------------------------------------------
# حفظ المسودة (حتى لا تضيع المراجعة عند إغلاق النافذة)
# ---------------------------------------------------------------------------
def draft_path(case_number):
    import storage
    safe = re.sub(r"[^\w\-]+", "_", str(case_number), flags=re.UNICODE)
    return storage._year_path(os.path.join("report_drafts", safe + ".json"))


def save_draft(draft):
    p = draft_path(draft["case_number"])
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(draft, f, ensure_ascii=False, indent=1)


def load_draft(case_number):
    p = draft_path(case_number)
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    return None


def source_label(draft, sid):
    for e in draft.get("evidence", []):
        if e["id"] == sid:
            return "%s%s" % (e["title"], (" ص %s" % e["page"]) if e["page"] else "")
    return sid


# ---------------------------------------------------------------------------
# مراحل مستقلة لصفحة التقرير: (1) تجهيز الأدلة  (2) العناوين  (3) الحسابات والجداول
# كل مرحلة تحفظ في نفس المسودة، فيستطيع الخبير اعتماد العناوين ثم طلب الحسابات المرتبطة بها.
# ---------------------------------------------------------------------------
def new_draft(case_number):
    return {"case_number": str(case_number), "sections": [], "calculations": [], "tables": [],
            "missing": [], "conflicts": [], "evidence": [], "plan": {}, "warnings": [], "audit": [], "audit_resolved": [], "legal": [], "legal_resolved": []}


def _next_id(items, prefix):
    used = {str(i.get("id", "")) for i in items}
    n = 1
    while "%s%d" % (prefix, n) in used:
        n += 1
    return "%s%d" % (prefix, n)


def ensure_ids(draft):
    """يرقّي المسودات القديمة: معرّف لكل عنوان/حساب/جدول وحالة للعنوان، ويضمن وجود المفاتيح."""
    draft.setdefault("tables", [])
    for key in ("sections", "calculations", "missing", "conflicts", "evidence", "warnings", "audit", "audit_resolved", "legal", "legal_resolved"):
        draft.setdefault(key, [])
    draft.setdefault("plan", {})
    for items, prefix in ((draft["sections"], "S"), (draft["calculations"], "C"), (draft["tables"], "T")):
        for it in items:
            if not it.get("id"):
                it["id"] = _next_id(items, prefix)
            it.setdefault("section", "")
    for s in draft["sections"]:
        s.setdefault("status", "approved")      # مسودات قديمة: تُعدّ معتمدة
    return draft


MAX_FACTS_CHARS = 40000


def _index_case(case_number, case_idx, say):
    """يفهرس وثائق هذه القضية الجديدة أو المتغيّرة قبل البحث (الفهرسة التلقائية معطّلة افتراضياً، فبدونها يجهل
    البرنامج كل وثيقة لم تُفهرس دون أن ينبّه). يرجع [(اسم, سبب)] للملفات التي تعذّرت قراءتها كلياً."""
    try:
        import rag_index
        say("فهرسة وثائق القضية الجديدة أو المتغيّرة (القراءة الآلية للصور قد تستغرق وقتاً)...")
        _rep, skipped = rag_index.index_case_documents(
            case_number, case_idx, progress=lambda i, n, name: say("قراءة الوثيقة %d من %d: %s" % (i, n, name)))
        return skipped
    except Exception as e:
        say("تعذّرت فهرسة وثائق القضية (%s)." % str(e)[:80])
        return []


def _add_audited_facts(case_number, evidence, case_idx, ai, anon, say, skipped=()):
    """يشغّل تدقيق الوثائق (استخراج + فحص حسابي؛ المخزَّن لا يُعاد) ويضيف أرقامها المنظّمة أدلةً [D#].
    فشل التدقيق (انقطاع الشبكة مثلاً) لا يوقف العمل: يُكمل البرنامج بالأدلة العادية ويُذكر ذلك في الحالة."""
    try:
        import doc_audit
        say("تدقيق وثائق القضية: استخراج الأرقام وفحصها حسابياً...")
        res = doc_audit.audit_case(case_number, case_idx, ai, anon, say, skipped=skipped)
        used = 0
        nums = [int(e["id"][1:]) for e in evidence if e["kind"] == "doc" and e["id"][1:].isdigit()]
        n = max(nums) if nums else 0
        facts = doc_audit.facts_evidence(case_number)
        cov = doc_audit.coverage_evidence(case_number)
        if cov:
            facts.insert(0, cov)
        dropped = []
        for fct in facts:
            if used + len(fct["text"]) > MAX_FACTS_CHARS:
                dropped.append(fct["title"].replace(FACTS_PREFIX, "", 1))
                continue
            used += len(fct["text"])
            n += 1
            evidence.append({"id": "D%d" % n, "kind": "doc", "title": fct["title"], "page": "",
                             "text": fct["text"], "category": "", "party": ""})
        if dropped:                                  # لا يسكت البرنامج عمّا لم يتّسع له الحجم
            n += 1
            evidence.append({"id": "D%d" % n, "kind": "doc", "title": FACTS_PREFIX + "تنبيه: وثائق لم تُدرج لضيق الحجم",
                             "text": "لم تُدرج بياناتها المستخرجة لضيق الحجم (اذكرها في missing ولا تفترض ما فيها): " + " ، ".join(dropped),
                             "page": "", "category": "", "party": ""})
        if res.get("failed"):
            say("تعذّر استخراج %d وثيقة؛ ستظهر في «تدقيق الوثائق»." % len(res["failed"]))
    except Exception as e:
        say("تعذّر تدقيق الوثائق آلياً (%s)؛ تابعت بالأدلة العادية." % str(e)[:80])
    return evidence


_AR_DIG = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")


def _article_re(num):
    return re.compile(r"(?:المادة|مادة|art(?:icle)?\.?)\s*0*%s(?!\d)" % re.escape(num), re.I)


def _ref_full_text(title):
    try:
        import rag_index
        return rag_index.reference_index().full_text(title)
    except Exception:
        return ""


def _used_numbers(item):
    """الأرقام التي يستعملها الحساب أو الجدول فعلاً (قيم المدخلات والمعادلة وخلايا الجدول)."""
    nums = set()
    for i in item.get("inputs", []) or []:
        try:
            nums.add(to_number(i["value"]))
        except (ValueError, KeyError):
            pass
    parts = [str(item.get("formula", ""))]
    for row in item.get("rows", []) or []:
        parts.extend(str(c) for c in row)
    return nums | evidence_numbers(" ".join(parts))


def legal_notes(draft):
    """يراجع الأساس القانوني لكل حساب وجدول. ما يتحقق منه الكود: وجود المادة في المرجع المذكور، وورود الرقم المأخوذ
    منها فيه، واستعمال هذا الرقم فعلاً في الحساب، وعدم صدور المرجع بعد الواقعة. أما **انطباق المادة على القضية**
    فحكم الخبير وحده: كل أساس سليم يظهر بندَ اعتماد ينتظر قرارك ولا يُعدّ معتمداً من تلقاء نفسه."""
    ev = {e["id"]: e for e in draft.get("evidence", [])}
    out, full_cache = [], {}
    items = [("الحساب", c) for c in draft.get("calculations", [])] + [("الجدول", t) for t in draft.get("tables", [])]
    method_nums, doc_nums, law_nums = {}, set(), set()
    for e in draft.get("evidence", []):
        nums = evidence_numbers(e.get("text", ""))
        if is_method_ref(e):
            for x in nums:
                if abs(x) >= 100:
                    method_nums.setdefault(round(x, 2), e.get("title", ""))
        elif e.get("kind") == "ref":
            law_nums |= nums
        else:
            doc_nums |= nums
    known = {round(x, 2) for x in (doc_nums | law_nums)}
    for kind, it in items:
        title = it.get("title", "")
        basis = it.get("basis") or []
        # (أ) استلهام منهج من كتاب أو أمثلة: قرار الخبير أن المعيار معمول به عندنا وأن الوقائع متشابهة
        srcs = list(it.get("method_sources") or []) + list(it.get("sources") or [])
        for sid in dict.fromkeys(srcs):
            e = ev.get(sid)
            if e and is_method_ref(e):
                out.append("⚖ %s «%s» استلهم طريقته من «%s» (مرجع منهجي/أمثلة). تحقق: (1) أن المعيار أو الخطوة معمول بها عندنا وقت "
                           "الواقعة (النظام المحاسبي المالي والتشريع الجزائري) وليست من نظام أجنبي أو قديم، (2) أن وقائع قضيتك تشبه "
                           "وقائع المثال فعلاً. ثم اضغط «تمت المعالجة»." % (kind, title, e.get("title", sid)))
        # (ب) أرقام ثابتة في الحساب أو الجدول تطابق أرقام أمثلة ولا ترد في وثائق القضية ولا في نص قانوني
        static = set()
        for i in it.get("inputs", []) or []:
            try:
                static.add(round(to_number(i["value"]), 2))
            except (ValueError, KeyError):
                pass
        for row in it.get("rows", []) or []:
            for cell in row:
                if not str(cell).strip().startswith("="):
                    try:
                        static.add(round(to_number(cell), 2))
                    except ValueError:
                        pass
        leaked = sorted(x for x in static if x in method_nums and x not in known and abs(x) >= 100)
        if leaked:
            out.append("❌ %s «%s»: الأرقام %s تطابق أرقاماً في «%s» (مرجع منهجي/أمثلة) ولا ترد في وثائق القضية ولا في نص قانوني؛ "
                       "تأكد أنها لم تتسرب من مثال." % (kind, title, " ، ".join(fmt_num(x) for x in leaked[:5]), method_nums[leaked[0]]))
        if it.get("law_dependent") and not basis:
            out.append("❌ %s «%s» يعتمد على نص قانوني أو نسبة أو مدة لكنه بلا أساس موثّق في المراجع المرفوعة؛ "
                       "ارفع المرجع أو حدّد المادة بنفسك قبل الاعتماد." % (kind, title))
            continue
        used = _used_numbers(it)
        for b in basis:
            e = ev.get(b.get("ref"))
            if not e or e.get("kind") != "ref":
                out.append("❌ %s «%s»: الأساس يحيل إلى %s وهو ليس مرجعاً مرفقاً بالمسودة." % (kind, title, b.get("ref")))
                continue
            if is_method_ref(e):
                out.append("❌ %s «%s»: الأساس القانوني يحيل إلى «%s» وهو كتاب أو أمثلة، ولا يصلح الكتاب أساساً قانونياً. "
                           "استند إلى النص القانوني أو اترك الأساس فارغاً وأدرج النقص." % (kind, title, e.get("title", "")))
                continue
            problems = []
            art = re.sub(r"\D", "", str(b.get("article", "")).translate(_AR_DIG))
            if not art:
                problems.append("لم يُحدَّد رقم المادة")
            elif not _article_re(art).search(e.get("text", "").translate(_AR_DIG)):
                full = full_cache.setdefault(e["title"], _ref_full_text(e["title"]).translate(_AR_DIG))
                if not _article_re(art).search(full):
                    problems.append("المادة %s لا ترد في المرجع «%s»" % (art, e["title"]))
            fig = b.get("figure", "")
            if str(fig).strip():
                try:
                    fv = to_number(fig)
                except ValueError:
                    fv = None
                if fv is None:
                    problems.append("الرقم المذكور أساساً («%s») غير مفهوم" % fig)
                else:
                    close = lambda xs: any(abs(fv - x) <= 1e-6 * max(1.0, abs(fv)) for x in xs)
                    in_ref = close(evidence_numbers(e.get("text", "")))
                    if not in_ref:
                        full = full_cache.setdefault(e["title"], _ref_full_text(e["title"]).translate(_AR_DIG))
                        in_ref = close(evidence_numbers(full))
                    if not in_ref:
                        problems.append("الرقم %s لا يرد في المرجع «%s»" % (fmt_num(fv), e["title"]))
                    if not close(used):
                        problems.append("الرقم %s المذكور أساساً لا يُستعمل في الحساب نفسه" % fmt_num(fv))
            y = re.findall(r"(?<!\d)(19\d{2}|20\d{2})(?!\d)", str(e.get("title", "")))
            asof = re.match(r"(\d{4})", str(b.get("as_of", "")))
            if y and asof and int(y[-1]) > int(asof.group(1)):
                problems.append("المرجع «%s» يبدو صادراً سنة %s بعد تاريخ الواقعة (%s)؛ تحقق أنه كان ساري المفعول" % (
                    e["title"], y[-1], b.get("as_of")))
            if not b.get("applies"):
                problems.append("لم يُبيَّن سبب انطباق المادة على وقائع القضية")
            if problems:
                out.append("❌ %s «%s» — أساسه المادة %s من «%s»: %s." % (kind, title, art or "؟", e["title"], " ؛ ".join(problems)))
            else:
                out.append("⚖ %s «%s»: المادة %s من «%s»%s. سبب الانطباق كما بيّنه النموذج: %s. "
                           "اقرأ نص المادة وقرّر أتنطبق على قضيتك، ثم اضغط «تمت المعالجة»." % (
                               kind, title, art, e["title"], (" (الرقم %s)" % fig) if fig else "", b["applies"]))
    done = set(draft.get("legal_resolved", []))
    return [x for x in out if x not in done]


def audit_notes(draft):
    """بنود تبويب «تدقيق الوثائق»: نتائج الفحص الحسابي المخزّنة لقضية المسودة، دون ما عالجه الخبير."""
    try:
        import doc_audit
        items = doc_audit.issues_text(draft.get("case_number", ""))
    except Exception:
        return list(draft.get("audit", []))
    done = set(draft.get("audit_resolved", []))
    return [x for x in items if x not in done]


def prepare_evidence(case_number, ai=None, ref_idx=None, case_idx=None, anonymize=True, progress=None):
    """يحلّل النبذة والمهام ثم يبحث في المراجع ووثائق القضية. يرجع (ctx, plan, evidence, anon)."""
    import rag_index
    import word_cover
    say = progress or (lambda m: None)
    ai = ai or _ai_default
    ctx = word_cover.build_case_context(case_number)
    ref_idx = ref_idx or rag_index.reference_index()
    case_idx = case_idx or rag_index.case_index()
    categories = sorted({r[2] for r in ref_idx.list_sources() if r[2]})
    anon = _Anonymizer([ctx.get("plaintiff"), ctx.get("defendant")]) if anonymize else None
    skipped = _index_case(case_number, case_idx, say)
    say("قراءة نبذة القضية والمهام وتحديد ما يلزم البحث عنه...")
    plan = plan_queries(ctx, categories, ai, anon)
    say("البحث في وثائق القضية والمراجع...")
    evidence = retrieve(case_number, plan, ref_idx, case_idx, categories)
    evidence = _add_audited_facts(case_number, evidence, case_idx, ai, anon, say, skipped)
    return ctx, plan, evidence, anon


def _by_title(sections):
    return {_norm_text(s["title"]): s["id"] for s in sections}


def suggest_outline(ctx, evidence, ai=None, anon=None):
    """عناوين مقترحة منظّمة حسب المهام ونبذة القضية. ترجع (sections, missing, conflicts)."""
    ai = ai or _ai_default
    hide = anon.hide if anon else (lambda t: t)
    prompt = (
        "نبذة القضية:\n%s\n\nالمهام المطلوبة من الخبير:\n%s\n\nالمصادر (أحِل برقمها فقط):\n%s\n\n"
        "اقترح هيكل تقرير الخبرة بعناوين رسمية مرتبة ترتيباً منطقياً (تمهيد وإجراءات الخبرة، ملخص الوقائع، "
        "ثم قسم أو أكثر لكل مهمة بترتيب المهام، ثم الدراسة والمناقشة، ثم النتائج والخلاصة). لكل عنوان اكتب "
        "نصاً أولياً بالعربية معتمداً على المصادر فقط. أعد JSON فقط:\n"
        '{"sections":[{"title":"...","body":"...","sources":["R1","D2"]}],"missing":["..."],"conflicts":["..."]}\n'
        "لا تضع أي أرقام مالية محسوبة في النص (الحسابات تُطلب في خطوة منفصلة)."
    ) % (hide(ctx.get("summary", "") or "(لا توجد نبذة)"), hide(ctx.get("tasks", "") or "(لا توجد مهام)"),
         _evidence_block(evidence, anon)) + LANG_RULES
    raw = _parse_json(_call(ai, prompt, SYSTEM, True, search=True))
    if anon:
        raw = anon.show(raw)
    valid = {e["id"] for e in evidence}
    sections = [{"title": str(s["title"]), "body": str(s.get("body", "")), "status": "suggested",
                 "sources": [x for x in (s.get("sources") or []) if x in valid]}
                for s in raw.get("sections", []) if isinstance(s, dict) and s.get("title")]
    return (sections, [str(m) for m in raw.get("missing", [])],
            [str(c) for c in raw.get("conflicts", []) if str(c).strip()])


def _existing_digest(existing, sections):
    """ملخّص مضغوط لما في المسودة من جداول وحسابات (لطلب «تحديث» يبني عليها بدل البدء من الصفر)."""
    if not existing:
        return ""
    title_of = {s["id"]: s["title"] for s in sections}
    lines = []
    for t in existing.get("tables", []):
        rows = "؛ ".join(" | ".join(map(str, r)) for r in t.get("rows", [])[:3])
        lines.append("- [%s] جدول «%s» (العنوان: %s) الأعمدة: %s | %d صف | أمثلة: %s" % (
            t["id"], t.get("title", ""), title_of.get(t.get("section"), "—"), " | ".join(t.get("columns", [])),
            len(t.get("rows", [])), rows))
    for c in existing.get("calculations", []):
        lines.append("- [%s] حساب «%s» المعادلة: %s" % (c["id"], c.get("title", ""), c.get("formula", "")))
    return "\n".join(lines)


_LEGAL_RULES = (
    "\n\nالأساس القانوني (إلزامي): كل حساب أو جدول فيه نسبة أو مدة أو غرامة أو فائدة أو أساس تقدير يوضع له "
    "law_dependent=true، وتُدرج في basis كل مادة اعتمدتها: ref رقم مصدر المرجع R# المرفق، article رقم المادة كما هي مكتوبة "
    "حرفياً في ذلك المصدر، figure النسبة أو الرقم الذي أخذته منها، applies جملة تبيّن لماذا تنطبق هذه المادة على وقائع هذه "
    "القضية بالذات (نوع الواقعة وتاريخها وأطرافها)، as_of تاريخ الواقعة التي يُحسب لها. ممنوع الاستشهاد بمادة أو نسبة لا ترد "
    "حرفياً في مصدر R# مرفق، وممنوع الاعتماد على معرفتك العامة بالقانون. إن لم تجد النص في المراجع فضع law_dependent=true "
    "وbasis فارغة وأدرج النقص في missing. إن وُجد أكثر من نص أو أكثر من طريقة مقبولة فاذكر ذلك في conflicts ولا تحسم بصمت. "
    "الأدلة المسمّاة «تنبيه تغطية الملف» تذكر وثائق لم تُقرأ أو ناقصة: أدرجها كلها في missing.\n"
)

_METHOD_RULES = (
    "\n\nالمراجع الموسومة «مرجع منهجي/أمثلة» (كتب وتمارين محلولة) تُستلهم ولا تُقلَّد:\n"
    "1) لا تنقل منها رقماً ولا نسبة ولا معياراً إلى حساب أو جدول: الأرقام من وثائق القضية، والنسب والمدد من النصوص القانونية فقط.\n"
    "2) لا يُستشهد بها أساساً قانونياً في basis.\n"
    "3) ابدأ من وقائع القضية ومهام الخبير، ثم خذ من الكتاب فكرة الطريقة أو الخطوة التي تلائمها. لا تنقل بنية تمرين كاملة "
    "إن اختلفت وقائعها عن وقائع القضية، وبيّن في method لماذا يلائم هذا المنهج هذه القضية بالذات.\n"
    "4) الكتب قد تكون أجنبية أو قديمة: إن بدا أن معياراً أو نسبة فيها تخالف نصاً قانونياً مرفقاً أو ما يُعمل به وقت الواقعة "
    "فاذكر ذلك في conflicts واتبع النص القانوني.\n"
    "5) إن استلهمت طريقة من كتاب فأدرج رقمه في method_sources ليراجعها الخبير.\n"
)

_CALC_RULES = (
    "\n\nقواعد الدقة في الجداول والصيغ (إلزامية):\n"
    "- التقريب: كل مبلغ بند ناتج عن ضرب أو قسمة أو نسبة يُلفّ بـ ROUND(...,2) قبل أن يدخل في أي مجموع، حتى يساوي المجموع "
    "المعروض مجموع البنود المعروضة بالسنتيم. ROUND يقرّب النصف للأعلى كما في المحاسبة.\n"
    "- دوال إضافية في الجداول: PCT(المبلغ, النسبة%)، INTEREST(الأصل, النسبة%, الأيام, الأساس 365 أو 360)، "
    "COMPOUND(الأصل, النسبة%, الفترات) للفوائد المركّبة فقط، PMT(نسبة الفترة%, عدد الفترات, الأصل)، ROUNDUP وROUNDDOWN، "
    "IF(شرط, إن_صح, إن_لم_يصح) بشرط من نوع A1>B1.\n"
    "- التواريخ: ضع التاريخ نصاً صريحاً YYYY-MM-DD في خلية (لا صيغة)، ثم استعمل DAYS(A1,B1) للأيام، "
    "MONTHS(A1,B1) للأشهر الكاملة، MONTHS_STARTED(A1,B1) حين ينص المرجع على «كل شهر أو جزء منه». "
    "لا تحسب الأيام أو الأشهر بنفسك أبداً.\n"
    "- في حسابات calculations تتوفر أيضاً الدوال: round roundup rounddown pct simple_interest compound_int pmt min max abs.\n"
    "- الرقم الذي يظهر في الوثيقة يُنقل حرفياً كما هو (لا تقرّبه ولا تعدّله)، والرقم الذي تحتاجه ولا يظهر فيها يُشتق "
    "بصيغة لا بقيمة جاهزة. لا تُدخل ناتج حساب كأنه معطى من وثيقة.\n"
    "- إن كان لرقم قراءتان متعارضتان أو مدرج تحت unreadable فلا تعتمده؛ اذكره في missing.\n"
)


def _clean_basis(raw, valid):
    out = []
    for b in (raw or []):
        if isinstance(b, dict) and str(b.get("ref", "")).strip():
            out.append({"ref": str(b["ref"]).strip(), "article": str(b.get("article", "")).strip(),
                        "figure": str(b.get("figure", "")).strip(), "applies": str(b.get("applies", "")).strip(),
                        "as_of": str(b.get("as_of", "")).strip()})
    return out


def suggest_calculations(ctx, evidence, sections, ai=None, anon=None, avoid=None, instructions="", existing=None):
    """جداول وحسابات تُبنى حسب القضية نفسها (نوعها ونبذتها ومهامها ووثائقها ومراجعها): عددها وأعمدتها وصفوفها
    يقرّرها النموذج لكل قضية، والأرقام المشتقة صيغ يحسبها الكود (انظر evaluate_table).

    avoid: حسابات سابقة تُطلب لها طريقة بديلة.   instructions: توجيه حرّ من الخبير.
    existing: {'tables': [...], 'calculations': [...]} الحاليّة؛ إن مُرّرت فالطلب «تحديث»: يُبقي النموذج ما يصلح
    ويستبدل (replaces) أو يحذف (remove) أو يضيف.
    ترجع (calcs, tables, missing, conflicts, remove_ids)؛ عنصر قد يحمل "replaces": معرّف عنصر قائم يحلّ محلّه."""
    ai = ai or _ai_default
    hide = anon.hide if anon else (lambda t: t)
    heads = "\n".join("- " + s["title"] for s in sections) or "(لا توجد عناوين بعد)"
    prompt = (
        "نبذة القضية:\n%s\n\nالمهام:\n%s\n\nعناوين التقرير المعتمدة:\n%s\n\nالمصادر (أحِل برقمها فقط):\n%s\n\n"
        "المطلوب: أنت من يقرّر كل شيء بنفسك حسب هذه القضية بالذات، بعد فهم موضوعها ووقائعها ومهام الخبير ووثائق "
        "الأطراف والمراجع: هل تلزم جداول وحسابات أصلاً، وكم عددها، وما موضوع كل جدول، وما أعمدته وصفوفه. "
        "لا تفترض نوعاً معيناً من الجداول ولا عدداً مسبقاً: قد تكفي القضية بجدول واحد أو بعدد قليل، وقد تحتاج عدداً "
        "كبيراً، والعدد وأشكال الجداول يتفاوتان من قضية لأخرى تفاوتاً حقيقياً ولا يُقلّد بعضها بعضاً. "
        "اجعل كل جدول بالشكل الذي تقتضيه معطياته (أعمدة وصفوف مختلفة من جدول لآخر)، وحاكِ شكل الجداول أو الوثائق "
        "الموجودة عند الأطراف فقط إن كان في ذلك فائدة لهذه القضية. أضِف سطر مجموع حيث يلزم. كل جدول يُربط بالعنوان "
        "الأنسب (section_title تطابق عنواناً أعلاه حرفياً). الحسابات المعقّدة متعددة الخطوات تُكتب حساباً (calculations) "
        "بمعادلة، والجداول (tables) للعرض المنظّم. اذكر في method الأساس القانوني أو المرجعي بالمادة إن وُجد في المصادر. "
        "أعد JSON فقط:\n"
        '{"calculations":[{"title":"...","section_title":"...","method":"شرح الطريقة والأساس","method_sources":["R2"],'
        '"inputs":[{"name":"amount","label":"...","value":0,"source":"D1","currency":"","rate":"","rate_date":""}],'
        '"formula":"amount*rate","law_dependent":false,'
        '"basis":[{"ref":"R2","article":"المادة 123","figure":"19","applies":"لماذا تنطبق على وقائع القضية","as_of":"YYYY-MM-DD"}],'
        '"replaces":""}],'
        '"tables":[{"title":"...","section_title":"...","columns":["..."],"rows":[["..."]],"sources":["D1"],"note":"","law_dependent":false,'
        '"basis":[{"ref":"R2","article":"المادة 123","figure":"19","applies":"...","as_of":"YYYY-MM-DD"}],"replaces":""}],'
        '"remove":[],"missing":["..."],"conflicts":["..."]}\n'
        "قواعد الأرقام: أسماء المتغيرات لاتينية وشرطة سفلية. كل رقم معطى يجب أن يرد في مصدر وإلا فاذكر النقص في missing "
        "ولا تخترعه. لا تحسب أي ناتج بنفسك أبداً: في الجداول اكتب الخلية المشتقة صيغة تبدأ بـ = بمراجع على نمط الجداول "
        "(حرف العمود A للأول ثم B... ورقم الصف 1 لأول صف بيانات دون صف العناوين)، مثل =C2*D2 و =SUM(E1:E12) و =B3-C3 "
        "(الدوال: SUM AVG MIN MAX ROUND ABS). "
        "أسعار تحويل العملات الأجنبية: إن ورد سعر التحويل في وثائق الأطراف أو في المصادر فاعتمده كما ورد "
        "(في جدول: ضعه في عمود خاص برقمه ونقله كما كُتب، ثم اضرب بصيغة، مثل =B2*C2؛ وفي حساب: الحقل rate بدل ترك "
        "الدالة تبحث) وأحِل إلى مصدره. وإن لم يرد سعر في أي مصدر فاستعمل سعر جدول الأسعار الذي يدخله الخبير: داخل الجدول "
        "=FX(B2,\"EUR\",\"2020-03-01\") بتاريخ الواقعة، وفي الحساب اترك rate فارغاً مع currency وrate_date. "
        "ولا تذكر أي سعر صرف من عندك أبداً. إن لم يوجد سعر لا في المصادر ولا يمكن الاعتماد على الجدول فاذكر النقص في "
        "missing. في حسابات calculations المبالغ بغير الدينار: value بمبلغها الأصلي مع currency برمز ISO. "
        "الأرقام المنقولة من وثائق تُكتب كما وردت."
    ) % (hide(ctx.get("summary", "") or "(لا توجد نبذة)"), hide(ctx.get("tasks", "") or "(لا توجد مهام)"),
         hide(heads), _evidence_block(evidence, anon))
    prompt += _CALC_RULES + _LEGAL_RULES + _METHOD_RULES
    try:
        import playbooks
        prompt += "\n\n" + playbooks.guidance(ctx)
    except Exception:
        pass
    if instructions and instructions.strip():
        prompt += "\n\nتوجيه الخبير (له الأولوية ما لم يخالف المصادر):\n" + hide(instructions.strip())
    digest = _existing_digest(existing, sections)
    if digest:
        prompt += (
            "\n\nهذه طلب «تحديث». الجداول والحسابات الحالية في المسودة:\n" + hide(digest) +
            "\n\nراجِعها على ضوء المستجدات (نبذة/مهام/وثائق/مراجع/توجيه الخبير): ما بقي صحيحاً **لا تُعده**. ما يحتاج تغييراً "
            "جوهرياً (أعمدة أو صفوف أو أرقام) أعِده كاملاً وضع في replaces معرّف العنصر القديم (مثل \"T2\"). "
            "ما صار لا لزوم له ضعه في remove بمعرّفه. وأضِف أي جداول أو حسابات جديدة تلزم (replaces فارغ). "
            "يجوز تغيير الشكل كلياً أو عدد الجداول.")
    if avoid:
        prompt += ("\n\nقدّم طريقة حساب بديلة مختلفة جوهرياً (أساس قانوني أو منهج آخر) عن هذه الحسابات السابقة:\n" +
                   "\n".join("- %s: %s" % (c.get("title", ""), c.get("formula", "")) for c in avoid))
    prompt += LANG_RULES
    raw = _parse_json(_call(ai, prompt, SYSTEM, True, search=True))
    if anon:
        raw = anon.show(raw)
    valid = {e["id"] for e in evidence}
    ok_src = lambda lst: [x for x in (lst or []) if x in valid]
    tmap = _by_title(sections)
    link = lambda t: tmap.get(_norm_text(t or ""), "")
    missing = [str(m) for m in raw.get("missing", [])]
    known = {x["id"] for k in ("tables", "calculations") for x in (existing or {}).get(k, [])}
    rep = lambda v: str(v).strip() if str(v or "").strip() in known else ""

    calcs = []
    for c in raw.get("calculations", []):
        if not (isinstance(c, dict) and c.get("formula")):
            continue
        inputs, ok = [], True
        for i in c.get("inputs", []):
            try:
                cur = fx_rates.norm_currency(i.get("currency", ""))
                rd = str(i.get("rate_date", "") or "").strip()
                if cur not in ("", "DZD"):
                    try:
                        rd = fx_rates.parse_date(rd).isoformat()
                    except ValueError as e:
                        missing.append("حساب «%s»: %s يحتاج تاريخاً صحيحاً لسعر الصرف. %s" % (c.get("title", ""), i.get("label", i["name"]), e))
                        rd = ""
                item = {"name": str(i["name"]), "label": str(i.get("label", i["name"])),
                        "value": to_number(i["value"]), "source": i.get("source", "") if i.get("source") in valid else "",
                        "currency": cur if cur != "DZD" else "", "rate_date": rd}
                if str(i.get("rate", "") or "").strip():          # سعر تحويل وارد في وثيقة الأطراف
                    item["rate"] = to_number(i["rate"])
                inputs.append(item)
            except Exception as e:
                ok = False
                missing.append("حساب «%s»: قيمة غير صالحة للمتغير %s (%s)" % (c.get("title", ""), i.get("name", "?"), e))
        if ok:
            basis = _clean_basis(c.get("basis"), valid)
            method = str(c.get("method", ""))
            cited = [b for b in basis if b["article"] and b["article"] not in method]
            if cited:
                method += " — الأساس: " + "؛ ".join("%s [%s]" % (b["article"], b["ref"]) for b in cited)
            calcs.append({"title": str(c.get("title", "حساب")), "section": link(c.get("section_title")),
                          "method": method, "method_sources": ok_src(c.get("method_sources")) or
                          ok_src([b["ref"] for b in basis]),
                          "inputs": inputs, "formula": str(c["formula"]), "note": str(c.get("note", "")),
                          "law_dependent": bool(c.get("law_dependent")) or bool(basis), "basis": basis,
                          "replaces": rep(c.get("replaces"))})
    tables = []
    for t in raw.get("tables", []):
        cols = [str(x) for x in (t.get("columns") or [])] if isinstance(t, dict) else []
        if not cols:
            continue
        rows = [[str(v) for v in (r + [""] * len(cols))[:len(cols)]] for r in (t.get("rows") or []) if isinstance(r, list)]
        tables.append({"title": str(t.get("title", "جدول")), "section": link(t.get("section_title")),
                       "columns": cols, "rows": rows, "sources": ok_src(t.get("sources")), "note": str(t.get("note", "")),
                       "law_dependent": bool(t.get("law_dependent")) or bool(t.get("basis")),
                       "basis": _clean_basis(t.get("basis"), valid), "replaces": rep(t.get("replaces"))})
    remove = [str(x).strip() for x in (raw.get("remove") or []) if str(x).strip() in known]
    return calcs, tables, missing, [str(c) for c in raw.get("conflicts", []) if str(c).strip()], remove


def _table_fx_pairs(draft):
    """(عملة, تاريخ) المستعملة في دوال FX داخل خلايا الجداول."""
    import fx_rates
    out = []
    for t in draft.get("tables", []):
        for row in t.get("rows", []):
            for v in row:
                for cur, d in _FX_USE.findall(str(v)):
                    out.append((fx_rates.norm_currency(cur), d.strip()))
    return out


def missing_rates(draft, rates=None):
    """(عملة, تاريخ) لكل مبلغ أجنبي لا يوجد له سعر في الجدول. قائمة فارغة = لا حاجة لأسعار الصرف."""
    rates = rates if rates is not None else fx_rates.load()
    pairs = []
    for c in draft.get("calculations", []):
        for i in c.get("inputs", []):
            if str(i.get("rate", "") or "").strip():
                continue
            pairs.append((fx_rates.norm_currency(i.get("currency", "")), i.get("rate_date", "")))
    pairs += _table_fx_pairs(draft)
    out = []
    for cur, d in pairs:
        if cur in ("", "DZD"):
            continue
        try:
            fx_rates.get_rate(rates, cur, fx_rates.parse_date(d))
        except ValueError:
            out.append((cur, str(d or "") or "؟"))
    return sorted(set(out))


def uses_foreign_currency(draft):
    return any(fx_rates.norm_currency(i.get("currency", "")) not in ("", "DZD") and not str(i.get("rate", "") or "").strip()
               for c in draft.get("calculations", []) for i in c.get("inputs", [])) \
        or any(cur not in ("", "DZD") for cur, _ in _table_fx_pairs(draft))


def copy_item(items, index):
    """نسخة من حساب/جدول/عنوان تُدرج بعده بمعرّف جديد."""
    import copy
    src = items[index]
    dup = copy.deepcopy(src)
    dup["id"] = ""
    dup["title"] = str(src.get("title", "")) + " (نسخة)"
    prefix = (str(src.get("id", "X")) or "X")[0]
    dup["id"] = _next_id(items, prefix)
    items.insert(index + 1, dup)
    return dup
