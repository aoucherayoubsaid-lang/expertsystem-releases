# -*- coding: utf-8 -*-
"""تنبيهات التلاعب (hardening.py / advanced_guard.py) عبر خادم الحماية expert-guard (/g/alert).

لا يوجد أي توكن تيليغرام في هذا الملف ولا في الـ exe: التوكن سرٌّ في Cloudflare فقط
(TELEGRAM_TOKEN و TELEGRAM_CHAT_ID في Worker expert-guard).

الواجهة العامة كما كانت: is_configured() و alert(reason) و alert_blocking(reason, timeout).
فشل الإرسال لا يوقف البرنامج أبداً. الخادم يتجاهل بصمت أي جهاز غير مسجّل عنده،
ويحدّ الطلبات لكل IP ويمنع تكرار نفس السبب في اليوم.
"""
import threading
import time

_LAST_SENT = {}            # debounce محلي: نفس السبب لا يُرسَل أكثر من مرة كل 5 دقائق
_DEBOUNCE_SECONDS = 300


def is_configured():
    try:
        import guard_client
        return guard_client.is_configured()
    except Exception:
        return False


def _reason_text(reason):
    try:
        import device_fingerprint
        fp = str(device_fingerprint.collect().get("hash", "?"))[:8]
    except Exception:
        fp = "?"
    # الخادم يقصّ السبب عند 80 حرفاً: نبقي النص قصيراً ونضع البصمة المختصرة في آخره
    return ("%s | fp=%s" % (str(reason)[:60], fp))[:80]


def _send_sync(reason, timeout=6):
    try:
        import guard_client
        import license_manager
        guard_client._post("/g/alert",
                           {"machine": license_manager.machine_code(), "reason": _reason_text(reason)},
                           timeout=timeout)
    except Exception:
        pass          # لا إنترنت أو الخادم غير متاح: لا يهم، البرنامج يتابع عمله بصمت


def alert_blocking(reason, timeout=4):
    """نسخة متزامنة قصيرة المهلة: تُستعمل فقط قبل os._exit() مباشرة (advanced_guard.py)."""
    if not is_configured():
        return
    _send_sync(reason, timeout=timeout)


def alert(reason):
    """يُستدعى من hardening.py عند رصد تلاعب. غير حاجز، ولا يرفع استثناءً، ولا يُظهر شيئاً في الواجهة."""
    if not is_configured():
        return
    now = time.monotonic()
    if now - _LAST_SENT.get(reason, 0.0) < _DEBOUNCE_SECONDS:
        return
    _LAST_SENT[reason] = now
    threading.Thread(target=_send_sync, args=(reason,), daemon=True).start()
