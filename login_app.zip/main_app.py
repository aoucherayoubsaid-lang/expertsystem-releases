from msgbox_ltr import show_info, show_warning
import sys
from PyQt5.QtCore import QCoreApplication, Qt
QCoreApplication.setAttribute(Qt.AA_ShareOpenGLContexts)
from PyQt5.QtWidgets import (
    QApplication, QWidget, QMainWindow, QLabel, QVBoxLayout, QHBoxLayout,
    QPushButton, QTabWidget, QFrame, QLineEdit, QMessageBox, QAction, QBoxLayout
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt, QSize, QTimer
import qtawesome as qta
from modern_theme import style_button, style_soft_button, MAIN_TAB_QSS
import theme_tokens as T
from ui_components import Sidebar

import storage
from auto_translation import get_auto_translation_manager

# استيراد الصفحات
from case_pages import CaseManagementPage
from party_page import PartyPage
from document_page import DocumentManagementPage
from minutes_page import MinutesPage
from report_files_page import ReportFilesPage
from deposit_page import DepositPage
from settings_page import SettingsPage, AppSettings, translations
from planning_page import PlanningPage
from ai_report_page import AIReportPage


class LoginDialog(QWidget):
    """نافذة تأكيد كلمة مرور بسيطة (تُستعمل عند تفعيل خيار طلب كلمة المرور عند بدء التشغيل)."""

    def __init__(self, settings):
        super().__init__()
        self.settings = settings
        self.accepted = False
        self.setWindowTitle("تأكيد كلمة المرور")
        self.setGeometry(400, 300, 350, 150)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 18, 24, 18)   # هوامش تمنع التصاق الكلمات بحدود النافذة
        layout.setSpacing(10)

        label = QLabel("أدخل كلمة المرور للمتابعة:")
        label.setFont(QFont("Segoe UI", 12))
        layout.addWidget(label)

        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        layout.addWidget(self.password_input)

        self.hint_label = QLabel()
        self.hint_label.setStyleSheet("color: gray")
        hint = self.settings.get("password_hint")
        if hint:
            self.hint_label.setText(f"تلميح: {hint}")
            layout.addWidget(self.hint_label)

        btn = QPushButton("دخول")
        btn.setMinimumHeight(36)
        btn.clicked.connect(self.check_password)
        layout.addWidget(btn)

    def check_password(self):
        import startup_password as sp
        if not sp.has_password(self.settings):
            # لا توجد كلمة مرور محفوظة (حالة غير متوقعة): لا نحبس المستخدم خارج برنامجه
            self.accepted = True
            self.close()
            return
        if sp.is_locked():
            show_warning(self, "تنبيه",
                         "تجاوزت عدد المحاولات المسموح. حاول بعد %d دقائق." % sp.lock_minutes())
            self.accepted = False
            return
        if sp.verify(self.settings, self.password_input.text()):
            sp.on_success()
            self.accepted = True
            self.close()
        else:
            sp.on_failure()
            show_warning(self, "خطأ", "كلمة المرور غير صحيحة")
            self.password_input.clear()
            self.accepted = False


class MainApp(QMainWindow):
    """
    صفحة العمل الرئيسية (Workspace) - تُفتح بعد اختيار السنة والمحكمة من الصفحة
    الرئيسية (DossierHomePage). لا تحتوي على "الصفحة الرئيسية" ضمن تبويباتها؛
    "الرئيسية"في الشريط العلوي يعيد فتح تلك الصفحة عند الحاجة.

    التبويبات: القضايا / الأطراف / الوثائق / محاضر (فرعي: حضور + انتقال) /
    الإيداع (فرعي: كشف الأتعاب + تسديد الأتعاب + وصل الإيداع) / إعداد التقرير / الإعدادات
    """

    def __init__(self, current_user=None):
        super().__init__()
        self.current_user = current_user or {"username": "admin", "role": "admin"}
        self.settings = AppSettings()
        self.auto_i18n = get_auto_translation_manager(QApplication.instance())
        # في أول دخول لمساحة العمل نعرض التنبيه الاحترافي الكبير فقط.
        # شريط التنبيه الصغير يظهر لاحقًا عند العودة إلى تبويب القضايا.
        self._suppress_case_alert_banner = True
        self._workspace_alert_shown = False

        dossier_name = storage.get_current_dossier_name() or "بدون ملف محدد"
        year = storage.get_current_year() or "—"
        court = storage.get_current_court() or "—"
        self.setWindowTitle(f"نظام الخبير القضائي  —  {dossier_name}  —  {court}  —  سنة {year}")
        self.setGeometry(100, 100, 1280, 830)
        self.setMinimumSize(1000, 650)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.main_layout = QVBoxLayout(self.central_widget)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)

        self.init_menu_bar()
        self.init_header(dossier_name, year)
        self.init_tabs()
        self.init_pages()

        self._init_sidebar()

        self.tabs.setCurrentIndex(0)

        # التنبيه الكبير يظهر مرة واحدة عند الدخول إلى مساحة العمل.
        QTimer.singleShot(250, self.show_deadline_alert)

        # فحص التحديثات في الخلفية بعد فتح البرنامج (بصمت إن لم يوجد تحديث أو انقطع الإنترنت)
        def _check_updates():
            try:
                import updater
                updater.start_background_check(self)
            except Exception:
                pass
        QTimer.singleShot(4000, _check_updates)

    def show_deadline_alert(self):
        self._workspace_alert_shown = True
        try:
            from case_status import case_status, deposit_receipts, near_days
            from deadline_alert import DeadlineAlertDialog
            receipts, near = deposit_receipts(), near_days()
            items = []
            for c in storage.load_cases():
                st = case_status(c, receipts, near)
                if st["state"] in ("late", "near"):
                    items.append((c, st))
            if not items:
                self._suppress_case_alert_banner = False
                return
            dlg = DeadlineAlertDialog(items, self.settings.get_language_code(), self)
            dlg.exec_()
            if dlg.view_clicked:
                self.tabs.setCurrentIndex(0)
            self._suppress_case_alert_banner = False
        except Exception:
            self._suppress_case_alert_banner = False

    # ------------------------------------------------------------------
    # القوائم العلوية (Menu Bar)
    # ------------------------------------------------------------------
    # نصوص القوائم بلغات الواجهة (بدون خلط عربي/لاتيني داخل النص الواحد)
    MENU_TEXTS = {
        "ar": {"file": "الملف", "home": "الصفحة الرئيسية (السنة/المحكمة)", "switch": "تبديل الملف",
               "logout": "تسجيل الخروج", "close": "إغلاق", "help": "مساعدة", "about": "حول التطبيق",
               "feedback": "إرسال اقتراح أو مشكلة", "guide": "دليل الاستخدام", "license": "الترخيص والتفعيل"},
        "fr": {"file": "Dossier", "home": "Page d'accueil (année / tribunal)", "switch": "Changer de dossier",
               "logout": "Déconnexion", "close": "Fermer", "help": "Aide", "about": "À propos",
               "feedback": "Envoyer une suggestion ou un problème", "guide": "Guide d'utilisation", "license": "Licence et activation"},
        "en": {"file": "Dossier", "home": "Home page (year / court)", "switch": "Switch dossier",
               "logout": "Log out", "close": "Close", "help": "Help", "about": "About",
               "feedback": "Send a suggestion or problem", "guide": "User guide", "license": "License and activation"},
    }
    HEADER_TEXTS = {
        "ar": {"home": "الرئيسية", "switch": "تبديل الملف", "year": "سنة"},
        "fr": {"home": "Accueil", "switch": "Changer de dossier", "year": "année"},
        "en": {"home": "Home", "switch": "Switch dossier", "year": "year"},
    }

    def init_menu_bar(self):
        menu_bar = self.menuBar()
        menu_bar.setFont(QFont("Segoe UI", 10))

        self.dossier_menu = menu_bar.addMenu("")
        self.home_action = QAction("", self)
        self.home_action.triggered.connect(self.go_home)
        self.dossier_menu.addAction(self.home_action)

        self.switch_action = QAction("", self)
        self.switch_action.triggered.connect(self.switch_dossier)
        self.dossier_menu.addAction(self.switch_action)

        self.dossier_menu.addSeparator()

        self.logout_action = QAction("", self)
        self.logout_action.triggered.connect(self.logout)
        self.dossier_menu.addAction(self.logout_action)

        self.exit_action = QAction("", self)
        self.exit_action.triggered.connect(self.close)
        self.dossier_menu.addAction(self.exit_action)

        self.help_menu = menu_bar.addMenu("")
        self.feedback_action = QAction("", self)
        self.feedback_action.triggered.connect(self.show_feedback)
        self.help_menu.addAction(self.feedback_action)

        # دليل الاستخدام (PDF) بثلاث لغات: قائمة فرعية تعرض اللغات الموجودة ملفاتها فقط
        self.guide_menu = self.help_menu.addMenu("")

        self.license_action = QAction("", self)
        self.license_action.triggered.connect(self.show_license)
        self.help_menu.addAction(self.license_action)

        # أيقونات من qtawesome (رموز الإيموجي تظهر مربعات فارغة على ويندوز 7)
        self.feedback_action.setIcon(qta.icon("fa5s.envelope", color="#4338ca"))
        self.guide_menu.setIcon(qta.icon("fa5s.book", color="#4338ca"))
        self.license_action.setIcon(qta.icon("fa5s.key", color="#4338ca"))

        self.help_menu.addSeparator()
        self.about_action = QAction("", self)
        self.about_action.triggered.connect(self.show_about)
        self.help_menu.addAction(self.about_action)

        # نفس الخط والمحاذاة والتباعد في القوائم المنسدلة (تتبع اتجاه اللغة)
        menu_bar.setStyleSheet("""
            QMenuBar { font-family: 'Segoe UI'; font-size: 10pt; background: %s;
                       border-bottom: 1px solid %s; color: %s; }
            QMenuBar::item { padding: 5px 14px; background: transparent; border-radius: 4px; }
            QMenuBar::item:selected { background: %s; }
            QMenu { font-family: 'Segoe UI'; font-size: 10pt; }
            QMenu::item { padding: 6px 26px; }
        """ % (T.SURFACE, T.BORDER, T.TEXT, T.HOVER_BG))

    def _apply_chrome_language(self, lang_code):
        """يُحدّث القوائم والشريط العلوي: النصوص والاتجاه يتبعان لغة الواجهة."""
        code = lang_code if lang_code in self.MENU_TEXTS else "ar"
        ar = code == "ar"
        direction = Qt.RightToLeft if ar else Qt.LeftToRight

        # --- القوائم ---
        m = self.MENU_TEXTS[code]
        self.menuBar().setLayoutDirection(direction)
        self.dossier_menu.setTitle(m["file"])
        self.help_menu.setTitle(m["help"])
        self.home_action.setText(m["home"])
        self.switch_action.setText(m["switch"])
        self.logout_action.setText(m["logout"])
        self.exit_action.setText(m["close"])
        self.about_action.setText("ℹ " + m["about"])
        self.feedback_action.setText(m["feedback"])
        self.guide_menu.setTitle(m["guide"])
        self._rebuild_guide_menu(code)
        self.license_action.setText(m["license"])
        for menu in (self.dossier_menu, self.help_menu, self.guide_menu):
            menu.setLayoutDirection(direction)
            menu.setFont(QFont("Segoe UI", 10))

        # --- الشريط العلوي: بالعربية العنوان يسار والأزرار يمين، وتنعكس في اللغات الأخرى ---
        h = self.HEADER_TEXTS[code]
        # عربي: اسم الملف/المحكمة أقصى اليمين والأزرار يسارها (وتنعكس في اللغتين الأخريين)
        self.header_layout.setDirection(QBoxLayout.RightToLeft if ar else QBoxLayout.LeftToRight)
        self.header_group_layout.setDirection(QBoxLayout.RightToLeft if ar else QBoxLayout.LeftToRight)
        self.home_btn.setText(h["home"])
        self.switch_btn.setText(h["switch"])
        for w in (self.home_btn, self.switch_btn, self.user_label, self.dossier_label):
            w.setLayoutDirection(direction)
        self.dossier_label.setText(f"{self._dossier_name} | {storage.get_current_court() or '—'} | {h['year']} {self._year}")

    def show_about(self):
        import app_info
        import license_manager
        show_info(
            self, "حول التطبيق",
            "%s\nالإصدار %s\n\nالمطوّر: %s\nالهاتف: %s\nالبريد: %s\n\n%s" % (
                app_info.APP_NAME_AR, app_info.APP_VERSION, app_info.DEVELOPER_NAME,
                app_info.DEVELOPER_PHONE, app_info.DEVELOPER_EMAIL,
                license_manager.status_text())
        )

    def show_feedback(self):
        from feedback_dialog import FeedbackDialog
        FeedbackDialog(self).exec_()

    def show_license(self):
        from license_dialog import LicenseDialog
        LicenseDialog(parent=self).exec_()

    def _guide_folders(self):
        import os
        import sys
        from resource_path import resource_path
        from app_paths import app_base_dir
        folders = []
        if getattr(sys, "frozen", False):
            folders.append(os.path.dirname(os.path.abspath(sys.executable)))   # مجلد التثبيت
        folders += [app_base_dir(), resource_path("")]
        return folders

    def _find_guide(self, names):
        import os
        for base in self._guide_folders():
            for name in names:
                p = os.path.join(base, name)
                if os.path.exists(p):
                    return p
        return None

    def _rebuild_guide_menu(self, current_lang="ar"):
        """يبني القائمة الفرعية: لغة الواجهة الحالية أولاً، ثم باقي اللغات المتوفرة."""
        import app_info
        self.guide_menu.clear()
        entries = []
        for code, label, names in app_info.USER_GUIDES:
            path = self._find_guide(names)
            if path:
                entries.append((code, label, path))
        entries.sort(key=lambda e: 0 if e[0] == current_lang else 1)
        for code, label, path in entries:
            act = self.guide_menu.addAction(label)
            act.triggered.connect(lambda checked=False, p=path: self.open_user_guide(p))
        self.guide_menu.menuAction().setVisible(bool(entries))

    def open_user_guide(self, path=None):
        import os
        if not path:
            return
        opened = False
        try:
            os.startfile(path)           # ويندوز
            opened = True
        except Exception:
            from PyQt5.QtCore import QUrl
            from PyQt5.QtGui import QDesktopServices
            opened = QDesktopServices.openUrl(QUrl.fromLocalFile(path))
        if not opened:
            show_warning(self, "دليل الاستخدام / User guide",
                         "لا يوجد على جهازك برنامج لقراءة ملفات PDF.\n"
                         "ثبّت Adobe Reader أو Foxit Reader أو افتح الملف بمتصفح Chrome:\n" + path)

    def go_home(self):
        from dossier_home_page import DossierHomePage
        self.home_page = DossierHomePage(current_user=self.current_user)
        self.home_page.showMaximized()
        self.close()

    def switch_dossier(self):
        from dossier_page import DossierPage
        storage.clear_current_year()
        storage.clear_current_dossier()
        self.dossier_page = DossierPage(current_user=self.current_user)
        self.dossier_page.show()
        self.close()

    def logout(self):
        storage.clear_current_year()
        storage.clear_current_dossier()
        from login_app import LoginWindow
        self.login_window = LoginWindow()
        self.login_window.show()
        self.close()

    # ------------------------------------------------------------------
    # شريط رأس يعرض الملف والسنة الحاليين + زر العودة للرئيسية
    # ------------------------------------------------------------------
    def init_header(self, dossier_name, year):
        self._dossier_name = dossier_name
        self._year = year

        header = QFrame()
        header.setObjectName("appHeader")
        header.setStyleSheet(
            "QFrame#appHeader { background: %s; border-bottom: 1px solid %s; }"
            "QFrame#appHeader QLabel { background: transparent; }" % (T.SURFACE, T.BORDER)
        )
        header.setFixedHeight(58)
        # الاتجاه الفعلي يُضبط بالكامل من _apply_chrome_language (لا يرث اتجاه النافذة)
        header.setLayoutDirection(Qt.LeftToRight)
        self.header_layout = QHBoxLayout(header)
        self.header_layout.setContentsMargins(15, 5, 15, 5)

        self.dossier_label = QLabel(f"{dossier_name} | {storage.get_current_court() or '—'} | {year}")
        self.dossier_label.setFont(QFont("Segoe UI", 11, QFont.Bold))
        self.dossier_label.setStyleSheet(
            "color: %s; background: %s; border-radius: 15px; padding: 6px 16px;"
            % (T.PRIMARY, T.HOVER_BG))
        self.header_layout.addWidget(self.dossier_label)

        self.header_layout.addStretch()

        group = QWidget()
        group.setStyleSheet("background: transparent;")
        self.header_group_layout = QHBoxLayout(group)
        self.header_group_layout.setContentsMargins(0, 0, 0, 0)
        self.header_group_layout.setSpacing(8)

        self.user_label = QLabel(f"{self.current_user.get('username','')}")
        self.user_label.setStyleSheet("color: %s; font-size: 10pt;" % T.TEXT_MUTED)
        self.header_group_layout.addWidget(self.user_label)

        from theme_manager import make_theme_button
        self.theme_btn = make_theme_button(self)
        self.header_group_layout.addWidget(self.theme_btn)

        self.home_btn = QPushButton("")
        self.home_btn.setIcon(qta.icon("fa5s.home", color=T.PRIMARY))
        self.home_btn.setIconSize(QSize(16, 16))
        style_soft_button(self.home_btn, "info", radius=8, padding="7px 16px")
        self.home_btn.clicked.connect(self.go_home)
        self.header_group_layout.addWidget(self.home_btn)

        self.switch_btn = QPushButton("")
        self.switch_btn.setIcon(qta.icon("fa5s.exchange-alt", color=T.PRIMARY))
        self.switch_btn.setIconSize(QSize(16, 16))
        style_soft_button(self.switch_btn, "secondary", radius=8, padding="7px 16px")
        self.switch_btn.clicked.connect(self.switch_dossier)
        self.header_group_layout.addWidget(self.switch_btn)

        self.header_layout.addWidget(group)
        self._header = header   # يُضاف إلى التخطيط في _init_sidebar

    # ------------------------------------------------------------------
    # تبويبات علوية (Top Tabs)
    # ------------------------------------------------------------------
    def init_tabs(self):
        self.tabs = QTabWidget()
        self.tabs.setTabPosition(QTabWidget.North)
        self.tabs.setIconSize(QSize(18, 18))

        # مهم جداً: حجم الخط يُضبط هنا عبر setFont وليس داخل stylesheet.
        # سبب المشكلة السابقة: Qt يحسب عرض كل تبويب (sizeHint) بالخط
        # الافتراضي قبل تطبيق الـ stylesheet، فإذا كان الخط في الـ stylesheet
        # أكبر تُقصّ أسماء التبويبات (مثل "إعداد التقرير" و"الإعدادات").
        tab_bar = self.tabs.tabBar()
        tab_bar.setFont(QFont("Segoe UI", 11, QFont.Bold))
        tab_bar.setElideMode(Qt.ElideNone)      # منع اختصار النص بنقاط
        tab_bar.setExpanding(False)              # كل تبويب بعرض محتواه
        tab_bar.setUsesScrollButtons(True)       # أسهم تمرير عند ضيق النافذة

        self.tabs.setStyleSheet(MAIN_TAB_QSS)
        tab_bar.setVisible(False)   # التنقل عبر القائمة الجانبية؛ التبويبات تبقى كحاوية للصفحات
        self.tabs.currentChanged.connect(self.on_tab_changed)

    def init_pages(self):
        # [0] القضايا
        self.case_page = CaseManagementPage(self)
        self.tabs.addTab(self.case_page, qta.icon("fa5s.folder", color="#4338ca"), "القضايا")

        # [1] الأطراف
        self.party_page = PartyPage()
        self.tabs.addTab(self.party_page, qta.icon("fa5s.users", color="#4338ca"), "الأطراف")

        # [2] الوثائق
        self.document_page = DocumentManagementPage(self.case_page)
        self.tabs.addTab(self.document_page, qta.icon("fa5s.file", color="#4338ca"), "الوثائق")

        # [3] محاضر (فرعي: محضر الحضور + محضر الانتقال)
        self.minutes_page = MinutesPage(self.case_page, self.document_page, self.party_page, self)
        self.tabs.addTab(self.minutes_page, qta.icon("fa5s.clipboard-list", color="#4338ca"), "محاضر")
        # مراجع مباشرة للتوافق مع بقية الكود
        self.attendance_page = self.minutes_page.attendance_page
        self.visit_page = self.minutes_page.visit_page

        # [4] الإيداع (فرعي: كشف الأتعاب + تسديد الأتعاب + وصل الإيداع)
        self.deposit_page = DepositPage(self.case_page, self)
        self.tabs.addTab(self.deposit_page, qta.icon("fa5s.hand-holding-usd", color="#4338ca"), "الإيداع")
        # مراجع مباشرة يستعملها case_pages.py (نافذة كشف الأتعاب) وغيره
        self.fees_status_page = self.deposit_page.fees_status_page
        self.payments_page = self.deposit_page.payments_page
        self.receipt_page = self.deposit_page.receipt_page

        # [5] إعداد التقرير
        self.report_files_page = ReportFilesPage(self.case_page)
        self.tabs.addTab(self.report_files_page, qta.icon("fa5s.pencil-alt", color="#4338ca"), "إعداد التقرير")

        # [6] الإعدادات
        self.settings_page = SettingsPage(self.settings, self.current_user)
        self.tabs.addTab(self.settings_page, qta.icon("fa5s.cog", color="#4338ca"), "الإعدادات")
        self.settings_page.language_changed.connect(self.apply_language)

        # [7] التخطيط والآجال (للقراءة فقط؛ يُضاف أخيراً كي لا تتغير أرقام التبويبات القديمة)
        self.planning_page = PlanningPage(self.case_page, self)
        self.tabs.addTab(self.planning_page, qta.icon("fa5s.calendar-alt", color="#4338ca"), "التخطيط")

        # [8] التقرير والغلاف بالذكاء الاصطناعي (نماذجي، المراجع، الفهرسة، الحسابات، التصدير)
        self.ai_report_page = AIReportPage(self.case_page, self)
        self.tabs.addTab(self.ai_report_page, qta.icon("fa5s.magic", color="#4338ca"), "التقرير بالذكاء الاصطناعي")

        # تعريف التبويبات مع مفتاح ترجمتها وصلاحية ظهورها. يُستعمل لإخفاء ما لا
        # يحق للدور رؤيته، ولربط الترجمة بالتبويب نفسه (لا برقم موضعه الذي يتغيّر).
        self._tab_defs = [
            ("cases",     "view_cases",     self.case_page),
            ("parties",   "view_parties",   self.party_page),
            ("documents", "view_documents", self.document_page),
            ("minutes",   "view_minutes",   self.minutes_page),
            ("deposit",   None,             self.deposit_page),   # يُحدَّد من التبويبات الفرعية
            ("report",    "view_reports",   self.report_files_page),
            ("settings",  None,             self.settings_page),  # يظهر للجميع (المحتوى مقيَّد داخله)
            ("planning",  "view_cases",     self.planning_page),   # يعرض القضايا فقط
            ("ai_report", "view_reports",   self.ai_report_page),
        ]
        self._apply_role_permissions()
        # Capture the original Arabic UI text before any manual page-level
        # translations run, so future language switches always start from the
        # original source text.
        if self.auto_i18n:
            self.auto_i18n.scan_and_translate()
        self.apply_language(self.settings.get_language_code())

        self.case_page.table.cellClicked.connect(self.on_case_selected)

    def _apply_role_permissions(self):
        """يُخفي التبويبات التي لا يملك الدور الحالي صلاحية الاطّلاع عليها.
        الصفحات تبقى منشأة (تعتمد عليها صفحات أخرى) لكنها لا تظهر ولا يمكن فتحها."""
        user = self.current_user
        for key, perm, widget in self._tab_defs:
            if key == "deposit":
                allowed = any(storage.user_can(user, p)
                              for p in ("view_fees", "view_payments", "view_receipts"))
            elif perm:
                allowed = storage.user_can(user, perm)
            else:
                allowed = True
            if not allowed:
                idx = self.tabs.indexOf(widget)
                if idx >= 0:
                    self.tabs.removeTab(idx)

    def apply_language(self, lang_code):
        """يُطبَّق فوراً عند حفظ لغة جديدة من صفحة الإعدادات: يُعيد تسمية
        عناوين التبويبات الرئيسية بلغة الواجهة المختارة."""
        t = translations.get(lang_code, translations["ar"])
        for key, _perm, widget in getattr(self, "_tab_defs", []):
            index = self.tabs.indexOf(widget)
            if index >= 0:
                self.tabs.setTabText(index, t.get(key, self.tabs.tabText(index)))
        self.setLayoutDirection(Qt.LeftToRight if lang_code != "ar" else Qt.RightToLeft)
        self._apply_chrome_language(lang_code)
        self._refresh_sidebar(lang_code)
        # صفحات تُترجم محتواها بالكامل عند تغيير اللغة
        for page_name in ("document_page", "party_page", "report_files_page", "planning_page"):
            page = getattr(self, page_name, None)
            if page is not None and hasattr(page, "apply_language"):
                page.apply_language(lang_code)
        if self.auto_i18n:
            self.auto_i18n.set_language(lang_code)
        try:                                   # محاذاة الحقول/الأزرار حسب اتجاه اللغة الجديدة
            import ui_style
            ui_style.refresh_rtl(QApplication.instance())
        except Exception:
            pass

    # ------------------------------------------------------------------
    # القائمة الجانبية (تحل محل شريط التبويبات العلوي)
    # ------------------------------------------------------------------
    BRAND_TEXTS = {
        "ar": "نظام الخبير القضائي",
        "fr": "Système de l'expert judiciaire",
        "en": "Judicial Expert System",
    }
    NAV_ICONS = {
        "cases": "fa5s.folder-open", "parties": "fa5s.users", "documents": "fa5s.file-alt",
        "minutes": "fa5s.clipboard-list", "deposit": "fa5s.hand-holding-usd",
        "report": "fa5s.pencil-alt", "settings": "fa5s.cog", "planning": "fa5s.calendar-alt",
        "ai_report": "fa5s.magic",
    }
    # ترتيب القائمة الجانبية ومجموعاتها (لا علاقة له بترتيب التبويبات الداخلي)
    SIDEBAR_GROUPS = (
        ("overview", ("planning",)),
        ("casework", ("cases", "parties", "documents", "minutes")),
        ("finance", ("deposit",)),
        ("system", ("ai_report", "report", "settings")),
    )
    GROUP_TEXTS = {
        "ar": {"overview": "نظرة عامة", "casework": "الملفات", "finance": "المالية", "system": "النظام"},
        "fr": {"overview": "Vue d'ensemble", "casework": "Dossiers", "finance": "Finances", "system": "Système"},
        "en": {"overview": "Overview", "casework": "Casework", "finance": "Finance", "system": "System"},
    }

    def _init_sidebar(self):
        """يبني: [القائمة الجانبية | (الشريط العلوي فوق صفحات التبويبات)].
        الاتجاه يتبع النافذة: القائمة على يمين الشاشة بالعربية وعلى يسارها في اللغتين الأخريين."""
        import app_info
        self.sidebar = Sidebar()
        by_key = {k: w for k, _p, w in self._tab_defs}
        for group, keys in self.SIDEBAR_GROUPS:
            visible = [k for k in keys if k in by_key and self.tabs.indexOf(by_key[k]) >= 0]
            if not visible:          # مجموعة كلها مخفية بسبب صلاحيات الدور
                continue
            self.sidebar.add_group(group)
            for key in visible:
                widget = by_key[key]
                idx = self.tabs.indexOf(widget)
                self.sidebar.add_item(self.NAV_ICONS.get(key, "fa5s.circle"), self.tabs.tabText(idx), widget)
        self.sidebar.set_footer("v%s" % app_info.APP_VERSION)
        self.sidebar.nav_requested.connect(self._on_nav_requested)
        self.tabs.currentChanged.connect(self._sync_sidebar)

        right = QVBoxLayout()
        right.setContentsMargins(0, 0, 0, 0)
        right.setSpacing(0)
        right.addWidget(self._header)
        right.addWidget(self.tabs, 1)

        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        body.addWidget(self.sidebar)
        body.addLayout(right, 1)
        self.main_layout.addLayout(body, 1)

        self._refresh_sidebar(self.settings.get_language_code())
        self._sync_sidebar(self.tabs.currentIndex())

    def _on_nav_requested(self, widget):
        self.tabs.setCurrentWidget(widget)

    def _sync_sidebar(self, index):
        sidebar = getattr(self, "sidebar", None)
        if sidebar is not None:
            sidebar.set_current(self.tabs.widget(index))

    def _refresh_sidebar(self, lang_code):
        """يُحدّث نصوص القائمة الجانبية (نفس ترجمة عناوين التبويبات) واتجاهها."""
        sidebar = getattr(self, "sidebar", None)
        if sidebar is None:
            return
        code = lang_code if lang_code in self.BRAND_TEXTS else "ar"
        sidebar.set_brand(self.BRAND_TEXTS[code])
        for _key, _perm, widget in self._tab_defs:
            idx = self.tabs.indexOf(widget)
            if idx >= 0:
                sidebar.set_item_text(widget, self.tabs.tabText(idx))
        for group, _keys in self.SIDEBAR_GROUPS:
            sidebar.set_group_text(group, self.GROUP_TEXTS[code][group])
        sidebar.set_rtl(code == "ar")

    def on_tab_changed(self, index):
        """إعادة تحميل بيانات الصفحة المعروضة حالياً لضمان تزامنها مع أي تعديلات حديثة."""
        widget = self.tabs.widget(index)
        if index == 0 and self._workspace_alert_shown:
            page = getattr(self, "case_page", None)
            if page is not None and hasattr(page, "show_alert_banner"):
                page.show_alert_banner()
        if hasattr(widget, "reload") and callable(getattr(widget, "reload")):
            try:
                widget.reload()
            except Exception as e:
                print(f"تعذر تحديث الصفحة: {e}")

    def display_page(self, index):
        self.tabs.setCurrentIndex(index)

    def on_case_selected(self, row, column):
        case_number = self.case_page.table.item(row, 0).text()
        self.document_page.filter_by_case(case_number)