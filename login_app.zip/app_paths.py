# -*- coding: utf-8 -*-
"""مسارات التخزين الثابتة للتطبيق.

ثلاثة مفاهيم منفصلة (وهذا هو جوهر دعم الجهاز الواحد والمجلد المشترك):

1. install_dir()  : مجلد البرنامج نفسه (الـ exe أو ملفات .py). للقراءة فقط: الدليل، docs_api.json...
2. app_base_dir() : جذر البيانات المشتركة (app_data وdossiers_data). هذا ما قد يكون على مجلد مشترك.
3. machine_dir()  : ملفات خاصة بهذا الجهاز وحده ولا يجوز مشاركتها أبداً: مفتاح الترخيص (.es_dk)،
                    حالة الترخيص (.es_state)، عدّاد القفل وسجل التدقيق، مفتاح الفهرس المحلي، فهرس المراجع.

الوضعان (يُحفظان في %LOCALAPPDATA%\\ExpertSystem\\data_location.json، لكل مستخدم ويندوز):
- local  (الافتراضي): البيانات في %LOCALAPPDATA%\\ExpertSystem\\data. مقصورة على حساب ويندوز الحالي.
- shared : البيانات في مجلد يختاره المستخدم (مجلد شبكي مشترك). ملفات الجهاز تبقى محلية دائماً.

أثناء التطوير (تشغيل من ملفات .py) تبقى البيانات بجانب الملفات كما كانت، إلا إن وُجد إعداد صريح
أو متغير البيئة EXPERT_DATA_DIR.
نسخة exe القديمة التي بياناتها بجانب الـ exe: تُنقل تلقائياً إلى %LOCALAPPDATA% عند أول تشغيل بعد
التحقق من سلامة النسخ؛ وإن فشل أي شيء يبقى العمل على المكان القديم (لا يُحذف شيء قبل التحقق).
"""
import hashlib
import json
import os
import shutil
import sys
import tempfile

_FALLBACK_NAME = "نظام_الخبير_البيانات"
_APP_FOLDER = "ExpertSystem"
_LOCATION_FILE = "data_location.json"
_cached_base = None
_migration_note = {"done": False, "error": "", "moved": False}


class DataLocationError(RuntimeError):
    """مجلد البيانات المشترك غير متاح (انقطاع الشبكة، حذف المجلد...). لا نعمل على مكان بديل بصمت."""


def _is_writable(path):
    try:
        os.makedirs(path, exist_ok=True)
        probe = os.path.join(path, ".write_test")
        with open(probe, "w") as f:
            f.write("ok")
        os.remove(probe)
        return True
    except OSError:
        return False


def install_dir():
    """مجلد البرنامج نفسه (للقراءة): الـ exe أو ملفات .py."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def local_dir():
    """مجلد هذا المستخدم على هذا الجهاز: %LOCALAPPDATA%\\ExpertSystem (خارج ويندوز: ~/.local/share)."""
    override = os.environ.get("EXPERT_LOCAL_DIR")
    if override:
        base = override
    else:
        root = os.environ.get("LOCALAPPDATA")
        if not root:
            root = os.path.join(os.path.expanduser("~"), ".local", "share")
        base = os.path.join(root, _APP_FOLDER)
    os.makedirs(base, exist_ok=True)
    return base


# ---------------------------------------------------------------------------
# إعداد موقع البيانات
# ---------------------------------------------------------------------------
def _location_path():
    return os.path.join(local_dir(), _LOCATION_FILE)


def read_location():
    """يرجع {"mode": "local"|"shared", "path": ...} أو None إن لم يُضبط شيء."""
    try:
        with open(_location_path(), "r", encoding="utf-8") as f:
            d = json.load(f)
        if d.get("mode") in ("local", "shared"):
            return d
    except (OSError, ValueError):
        pass
    return None


def write_location(mode, path=None):
    if mode not in ("local", "shared"):
        raise ValueError("mode")
    d = {"mode": mode}
    if mode == "shared":
        if not path:
            raise ValueError("shared mode needs a path")
        d["path"] = os.path.abspath(path)
    tmp = _location_path() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False)
    os.replace(tmp, _location_path())
    reset_cache()


def reset_cache():
    global _cached_base
    _cached_base = None


def data_mode():
    """'shared' إن كانت البيانات على مجلد مشترك، وإلا 'local'."""
    if os.environ.get("EXPERT_DATA_DIR"):
        return "local"
    loc = read_location()
    return "shared" if loc and loc["mode"] == "shared" else "local"


# ---------------------------------------------------------------------------
# النقل من المكان القديم (بجانب الـ exe) إلى %LOCALAPPDATA%
# ---------------------------------------------------------------------------
_MIGRATE_FOLDERS = ("app_data", "dossiers_data", "reports_unassigned", "data")
_MIGRATE_FILES = ("ui_theme.txt", "docs_log.txt")


def _tree_manifest(root):
    """{مسار نسبي: (حجم، sha256)} لكل الملفات تحت root."""
    out = {}
    for dp, _dn, fns in os.walk(root):
        for fn in fns:
            p = os.path.join(dp, fn)
            h = hashlib.sha256()
            with open(p, "rb") as f:
                for b in iter(lambda: f.read(1 << 20), b""):
                    h.update(b)
            out[os.path.relpath(p, root)] = (os.path.getsize(p), h.hexdigest())
    return out


def _migrate_legacy(src_base, dst_base):
    """ينسخ البيانات القديمة، يتحقق من تطابقها ملفاً ملفاً، ثم يحذف الأصل. يرجع True عند النجاح الكامل.

    أي فشل: يُترك الأصل كما هو، ويُحذف الجزء المنسوخ ناقصاً، ويرجع False (فيستمر العمل على المكان القديم)."""
    todo = [n for n in _MIGRATE_FOLDERS if os.path.isdir(os.path.join(src_base, n))]
    files = [n for n in _MIGRATE_FILES if os.path.isfile(os.path.join(src_base, n))]
    if not todo and not files:
        return True
    staging = dst_base + ".incoming"
    try:
        if os.path.exists(staging):
            shutil.rmtree(staging)
        os.makedirs(staging)
        for n in todo:
            shutil.copytree(os.path.join(src_base, n), os.path.join(staging, n))
        for n in files:
            shutil.copy2(os.path.join(src_base, n), os.path.join(staging, n))
        for n in todo:
            if _tree_manifest(os.path.join(src_base, n)) != _tree_manifest(os.path.join(staging, n)):
                raise OSError("verification mismatch in " + n)
        for n in files:
            if _tree_manifest_file(os.path.join(src_base, n)) != _tree_manifest_file(os.path.join(staging, n)):
                raise OSError("verification mismatch in " + n)
        if os.path.exists(dst_base):
            shutil.rmtree(dst_base)
        os.replace(staging, dst_base)
    except Exception as exc:
        shutil.rmtree(staging, ignore_errors=True)
        _migration_note["error"] = str(exc)
        return False
    for n in todo:
        shutil.rmtree(os.path.join(src_base, n), ignore_errors=True)
    for n in files:
        try:
            os.remove(os.path.join(src_base, n))
        except OSError:
            pass
    _migration_note["moved"] = True
    return True


def _tree_manifest_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return (os.path.getsize(p), h.hexdigest())


def migration_status():
    """للواجهة: {"moved": bool, "error": str}."""
    return dict(_migration_note)


# ---------------------------------------------------------------------------
# الجذر
# ---------------------------------------------------------------------------
def app_base_dir():
    """جذر البيانات (app_data و dossiers_data وما بداخلهما). قد يكون مجلداً مشتركاً في وضع shared."""
    global _cached_base
    if _cached_base:
        return _cached_base

    env = os.environ.get("EXPERT_DATA_DIR")
    if env:
        os.makedirs(env, exist_ok=True)
        _cached_base = env
        return env

    loc = read_location()
    if loc and loc["mode"] == "shared":
        path = loc["path"]
        if not os.path.isdir(path) or not _is_writable(path):
            raise DataLocationError(path)
        _cached_base = path
        return path

    explicit_local = bool(loc and loc["mode"] == "local")
    frozen = getattr(sys, "frozen", False)
    legacy = install_dir()

    if frozen or explicit_local:
        target = os.path.join(local_dir(), "data")
        legacy_has_data = any(os.path.isdir(os.path.join(legacy, n)) for n in ("app_data", "dossiers_data"))
        if legacy_has_data and not os.path.isdir(os.path.join(target, "app_data")):
            if not _migrate_legacy(legacy, target):
                # فشل النقل: نكمل على المكان القديم بدل أن تبدو البيانات «مفقودة»
                _cached_base = legacy
                return legacy
        if _is_writable(target):
            _cached_base = target
            return target

    base = legacy
    if not _is_writable(base):
        base = os.path.join(os.path.expanduser("~"), "Documents", _FALLBACK_NAME)
        os.makedirs(base, exist_ok=True)
    _cached_base = base
    return base


def machine_dir():
    """ملفات خاصة بهذا الجهاز فقط. في وضع local هي app_data نفسه (توافق مع النسخ المثبَّتة)،
    وفي وضع shared مجلد محلي خارج المجلد المشترك."""
    if data_mode() == "shared":
        d = os.path.join(local_dir(), "machine")
    else:
        d = os.path.join(app_base_dir(), "app_data")
    os.makedirs(d, exist_ok=True)
    return d


def shared_app_data_dir():
    """app_data المشترك (users.json وsettings.json وتواقيعها...)."""
    return os.path.join(app_base_dir(), "app_data")


def temp_dir():
    """مجلد مؤقت لملفات HTML الوسيطة (لا تُحفظ مع البيانات ولا مع ملفات .py)."""
    path = os.path.join(tempfile.gettempdir(), "ExpertSystem_tmp")
    os.makedirs(path, exist_ok=True)
    return path
