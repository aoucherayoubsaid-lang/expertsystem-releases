"""شريط فلترة جاهز لأي QTableWidget (بحث نصي + قوائم تصفية حسب أعمدة + زر مسح + عدّاد).

- الفلترة تتم بإخفاء الصفوف (setRowHidden) دون حذفها، فتبقى أرقام الصفوف كما هي
  (مهم للصفحات التي تربط الصف بملف مرفق عبر رقم الصف).
- مستقل تماماً عن قوائم الإدخال (الطرف/القضية) في أعلى الصفحة.
"""
import re

import qtawesome as qta
from PyQt5.QtWidgets import (
    QWidget, QHBoxLayout, QLineEdit, QComboBox, QPushButton, QLabel
)

_DIACRITICS = re.compile(r"[\u0640\u064B-\u065F\u0670]")


def _norm(text):
    """توحيد النص للمقارنة: تشكيل، همزات، ياء/ألف مقصورة، تاء مربوطة، مسافات."""
    s = _DIACRITICS.sub("", str(text or ""))
    s = (s.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
          .replace("ى", "ي").replace("ة", "ه"))
    return re.sub(r"\s+", " ", s).strip().casefold()


class _NoWheelCombo(QComboBox):
    """لا يتغير اختيارها بعجلة الفأرة (يمنع فلترة غير مقصودة أثناء التمرير)."""
    def wheelEvent(self, event):
        event.ignore()


class TableFilterBar(QWidget):
    def __init__(self, table, filters, search_placeholder="ابحث في الجدول...", extra_text=None, parent=None):
        """
        table:   الجدول المراد فلترته.
        filters: قائمة (رقم_العمود, نص_الخيار_الافتراضي) مثل [(0, "كل القضايا"), (1, "كل الأطراف")].
        extra_text: دالة اختيارية row -> نص إضافي يشمله البحث (مثل اسم الملف المرفق).
        """
        super().__init__(parent)
        self.table = table
        self.extra_text = extra_text
        self._filters = []          # [(col, placeholder, combo)]

        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(8)

        self.search = QLineEdit()
        self.search.setPlaceholderText(search_placeholder)
        self.search.setClearButtonEnabled(True)
        self.search.setMaxLength(200)   # حد أقصى لطول نص البحث
        self.search.setMinimumHeight(32)
        self.search.textChanged.connect(self.apply)
        lay.addWidget(self.search, 1)

        for col, placeholder in filters:
            combo = _NoWheelCombo()
            combo.setMinimumHeight(32)
            combo.setMinimumWidth(150)
            combo.currentIndexChanged.connect(self.apply)
            self._filters.append((col, placeholder, combo))
            lay.addWidget(combo)

        self.clear_btn = QPushButton("مسح الفلتر")
        self.clear_btn.setIcon(qta.icon("fa5s.times-circle", color="#d03a50"))
        self.clear_btn.setMinimumHeight(32)
        self.clear_btn.clicked.connect(self.clear)
        lay.addWidget(self.clear_btn)

        self.count_lbl = QLabel()
        self.count_lbl.setStyleSheet("color:#4338ca; font-weight:bold;")
        lay.addWidget(self.count_lbl)

        self._fill_combos()

    # ------------------------------------------------------------------
    def _cell(self, row, col):
        item = self.table.item(row, col)
        return item.text().strip() if item else ""

    def _fill_combos(self):
        """تعبئة قوائم التصفية بالقيم الموجودة فعلاً في الجدول (مع إبقاء الاختيار إن بقي موجوداً)."""
        for col, placeholder, combo in self._filters:
            current = combo.currentData()
            values, seen = [], set()
            for r in range(self.table.rowCount()):
                v = self._cell(r, col)
                if v and _norm(v) not in seen:
                    seen.add(_norm(v))
                    values.append(v)
            values.sort(key=_norm)
            combo.blockSignals(True)
            combo.clear()
            combo.addItem(placeholder, None)
            for v in values:
                combo.addItem(v, v)
            idx = combo.findData(current) if current else 0
            combo.setCurrentIndex(idx if idx >= 0 else 0)
            combo.blockSignals(False)

    # ------------------------------------------------------------------
    def refresh(self):
        """يُستدعى بعد تحميل الجدول أو تغيّر صفوفه."""
        self._fill_combos()
        self.apply()

    def clear(self):
        """يمسح البحث والتصفية فتظهر كل الصفوف."""
        self.search.blockSignals(True)
        self.search.clear()
        self.search.blockSignals(False)
        for _col, _ph, combo in self._filters:
            combo.blockSignals(True)
            combo.setCurrentIndex(0)
            combo.blockSignals(False)
        self.apply()

    def apply(self, *_):
        query = _norm(self.search.text())
        wanted = [(col, _norm(combo.currentData())) for col, _ph, combo in self._filters
                  if combo.currentData()]
        total, shown = self.table.rowCount(), 0
        for r in range(total):
            ok = all(_norm(self._cell(r, col)) == val for col, val in wanted)
            if ok and query:
                parts = [self._cell(r, c) for c in range(self.table.columnCount())]
                if self.extra_text:
                    try:
                        parts.append(self.extra_text(r) or "")
                    except Exception:
                        pass
                ok = query in _norm(" ".join(parts))
            self.table.setRowHidden(r, not ok)
            shown += 1 if ok else 0
        self.count_lbl.setText(f"{shown} / {total}")
