# -*- coding: utf-8 -*-
"""Secure-ish managed file storage for Expert Judicial.

Provides generated storage names, SHA-256 integrity metadata, atomic copies,
and encrypted-backup-ready manifests. It intentionally does not encrypt files
itself because encryption/key management should use a vetted crypto library.
"""
import hashlib
import json
import os
import shutil
import tempfile
import uuid
from datetime import datetime


def sha256_file(path, chunk_size=1024 * 1024):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def safe_extension(filename):
    ext = os.path.splitext(filename or "")[1].lower()
    if len(ext) > 16:
        ext = ""
    return ext


def generated_name(original_name):
    return uuid.uuid4().hex + safe_extension(original_name)


def atomic_copy(src, dest):
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".upload_", dir=os.path.dirname(dest))
    os.close(fd)
    try:
        shutil.copyfile(src, tmp)
        try:
            shutil.copystat(src, tmp)
        except OSError:
            pass
        os.replace(tmp, dest)
    finally:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass


def store_file(src, target_dir):
    if not src or not os.path.isfile(src):
        raise FileNotFoundError(src or "")
    os.makedirs(target_dir, exist_ok=True)
    stored_name = generated_name(os.path.basename(src))
    dest = os.path.join(target_dir, stored_name)
    atomic_copy(src, dest)
    return {
        "stored_name": stored_name,
        "path": os.path.abspath(dest),
        "size": os.path.getsize(dest),
        "sha256": sha256_file(dest),
        "original_name": os.path.basename(src),
        "original_extension": safe_extension(src),
        "stored_at": datetime.now().isoformat(timespec="seconds"),
    }


def verify_file(path, expected_sha256=None, expected_size=None):
    if not path or not os.path.isfile(path):
        return False, "missing"
    if expected_size is not None and os.path.getsize(path) != int(expected_size):
        return False, "size_mismatch"
    if expected_sha256:
        actual = sha256_file(path)
        if actual.lower() != str(expected_sha256).lower():
            return False, "hash_mismatch"
    return True, "ok"


def build_manifest(root_dir):
    """Return a JSON-serializable integrity manifest for all regular files."""
    manifest = {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "algorithm": "SHA-256",
        "files": []
    }
    if not os.path.isdir(root_dir):
        return manifest
    for base, dirs, files in os.walk(root_dir):
        dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git")]
        for name in files:
            path = os.path.join(base, name)
            try:
                rel = os.path.relpath(path, root_dir)
                manifest["files"].append({
                    "path": rel,
                    "size": os.path.getsize(path),
                    "sha256": sha256_file(path),
                })
            except OSError:
                continue
    return manifest


def write_manifest(root_dir):
    manifest = build_manifest(root_dir)
    path = os.path.join(root_dir, "storage_manifest.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    return path
