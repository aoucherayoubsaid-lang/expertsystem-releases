from msgbox_ltr import show_info, show_warning, show_question
"""
صفحة إعداد التقرير — أرشيف ملفات الخبرة.

لكل قضية ثلاثة مكوّنات، لكل منها نسختان (قابلة للتحرير + PDF):
    - الخبرة            (Word + PDF)          ← الأساسي
    - صفحة الغلاف       (Word + PDF)          ← اختياري
    - كشف الأتعاب       (Excel + PDF)         ← اختياري
تُنسخ الملفات إلى مجلد البرنامج (خاص بالسنة والقضية) فلا تضيع إن نُقل الأصل،
ويُفتح Word/Excel مباشرة على النسخة المحفوظة فتبقى التعديلات مرتبطة بالقضية.
حالة الإيداع تُقرأ من "وصل إيداع تقرير الخبرة" في صفحة الإيداع.
"""
import datetime
import os
import platform
import re
import shutil
import subprocess
import zipfile

import qtawesome as qta
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QFontMetrics
from PyQt5.QtWidgets import (
    QAbstractItemView, QComboBox, QFileDialog, QFrame, QHBoxLayout, QHeaderView,
    QInputDialog, QLabel, QLineEdit, QMessageBox, QPushButton, QScrollArea,
    QSplitter, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget
)

import storage

# (المفتاح، أيقونة، لون، نوع الملف القابل للتحرير، اختياري؟)
KINDS = [
    ("report", "fa5s.file-alt", "#4338ca", "word", False),
    ("cover", "fa5s.book", "#7c3aed", "word", True),
    ("invoice", "fa5s.file-invoice-dollar", "#0f7a52", "excel", True),
]
EXTS = {
    "word": (".docx", ".doc"),
    "excel": (".xlsx", ".xlsm", ".xls"),
    "pdf": (".pdf",),
}

TEXTS = {
    "ar": {
        "title": "إعداد التقرير",
        "search": "ابحث برقم القضية أو اسم الطرف...",
        "status": "الحالة", "add_report": "إضافة ملف خبرة",
        "f_all": "كل الحالات", "f_deposited": "أُودعت (بوصل)", "f_no_receipt": "إيداع بلا وصل",
        "f_pending": "لم تُودع", "f_no_report": "بدون خبرة مرفقة",
        "c_case": "القضية", "c_parties": "الأطراف", "c_report": "الخبرة",
        "c_cover": "صفحة الغلاف", "c_invoice": "كشف الأتعاب", "c_deposit": "الإيداع",
        "k_report": "الخبرة", "k_cover": "صفحة الغلاف", "k_invoice": "كشف الأتعاب",
        "optional": "اختياري", "pdf_copy": "PDF",
        "word": "Word", "excel": "Excel",
        "no_file": "لا يوجد ملف", "missing": "الملف غير موجود",
        "attach": "إرفاق", "replace": "استبدال", "open": "فتح", "remove": "إزالة",
        "export_pdf": "تصدير PDF من Word", "folder": "مجلد القضية",
        "deposit_title": "الإيداع لدى أمانة الضبط",
        "dep_ok": "أُودعت الخبرة — وصل رقم {n}", "dep_date": "بتاريخ {d}",
        "dep_no_receipt": "تاريخ الإيداع مسجّل في القضية لكن لا يوجد وصل إيداع في صفحة الإيداع",
        "dep_none": "لم تُودع بعد", "open_receipt": "فتح وصل الإيداع",
        "pick_case": "اختر قضية من القائمة لعرض ملفاتها",
        "counts": "القضايا: {a}   |   بخبرة مرفقة: {b}   |   أُودعت: {c}",
        "vs": "ضد", "receipt_short": "وصل رقم {n}", "no_receipt_short": "بلا وصل",
        "warn": "تنبيه", "error": "خطأ", "confirm": "تأكيد",
        "wrong_type": "نوع الملف غير مناسب لهذا الحقل. الأنواع المقبولة: {t}",
        "other_case": "يبدو أن هذا الملف يخص القضية {found} بينما القضية المحددة هي {sel}.\n\nهل تريد إرفاقه بالقضية {sel} رغم ذلك؟",
        "replace_q": "يوجد ملف مرفق حالياً. هل تريد استبداله؟",
        "remove_q": "هل تريد إزالة هذا الملف من القضية؟",
        "pick_file": "اختر الملف", "detected": "تم التعرف على القضية {c} من محتوى الملف. هل هي القضية الصحيحة؟",
        "choose_case_title": "اختيار القضية", "choose_case_lbl": "تعذّر التعرّف التلقائي على القضية. اختر القضية:",
        "no_cases": "لا توجد قضايا في هذه السنة.",
        "copy_fail": "تعذر نسخ الملف إلى مجلد البرنامج:",
        "open_err": "تعذر فتح الملف:",
        "export_fail": "تعذر التصدير التلقائي. هذه الميزة تحتاج Microsoft Word على Windows.\nافتح الملف في Word واحفظه بصيغة PDF ثم أرفقه.\n\n{e}",
        "exported": "تم إنشاء ملف PDF وربطه بالقضية.",
        "not_pdf_word": "يقبل هذا الزر ملفات PDF أو Word فقط.",
    },
    "fr": {
        "title": "Préparation du rapport",
        "search": "Rechercher par n° d'affaire ou nom d'une partie...",
        "status": "Statut", "add_report": "Ajouter un rapport",
        "f_all": "Tous les statuts", "f_deposited": "Déposé (avec reçu)", "f_no_receipt": "Dépôt sans reçu",
        "f_pending": "Non déposé", "f_no_report": "Sans rapport joint",
        "c_case": "Affaire", "c_parties": "Parties", "c_report": "Rapport",
        "c_cover": "Page de garde", "c_invoice": "Note d'honoraires", "c_deposit": "Dépôt",
        "k_report": "Rapport d'expertise", "k_cover": "Page de garde", "k_invoice": "Note d'honoraires",
        "optional": "facultatif", "pdf_copy": "PDF",
        "word": "Word", "excel": "Excel",
        "no_file": "Aucun fichier", "missing": "Fichier introuvable",
        "attach": "Joindre", "replace": "Remplacer", "open": "Ouvrir", "remove": "Retirer",
        "export_pdf": "Exporter en PDF depuis Word", "folder": "Dossier de l'affaire",
        "deposit_title": "Dépôt au greffe",
        "dep_ok": "Rapport déposé — reçu n° {n}", "dep_date": "le {d}",
        "dep_no_receipt": "La date de dépôt est enregistrée mais aucun reçu n'existe dans la page Dépôt",
        "dep_none": "Pas encore déposé", "open_receipt": "Ouvrir le reçu de dépôt",
        "pick_case": "Sélectionnez une affaire pour afficher ses fichiers",
        "counts": "Affaires : {a}   |   Avec rapport : {b}   |   Déposées : {c}",
        "vs": "contre", "receipt_short": "Reçu n° {n}", "no_receipt_short": "Sans reçu",
        "warn": "Attention", "error": "Erreur", "confirm": "Confirmation",
        "wrong_type": "Type de fichier inadapté. Types acceptés : {t}",
        "other_case": "Ce fichier semble concerner l'affaire {found} alors que l'affaire sélectionnée est {sel}.\n\nLe joindre quand même à l'affaire {sel} ?",
        "replace_q": "Un fichier est déjà joint. Voulez-vous le remplacer ?",
        "remove_q": "Retirer ce fichier de l'affaire ?",
        "pick_file": "Choisir le fichier", "detected": "L'affaire {c} a été reconnue dans le fichier. Est-ce la bonne ?",
        "choose_case_title": "Choix de l'affaire", "choose_case_lbl": "Reconnaissance automatique impossible. Choisissez l'affaire :",
        "no_cases": "Aucune affaire cette année.",
        "copy_fail": "Impossible de copier le fichier dans le dossier du programme :",
        "open_err": "Impossible d'ouvrir le fichier :",
        "export_fail": "Export automatique impossible. Cette fonction nécessite Microsoft Word sous Windows.\nOuvrez le fichier dans Word, enregistrez-le en PDF puis joignez-le.\n\n{e}",
        "exported": "Le PDF a été créé et lié à l'affaire.",
        "not_pdf_word": "Ce bouton accepte uniquement les fichiers PDF ou Word.",
    },
    "en": {
        "title": "Report preparation",
        "search": "Search by case number or party name...",
        "status": "Status", "add_report": "Add expert report",
        "f_all": "All statuses", "f_deposited": "Deposited (with receipt)", "f_no_receipt": "Deposit without receipt",
        "f_pending": "Not deposited", "f_no_report": "No report attached",
        "c_case": "Case", "c_parties": "Parties", "c_report": "Report",
        "c_cover": "Cover page", "c_invoice": "Fee statement", "c_deposit": "Deposit",
        "k_report": "Expert report", "k_cover": "Cover page", "k_invoice": "Fee statement",
        "optional": "optional", "pdf_copy": "PDF",
        "word": "Word", "excel": "Excel",
        "no_file": "No file", "missing": "File not found",
        "attach": "Attach", "replace": "Replace", "open": "Open", "remove": "Remove",
        "export_pdf": "Export PDF from Word", "folder": "Case folder",
        "deposit_title": "Court registry deposit",
        "dep_ok": "Report deposited — receipt no. {n}", "dep_date": "on {d}",
        "dep_no_receipt": "A deposit date is recorded but no receipt exists in the Deposit page",
        "dep_none": "Not deposited yet", "open_receipt": "Open deposit receipt",
        "pick_case": "Select a case to see its files",
        "counts": "Cases: {a}   |   With report: {b}   |   Deposited: {c}",
        "vs": "vs", "receipt_short": "Receipt no. {n}", "no_receipt_short": "No receipt",
        "warn": "Warning", "error": "Error", "confirm": "Confirm",
        "wrong_type": "Unsuitable file type. Accepted types: {t}",
        "other_case": "This file seems to belong to case {found}, but the selected case is {sel}.\n\nAttach it to case {sel} anyway?",
        "replace_q": "A file is already attached. Replace it?",
        "remove_q": "Remove this file from the case?",
        "pick_file": "Choose the file", "detected": "Case {c} was recognised in the file. Is it the right case?",
        "choose_case_title": "Choose case", "choose_case_lbl": "Automatic detection failed. Choose the case:",
        "no_cases": "No cases this year.",
        "copy_fail": "Could not copy the file to the program folder:",
        "open_err": "Could not open the file:",
        "export_fail": "Automatic export failed. This feature requires Microsoft Word on Windows.\nOpen the file in Word, save it as PDF, then attach it.\n\n{e}",
        "exported": "The PDF was created and linked to the case.",
        "not_pdf_word": "This button only accepts PDF or Word files.",
    },
}


# ---------------------------------------------------------------------------
# أدوات: قراءة نص الملف والتعرّف على رقم القضية (اقتراح يؤكّده المستخدم دائماً)
# ---------------------------------------------------------------------------
_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def _western(s):
    return str(s).translate(_DIGITS)


def case_key(number):
    """مفتاح مرن لرقم القضية: يتجاهل الأصفار الزائدة والمسافات وترتيب الجزأين
    (00959/24 و 959 / 24 و 24/00959 تُعدّ نفس القضية)."""
    tokens = re.findall(r"\d+", _western(number))
    return tuple(sorted(str(int(t)) for t in tokens)) if tokens else None


def extract_text(path, max_pages=4):
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext == ".docx":
            with zipfile.ZipFile(path) as z:
                xml = z.read("word/document.xml").decode("utf8", "ignore")
            xml = re.sub(r"</w:p>", "\n", xml)
            return re.sub(r"<[^>]+>", "", xml)
        if ext == ".pdf":
            for mod in ("pypdf", "PyPDF2"):
                try:
                    lib = __import__(mod)
                except ImportError:
                    continue
                reader = lib.PdfReader(path)
                return "\n".join((p.extract_text() or "") for p in reader.pages[:max_pages])
            try:
                import fitz  # PyMuPDF
                with fitz.open(path) as doc:
                    return "\n".join(doc[i].get_text() for i in range(min(max_pages, len(doc))))
            except ImportError:
                pass
    except Exception:
        pass
    return ""


def detect_cases(path, case_numbers):
    """أرقام القضايا المعروفة التي يظهر رقمها داخل الملف (قائمة قد تكون فارغة)."""
    text = _western(extract_text(path))
    if not text:
        return []
    found = {case_key(m) for m in re.findall(r"\d+\s*/\s*\d+", text)}
    compact = re.sub(r"\s+", "", text)
    result = []
    for n in case_numbers:
        k = case_key(n)
        if not k or n in result:
            continue
        plain = _western(n).strip()
        if k in found or ("/" not in plain and len(plain) >= 5 and plain in compact):
            result.append(n)
    return result


def _safe_name(text):
    cleaned = re.sub(r'[\\/:*?"<>|]+', "_", str(text)).strip().strip(".")
    return cleaned or "_"


def _open_path(path):
    import safe_open
    safe_open.open_path(path)


def _normalize_records(raw):
    """يحوّل السجلات المحفوظة (القديمة والجديدة) إلى {رقم القضية: {kind: {edit, pdf}}}."""
    result = {}
    for rec in raw if isinstance(raw, list) else []:
        case = str(rec.get("case", "") or "").strip()
        if not case:
            continue
        docs = result.setdefault(case, {k: {"edit": "", "pdf": ""} for k, *_ in KINDS})
        new_docs = rec.get("docs")
        for kind, *_ in KINDS:
            if isinstance(new_docs, dict) and isinstance(new_docs.get(kind), dict):
                for slot in ("edit", "pdf"):
                    if new_docs[kind].get(slot):
                        docs[kind][slot] = new_docs[kind][slot]
            else:  # صيغة قديمة: مسار واحد لكل نوع
                p = rec.get(kind) or ""
                if p:
                    docs[kind]["pdf" if p.lower().endswith(".pdf") else "edit"] = p
    return result


class ReportFilesPage(QWidget):
    def __init__(self, case_page):
        super().__init__()
        self.case_page = case_page
        self.records = {}          # case_number -> {kind: {edit, pdf}}
        self.cases = []            # قضايا السنة الحالية
        self.receipts = {}         # case_number -> آخر وصل "إيداع تقرير الخبرة"
        self.selected_case = None
        self.lang = self._saved_language()

        self.setStyleSheet("background-color: #f8f9ff;")
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 18, 20, 14)
        root.setSpacing(10)

        self.title_lbl = QLabel()
        self.title_lbl.setFont(QFont("Segoe UI", 16, QFont.Bold))
        self.title_lbl.setStyleSheet("color:#4338ca; background:transparent;")
        root.addWidget(self.title_lbl)

        # ---- شريط الأدوات ----
        tools = QHBoxLayout()
        tools.setSpacing(8)
        self.search_bar = QLineEdit()
        self.search_bar.setMinimumHeight(34)
        self.search_bar.textChanged.connect(self.refresh_table)
        tools.addWidget(self.search_bar, stretch=1)

        self.status_lbl = QLabel()
        self.status_lbl.setStyleSheet("color:#1f2347; font-weight:bold; background:transparent;")
        tools.addWidget(self.status_lbl)
        self.status_combo = QComboBox()
        self.status_combo.setMinimumHeight(34)
        self.status_combo.setMinimumWidth(190)
        self.status_combo.currentIndexChanged.connect(self.refresh_table)
        tools.addWidget(self.status_combo)

        self.add_btn = QPushButton()
        self.add_btn.setIcon(qta.icon("fa5s.file-import", color="white"))
        self.add_btn.setMinimumHeight(34)
        self.add_btn.setStyleSheet(
            "QPushButton{background:#128456;color:white;padding:0 16px;border-radius:6px;font-weight:bold;}"
            "QPushButton:hover{background:#0f7a52;}")
        self.add_btn.clicked.connect(self.add_report_smart)
        tools.addWidget(self.add_btn)
        root.addLayout(tools)

        # ---- الجدول + لوحة التفاصيل ----
        self.splitter = QSplitter(Qt.Horizontal)
        self.splitter.setChildrenCollapsible(False)

        self.table = QTableWidget(0, 6)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.setStyleSheet("""
            QTableWidget { background: white; alternate-background-color: #f1f2ff;
                           gridline-color: #eef0ff; border: 1px solid #e4e7f7; font-size: 10.5pt; }
            QTableWidget::item { padding: 4px; }
            QTableWidget::item:selected { background-color: #5a4ee3; color: white; }
            QHeaderView::section { background-color: #4338ca; color: white; padding: 7px;
                                   border: none; font-weight: bold; }
        """)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.Stretch)
        for c in (2, 3, 4):
            header.setSectionResizeMode(c, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(5, QHeaderView.ResizeToContents)
        self.table.itemSelectionChanged.connect(self._on_row_selected)
        self.table.cellDoubleClicked.connect(self._on_cell_double_clicked)
        self.splitter.addWidget(self.table)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setMinimumWidth(440)
        self.scroll.setStyleSheet("QScrollArea{background:transparent;border:none;}")
        self.splitter.addWidget(self.scroll)
        self.splitter.setStretchFactor(0, 3)
        self.splitter.setStretchFactor(1, 2)
        root.addWidget(self.splitter, stretch=1)

        self.counts_lbl = QLabel()
        self.counts_lbl.setStyleSheet("color:#5b6485; background:transparent;")
        root.addWidget(self.counts_lbl)

        self.apply_language(self.lang)
        self.reload()

    # ------------------------------------------------------------------
    @staticmethod
    def _saved_language():
        try:
            from settings_page import AppSettings
            return AppSettings().get_language_code()
        except Exception:
            return "ar"

    def _t(self, key, **kw):
        text = TEXTS.get(self.lang, TEXTS["ar"]).get(key, TEXTS["ar"].get(key, key))
        return text.format(**kw) if kw else text

    def apply_language(self, lang_code):
        self.lang = lang_code if lang_code in TEXTS else "ar"
        self.title_lbl.setText(self._t("title"))
        self.search_bar.setPlaceholderText(self._t("search"))
        self.status_lbl.setText(self._t("status") + " :")
        self.add_btn.setText(self._t("add_report"))
        self.table.setHorizontalHeaderLabels([
            self._t("c_case"), self._t("c_parties"), self._t("c_report"),
            self._t("c_cover"), self._t("c_invoice"), self._t("c_deposit")])
        previous = self.status_combo.currentData()
        self.status_combo.blockSignals(True)
        self.status_combo.clear()
        for key in ("all", "deposited", "no_receipt", "pending", "no_report"):
            fkey = {"all": "f_all", "deposited": "f_deposited", "no_receipt": "f_no_receipt",
                    "pending": "f_pending", "no_report": "f_no_report"}[key]
            self.status_combo.addItem(self._t(fkey), key)
        idx = self.status_combo.findData(previous) if previous else 0
        self.status_combo.setCurrentIndex(idx if idx >= 0 else 0)
        self.status_combo.blockSignals(False)
        if hasattr(self, "table"):
            self.refresh_table()

    # ------------------------------------------------------------------
    def showEvent(self, event):
        self.reload()
        super().showEvent(event)

    def reload(self):
        """تُستدعى عند تفعيل التبويب: قراءة القضايا والملفات ووصولات الإيداع من جديد."""
        try:
            self.cases = [c for c in storage.load_cases() if str(c.get("case_number", "")).strip()]
        except Exception:
            self.cases = []
        try:
            self.records = _normalize_records(storage.load_reports())
        except Exception:
            self.records = {}
        self.receipts = {}
        try:
            for r in storage.load_receipts():
                if r.get("type") == "report_deposit":
                    self.receipts[str(r.get("case_number", "")).strip()] = r
        except Exception:
            pass
        self.refresh_table()

    # للتوافق مع الاستدعاءات القديمة
    def load_reports_data(self):
        self.reload()

    def update_case_list(self):
        self.reload()

    def _save(self):
        out = []
        for case, docs in self.records.items():
            if not any(docs[k][s] for k, *_ in KINDS for s in ("edit", "pdf")):
                continue
            rec = {"case": case, "docs": docs}
            for kind, *_ in KINDS:  # مفاتيح قديمة للتوافق الخلفي
                rec[kind] = docs[kind]["pdf"] or docs[kind]["edit"]
            out.append(rec)
        storage.save_reports(out)

    def _docs(self, case):
        return self.records.setdefault(case, {k: {"edit": "", "pdf": ""} for k, *_ in KINDS})

    # ------------------------------------------------------------------
    # حالة الإيداع: تعتمد على وصل "إيداع تقرير الخبرة" في صفحة الإيداع
    # ------------------------------------------------------------------
    def _deposit_state(self, case):
        number = str(case.get("case_number", "")).strip()
        if number in self.receipts:
            return "receipt"
        if str(case.get("submission_date", "") or "").strip():
            return "no_receipt"
        return "pending"

    def _has_report(self, number):
        d = self.records.get(number)
        return bool(d and (d["report"]["edit"] or d["report"]["pdf"]))

    # ------------------------------------------------------------------
    def refresh_table(self, *_):
        if not hasattr(self, "table"):
            return
        query = self.search_bar.text().strip().lower()
        status = self.status_combo.currentData() or "all"
        keep = self.selected_case
        vs = self._t("vs")

        rows = []
        for c in self.cases:
            number = str(c.get("case_number", "")).strip()
            state = self._deposit_state(c)
            if status == "deposited" and state != "receipt":
                continue
            if status == "no_receipt" and state != "no_receipt":
                continue
            if status == "pending" and state != "pending":
                continue
            if status == "no_report" and self._has_report(number):
                continue
            hay = " ".join(str(c.get(k, "") or "") for k in ("case_number", "plaintiff", "defendant", "court")).lower()
            docs = self.records.get(number, {})
            for k, *_ in KINDS:
                for s in ("edit", "pdf"):
                    p = docs.get(k, {}).get(s, "")
                    if p:
                        hay += " " + os.path.basename(p).lower()
            if query and query not in hay:
                continue
            rows.append((c, number, state))

        self.table.blockSignals(True)
        self.table.setRowCount(0)
        for c, number, state in rows:
            r = self.table.rowCount()
            self.table.insertRow(r)
            it = QTableWidgetItem(number)
            it.setData(Qt.UserRole, number)
            it.setFont(QFont("Segoe UI", 10, QFont.Bold))
            self.table.setItem(r, 0, it)
            parties = f"{c.get('plaintiff') or '؟'}  {vs}  {c.get('defendant') or '؟'}"
            self.table.setItem(r, 1, QTableWidgetItem(parties))
            self.table.item(r, 1).setToolTip(parties)

            docs = self.records.get(number)
            for col, (kind, *_rest) in enumerate(KINDS, start=2):
                tags = []
                if docs:
                    if docs[kind]["pdf"]:
                        tags.append("PDF")
                    if docs[kind]["edit"]:
                        tags.append(self._t("excel" if kind == "invoice" else "word"))
                cell = QTableWidgetItem(" + ".join(tags) if tags else "—")
                cell.setTextAlignment(Qt.AlignCenter)
                cell.setForeground(QColor("#0f7a52" if tags else "#bcc3e4"))
                self.table.setItem(r, col, cell)

            rec = self.receipts.get(number)
            if state == "receipt":
                text, color = "✔ " + self._t("receipt_short", n=rec.get("receipt_number", "")), "#0f7a52"
                tip = self._t("dep_date", d=rec.get("date", ""))
            elif state == "no_receipt":
                text, color, tip = "⚠ " + self._t("no_receipt_short"), "#8a4b00", self._t("dep_no_receipt")
            else:
                text, color, tip = "—", "#bcc3e4", self._t("dep_none")
            dep = QTableWidgetItem(text)
            dep.setTextAlignment(Qt.AlignCenter)
            dep.setForeground(QColor(color))
            dep.setToolTip(tip)
            self.table.setItem(r, 5, dep)
        self.table.blockSignals(False)

        total = len(self.cases)
        with_report = sum(1 for c in self.cases if self._has_report(str(c.get("case_number", "")).strip()))
        deposited = sum(1 for c in self.cases if self._deposit_state(c) == "receipt")
        self.counts_lbl.setText(self._t("counts", a=total, b=with_report, c=deposited))

        # أعِد تحديد القضية السابقة إن بقيت ظاهرة
        target = -1
        for r in range(self.table.rowCount()):
            if self.table.item(r, 0).data(Qt.UserRole) == keep:
                target = r
                break
        if target >= 0:
            self.table.blockSignals(True)
            self.table.selectRow(target)
            self.table.blockSignals(False)
            self.selected_case = keep
        else:
            self.selected_case = None
        self.build_panel()

    def _on_row_selected(self):
        row = self.table.currentRow()
        item = self.table.item(row, 0) if row >= 0 else None
        self.selected_case = item.data(Qt.UserRole) if item else None
        self.build_panel()

    def _on_cell_double_clicked(self, row, col):
        number = self.table.item(row, 0).data(Qt.UserRole)
        if col in (2, 3, 4):
            kind = KINDS[col - 2][0]
            d = self.records.get(number, {}).get(kind, {})
            self._open_file(d.get("pdf") or d.get("edit") or "")
        elif col == 5:
            self._open_receipt(number)

    def _select_case(self, number):
        self.search_bar.blockSignals(True)
        self.search_bar.clear()
        self.search_bar.blockSignals(False)
        self.status_combo.blockSignals(True)
        self.status_combo.setCurrentIndex(0)
        self.status_combo.blockSignals(False)
        self.selected_case = number
        self.refresh_table()
        for r in range(self.table.rowCount()):
            if self.table.item(r, 0).data(Qt.UserRole) == number:
                self.table.selectRow(r)
                self.table.scrollToItem(self.table.item(r, 0))
                break

    # ------------------------------------------------------------------
    # لوحة تفاصيل القضية المحددة
    # ------------------------------------------------------------------
    def _card(self):
        card = QFrame()
        card.setObjectName("card")
        card.setStyleSheet("QFrame#card{background:white;border:1px solid #eef0ff;border-radius:10px;}"
                           "QLabel{background:transparent;}")
        lay = QVBoxLayout(card)
        lay.setContentsMargins(14, 10, 14, 12)
        lay.setSpacing(8)
        return card, lay

    @staticmethod
    def _icon_btn(icon, color, tip, enabled=True):
        b = QPushButton()
        b.setIcon(qta.icon(icon, color=color))
        b.setToolTip(tip)
        b.setFixedSize(32, 30)
        b.setEnabled(enabled)
        b.setStyleSheet("QPushButton{background:#f8f9ff;border:1px solid #e4e7f7;border-radius:6px;}"
                        "QPushButton:hover{background:#eef0ff;}QPushButton:disabled{background:#f8f9ff;}")
        return b

    def build_panel(self):
        holder = QWidget()
        lay = QVBoxLayout(holder)
        lay.setContentsMargins(10, 0, 0, 0)
        lay.setSpacing(10)
        self.scroll.setWidget(holder)

        case = next((c for c in self.cases if str(c.get("case_number", "")).strip() == self.selected_case), None)
        if not case:
            hint = QLabel(self._t("pick_case"))
            hint.setAlignment(Qt.AlignCenter)
            hint.setWordWrap(True)
            hint.setStyleSheet("color:#9aa3c7; font-size:11pt; padding:40px; background:transparent;")
            lay.addWidget(hint)
            lay.addStretch()
            return

        number = str(case.get("case_number", "")).strip()

        # ---- ترويسة القضية ----
        card, cl = self._card()
        top = QHBoxLayout()
        title = QLabel(f"{number}")
        title.setFont(QFont("Segoe UI", 15, QFont.Bold))
        title.setStyleSheet("color:#4338ca;")
        top.addWidget(title)
        top.addStretch()
        folder_btn = QPushButton(self._t("folder"))
        folder_btn.setIcon(qta.icon("fa5s.folder-open", color="#4338ca"))
        folder_btn.setStyleSheet("QPushButton{background:#f8f9ff;border:1px solid #e4e7f7;border-radius:6px;padding:5px 10px;}"
                                 "QPushButton:hover{background:#eef0ff;}")
        folder_btn.clicked.connect(lambda: self._open_case_folder(number))
        top.addWidget(folder_btn)
        cl.addLayout(top)
        parties = QLabel(f"{case.get('plaintiff') or '؟'}  {self._t('vs')}  {case.get('defendant') or '؟'}")
        parties.setWordWrap(True)
        parties.setStyleSheet("color:#5b6485;")
        cl.addWidget(parties)
        if case.get("court"):
            court = QLabel(str(case.get("court")))
            court.setStyleSheet("color:#9aa3c7;")
            cl.addWidget(court)
        lay.addWidget(card)

        # ---- بطاقات الملفات ----
        docs = self._docs(number)
        for kind, icon, color, edit_type, optional in KINDS:
            card, cl = self._card()
            head = QHBoxLayout()
            ic = QLabel()
            ic.setPixmap(qta.icon(icon, color=color).pixmap(18, 18))
            head.addWidget(ic)
            name = QLabel(self._t("k_" + kind))
            name.setStyleSheet(f"color:{color}; font-size:11.5pt; font-weight:bold;")
            head.addWidget(name)
            if optional:
                opt = QLabel(f"({self._t('optional')})")
                opt.setStyleSheet("color:#9aa3c7; font-size:9pt;")
                head.addWidget(opt)
            head.addStretch()
            cl.addLayout(head)
            line = QFrame()
            line.setFixedHeight(1)
            line.setStyleSheet("background:#f1f2ff;border:none;")
            cl.addWidget(line)
            cl.addLayout(self._file_row(number, kind, "edit", self._t(edit_type), edit_type))
            cl.addLayout(self._file_row(number, kind, "pdf", self._t("pdf_copy"), "pdf"))
            lay.addWidget(card)

        # ---- بطاقة الإيداع ----
        card, cl = self._card()
        head = QHBoxLayout()
        ic = QLabel()
        ic.setPixmap(qta.icon("fa5s.stamp", color="#d03a50").pixmap(18, 18))
        head.addWidget(ic)
        t = QLabel(self._t("deposit_title"))
        t.setStyleSheet("color:#d03a50; font-size:11.5pt; font-weight:bold;")
        head.addWidget(t)
        head.addStretch()
        cl.addLayout(head)
        state = self._deposit_state(case)
        rec = self.receipts.get(number)
        if state == "receipt":
            msg = QLabel("✔ " + self._t("dep_ok", n=rec.get("receipt_number", "")) + "  " +
                         self._t("dep_date", d=rec.get("date", "")))
            msg.setStyleSheet("color:#0f7a52; font-weight:bold;")
        elif state == "no_receipt":
            msg = QLabel("⚠ " + self._t("dep_no_receipt"))
            msg.setStyleSheet("color:#8a4b00;")
        else:
            msg = QLabel(self._t("dep_none"))
            msg.setStyleSheet("color:#5b6485;")
        msg.setWordWrap(True)
        cl.addWidget(msg)
        if rec and rec.get("scan_path"):
            b = QPushButton(self._t("open_receipt"))
            b.setIcon(qta.icon("fa5s.receipt", color="white"))
            b.setStyleSheet("QPushButton{background:#5a4ee3;color:white;border-radius:6px;padding:7px 12px;}"
                            "QPushButton:hover{background:#5a4ee3;}")
            b.clicked.connect(lambda: self._open_receipt(number))
            cl.addWidget(b, alignment=Qt.AlignLeading)
        lay.addWidget(card)
        lay.addStretch()

    def _file_row(self, case, kind, slot, label, ftype):
        path = self._docs(case)[kind][slot]
        row = QHBoxLayout()
        row.setSpacing(6)
        tag = QLabel(label)
        tag.setFixedWidth(58)
        tag.setStyleSheet("font-weight:bold; color:#5b6485;")
        row.addWidget(tag)

        exists = bool(path) and os.path.exists(path)
        if path:
            text = os.path.basename(path)
            style = "color:#1f2347;" if exists else "color:#d03a50;"
            tip = path if exists else self._t("missing")
        else:
            text, style, tip = self._t("no_file"), "color:#bcc3e4;", ""
        name = QLabel()
        name.setStyleSheet(style)
        name.setToolTip(tip)
        name.setMinimumWidth(80)
        fm = QFontMetrics(name.font())
        name.setText(fm.elidedText(text, Qt.ElideMiddle, 190))
        row.addWidget(name, stretch=1)

        attach = QPushButton(self._t("replace" if path else "attach"))
        attach.setIcon(qta.icon("fa5s.upload", color="#4338ca"))
        attach.setFixedHeight(30)
        attach.setStyleSheet("QPushButton{background:#f1f2ff;border:1px solid #d0d6ee;border-radius:6px;padding:0 10px;}"
                             "QPushButton:hover{background:#eef0ff;}")
        attach.clicked.connect(lambda: self.attach_file(case, kind, slot, ftype))
        row.addWidget(attach)

        open_b = self._icon_btn("fa5s.external-link-alt", "#5a4ee3", self._t("open"), enabled=exists)
        open_b.clicked.connect(lambda: self._open_file(path))
        row.addWidget(open_b)

        if slot == "edit" and ftype == "word":
            exp = self._icon_btn("fa5s.file-pdf", "#d03a50", self._t("export_pdf"), enabled=exists)
            exp.clicked.connect(lambda: self.export_pdf(case, kind))
            row.addWidget(exp)

        rm = self._icon_btn("fa5s.trash", "#d03a50", self._t("remove"), enabled=bool(path))
        rm.clicked.connect(lambda: self.remove_file(case, kind, slot))
        row.addWidget(rm)
        return row

    # ------------------------------------------------------------------
    # الملفات: نسخ إلى مجلد القضية، فتح، إزالة، تصدير
    # ------------------------------------------------------------------
    def _base_dir(self):
        return os.path.join(os.path.dirname(storage._year_path("reports.json")), "expertise_files")

    def _case_dir(self, case):
        path = os.path.join(self._base_dir(), _safe_name(case))
        os.makedirs(path, exist_ok=True)
        return path

    @staticmethod
    def _unique(folder, filename):
        dest = os.path.join(folder, filename)
        stem, ext = os.path.splitext(filename)
        n = 2
        while os.path.exists(dest):
            dest = os.path.join(folder, f"{stem} ({n}){ext}")
            n += 1
        return dest

    def _is_managed(self, path):
        try:
            base = os.path.abspath(self._base_dir())
            return os.path.commonpath([base, os.path.abspath(path)]) == base
        except Exception:
            return False

    def _open_file(self, path):
        if not path or not os.path.exists(path):
            show_warning(self, self._t("warn"), self._t("missing"))
            return
        try:
            _open_path(path)
        except Exception as e:
            show_warning(self, self._t("error"), f"{self._t('open_err')}\n{e}")

    def _open_receipt(self, case):
        rec = self.receipts.get(case)
        path = (rec or {}).get("scan_path", "")
        if path:
            self._open_file(path)

    def _open_case_folder(self, case):
        try:
            _open_path(self._case_dir(case))
        except Exception as e:
            show_warning(self, self._t("error"), f"{self._t('open_err')}\n{e}")

    def _known_numbers(self):
        return [str(c.get("case_number", "")).strip() for c in self.cases]

    def _store_file(self, case, kind, slot, source):
        """ينسخ الملف إلى مجلد القضية ويسجّله؛ يُرجع True عند النجاح."""
        try:
            dest = self._unique(self._case_dir(case), os.path.basename(source))
            shutil.copy2(source, dest)
        except Exception as e:
            show_warning(self, self._t("error"), f"{self._t('copy_fail')}\n{e}")
            return False
        docs = self._docs(case)
        old = docs[kind][slot]
        docs[kind][slot] = dest
        if old and old != dest and self._is_managed(old) and os.path.exists(old):
            try:
                os.remove(old)
            except Exception:
                pass
        self._save()
        return True

    def attach_file(self, case, kind, slot, ftype):
        exts = EXTS[ftype]
        pattern = " ".join("*" + e for e in exts)
        source, _ = QFileDialog.getOpenFileName(self, self._t("pick_file"), "", f"({pattern})")
        if not source:
            return
        if not source.lower().endswith(exts):
            show_warning(self, self._t("warn"), self._t("wrong_type", t=", ".join(exts)))
            return

        # حماية من الخطأ: هل يخص الملف قضية أخرى؟
        found = detect_cases(source, self._known_numbers())
        if found and case not in found:
            reply = show_question(
                self, self._t("confirm"), self._t("other_case", found="، ".join(found), sel=case))
            if reply != QMessageBox.Yes:
                return

        if self._docs(case)[kind][slot]:
            if show_question(self, self._t("confirm"), self._t("replace_q")) != QMessageBox.Yes:
                return
        if self._store_file(case, kind, slot, source):
            self.refresh_table()

    def add_report_smart(self):
        """إضافة ملف خبرة (PDF أو Word) مع التعرّف التلقائي على القضية من محتواه."""
        if not self.cases:
            show_info(self, self._t("warn"), self._t("no_cases"))
            return
        source, _ = QFileDialog.getOpenFileName(self, self._t("pick_file"), "", "(*.pdf *.docx *.doc)")
        if not source:
            return
        low = source.lower()
        slot = "pdf" if low.endswith(".pdf") else ("edit" if low.endswith((".docx", ".doc")) else None)
        if slot is None:
            show_warning(self, self._t("warn"), self._t("not_pdf_word"))
            return

        numbers = self._known_numbers()
        found = detect_cases(source, numbers)
        case = None
        if len(found) == 1:
            if show_question(self, self._t("confirm"), self._t("detected", c=found[0])) == QMessageBox.Yes:
                case = found[0]
        options = found if len(found) > 1 else numbers
        if case is None:
            vs = self._t("vs")
            labels, mapping = [], {}
            for c in self.cases:
                n = str(c.get("case_number", "")).strip()
                if n in options:
                    lab = f"{n}   —   {c.get('plaintiff') or '؟'} {vs} {c.get('defendant') or '؟'}"
                    labels.append(lab)
                    mapping[lab] = n
            choice, ok = QInputDialog.getItem(self, self._t("choose_case_title"), self._t("choose_case_lbl"),
                                              labels, 0, False)
            if not ok:
                return
            case = mapping[choice]

        if self._docs(case)["report"][slot]:
            if show_question(self, self._t("confirm"), self._t("replace_q")) != QMessageBox.Yes:
                return
        if self._store_file(case, "report", slot, source):
            self._select_case(case)

    def remove_file(self, case, kind, slot):
        path = self._docs(case)[kind][slot]
        if not path:
            return
        if show_question(self, self._t("confirm"), self._t("remove_q")) != QMessageBox.Yes:
            return
        if self._is_managed(path) and os.path.exists(path):
            try:
                os.remove(path)
            except Exception:
                pass
        self._docs(case)[kind][slot] = ""
        self._save()
        self.refresh_table()

    def export_pdf(self, case, kind):
        """تصدير ملف Word المحفوظ إلى PDF (يحتاج Microsoft Word على Windows) ثم ربطه بالقضية."""
        src = self._docs(case)[kind]["edit"]
        if not src or not os.path.exists(src):
            return
        pdf_path = self._unique(os.path.dirname(src), os.path.splitext(os.path.basename(src))[0] + ".pdf")
        word = None
        try:
            import win32com.client
            word = win32com.client.DispatchEx("Word.Application")
            word.Visible = False
            doc = word.Documents.Open(os.path.abspath(src), ReadOnly=True)
            doc.SaveAs2(os.path.abspath(pdf_path), FileFormat=17)
            doc.Close(False)
        except Exception as e:
            show_warning(self, self._t("error"), self._t("export_fail", e=e))
            return
        finally:
            try:
                if word is not None:
                    word.Quit()
            except Exception:
                pass

        docs = self._docs(case)
        old = docs[kind]["pdf"]
        docs[kind]["pdf"] = pdf_path
        if old and old != pdf_path and self._is_managed(old) and os.path.exists(old):
            try:
                os.remove(old)
            except Exception:
                pass
        self._save()
        self.refresh_table()
        show_info(self, self._t("confirm"), self._t("exported"))
