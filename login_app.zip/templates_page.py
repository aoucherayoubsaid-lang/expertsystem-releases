# -*- coding: utf-8 -*-
"""نافذة «نماذجي»: يرفع الخبير نموذج الغلاف ونموذج التقرير (Word) ويتحقق من علاماتهما.

    from templates_page import TemplatesDialog, get_template_paths
    TemplatesDialog(self).exec_()
"""
import json
import os
import shutil

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (QDialog, QFileDialog, QHBoxLayout, QLabel, QPlainTextEdit,
                             QPushButton, QVBoxLayout)

import storage
import word_cover
from msgbox_ltr import show_warning

_KINDS = (("cover", "نموذج صفحة الغلاف"), ("report", "نموذج تقرير الخبرة"))


def _cfg_path():
    return os.path.join(storage.APP_DATA_DIR, "my_templates.json")


def _load():
    try:
        with open(_cfg_path(), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def get_template_paths():
    """{'cover': مسار أو '', 'report': مسار أو ''} للملفات الموجودة فعلاً."""
    cfg = _load()
    return {k: (cfg.get(k) if cfg.get(k) and os.path.exists(cfg.get(k)) else "") for k, _ in _KINDS}


def check_template(kind, path):
    """يرجع نصاً يشرح حالة العلامات في النموذج."""
    found = word_cover.list_placeholders(path)
    known = set(word_cover.known_keys())
    if kind == "report":
        known.add("report_body")
    ok = sorted(found & known)
    bad = sorted(found - known)
    lines = []
    if ok:
        lines.append("✔ علامات صحيحة: " + "  ".join("{{%s}}" % k for k in ok))
    if bad:
        lines.append("✘ علامات غير معروفة (راجع كتابتها): " + "  ".join("{{%s}}" % k for k in bad))
    if kind == "report" and "report_body" not in found:
        lines.append("✘ ينقص {{report_body}} في فقرة مستقلة، وهو مكان كتابة محتوى التقرير.")
    if not found:
        lines.append("لم أجد أي علامة {{...}} في النموذج.")
    return "\n".join(lines)


class TemplatesDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("نماذجي")
        self.setLayoutDirection(Qt.RightToLeft)
        self.resize(720, 520)
        self.cfg = _load()
        self.labels = {}
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("ارفع نموذجك (Word بصيغة docx) بعد وضع العلامات فيه، مثل {{case_number}} و{{court}}.\n"
                             "في نموذج التقرير ضع {{report_body}} في فقرة مستقلة مكان المحتوى."))
        for kind, title in _KINDS:
            row = QHBoxLayout()
            row.addWidget(QLabel(title + " :"))
            lab = QLabel(os.path.basename(self.cfg.get(kind, "")) or "— لم يُرفع —")
            self.labels[kind] = lab
            row.addWidget(lab, 1)
            b1 = QPushButton("اختيار...")
            b1.clicked.connect(lambda _=False, k=kind: self._pick(k))
            b2 = QPushButton("تحقق")
            b2.clicked.connect(lambda _=False, k=kind: self._check(k))
            row.addWidget(b1)
            row.addWidget(b2)
            lay.addLayout(row)
        self.out = QPlainTextEdit()
        self.out.setReadOnly(True)
        self.out.setPlaceholderText("نتيجة التحقق تظهر هنا")
        lay.addWidget(self.out, 1)
        lay.addWidget(QLabel("العلامات المتاحة للنسخ:"))
        keys = QPlainTextEdit()
        keys.setReadOnly(True)
        keys.setMaximumHeight(110)
        try:
            keys.setPlainText("  ".join("{{%s}}" % k for k in sorted(word_cover.known_keys())))
        except Exception:
            keys.setPlainText("(تعذّر قراءة الحقول)")
        lay.addWidget(keys)

    def _pick(self, kind):
        path, _ = QFileDialog.getOpenFileName(self, "اختر النموذج", "", "Word (*.docx)")
        if not path:
            return
        if not path.lower().endswith(".docx"):
            show_warning(self, "نماذجي", "يجب أن يكون الملف بصيغة docx. احفظه من Word بصيغة (مستند Word).")
            return
        folder = os.path.join(storage.APP_DATA_DIR, "templates")
        os.makedirs(folder, exist_ok=True)
        dest = os.path.join(folder, kind + ".docx")
        shutil.copy2(path, dest)              # نسخة ثابتة حتى لو حُذف الأصل
        self.cfg[kind] = dest
        with open(_cfg_path(), "w", encoding="utf-8") as f:
            json.dump(self.cfg, f, ensure_ascii=False)
        self.labels[kind].setText(os.path.basename(path))
        self._check(kind)

    def _check(self, kind):
        path = self.cfg.get(kind, "")
        if not path or not os.path.exists(path):
            self.out.setPlainText("لم يُرفع هذا النموذج بعد.")
            return
        try:
            self.out.setPlainText(check_template(kind, path))
        except Exception as e:
            self.out.setPlainText("تعذّر قراءة الملف: %s" % e)
