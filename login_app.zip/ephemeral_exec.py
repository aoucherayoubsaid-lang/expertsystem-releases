# -*- coding: utf-8 -*-
"""تجريبي -- توضيحي بالدرجة الأولى، غير مُفعَّل تلقائياً في أي مكان من البرنامج.

يوضّح آلية "فك التشفير وقت الاستدعاء فقط ثم المحو" على مستوى دالة واحدة (أدق حبيبياً من
bundle_loader.py الذي يفك الوحدة كاملة مرة عند أول استيراد ويُبقيها في الذاكرة طوال التشغيل).

اقرأ هذا قبل استعماله -- حدود حقيقية في CPython لا يتجاوزها أي كود بايثون صرف:
1. marshal.loads() يقبل bytearray القابل للمحو (لا ينسخه إلى bytes منفصلة لا يمكن التحكم
   بها)، لكن الكائنات الناتجة داخل كائن الكود (code object) -- النصوص الثابتة والأسماء في
   co_consts/co_names -- تصبح كائنات بايثون عادية بعد compile/marshal، وبايثون قد يُخزّنها
   مُدخَلة (interned) في جداول داخلية خارج سيطرتك. محو المخزن المؤقت (buffer) الأصلي بعد
   الفك لا يمحو هذه النسخ الثانوية -- لا توجد طريقة بايثون صرفة لضمان ذلك.
2. ما تربحه فعلياً هنا: تقليل "نافذة التعرّض" لنص الكود المصدري بالكامل (bytecode الدالة)
   من "طوال مدة التشغيل" (bundle_loader الحالي) إلى "فقط أثناء التنفيذ الفعلي + جزء من
   الثانية بعده" -- فائدة حقيقية لكن جزئية، وليست "تشفيراً متعدد الأشكال" بالمعنى الكامل
   الذي يصفه أدوات مثل Themida (تلك تعمل على مستوى تعليمات المعالج مباشرة، لا بايثون).
3. الكلفة: فك وتجميع (compile/marshal) في كل استدعاء -- غير مناسب لدالة تُستدعى بكثرة
   (حلقة أو واجهة مستخدم)، مناسب فقط لعملية نادرة وحسّاسة جداً (مثل التحقق من مفتاح ترخيص
   مرة واحدة عند بدء التشغيل).

الاستعمال (اختياري، لم يُربَط بأي مكان في البرنامج عمداً -- قرّر أنت أين يستحق الأمر):
    key = ...                                  # 32 بايت، من نفس آلية bundle_loader._module_key
    nonce_ct = <bytes المشفّرة>                  # nonce (12) + ciphertext، كما يُنتجها AESGCM
    result = run_ephemeral(key, nonce_ct, aad=b"...", func_name="check", args=(x, y))
"""
import ctypes
import gc
import marshal

from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def run_ephemeral(key, nonce_ct, aad, func_name, args=(), kwargs=None):
    """يفك دالة واحدة مشفّرة، يُنفّذها، يمحو مخزنها المؤقت فوراً، ثم يُرجع ناتجها.
    key: 32 بايت. nonce_ct: nonce(12)+ciphertext كما ينتجها AESGCM.encrypt.
    aad: نفس AAD المستعمل عند التشفير (انظر tools/build_bundle.py للنمط المرجعي)."""
    kwargs = kwargs or {}
    buf = bytearray(AESGCM(key).decrypt(nonce_ct[:12], nonce_ct[12:], aad))   # نص بايثون صرف مفكوك
    try:
        code = marshal.loads(bytes(buf))      # bytes() هنا نسخة للقراءة فقط يتطلبها marshal داخلياً
        ns = {}
        exec(code, ns)                        # ينفّذ تعريف الدالة داخل namespace معزول مؤقت
        return ns[func_name](*args, **kwargs)
    finally:
        # محو ما نملك التحكم الفعلي به: المخزن المؤقت الأصلي (bytearray قابل للكتابة فوقه).
        if buf:
            ctypes.memset((ctypes.c_char * len(buf)).from_buffer(buf), 0, len(buf))
        del buf
        gc.collect()      # لا يضمن محو الذاكرة الفعلي، فقط يُسرّع تحرير المراجع غير المستعملة
