# -*- coding: utf-8 -*-
"""عميل الذكاء الاصطناعي: يتصل بوسيط Cloudflare (expert-ai) وليس بـ Gemini مباشرة.
بايثون 3.8 + مكتبات المشروع الحالية فقط (urllib + certifi). لا يحتوي أي مفتاح سري.

اختبار سريع من مجلد البرنامج (بعد وضع AI_URL):
    python ai_client.py
"""
import base64
import json
import re
import ssl
import time
import urllib.error
import urllib.request

AI_URL = "https://expert-ai.aoucher-ayoubsaid.workers.dev/"   # رابط الـ Worker بدون / في الآخر

_ERRORS = {
    "no_access": "الذكاء الاصطناعي متاح للتراخيص المدفوعة المفعّلة على هذا الجهاز فقط.",
    "rate_limited": "تجاوزت الحد المسموح من الطلبات. حاول لاحقاً.",
    "upstream": "تعذّر الاتصال بخدمة الذكاء الاصطناعي. حاول لاحقاً.",
    "not_configured": "الخدمة غير مهيأة على الخادم.",
    "no_model": "اسم النموذج غير مضبوط على الخادم.",
}


class AIError(Exception):
    pass


def _ssl_context():
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def _post(path, body, timeout=120):
    import license_manager
    body = dict(body)
    body["key"] = license_manager.current_license_key() or ""
    body["machine_id"] = license_manager.machine_code()   # نفس رمز الجهاز المستعمل في التفعيل
    payload = json.dumps(body).encode("utf-8")
    for attempt in range(5):                      # إعادة محاولة عند ازدحام الخدمة أو انقطاع الشبكة
        req = urllib.request.Request(
            AI_URL.rstrip("/") + path, data=payload,
            headers={"Content-Type": "application/json", "User-Agent": "ExpertSystem/1.0"})
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=_ssl_context()) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            code, status, detail = "", 0, ""
            try:
                data = json.loads(e.read().decode("utf-8"))
                code, status = data.get("error", ""), int(data.get("status", 0) or 0)
                detail = str(data.get("detail", "") or "")[:300]
            except Exception:
                pass
            busy = (code == "upstream" and status in (429, 500, 502, 503, 504)) or e.code in (502, 503, 504)
            if busy and attempt < 4:
                time.sleep(4 * (attempt + 1))     # 4 ثم 8 ثم 12 ثم 16 ثانية
                continue
            msg = _ERRORS.get(code, "خطأ من الخادم (%s)" % e.code)
            if code == "upstream":                # تشخيص: رمز Gemini وسببه
                msg += " [Gemini %s] %s" % (status, detail)
            raise AIError(msg.strip())
        except Exception as ex:
            if attempt < 4:
                time.sleep(3 * (attempt + 1))     # 3 ثم 6 ثم 9 ثم 12 ثانية
                continue
            raise AIError("لا يوجد اتصال بالإنترنت أو الخادم غير متاح. [%s: %s]"
                          % (type(ex).__name__, str(ex)[:200]))


def generate(prompt, system=None, as_json=False, search=False):
    """يرجع نص الرد (أو نص JSON إن كان as_json=True).
    search=True: يطلب من الوسيط تفعيل البحث في الإنترنت (للتحقق من المصطلحات القانونية)؛
    الوسيط القديم يتجاهل الحقل بلا أي خطأ."""
    body = {"prompt": prompt, "json": bool(as_json)}
    if search:
        body["search"] = True
    if system:
        body["system"] = system
    return _post("/generate", body).get("text", "")


def embed(texts, is_query=False):
    """يحوّل قائمة نصوص إلى قائمة متجهات (بدفعات حتى 100 نص)."""
    out = []
    for i in range(0, len(texts), 100):
        r = _post("/embed", {"texts": texts[i:i + 100], "query": bool(is_query)})
        out.extend(r.get("vectors", []))
    return out


def ocr_images(images):
    """images: قائمة بايتات JPEG. يرجع قائمة نصوص بنفس الترتيب (نص فارغ لصفحة فشلت)."""
    out = []
    for i in range(0, len(images), 2):             # صفحتان لكل طلب: حمولة أصغر = اتصال أثبت
        batch = images[i:i + 2]
        text = _post("/ocr", {"images": [base64.b64encode(b).decode("ascii") for b in batch]}, 180).get("text", "")
        parts = re.split(r"<<<PAGE\s*(\d+)>>>", text)
        found = {}
        for k in range(1, len(parts) - 1, 2):
            found[int(parts[k])] = parts[k + 1].strip()
        if not found:
            found = {1: text.strip()}             # لم يضع النموذج الفواصل
        out.extend(found.get(j + 1, "") for j in range(len(batch)))
    return out


if __name__ == "__main__":
    # اختبار بنص وهمي فقط. لا ترسل بيانات قضايا حقيقية على الخطة المجانية.
    try:
        print("الرد:", generate("اكتب جملة واحدة قصيرة بالعربية عن المحاسبة."))
        v = embed(["مثال تجريبي"])
        print("embedding OK، طول المتجه:", len(v[0]) if v and v[0] else 0)
    except AIError as e:
        print("فشل:", e)
