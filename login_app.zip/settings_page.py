from msgbox_ltr import show_info, show_warning, show_question
import sys
import storage
from encrypted_backup import create_backup, restore_backup, BackupError
import startup_password
import password_policy
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QVBoxLayout, QHBoxLayout, QPushButton, QLineEdit,
    QComboBox, QSpinBox, QTabWidget, QFileDialog, QFormLayout, QMessageBox,
    QCheckBox, QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView,
    QDialog
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt, pyqtSignal

# ---------------------------------------------------------------------------
# الترجمة: تُستعمل لتسمية التبويبات الرئيسية في main_app.py، ولنصوص هذه
# الصفحة نفسها. لإضافة عنصر جديد قابل للترجمة: أضف مفتاحه في كل لغة هنا.
# ---------------------------------------------------------------------------
translations = {
    "ar": {
        "home": "الرئيسية", "cases": "القضايا", "parties": "الأطراف",
        "documents": "الوثائق", "minutes": "محاضر", "deposit": "الإيداع",
        "report": "إعداد التقرير", "settings": "الإعدادات",
        "planning": "التخطيط", "ai_report": "التقرير بالذكاء الاصطناعي",
    },
    "fr": {
        "home": "Accueil", "cases": "Affaires", "parties": "Parties",
        "documents": "Documents", "minutes": "Procès-verbaux", "deposit": "Dépôt",
        "report": "Rapport", "settings": "Paramètres",
        "planning": "Planning", "ai_report": "Rapport par IA",
    },
    "en": {
        "home": "Home", "cases": "Cases", "parties": "Parties",
        "documents": "Documents", "minutes": "Minutes", "deposit": "Deposit",
        "report": "Report", "settings": "Settings",
        "planning": "Planning", "ai_report": "AI report",
    },
}

LANGUAGE_LABELS = ["العربية", "Français", "English"]
LANGUAGE_CODE_BY_LABEL = {"العربية": "ar", "Français": "fr", "English": "en"}

# خطوط شائعة تدعم العربية جيداً (Arial/Tahoma/Calibri) بالإضافة لخطوط
# لاتينية كلاسيكية (Times New Roman) يطلبها بعض المستخدمين. هذه القائمة
# تُستعمل في كل من واجهة البرنامج وفي كل التقارير المولَّدة (PDF/HTML).
FONT_FAMILY_CHOICES = [
    "Arial", "Tahoma", "Calibri", "Times New Roman",
    "Segoe UI", "Traditional Arabic", "Simplified Arabic", "Sakkal Majalla",
]


# ---------------------------------------------------------------------------
# إعدادات التطبيق العامة (مشتركة بين كل الملفات/Dossiers)
# ---------------------------------------------------------------------------
class AppSettings:
    def __init__(self, file="settings.json"):
        # يبقى المعامل file للتوافق الخلفي فقط، التخزين الفعلي يتم عبر storage.py
        self.file = file
        self.data = {
            "language": "العربية",
            "font_size": 13,
            "font_family": "Arial",
            "theme": "#f8f9ff",
            "expert_name": "",
            "expert_title": "",
            "expert_id": "",
            "save_folder": "",
            "require_password_on_start": False,
            "startup_password_hash": "",
            "password_hint": "",
            "near_deadline_days": 30,
        }
        self.load()
        # نسخ قديمة حفظت كلمة مرور بدء التشغيل صريحة: تُحوَّل إلى تجزئة هنا
        startup_password.migrate_legacy(self)

    def load(self):
        saved = storage.load_settings()
        if saved:
            self.data.update(saved)

    def save(self):
        storage.save_settings(self.data)

    def get(self, key):
        return self.data.get(key, "")

    def set(self, key, value):
        self.data[key] = value
        self.save()

    def get_language_code(self):
        return LANGUAGE_CODE_BY_LABEL.get(self.get("language"), "ar")


# ---------------------------------------------------------------------------
# نافذة إضافة/تعديل مستخدم
# ---------------------------------------------------------------------------
class UserEditDialog(QDialog):
    def __init__(self, parent=None, username=None):
        super().__init__(parent)
        self.editing_username = username  # None = مستخدم جديد
        self._existing_question = ""
        self.setWindowTitle("تعديل مستخدم" if username else "إضافة مستخدم جديد")
        self.setFixedWidth(400)
        self.setStyleSheet("QDialog{background:#f4f5ff;}")

        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.username_input = QLineEdit()
        self.username_input.setEnabled(username is None)  # لا يُغيَّر اسم المستخدم بعد الإنشاء
        form.addRow("اسم المستخدم:", self.username_input)

        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.setPlaceholderText(
            "اتركه فارغاً لعدم التغيير" if username else "12 حرفاً على الأقل، أصناف متنوعة")
        form.addRow("كلمة المرور:" if username else "كلمة المرور الأولية:", self.password_input)

        self.role_combo = QComboBox()
        for key, label in storage.ROLES.items():
            self.role_combo.addItem(label, key)
        form.addRow("الدور:", self.role_combo)

        self.security_question_input = QLineEdit()
        self.security_question_input.setPlaceholderText("مثال: ما اسم مسقط رأسك؟")
        form.addRow("سؤال الأمان:", self.security_question_input)

        self.security_answer_input = QLineEdit()
        self.security_answer_input.setPlaceholderText(
            "اتركه فارغاً لعدم التغيير" if username else "")
        form.addRow("إجابة سؤال الأمان:", self.security_answer_input)

        self.active_checkbox = QCheckBox("الحساب مفعّل")
        self.active_checkbox.setChecked(True)
        form.addRow("", self.active_checkbox)

        layout.addLayout(form)

        if username:
            self._load_existing(username)

        btn = QPushButton("حفظ")
        btn.setStyleSheet("background:#128456;color:white;padding:8px;border-radius:6px;")
        btn.clicked.connect(self.save)
        layout.addWidget(btn)

    def _load_existing(self, username):
        users = storage.load_users()
        for u in users:
            if u.get("username") == username:
                self.username_input.setText(username)
                idx = self.role_combo.findData(u.get("role", "assistant"))
                if idx >= 0:
                    self.role_combo.setCurrentIndex(idx)
                self._existing_question = u.get("security_question", "")
                self.security_question_input.setText(self._existing_question)
                self.active_checkbox.setChecked(u.get("active", True))
                break

    def save(self):
        username = self.username_input.text().strip()
        role = self.role_combo.currentData()
        if not username:
            show_warning(self, "تنبيه", "أدخل اسم المستخدم.")
            return

        question = self.security_question_input.text().strip()
        answer = self.security_answer_input.text().strip()
        password = self.password_input.text()

        # التحقق من كل المدخلات قبل أي حفظ (لا يُحفظ نصف التعديل)
        if self.editing_username is None or password:
            ok, problems = password_policy.check(password, username)
            if not ok:
                show_warning(self, "كلمة مرور ضعيفة",
                             password_policy.explain(problems) + "\n\n" + password_policy.requirements_text())
                return
        if answer:
            ok, problems = password_policy.check_answer(answer)
            if not ok:
                show_warning(self, "تنبيه", "؛ ".join(problems))
                return
            if len(question) < 8 and not (self.editing_username and self._existing_question):
                show_warning(self, "تنبيه", "اكتب سؤال أمان واضحاً (8 أحرف على الأقل) مع الإجابة.")
                return
        elif question and self.editing_username is None:
            show_warning(self, "تنبيه", "أدخل إجابة سؤال الأمان أو اترك السؤال فارغاً.")
            return

        try:
            if self.editing_username is None:
                storage.add_user(username, password, role,
                                 security_question=question, security_answer=answer)
            else:
                storage.update_user(username, role=role, active=self.active_checkbox.isChecked())
                if password:
                    storage.change_password(username, password)
                if answer:
                    storage.set_recovery(username, question or self._existing_question, answer)
        except (ValueError, OSError) as e:       # WeakPassword وIntegrityError... يعرضها كما هي
            show_warning(self, "خطأ", str(e))
            return

        self.accept()


# ---------------------------------------------------------------------------
# تبويب إدارة المستخدمين (يظهر فقط لمن يملك صلاحية manage_users)
# ---------------------------------------------------------------------------
class UsersManagementTab(QWidget):
    def __init__(self, current_user):
        super().__init__()
        self.current_user = current_user
        layout = QVBoxLayout(self)

        top_row = QHBoxLayout()
        add_btn = QPushButton("+ إضافة مستخدم")
        add_btn.setStyleSheet("background:#5a4ee3;color:white;padding:7px 14px;border-radius:6px;")
        add_btn.clicked.connect(self.add_user)
        top_row.addWidget(add_btn)
        top_row.addStretch()
        layout.addLayout(top_row)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["اسم المستخدم", "الدور", "الحالة", ""])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        layout.addWidget(self.table)

        self.reload()

    def reload(self):
        users = storage.load_users()
        self.table.setRowCount(0)
        for u in users:
            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(u.get("username", "")))
            self.table.setItem(row, 1, QTableWidgetItem(storage.ROLES.get(u.get("role"), u.get("role"))))
            self.table.setItem(row, 2, QTableWidgetItem("مفعّل" if u.get("active", True) else "معطّل"))

            actions = QWidget()
            h = QHBoxLayout(actions)
            h.setContentsMargins(0, 0, 0, 0)
            edit_btn = QPushButton("تعديل")
            edit_btn.clicked.connect(lambda _, un=u.get("username"): self.edit_user(un))
            h.addWidget(edit_btn)

            if u.get("username") != "admin":  # لا يمكن حذف/تعطيل آخر حساب admin عن طريق الخطأ
                del_btn = QPushButton("حذف")
                del_btn.setStyleSheet("color:#d03a50;")
                del_btn.clicked.connect(lambda _, un=u.get("username"): self.delete_user(un))
                h.addWidget(del_btn)
            self.table.setCellWidget(row, 3, actions)

    def add_user(self):
        dlg = UserEditDialog(self)
        if dlg.exec_() == QDialog.Accepted:
            self.reload()

    def edit_user(self, username):
        dlg = UserEditDialog(self, username=username)
        if dlg.exec_() == QDialog.Accepted:
            self.reload()

    def delete_user(self, username):
        reply = show_question(
            self, "تأكيد", f"حذف المستخدم '{username}' نهائياً؟")
        if reply == QMessageBox.Yes:
            storage.delete_user(username)
            self.reload()


# ---------------------------------------------------------------------------
# واجهة صفحة الإعدادات
# ---------------------------------------------------------------------------
class SettingsPage(QWidget):
    language_changed = pyqtSignal(str)

    def __init__(self, settings, current_user=None):
        super().__init__()
        self.settings = settings
        self.current_user = current_user or {"username": "admin", "role": "admin"}
        self.setWindowTitle("إعدادات التطبيق")
        self.setStyleSheet("background-color: #f8f9ff; font-family: Segoe UI; font-size: 12pt;")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)

        title = QLabel("إعدادات التطبيق")
        title.setFont(QFont("Segoe UI", 16, QFont.Bold))
        layout.addWidget(title)

        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)

        can_manage_settings = storage.user_can(self.current_user, "manage_settings")

        if can_manage_settings:
            self.init_general_tab()
            self.init_expert_tab()
            self.init_storage_tab()
            self.init_security_tab()
            if storage.user_can(self.current_user, "manage_users"):
                self.users_tab = UsersManagementTab(self.current_user)
                self.tabs.addTab(self.users_tab, "المستخدمون")
        else:
            # غير admin: لا يرى أي إعداد عام للتطبيق (لغة/خبير/حفظ/أمان)،
            # هذه إعدادات مصيرية تخص المدير فقط.
            info = QWidget()
            info_layout = QVBoxLayout(info)
            msg = QLabel(
                "لا تملك صلاحية الوصول إلى إعدادات التطبيق العامة.\n"
                "تواصل مع المدير (admin) إن احتجت تغيير أي إعداد."
            )
            msg.setStyleSheet("color:#5b6485; padding:30px;")
            msg.setWordWrap(True)
            info_layout.addWidget(msg)
            self.tabs.addTab(info, "معلومة")

        self.init_about_tab()
        self.init_buttons(can_manage_settings)

    # ------------------------------------------------------------------
    def init_general_tab(self):
        tab = QWidget()
        form = QFormLayout(tab)

        self.lang = QComboBox()
        self.lang.addItems(LANGUAGE_LABELS)
        self.lang.setCurrentText(self.settings.get("language"))
        form.addRow("اللغة:", self.lang)

        self.font_size = QSpinBox()
        self.font_size.setRange(10, 30)
        self.font_size.setValue(self.settings.get("font_size"))
        form.addRow("حجم الخط:", self.font_size)

        self.font_family = QComboBox()
        self.font_family.addItems(FONT_FAMILY_CHOICES)
        current_font = self.settings.get("font_family") or "Arial"
        if self.font_family.findText(current_font) == -1:
            # يسمح أيضاً بخط غير موجود في القائمة (كتبه مستخدم سابق يدوياً)
            self.font_family.addItem(current_font)
        self.font_family.setCurrentText(current_font)
        form.addRow("نوع الخط (البرنامج والتقارير):", self.font_family)

        self.near_deadline_days = QSpinBox()
        self.near_deadline_days.setRange(1, 180)
        self.near_deadline_days.setValue(int(self.settings.get("near_deadline_days") or 30))
        self.near_deadline_days.setSuffix(" يوم")
        form.addRow("تنبيه \"قريبة الإيداع\" قبل الأجل بـ:", self.near_deadline_days)

        self.tabs.addTab(tab, "عام")

    def init_expert_tab(self):
        tab = QWidget()
        form = QFormLayout(tab)
        self.expert_name = QLineEdit(self.settings.get("expert_name"))
        self.expert_title = QLineEdit(self.settings.get("expert_title"))
        self.expert_id = QLineEdit(self.settings.get("expert_id"))
        form.addRow("اسم الخبير:", self.expert_name)
        form.addRow("الصفة:", self.expert_title)
        form.addRow("رقم التسجيل:", self.expert_id)
        self.tabs.addTab(tab, "الخبير")

    def init_storage_tab(self):
        tab = QWidget()
        form = QFormLayout(tab)

        self.save_folder = QLineEdit(self.settings.get("save_folder"))
        btn_browse = QPushButton("استعراض")
        btn_browse.clicked.connect(self.select_folder)
        row = QHBoxLayout()
        row.addWidget(self.save_folder)
        row.addWidget(btn_browse)
        wrapper = QWidget()
        wrapper.setLayout(row)
        form.addRow("مجلد الحفظ:", wrapper)

        backup_btn = QPushButton("نسخ احتياطي لكل بيانات التطبيق الآن")
        backup_btn.setStyleSheet("background:#7c3aed;color:white;padding:8px;border-radius:6px;")
        backup_btn.clicked.connect(self.backup_now)
        form.addRow("", backup_btn)

        encrypted_btn = QPushButton("نسخة احتياطية مشفّرة بكلمة مرور")
        encrypted_btn.setStyleSheet("background:#5b52d6;color:white;padding:8px;border-radius:6px;")
        encrypted_btn.clicked.connect(self.encrypted_backup_now)
        form.addRow("", encrypted_btn)

        restore_btn = QPushButton("استرجاع نسخة احتياطية مشفّرة")
        restore_btn.setStyleSheet("background:#d03a50;color:white;padding:8px;border-radius:6px;")
        restore_btn.clicked.connect(self.restore_encrypted_backup)
        form.addRow("", restore_btn)

        self.tabs.addTab(tab, "الحفظ")

    def init_security_tab(self):
        tab = QWidget()
        form = QFormLayout(tab)

        self.require_password_checkbox = QCheckBox("طلب كلمة مرور عند بدء تشغيل البرنامج")
        self.require_password_checkbox.setChecked(bool(self.settings.get("require_password_on_start")))
        self.require_password_checkbox.toggled.connect(self._toggle_startup_password_fields)
        form.addRow("", self.require_password_checkbox)

        self.startup_password = QLineEdit()
        self.startup_password.setEchoMode(QLineEdit.Password)
        self.startup_password.setPlaceholderText("اتركها فارغة لعدم التغيير")
        form.addRow("كلمة مرور بدء التشغيل:", self.startup_password)

        self.startup_password_confirm = QLineEdit()
        self.startup_password_confirm.setEchoMode(QLineEdit.Password)
        form.addRow("تأكيدها:", self.startup_password_confirm)

        self._toggle_startup_password_fields(self.require_password_checkbox.isChecked())

        note = QLabel(
            "ملاحظة: كلمة مرور حسابك الشخصي (تسجيل الدخول) تُغيَّر من\n"
            "تبويب \"المستخدمون\" أعلاه (أو اطلب من المدير تعديلها)،\n"
            "وهي مختلفة عن كلمة مرور بدء التشغيل هذه."
        )
        note.setStyleSheet("color:#5b6485; font-size:9pt;")
        form.addRow(note)

        self.tabs.addTab(tab, "الأمان")

    def _toggle_startup_password_fields(self, checked):
        self.startup_password.setEnabled(checked)
        self.startup_password_confirm.setEnabled(checked)

    def init_about_tab(self):
        tab = QWidget()
        form = QFormLayout(tab)
        from app_info import APP_VERSION
        label = QLabel("إصدار التطبيق: " + APP_VERSION)
        label.setWordWrap(True)
        form.addRow(label)
        self.tabs.addTab(tab, "حول")

    def init_buttons(self, can_manage_settings=True):
        if not can_manage_settings:
            return  # لا حقول إعدادات عامة لديه أصلاً، فلا داعي لأزرار حفظ/تصفير

        btn_save = QPushButton("حفظ")
        btn_save.setStyleSheet("background-color: #128456; color: white; padding: 8px; border-radius: 6px;")
        btn_save.clicked.connect(self.save_all)

        btn_reset = QPushButton("إعادة تعيين")
        btn_reset.clicked.connect(self.reset_all)

        row = QHBoxLayout()
        row.addStretch()
        row.addWidget(btn_save)
        row.addWidget(btn_reset)
        self.layout().addLayout(row)

    # ------------------------------------------------------------------
    def select_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "اختر مجلدًا")
        if folder:
            self.save_folder.setText(folder)

    def backup_now(self):
        import shutil, datetime, os
        dest_root = QFileDialog.getExistingDirectory(self, "اختر مكان حفظ النسخة الاحتياطية")
        if not dest_root:
            return
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        dest = os.path.join(dest_root, f"نسخة_احتياطية_{stamp}")
        try:
            shutil.copytree(storage.APP_DATA_DIR, os.path.join(dest, "app_data"))
            if os.path.isdir(storage.DOSSIERS_DATA_DIR):
                shutil.copytree(storage.DOSSIERS_DATA_DIR, os.path.join(dest, "dossiers_data"))
            show_info(self, "تم", f"تم إنشاء نسخة احتياطية في:\n{dest}")
        except Exception as e:
            show_warning(self, "خطأ", f"تعذر إنشاء النسخة الاحتياطية:\n{e}")

    def encrypted_backup_now(self):
        from PyQt5.QtWidgets import QInputDialog
        dest_root = QFileDialog.getExistingDirectory(self, "اختر مكان حفظ النسخة الاحتياطية المشفّرة")
        if not dest_root:
            return
        password, ok = QInputDialog.getText(
            self, "حماية النسخة الاحتياطية", "كلمة مرور التشفير:", QLineEdit.Password)
        if not ok or not password:
            return
        ok_pw, problems = password_policy.check(password)
        if not ok_pw:
            show_warning(self, "تنبيه", password_policy.explain(problems))
            return
        confirm, ok = QInputDialog.getText(
            self, "تأكيد كلمة المرور", "أعد إدخال كلمة المرور:", QLineEdit.Password)
        if not ok or password != confirm:
            show_warning(self, "خطأ", "كلمتا المرور غير متطابقتين.")
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            path = create_backup(
                dest_root, password, storage.APP_DATA_DIR, storage.DOSSIERS_DATA_DIR,
                progress=lambda i, n: QApplication.processEvents())
        except BackupError as e:
            QApplication.restoreOverrideCursor()
            show_warning(self, "خطأ", "تعذر إنشاء النسخة المشفّرة:\n%s" % e)
            return
        except Exception as e:
            QApplication.restoreOverrideCursor()
            show_warning(self, "خطأ", "تعذر إنشاء النسخة المشفّرة:\n%s" % e)
            return
        QApplication.restoreOverrideCursor()
        show_info(
            self, "تم",
            "تم إنشاء نسخة احتياطية مشفّرة بنجاح:\n%s\n\n"
            "احفظ كلمة المرور في مكان آمن؛ بدونها لا يمكن استرجاع النسخة أبداً." % path)

    def restore_encrypted_backup(self):
        from PyQt5.QtWidgets import QInputDialog
        import app_paths
        src, _ = QFileDialog.getOpenFileName(
            self, "اختر ملف النسخة الاحتياطية المشفّرة", "", "نسخة احتياطية (*.ejbackup)")
        if not src:
            return
        password, ok = QInputDialog.getText(
            self, "استرجاع النسخة", "كلمة مرور النسخة:", QLineEdit.Password)
        if not ok or not password:
            return
        answer = show_question(
            self, "تأكيد الاسترجاع",
            "سيتم استبدال كل بيانات البرنامج الحالية (القضايا، الأطراف، الوثائق...) "
            "ببيانات النسخة المختارة.\n\n"
            "تُحفظ البيانات الحالية في مجلد جانبي باسم _before_restore_... "
            "بجانب البرنامج، ويُغلق البرنامج بعد الانتهاء ليُعاد فتحه.\n\nهل تريد المتابعة؟")
        if answer != QMessageBox.Yes:
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            result = restore_backup(
                src, password, app_paths.app_base_dir(),
                progress=lambda i, n: QApplication.processEvents())
        except BackupError as e:
            QApplication.restoreOverrideCursor()
            show_warning(self, "تعذّر الاسترجاع", "%s\n\nلم يتغيّر شيء في بياناتك الحالية." % e)
            return
        except Exception as e:
            QApplication.restoreOverrideCursor()
            show_warning(self, "تعذّر الاسترجاع", "%s\n\nلم يتغيّر شيء في بياناتك الحالية." % e)
            return
        QApplication.restoreOverrideCursor()
        show_info(
            self, "تم الاسترجاع",
            "تم استرجاع %d ملفاً بنجاح.\n\nالبيانات السابقة محفوظة في:\n%s\n\n"
            "سيُغلق البرنامج الآن؛ افتحه من جديد لتظهر البيانات المسترجعة."
            % (result["files"], result["safety_dir"]))
        QApplication.instance().quit()

    def save_all(self):
        # التحقق من كلمة مرور بدء التشغيل قبل أي حفظ
        if self.require_password_checkbox.isChecked():
            new_pass = self.startup_password.text()
            confirm = self.startup_password_confirm.text()
            if new_pass or confirm:
                if new_pass != confirm:
                    show_warning(self, "تنبيه", "كلمتا مرور بدء التشغيل غير متطابقتين.")
                    return
                ok_pw, problems = password_policy.check(new_pass)
                if not ok_pw:
                    show_warning(self, "تنبيه", password_policy.explain(problems))
                    return
                startup_password.set_password(self.settings, new_pass)
                self.startup_password.clear()
                self.startup_password_confirm.clear()
            elif not startup_password.has_password(self.settings):
                show_warning(
                    self, "تنبيه",
                    "فعّلت طلب كلمة المرور عند بدء التشغيل لكن لم تحدد كلمة مرور بعد.")
                return

        prev_lang = self.settings.get_language_code()

        self.settings.set("language", self.lang.currentText())
        self.settings.set("font_size", self.font_size.value())
        self.settings.set("font_family", self.font_family.currentText())
        self.settings.set("near_deadline_days", self.near_deadline_days.value())
        self.settings.set("expert_name", self.expert_name.text())
        self.settings.set("expert_title", self.expert_title.text())
        self.settings.set("expert_id", self.expert_id.text())
        self.settings.set("save_folder", self.save_folder.text())
        self.settings.set("require_password_on_start", self.require_password_checkbox.isChecked())

        new_lang = self.settings.get_language_code()
        if prev_lang != new_lang:
            # اللغة أصبحت تُطبّق مباشرة على جميع نوافذ وواجهات Qt؛ لا حاجة
            # لإعادة تشغيل البرنامج ولا لإضافة النص الجديد إلى قاموس يدوي.
            self.language_changed.emit(new_lang)

        # نطبّق الخط الجديد فوراً على كل نوافذ البرنامج المفتوحة، بدون
        # حاجة لإعادة التشغيل (نفس مبدأ تغيير اللغة أعلاه). نستعمل قاعدة
        # Stylesheet عامة (وليس setFont بسيطاً) لأنها الوحيدة القادرة على
        # تجاوز استدعاءات setFont() الصريحة المنتشرة في نوافذ كثيرة بالكود.
        app = QApplication.instance()
        if app is not None:
            from ui_style import apply_global_font
            apply_global_font(app, self.font_family.currentText(), self.font_size.value())

        show_info(self, "", "تم حفظ الإعدادات بنجاح")

    def reset_all(self):
        self.lang.setCurrentIndex(0)
        self.font_size.setValue(13)
        self.font_family.setCurrentText("Arial")
        self.near_deadline_days.setValue(30)
        self.expert_name.clear()
        self.expert_title.clear()
        self.expert_id.clear()
        self.save_folder.clear()
        self.require_password_checkbox.setChecked(False)
        self.startup_password.clear()
        self.startup_password_confirm.clear()


# تجربة مباشرة
if __name__ == "__main__":
    app = QApplication(sys.argv)
    settings = AppSettings()
    window = SettingsPage(settings)
    window.language_changed.connect(lambda lang: print("تم تغيير اللغة إلى:", lang))
    window.show()
    sys.exit(app.exec_())
