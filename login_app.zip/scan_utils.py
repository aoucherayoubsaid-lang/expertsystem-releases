# -*- coding: utf-8 -*-
"""
مساعد مسح ضوئي (Scanner) + إرفاق ملفات موحّد، تستعمله كل صفحات البرنامج
(الوثائق، المحاضر، الإيداع) بدل أن تكتب كل صفحة منطقها الخاص.

المسح الضوئي يعتمد على واجهة ويندوز القياسية (WIA) عبر pywin32، فيفتح نفس
نافذة "المسح الضوئي" التي يراها المستخدم في أي برنامج ويندوز عادي (اختيار
الجهاز، الدقة، ثم مسح) - بدل أن نتحكم يدوياً في كل نوع ماسح (أكثر أماناً
وأقل عرضة للأعطال، لأن ويندوز نفسه يتولى الحوار مع الجهاز).

قاعدة أمان صارمة في هذا الملف: أي خطأ هنا (لا يوجد ماسح، pywin32 غير مثبَّت،
المستخدم ألغى العملية، تعريف الجهاز معطوب...) يُعرض كرسالة عادية للمستخدم عبر
show_warning، ولا يُسمح له أبداً بالخروج كاستثناء غير مُمسوك قد يُسقط البرنامج.
"""
import os
import tempfile
import datetime

from PyQt5.QtWidgets import QFileDialog, QMenu

from msgbox_ltr import show_warning

ATTACH_FILE_FILTER = "الصور وملفات PDF (*.png *.jpg *.jpeg *.bmp *.tif *.tiff *.pdf);;كل الملفات (*.*)"


def scanning_supported():
    """True فقط إن كنا على ويندوز ومكتبة pywin32 (win32com) مثبَّتة."""
    if os.name != "nt":
        return False
    try:
        import win32com.client  # noqa: F401
        return True
    except Exception:
        return False


def scan_document(parent, suggested_name="scan"):
    """
    يفتح نافذة المسح الضوئي القياسية لويندوز (WIA) ويحفظ النتيجة كملف مؤقت.
    يُرجع مسار الملف الممسوح، أو None إن ألغى المستخدم العملية أو تعذّر المسح
    (مع عرض رسالة توضيحية للمستخدم في حالة التعذّر فقط، وليس عند الإلغاء).
    """
    if not scanning_supported():
        import sys
        if getattr(sys, "frozen", False):
            msg = ("تعذّر العثور على دعم المسح الضوئي على هذا الجهاز.\n"
                   "المسح الضوئي يعمل على ويندوز فقط، وتأكد من أن الماسح متصل ومُشغَّل\n"
                   "وأن تعريفه (Driver) مثبَّت، وأن خدمة Windows Image Acquisition (WIA) تعمل.")
        else:
            msg = ("تعذّر العثور على دعم المسح الضوئي على هذا الجهاز.\n"
                   "تأكد من تثبيت مكتبة pywin32 (الأمر: pip install pywin32)،\n"
                   "ومن أن الماسح الضوئي متصل وتعريفه (Driver) مثبَّت.")
        show_warning(parent, "المسح الضوئي غير متاح", msg)
        return None

    try:
        import win32com.client
        wia = win32com.client.Dispatch("WIA.CommonDialog")
        # تفتح هذه الدالة نافذة ويندوز القياسية لاختيار الجهاز ثم المسح.
        # إن ألغى المستخدم العملية من النافذة نفسها، تُرجع None بدون أي خطأ.
        image = wia.ShowAcquireImage()
        if image is None:
            return None

        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        tmp_dir = tempfile.gettempdir()
        out_path = os.path.join(tmp_dir, f"{suggested_name}_{ts}.jpg")
        try:
            image.SaveFile(out_path)
        except Exception:
            # بعض الماسحات/التعريفات لا تدعم الحفظ مباشرة بصيغة jpg، نجرّب bmp احتياطياً
            out_path = os.path.join(tmp_dir, f"{suggested_name}_{ts}.bmp")
            image.SaveFile(out_path)
        return out_path
    except Exception as e:
        show_warning(
            parent, "تعذّر المسح الضوئي",
            "حدث خطأ أثناء محاولة المسح الضوئي.\n"
            "تأكد من أن الماسح الضوئي متصل ومُشغَّل، وأن تعريفه مثبَّت بشكل صحيح.\n\n"
            f"تفاصيل: {e}"
        )
        return None


def pick_existing_file(parent, title="اختر ملفاً", file_filter=ATTACH_FILE_FILTER):
    """اختيار ملف موجود مسبقاً على الجهاز (نفس آلية الإرفاق التقليدية)."""
    file_path, _ = QFileDialog.getOpenFileName(parent, title, "", file_filter)
    return file_path or None


def pick_existing_files(parent, title="اختر ملفاً أو أكثر", file_filter="كل الملفات (*.*)"):
    """نسخة متعددة الملفات (لصفحة الوثائق التي تسمح برفع عدة ملفات دفعة واحدة)."""
    files, _ = QFileDialog.getOpenFileNames(parent, title, "", file_filter)
    return list(files) if files else []


def attach_menu_for_button(button, parent, on_scan, on_pick_file, scan_label="📷  مسح ضوئي جديد",
                            file_label="📁  إرفاق ملف موجود من الجهاز"):
    """
    يحوّل زراً عادياً إلى زر بقائمة منسدلة صغيرة بخيارين: مسح ضوئي جديد، أو
    إرفاق ملف موجود. on_scan / on_pick_file: دالتان بلا معاملات.
    يُرجع القائمة (menu) حتى يحتفظ المستدعي بمرجع لها إن احتاج.
    """
    menu = QMenu(parent)
    scan_action = menu.addAction(scan_label)
    file_action = menu.addAction(file_label)
    scan_action.triggered.connect(on_scan)
    file_action.triggered.connect(on_pick_file)
    button.setMenu(menu)
    return menu
