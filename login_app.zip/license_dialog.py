# -*- coding: utf-8 -*-
"""نافذة الترخيص والتفعيل + فحص بدء التشغيل (التجربة المجانية لمدة شهر)."""
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QApplication, QDialog, QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QTextEdit, QVBoxLayout,
)
import qtawesome as qta

import app_info
import contact_utils
import integrity
import license_manager as lm
import message_templates as mt
from msgbox_ltr import show_info, show_warning

NAVY = "#4338ca"

_HEAD = {
    "trial": ("النسخة التجريبية", "#5a4ee3"),
    "licensed": ("البرنامج مفعّل", "#128456"),
    "expired": ("انتهت الفترة التجريبية", "#d03a50"),
    "license_expired": ("انتهت صلاحية الترخيص", "#d03a50"),
    "tampered": ("تعذّر التحقق من الترخيص", "#d03a50"),
    "blocked": ("تعذّر تشغيل النسخة التجريبية", "#d03a50"),
    "need_online": ("يلزم الاتصال بالإنترنت", "#d03a50"),
}


def _message(st):
    s = st["state"]
    if s == "trial":
        return ("أنت تستعمل النسخة التجريبية المجانية، وتبقّى %d يوماً. للاستمرار بعد ذلك "
                "أرسل لي رمز جهازك أدناه وسأرسل لك مفتاح التفعيل." % st["days_left"])
    if s == "licensed":
        who = ("مرخّص باسم: %s\n" % st["customer"]) if st["customer"] else ""
        until = ("ينتهي الترخيص في %s." % st["expiry"].strftime("%d/%m/%Y")) if st["expiry"] \
            else "الترخيص دائم على هذا الجهاز."
        return who + until
    if s == "expired":
        return ("انتهت الفترة التجريبية (%d يوماً). لمتابعة العمل فعّل البرنامج بمفتاح. "
                "ويمكنك الآن فتح البرنامج بوضع «القراءة فقط» لعرض بياناتك وتصديرها دون تعديل، "
                "فلن يضيع أي شيء من عملك." % lm.TRIAL_DAYS)
    if s == "license_expired":
        if st.get("reason") == "other_device":
            return ("هذا المفتاح مُفعَّل على جهاز آخر. تواصل معي إن غيّرت حاسوبك لأنقل الترخيص إلى "
                    "هذا الجهاز، أو افتح البرنامج بوضع «القراءة فقط».")
        if st.get("reason") == "invalid":
            return ("لم يعد هذا الترخيص صالحاً (أُلغي). تواصل معي لحل المشكلة، أو افتح البرنامج "
                    "بوضع «القراءة فقط» لعرض بياناتك.")
        return ("انتهت صلاحية ترخيصك بتاريخ %s. تواصل معي لتجديده، أو افتح البرنامج بوضع "
                "«القراءة فقط» لعرض بياناتك." % st["expiry"].strftime("%d/%m/%Y"))
    if s == "blocked":
        if st.get("reason") == "rate_limited":
            return ("وصلتنا طلبات تجربة كثيرة من شبكتك. حاول لاحقاً، أو أرسل لي رمز جهازك أدناه "
                    "وسأساعدك. ويمكنك فتح البرنامج بوضع «القراءة فقط».")
        return ("أُوقفت النسخة التجريبية على هذا الجهاز. إن كان ذلك خطأً فأرسل لي رمز جهازك أدناه "
                "لأراجع الحالة، أو افتح البرنامج بوضع «القراءة فقط» لعرض بياناتك.")
    if s == "need_online" and st.get("reason") == "guard":
        return ("يلزم اتصال بالإنترنت للتحقق الدوري من النسخة التجريبية. اتصل بالإنترنت ثم اضغط "
                "«إعادة المحاولة» (أو أعد تشغيل البرنامج).")
    if s == "need_online" and st.get("reason") == "license":
        return ("يلزم الاتصال بالإنترنت للتحقق من اشتراكك (يُجدَّد التحقق دورياً). اتصل بالإنترنت "
                "ثم اضغط «إعادة المحاولة».")
    if s == "need_online":
        return ("لبدء الفترة التجريبية يلزم اتصال بالإنترنت مرة واحدة فقط عند أول تشغيل. "
                "اتصل بالإنترنت ثم اضغط «إعادة المحاولة». وإن لم يتوفر لديك اتصال فأرسل لي "
                "رمز جهازك أدناه وسأرسل لك مفتاح التفعيل.")
    return ("اكتُشف تغيير في تاريخ الجهاز أو في ملفات الترخيص. صحّح تاريخ الجهاز وساعته ثم أعد "
            "تشغيل البرنامج. وإن كان التاريخ سليماً فأرسل لي رمز جهازك لأساعدك، أو افتح "
            "البرنامج بوضع «القراءة فقط».")


class LicenseDialog(QDialog):
    """startup=True: عند بدء التشغيل بعد الانتهاء (أزرار: قراءة فقط / خروج)."""

    def __init__(self, st=None, startup=False, parent=None):
        super().__init__(parent)
        self.st = st or lm.evaluate(update=False)
        self.startup = startup
        self.choice = "closed"
        self.setWindowTitle("الترخيص والتفعيل")
        self.setLayoutDirection(Qt.RightToLeft)
        self.setMinimumWidth(560)
        self.setStyleSheet("""
            QDialog { background: #f8f9ff; } QLabel { color: #1f2347; }
            QLineEdit, QTextEdit { background: white; border: 1px solid #cdd3ee;
                                   border-radius: 6px; padding: 6px; }
        """)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 14)
        root.setSpacing(10)

        title, color = _HEAD.get(self.st["state"], _HEAD["expired"])
        head = QFrame()
        head.setStyleSheet("QFrame { background: %s; } QLabel { background: transparent; color: white; }" % NAVY)
        hl = QHBoxLayout(head)
        hl.setContentsMargins(22, 14, 22, 14)
        icon = QLabel()
        icon.setPixmap(qta.icon("fa5s.key", color="white").pixmap(30, 30))
        t = QLabel(title)
        t.setStyleSheet("font-size: 19px; font-weight: bold; color: white;")
        badge = QLabel(app_info.APP_NAME_EN + "  v" + app_info.APP_VERSION)
        badge.setStyleSheet("color: #cdd3ee; font-size: 11px;")
        hl.addWidget(icon)
        hl.addWidget(t)
        hl.addStretch(1)
        hl.addWidget(badge)
        root.addWidget(head)

        body = QVBoxLayout()
        body.setContentsMargins(22, 4, 22, 0)
        body.setSpacing(10)
        root.addLayout(body)

        msg = QLabel(_message(self.st))
        msg.setWordWrap(True)
        msg.setStyleSheet("font-size: 13px; padding: 6px; border-right: 4px solid %s;" % color)
        body.addWidget(msg)

        # ---- رمز الجهاز ----
        body.addWidget(QLabel("رمز هذا الجهاز:"))
        row = QHBoxLayout()
        self.code = QLineEdit(lm.machine_code())
        self.code.setReadOnly(True)
        self.code.setAlignment(Qt.AlignCenter)
        self.code.setLayoutDirection(Qt.LeftToRight)
        self.code.setStyleSheet("font-family: Consolas, 'Courier New', monospace; font-size: 17px;"
                                " font-weight: bold; letter-spacing: 2px; background: #f1f2ff;"
                                " border: 1px solid #cdd3ee; border-radius: 6px; padding: 8px;")
        copy = QPushButton(" نسخ")
        copy.setIcon(qta.icon("fa5s.copy", color="#1f2347"))
        copy.setMinimumHeight(40)
        copy.clicked.connect(self._copy_code)
        row.addWidget(self.code, 1)
        row.addWidget(copy)
        body.addLayout(row)

        if self.st["state"] != "licensed":
            req = QHBoxLayout()
            self._btn(req, "اطلب التفعيل عبر واتساب", "fa5b.whatsapp", "#128456", self._ask_whatsapp)
            self._btn(req, "عبر البريد", "fa5s.envelope", "#d03a50", self._ask_mail)
            body.addLayout(req)

        # ---- إدخال المفتاح ----
        body.addWidget(QLabel("لديك مفتاح تفعيل؟ الصقه هنا:"))
        self.key = QTextEdit()
        self.key.setFixedHeight(78)
        self.key.setLayoutDirection(Qt.LeftToRight)
        self.key.setAlignment(Qt.AlignLeft)
        self.key.setPlaceholderText("XXXXX-XXXXX-XXXXX-XXXXX-...")
        body.addWidget(self.key)
        act = QHBoxLayout()
        self._btn(act, "تفعيل البرنامج", "fa5s.check-circle", "#128456", self._activate)
        body.addLayout(act)

        # ---- أزرار الأسفل ----
        foot = QHBoxLayout()
        if startup and self.st["state"] != "licensed":
            if self.st["state"] == "need_online":      # لا بيانات بعد: القراءة فقط بلا معنى
                ro = QPushButton("إعادة المحاولة")
                ro.clicked.connect(self._retry)
            else:
                ro = QPushButton("متابعة بوضع القراءة فقط")
                ro.clicked.connect(self._readonly)
            ro.setMinimumHeight(36)
            ex = QPushButton("خروج")
            ex.setMinimumHeight(36)
            ex.clicked.connect(self._exit)
            foot.addWidget(ro)
            foot.addStretch(1)
            foot.addWidget(ex)
        else:
            foot.addStretch(1)
            cl = QPushButton("إغلاق")
            cl.setMinimumHeight(36)
            cl.clicked.connect(self.accept)
            foot.addWidget(cl)
        body.addLayout(foot)

        contact = QLabel("%s  |  %s" % (app_info.DEVELOPER_PHONE, app_info.DEVELOPER_EMAIL))
        contact.setAlignment(Qt.AlignCenter)
        contact.setStyleSheet("color: #5b6485; font-size: 11px;")
        contact.setTextInteractionFlags(Qt.TextSelectableByMouse)
        body.addWidget(contact)

    def _btn(self, layout, text, icon, color, handler):
        b = QPushButton("  " + text)
        b.setIcon(qta.icon(icon, color="white"))
        b.setMinimumHeight(38)
        b.setCursor(Qt.PointingHandCursor)
        b.setStyleSheet("QPushButton { background: %s; color: white; border: none; border-radius: 6px;"
                        " padding: 6px 16px; font-weight: bold; } QPushButton:hover { background: #1f2347; }" % color)
        b.clicked.connect(handler)
        layout.addWidget(b)

    def _request_text(self, style="wa"):
        return mt.license_request(style, lm.machine_code())

    def _copy_code(self):
        QApplication.clipboard().setText(lm.machine_code())
        show_info(self, "تم النسخ", "نُسخ رمز الجهاز. أرسله لي لأصدر لك مفتاح التفعيل.")

    def _ask_whatsapp(self):
        contact_utils.open_whatsapp(self._request_text("wa"))

    def _ask_mail(self):
        contact_utils.open_gmail(mt.license_subject(), self._request_text("mail"))

    def _activate(self):
        ok, message = lm.activate(self.key.toPlainText())
        if ok:
            show_info(self, "تم التفعيل", message)
            self.choice = "activated"
            self.accept()
        else:
            show_warning(self, "تعذّر التفعيل", message)

    def _retry(self):
        self.choice = "retry"
        self.accept()

    def _readonly(self):
        self.choice = "readonly"
        self.accept()

    def _exit(self):
        self.choice = "exit"
        self.reject()

    def reject(self):                       # إغلاق النافذة بزر X عند بدء التشغيل = خروج
        if self.startup and self.choice == "closed":
            self.choice = "exit"
        super().reject()


class TrialStartDialog(QDialog):
    """نافذة أول تشغيل: بريد + رمز تحقق. تظهر فقط إذا فعّل الخادم REQUIRE_OTP."""

    def __init__(self, st=None, parent=None):
        super().__init__(parent)
        self.choice = "closed"
        self.setWindowTitle("بدء النسخة التجريبية")
        self.setLayoutDirection(Qt.RightToLeft)
        self.setMinimumWidth(480)
        self.setStyleSheet("""
            QDialog { background: #f8f9ff; } QLabel { color: #1f2347; }
            QLineEdit { background: white; border: 1px solid #cdd3ee; border-radius: 6px; padding: 8px; }
        """)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 14)
        root.setSpacing(10)
        head = QFrame()
        head.setStyleSheet("QFrame { background: %s; } QLabel { background: transparent; color: white; }" % NAVY)
        hl = QHBoxLayout(head)
        hl.setContentsMargins(22, 14, 22, 14)
        icon = QLabel()
        icon.setPixmap(qta.icon("fa5s.envelope-open-text", color="white").pixmap(28, 28))
        title = QLabel("ابدأ نسختك التجريبية المجانية")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: white;")
        hl.addWidget(icon)
        hl.addWidget(title)
        hl.addStretch(1)
        root.addWidget(head)

        body = QVBoxLayout()
        body.setContentsMargins(22, 4, 22, 0)
        body.setSpacing(10)
        root.addLayout(body)
        reason = (st or {}).get("reason")
        text = {"otp_invalid": "الرمز غير صحيح. تأكد منه أو اطلب رمزاً جديداً.",
                "otp_locked": "تجاوزت عدد المحاولات. اطلب رمزاً جديداً بعد قليل.",
                "bad_email": "البريد غير صالح أو غير مقبول. استعمل بريداً حقيقياً."}.get(
            reason, "أدخل بريدك الإلكتروني ثم الرمز المرسَل إليه لبدء الفترة التجريبية (مرة واحدة فقط).")
        msg = QLabel(text)
        msg.setWordWrap(True)
        msg.setStyleSheet("font-size: 13px; padding: 6px; border-right: 4px solid #5a4ee3;")
        body.addWidget(msg)

        self.email = QLineEdit(lm._IDENTITY.get("email") or "")
        self.email.setPlaceholderText("name@example.com")
        self.email.setLayoutDirection(Qt.LeftToRight)
        body.addWidget(QLabel("البريد الإلكتروني:"))
        body.addWidget(self.email)
        send = QPushButton("  إرسال الرمز إلى بريدي")
        send.setIcon(qta.icon("fa5s.paper-plane", color="white"))
        send.setMinimumHeight(38)
        send.setCursor(Qt.PointingHandCursor)
        send.setStyleSheet("QPushButton { background: #5a4ee3; color: white; border: none; border-radius: 6px;"
                           " padding: 6px 16px; font-weight: bold; } QPushButton:hover { background: #1f2347; }")
        send.clicked.connect(self._send)
        body.addWidget(send)

        self.code = QLineEdit()
        self.code.setMaxLength(6)
        self.code.setPlaceholderText("000000")
        self.code.setAlignment(Qt.AlignCenter)
        self.code.setLayoutDirection(Qt.LeftToRight)
        self.code.setStyleSheet("font-size: 20px; letter-spacing: 6px; font-weight: bold;")
        body.addWidget(QLabel("رمز التحقق (6 أرقام):"))
        body.addWidget(self.code)

        foot = QHBoxLayout()
        ok = QPushButton("  تأكيد وبدء التجربة")
        ok.setIcon(qta.icon("fa5s.check-circle", color="white"))
        ok.setMinimumHeight(38)
        ok.setCursor(Qt.PointingHandCursor)
        ok.setStyleSheet("QPushButton { background: #128456; color: white; border: none; border-radius: 6px;"
                         " padding: 6px 16px; font-weight: bold; } QPushButton:hover { background: #1f2347; }")
        ok.clicked.connect(self._confirm)
        ex = QPushButton("خروج")
        ex.setMinimumHeight(38)
        ex.clicked.connect(self._exit)
        foot.addWidget(ok, 1)
        foot.addWidget(ex)
        body.addLayout(foot)

    def _send(self):
        done, message = lm.request_otp(self.email.text())
        (show_info if done else show_warning)(self, "رمز التحقق", message)

    def _confirm(self):
        if not self.email.text().strip() or len(self.code.text().strip()) < 4:
            show_warning(self, "بيانات ناقصة", "أدخل البريد والرمز المرسَل إليه.")
            return
        lm.set_trial_identity(self.email.text(), self.code.text())
        self.choice = "continue"
        self.accept()

    def _exit(self):
        self.choice = "exit"
        self.reject()

    def reject(self):
        if self.choice == "closed":
            self.choice = "exit"
        super().reject()


def startup_check(parent=None):
    """يُستدعى عند بدء البرنامج. يرجع False إن اختار المستخدم الخروج."""
    ok, why = integrity.check()
    if not ok:
        show_warning(parent, "سلامة البرنامج",
                     "تم اكتشاف تعديل في ملفات البرنامج (%s).\nأعد تثبيت البرنامج من المصدر الأصلي أو تواصل مع المطوّر:\n%s"
                     % (why, app_info.DEVELOPER_EMAIL))
        return False
    while True:
        st = lm.evaluate()
        s = st["state"]
        if s == "need_otp":
            tdlg = TrialStartDialog(st, parent=parent)
            tdlg.exec_()
            if tdlg.choice == "continue":
                continue
            return False
        if s in ("trial", "licensed"):
            if st.get("first_run"):
                LicenseDialog(st, parent=parent).exec_()      # نافذة أول تشغيل: بدأت التجربة + رمز الجهاز
                return True
            left = st["days_left"]
            if left is not None and left <= lm.REMIND_DAYS:
                what = "الفترة التجريبية" if s == "trial" else "الترخيص"
                show_info(parent, "تذكير",
                          "تبقّى %d يوماً على انتهاء %s.\nللتفعيل أو التجديد تواصل معي:\n%s\n%s\n"
                          "(مساعدة ← الترخيص والتفعيل)"
                          % (left, what, app_info.DEVELOPER_PHONE, app_info.DEVELOPER_EMAIL))
            return True
        dlg = LicenseDialog(st, startup=True, parent=parent)
        dlg.exec_()
        if dlg.choice == "retry":
            continue
        if dlg.choice == "activated":
            return True
        if dlg.choice == "readonly":
            lm.set_read_only(True)
            return True
        return False


def guard_tick(parent=None):
    """يُستدعى من مؤقّت دوري: تحقق الخادم في الخلفية، وعند تغيّر الحالة (حظر/انتهاء) يُحوَّل البرنامج للقراءة فقط."""
    try:
        import hardening
        ok, _why = integrity.check()
        if not ok or hardening.tampered_runtime():
            lm.set_read_only(True)
            return
        lm.start_background_check()
        r = lm.take_background_result()
    except Exception:
        return
    if r and r["state"] in ("blocked", "expired", "tampered", "need_online"):
        lm.set_read_only(True)
        LicenseDialog(r, startup=False, parent=parent).exec_()
