from msgbox_ltr import show_warning
import os
import platform
import subprocess
import storage
import qtawesome as qta
from table_filter import TableFilterBar
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QTextEdit, QPushButton, QComboBox, QTableWidget, QTableWidgetItem,
    QDateEdit, QMessageBox, QHeaderView, QFileDialog, QSpinBox
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt, QDate, QSize


class AttendanceVisitPage(QWidget):
    def __init__(self, case_page, document_page=None):
        super().__init__()
        self.case_page = case_page
        self.document_page = document_page
        self.visit_reports = [] # تخزين المحاضر محليًا
        self.report_file_path =""# مسار محضر الانتقال المرفق

        self.setStyleSheet("background-color: #f1f2ff;")
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(20, 20, 20, 20)
        self.layout.setSpacing(15)

        title = QLabel("محاضر الانتقال إلى موقع النزاع")
        title.setFont(QFont("Segoe UI", 16, QFont.Bold))
        title.setStyleSheet("color: #1f2347;")
        self.layout.addWidget(title)

        self.init_form()
        self.init_table()
        self.load_visits_data()

    def showEvent(self, event):
        self.update_case_list()
        super().showEvent(event)

    def reload(self):
        """إعادة تحميل بيانات محاضر الانتقال (تُستدعى عند تفعيل التبويب)."""
        self.update_case_list()
        self.load_visits_data()

    def load_visits_data(self):
        self.visit_reports = storage.load_visits()
        self.table.setRowCount(0)
        for report in self.visit_reports:
            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(report.get("case", "")))
            self.table.setItem(row, 1, QTableWidgetItem(report.get("location", "")))
            self.table.setItem(row, 2, QTableWidgetItem(report.get("date", "")))
            self.table.setItem(row, 3, QTableWidgetItem(report.get("notes", "")))
            file_path = report.get("file", "")
            self.table.setItem(row, 4, QTableWidgetItem(
                os.path.basename(file_path) if file_path else"لم يُرفق"
            ))
        if hasattr(self, "filter_bar"):
            self.filter_bar.refresh()

    def save_visits_data(self):
        storage.save_visits(self.visit_reports)

    def update_case_list(self):
        self.case_combo.clear()
        self.case_combo.addItem("اختر القضية")
        for row in range(self.case_page.table.rowCount()):
            case_number = self.case_page.table.item(row, 0).text()
            self.case_combo.addItem(case_number)

    def init_form(self):
        form_layout = QHBoxLayout()

        # البلدية
        self.location_input = QLineEdit()
        self.location_input.setPlaceholderText(" المدعى عليه")
        self.location_input.setMinimumWidth(150)
        form_layout.addWidget(QLabel("المدعي عليه:"))
        form_layout.addWidget(self.location_input)

         # رقم القضية
        self.case_combo = QComboBox()
        self.case_combo.setMinimumWidth(150)
        form_layout.addWidget(QLabel("رقم القضية:"))
        form_layout.addWidget(self.case_combo)
        

        # التاريخ
        self.date_edit = QDateEdit()
        self.date_edit.setCalendarPopup(True)
        self.date_edit.setDate(QDate.currentDate())
        form_layout.addWidget(QLabel("تاريخ الانتقال:"))
        form_layout.addWidget(self.date_edit)
        

        self.layout.addLayout(form_layout)

        # ملاحظات
        self.notes_edit = QTextEdit()
        self.notes_edit.setPlaceholderText("ملاحظات حول الانتقال...")
        self.notes_edit.setFixedHeight(100)
        self.layout.addWidget(self.notes_edit)

        # التحكم في حجم خط المحضر عند الطباعة
        font_row = QHBoxLayout()
        font_row.addWidget(QLabel("حجم خط المحضر عند الطباعة:"))
        self.font_size_spin = QSpinBox()
        self.font_size_spin.setRange(12, 36)
        self.font_size_spin.setValue(19)
        self.font_size_spin.setSuffix(" px")
        font_row.addWidget(self.font_size_spin)
        font_row.addStretch()
        self.layout.addLayout(font_row)

        # زر اعداد محضر
        generate_btn = QPushButton("إعداد محضر الانتقال")
        generate_btn.setIcon(qta.icon("fa5s.file-signature", color="white"))
        generate_btn.setIconSize(QSize(18, 18))
        generate_btn.setStyleSheet("""
            QPushButton {
                background-color: #128456;
                color: white;
                padding: 10px;
                border-radius: 6px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #128456;
            }
        """)
        generate_btn.clicked.connect(self.generate_visit_report)
        self.layout.addWidget(generate_btn)

        # زر إرفاق محضر جاهز (مسح ضوئي أو ملف موجود) قبل الحفظ
        self.attach_file_btn = QPushButton("إرفاق محضر")
        self.attach_file_btn.setIcon(qta.icon("fa5s.paperclip", color="#4338ca"))
        from scan_utils import attach_menu_for_button
        self._attach_menu = attach_menu_for_button(
            self.attach_file_btn, self,
            on_scan=self.scan_report_file,
            on_pick_file=self.upload_report_file,
        )
        self.layout.addWidget(self.attach_file_btn)

        # زر حفظ
        save_btn = QPushButton("حفظ المحضر")
        save_btn.setIcon(qta.icon("fa5s.save", color="white"))
        save_btn.setIconSize(QSize(18, 18))
        save_btn.setStyleSheet("""
            QPushButton {
                background-color: #5a4ee3;
                color: white;
                padding: 10px;
                font-weight: bold;
                border-radius: 8px;
            }
            QPushButton:hover {
                background-color: #5a4ee3;
            }
        """)
        save_btn.clicked.connect(self.save_report)
        self.layout.addWidget(save_btn)

    def init_table(self):
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["القضية", "المدعي عليه", "تاريخ الانتقال", "ملاحظات", "ملف المحضر"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setStyleSheet("background-color: white;")
        self.table.cellDoubleClicked.connect(self.open_attached_report)
        self.filter_bar = TableFilterBar(
            self.table, [(0, "كل القضايا"), (1, "كل المدعى عليهم")],
            "ابحث في المحاضر...",
        )
        self.layout.addWidget(self.filter_bar)
        self.layout.addWidget(self.table)

    def upload_report_file(self):
        file, _ = QFileDialog.getOpenFileName(self, "اختر ملف محضر الانتقال", "", "PDF Files (*.pdf);;All Files (*)")
        if file:
            self._set_report_file(file)

    def scan_report_file(self):
        from scan_utils import scan_document
        file = scan_document(self, suggested_name="محضر_انتقال")
        if file:
            self._set_report_file(file)

    def _set_report_file(self, file):
        self.report_file_path = file
        self.attach_file_btn.setText(os.path.basename(file) + "")

    def save_report(self):
        case = self.case_combo.currentText()
        location = self.location_input.text().strip()
        date = self.date_edit.date().toString("yyyy-MM-dd")
        notes = self.notes_edit.toPlainText().strip()

        if case == "اختر القضية" or not location:
            show_warning(self, "خطأ", "يرجى اختيار رقم القضية وكتابة اسم البلدية.")
            return

        report = {
            "case": case,
            "location": location,
            "date": date,
            "notes": notes,
            "file": self.report_file_path if self.report_file_path else ""
        }
        self.visit_reports.append(report)

        # إضافة للسطر الجديد في الجدول
        row = self.table.rowCount()
        self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(case))
        self.table.setItem(row, 1, QTableWidgetItem(location))
        self.table.setItem(row, 2, QTableWidgetItem(date))
        self.table.setItem(row, 3, QTableWidgetItem(notes))
        self.table.setItem(row, 4, QTableWidgetItem(
            os.path.basename(self.report_file_path) if self.report_file_path else"لم يُرفق"
        ))

        # إعادة تعيين الحقول
        self.location_input.clear()
        self.notes_edit.clear()
        self.date_edit.setDate(QDate.currentDate())
        self.report_file_path = ""
        self.attach_file_btn.setText("إرفاق محضر")

        # حفظ دائم في تخزين الملف (Dossier) الحالي
        self.save_visits_data()

        self.filter_bar.clear()      # لتظهر الصفوف كلها بما فيها الجديد
        self.filter_bar.refresh()

    def open_attached_report(self, row, column):
        if column != 4:
            return

        filename = self.table.item(row, 4).text()
        if filename and filename !="لم يُرفق":
            try:
                file_path = self.visit_reports[row]["file"]
                import safe_open
                safe_open.open_path(file_path)
            except Exception as e:
                show_warning(self, "خطأ", f"تعذر فتح الملف:\n{e}")
    def generate_visit_report(self):

        date = self.date_edit.date().toString("yyyy-MM-dd")
        location = self.location_input.text()

        expert_info = storage.load_expert_info()
        expert_name = expert_info.get("name", "")

        intro_text = f"""
        بتاريخ {date} انتقلنا نحن الأستاذ {expert_name} إلى مقر {location}
        """

        data = {
          "expert_name": expert_name,
          "expert_address": expert_info.get("address", ""),
          "expert_phone": expert_info.get("phone", ""),
          "expert_fax": expert_info.get("fax", ""),
          "date": date,
          "intro_text": intro_text,
          "notes": self.notes_edit.toPlainText(),
          "font_size": self.font_size_spin.value(),
        }

        from generate_visit import generate_visit_report
        html_file, pdf_file = generate_visit_report(data)

        from report_viewer import ReportViewer
        self.viewer = ReportViewer(html_file, pdf_file=pdf_file, title="معاينة محضر الانتقال")
        self.viewer.show()