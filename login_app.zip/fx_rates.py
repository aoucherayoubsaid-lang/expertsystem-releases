# -*- coding: utf-8 -*-
"""جدول أسعار الصرف (يملؤه الخبير من مصدره الرسمي) والبحث فيه بالتاريخ.

- السعر = كم دينار جزائري (DZD) مقابل وحدة واحدة من العملة الأجنبية.
- النموذج لا يذكر أي سعر صرف أبداً: كل التحويلات تأتي من هذا الجدول فقط.
- إن لم يوجد سعر بتاريخ الواقعة يؤخذ آخر سعر قبلها بحد أقصى MAX_GAP_DAYS (عطل نهاية الأسبوع)، ويُذكر ذلك
  صراحةً في نتيجة الحساب. وإن لم يوجد يفشل الحساب برسالة واضحة بدل تخمين سعر.
"""
import csv
import json
import os
import re
import unicodedata
from datetime import date, datetime, timedelta

MAX_GAP_DAYS = 7
_ALIASES = {"DA": "DZD", "DZD": "DZD", "DINAR": "DZD", "دج": "DZD", "دينار": "DZD",
            "€": "EUR", "EUR": "EUR", "EURO": "EUR", "اورو": "EUR", "أورو": "EUR", "يورو": "EUR",
            "$": "USD", "USD": "USD", "دولار": "USD", "£": "GBP", "GBP": "GBP"}
_DATE_FORMATS = ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y")


def norm_currency(c):
    s = str(c or "").strip().upper().replace(".", "").replace(" ", "")
    return _ALIASES.get(s, s)


def parse_date(s):
    s = str(s or "").strip()
    for f in _DATE_FORMATS:
        try:
            return datetime.strptime(s, f).date()
        except ValueError:
            continue
    raise ValueError("تاريخ غير مفهوم: «%s» (المطلوب YYYY-MM-DD)" % s)


def _path():
    import storage
    return os.path.join(storage.APP_DATA_DIR, "fx_rates.json")


def load():
    """{'EUR': {'2024-03-15': 145.23}, ..., '__meta__': {'source': '...'}}"""
    try:
        with open(_path(), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def get_source(rates):
    return str(((rates or {}).get("__meta__") or {}).get("source", "")).strip()


def set_source(rates, text):
    rates["__meta__"] = {"source": str(text or "").strip()}


def currencies(rates):
    return sorted(k for k in (rates or {}) if not k.startswith("__"))


def save(rates):
    p = _path()
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(rates, f, ensure_ascii=False, indent=1, sort_keys=True)


def set_rate(rates, currency, d, rate):
    cur = norm_currency(currency)
    if cur in ("", "DZD"):
        raise ValueError("العملة غير صالحة للجدول")
    r = float(rate)
    if r <= 0:
        raise ValueError("السعر يجب أن يكون موجباً")
    rates.setdefault(cur, {})[d.isoformat()] = r


def get_rate(rates, currency, d, max_gap_days=MAX_GAP_DAYS):
    """يرجع (السعر, التاريخ_المستعمل). يرفع ValueError إن لم يوجد."""
    cur = norm_currency(currency)
    if cur in ("", "DZD"):
        return 1.0, d
    table = (rates or {}).get(cur) or {}
    for k in range(max_gap_days + 1):
        day = d - timedelta(days=k)
        v = table.get(day.isoformat())
        if v:
            return float(v), day
    raise ValueError("لا يوجد سعر صرف %s بتاريخ %s (ولا خلال %d أيام قبله) في جدول الأسعار. "
                     "أضفه من «أسعار الصرف»." % (cur, d.isoformat(), max_gap_days))


def _num(s):
    s = str(s).strip().replace(" ", "").replace("\u00a0", "").replace("\u202f", "")
    if "," in s and "." not in s:
        s = s.replace(",", ".")
    elif "," in s and "." in s:
        s = s.replace(",", "") if s.rfind(".") > s.rfind(",") else s.replace(".", "").replace(",", ".")
    return float(s)


def _cell_num(v):
    if isinstance(v, bool):
        raise ValueError("ليس رقماً")
    if isinstance(v, (int, float)):
        return float(v)
    return _num(v)


def _cell_date(v):
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    return parse_date(v)


# أسماء شائعة لرؤوس الأعمدة -> رمز ISO
_NAMES = {"DOLLARUS": "USD", "DOLLARAMERICAIN": "USD", "USDOLLAR": "USD", "DOLLARDESETATSUNIS": "USD",
          "EURO": "EUR", "LIVRESTERLING": "GBP", "LIVRE": "GBP", "DOLLARCANADIEN": "CAD",
          "FRANCSUISSE": "CHF", "YENJAPONAIS": "JPY", "YEN": "JPY", "DIRHAMEMIRATI": "AED"}


def _header_code(v):
    s = unicodedata.normalize("NFD", str(v or "")).upper()
    s = "".join(ch for ch in s if unicodedata.category(ch) != "Mn")
    s = re.sub(r"[^A-Z]", "", s)
    if s in _NAMES:
        return _NAMES[s]
    if re.fullmatch(r"[A-Z]{3}", s) and s != "DZD":
        return s
    return None


_PAIR = re.compile(r"^\s*(?:(\d+(?:[.,]\d+)?)\s*)?([A-Za-z]{3})\s*/\s*DZD\s*$", re.IGNORECASE)


def _import_pair_sheet(rows, rates):
    """ورقة لعملة واحدة (تخطيط أرشيف بنك الجزائر): عنوان مثل «EUR / DZD» أو «100 JPY / DZD»،
    ثم أسطر (تاريخ، سعر). الرقم قبل الرمز هو عدد الوحدات التي يُقاس بها السعر (100 ين)،
    فيُقسَّم السعر عليه ليصير سعر وحدة واحدة. يرجع None إن لم تكن الورقة بهذا التخطيط."""
    code, mult = None, 1.0
    for r in rows[:10]:
        for c in r:
            m = _PAIR.match(str(c)) if c is not None else None
            if m:
                code = m.group(2).upper()
                if m.group(1):
                    mult = max(mult, float(m.group(1).replace(",", ".")))
    if not code or code == "DZD":
        return None
    added, errors = 0, []
    for n, r in enumerate(rows, 1):
        if not r:
            continue
        try:
            d = _cell_date(r[0])
        except (ValueError, TypeError):
            continue
        val = next((x for x in r[1:] if x not in (None, "") and not isinstance(x, (datetime, date))), None)
        if val is None:
            continue                                   # يوم بلا سعر
        try:
            set_rate(rates, code, d, _cell_num(val) / mult)
            added += 1
        except Exception as e:
            errors.append("%s السطر %d: %s" % (code, n, e))
    return added, errors


def coverage(rates):
    """[(عملة, أول_تاريخ, آخر_تاريخ, عدد_الأيام)] لكل عملة في الجدول."""
    out = []
    for cur in currencies(rates):
        days = sorted(rates[cur])
        if days:
            out.append((cur, days[0], days[-1], len(days)))
    return out


def last_date(rates):
    ends = [c[2] for c in coverage(rates)]
    return max(ends) if ends else ""


def _import_rows(rows, rates):
    """جدول واحد: ورقة عملة (أرشيف البنك) أو عريض (تاريخ + عمود لكل عملة) أو طويل (تاريخ، عملة، سعر)."""
    pair = _import_pair_sheet(rows, rates)
    if pair is not None:
        return pair
    added, errors = 0, []
    for h in range(min(25, len(rows))):
        cols = [(j, _header_code(c)) for j, c in enumerate(rows[h]) if _header_code(c)]
        if len(cols) >= 2:                                   # ---- عريض ----
            codes = {j for j, _ in cols}
            dcol = None
            for j in range(len(rows[h])):
                if j in codes:
                    continue
                for r in rows[h + 1:h + 6]:
                    try:
                        _cell_date(r[j])
                        dcol = j
                        break
                    except (ValueError, IndexError):
                        continue
                if dcol is not None:
                    break
            if dcol is None:
                errors.append("لم أجد عمود التواريخ بجانب أعمدة العملات")
                return added, errors
            for n, r in enumerate(rows[h + 1:], h + 2):
                try:
                    d = _cell_date(r[dcol])
                except (ValueError, IndexError):
                    continue
                for j, code in cols:
                    if j < len(r) and r[j] not in (None, ""):
                        try:
                            set_rate(rates, code, d, _cell_num(r[j]))
                            added += 1
                        except Exception as e:
                            errors.append("السطر %d (%s): %s" % (n, code, e))
            return added, errors
    for n, r in enumerate(rows, 1):                          # ---- طويل ----
        if len(r) < 3 or not any(str(x or "").strip() for x in r):
            continue
        try:
            d = _cell_date(r[0])
        except ValueError:
            if n == 1:
                continue
            errors.append("السطر %d: تاريخ غير مفهوم «%s»" % (n, r[0]))
            continue
        try:
            set_rate(rates, r[1], d, _cell_num(r[2]))
            added += 1
        except Exception as e:
            errors.append("السطر %d: %s" % (n, e))
    return added, errors


def import_table(path, rates):
    """يستورد CSV أو Excel (xlsx). يرجع (عدد_المضاف, أخطاء). يفهم الشكلين:
    عريض (عمود تاريخ + عمود لكل عملة برمزها أو اسمها) وطويل (التاريخ، العملة، السعر)."""
    ext = os.path.splitext(path)[1].lower()
    tables = []
    if ext in (".xlsx", ".xlsm"):
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        for ws in wb.worksheets:
            tables.append([list(r) for r in ws.iter_rows(values_only=True)])
        wb.close()
    elif ext in (".csv", ".txt", ".tsv"):
        with open(path, "r", encoding="utf-8-sig", newline="") as f:
            text = f.read()
        delim = max(",;\t", key=text[:2000].count)
        tables.append([row for row in csv.reader(text.splitlines(), delimiter=delim)])
    else:
        raise ValueError("صيغة غير مدعومة: %s (المدعوم CSV وxlsx)" % ext)
    added, errors = 0, []
    for rows in tables:
        a, e = _import_rows(rows, rates)
        added += a
        errors += e
    if added == 0 and not errors:
        errors.append("لم أتعرف على تخطيط الملف. أرسل لي أول 10 أسطر منه لأضبط الاستيراد.")
    return added, errors


import_csv = import_table          # للتوافق مع الاستدعاءات القديمة
