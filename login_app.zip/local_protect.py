# -*- coding: utf-8 -*-
"""حماية ملفات الأمان المحلية من التعديل (users.json وsettings.json وsecurity.json) وحماية أسرار الجهاز.

ما يفعله:
  * مفتاح رئيسي عشوائي (32 بايت) يُخزَّن في app_data/.es_mk محميّاً بـ DPAPI على ويندوز
    (مرتبط بحساب ويندوز الحالي وبالجهاز؛ نسخ الملف إلى جهاز/حساب آخر لا يفيد).
  * كل ملف محمي له توقيع HMAC-SHA256 في ملف جانبي <اسم الملف>.sig. أي تعديل بمحرر نصوص
    (تغيير دور إلى admin، تعطيل كلمة بدء التشغيل...) يُكتشف فيُرفض الملف (فشل مغلق).
  * «الختم»: أسماء الملفات التي وُقِّعت مرة تُسجَّل في سجل ويندوز (HKCU) خارج مجلد البيانات.
    فحذف الملف أو توقيعه (لإعادة إنشاء admin/admin123 أو تصفير عدّاد القفل) يُكتشف أيضاً.
  * protect()/unprotect(): تغليف أسرار (مثل المفتاح الخاص .es_dk) بـ DPAPI.

حدود صريحة:
  * من يملك حساب ويندوز نفسه يستطيع استدعاء DPAPI؛ هذه الطبقة تمنع التعديل من محرر نصوص أو من
    مجلد مشترك أو من جهاز/حساب آخر، لا من مالك الحساب المصمم لكسر البرنامج.
  * خارج ويندوز (للتطوير والاختبار) يُحفظ المفتاح في ملف بصلاحية 600 دون DPAPI.
  * الحل المكمّل في النشر: صلاحيات NTFS على app_data (حساب المستخدم فقط) أو BitLocker.
"""
import base64
import hashlib
import hmac
import json
import os
import secrets
import sys

import app_paths

# مجلد ملفات «هذا الجهاز»: المفتاح الرئيسي المحمي بـ DPAPI وبديل الختم. في وضع المجلد المشترك يكون محلياً
# دائماً (خارج المجلد المشترك)، وفي وضع الجهاز الواحد هو app_data نفسه.
DATA_DIR = None                                         # None = app_paths.machine_dir() (يُحسب عند الطلب)؛ الاختبارات تضبطه
SHARED_DIR = None                                       # مجلد الملفات الموقَّعة؛ None = يُحسب من الوضع (أو DATA_DIR)
SHARED_DESCRIPTOR = ".es_shared.json"
KEY_FILE = ".es_mk"
META_FILE = ".es_meta"                                  # بديل سجل ويندوز خارج ويندوز
_REG_PATH = r"Software\ExpertSystem\Integrity"
_ENTROPY = b"ExpertSystem-local-protect-v1"
_DPAPI_TAG = b"DPAPI1:"
_PLAIN_TAG = b"PLAIN0:"

_cache = {"key": None}


def _data_dir():
    return DATA_DIR or app_paths.machine_dir()
_tamper = {"flag": False, "reasons": []}


class IntegrityError(Exception):
    """ملف أمان معدَّل أو مفقود أو لا يمكن التحقق منه."""


class PassphraseRequired(Exception):
    """وضع المجلد المشترك: هذا الجهاز لا يملك المفتاح بعد. اطلب عبارة المرور واستدعِ unlock_shared().
    ليست IntegrityError عمداً: غياب المفتاح هنا ليس عبثاً ولا يجوز أن يُعامل كذلك."""


# ---------------------------------------------------------------------------
# DPAPI (ويندوز فقط)
# ---------------------------------------------------------------------------
def dpapi_available():
    return os.name == "nt"


def _dpapi(data, protect):
    import ctypes
    from ctypes import wintypes

    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    def mk(b):
        buf = ctypes.create_string_buffer(b, len(b))
        return BLOB(len(b), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), buf

    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    src, keep1 = mk(data)
    ent, keep2 = mk(_ENTROPY)
    out = BLOB()
    CRYPTPROTECT_UI_FORBIDDEN = 0x1
    if protect:
        ok = crypt32.CryptProtectData(ctypes.byref(src), None, ctypes.byref(ent), None, None,
                                      CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(out))
    else:
        ok = crypt32.CryptUnprotectData(ctypes.byref(src), None, ctypes.byref(ent), None, None,
                                        CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(out))
    if not ok:
        raise OSError("DPAPI failed")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        kernel32.LocalFree(out.pbData)


def protect(data: bytes):
    """يغلّف بايتات بـ DPAPI. يرجع None خارج ويندوز أو عند الفشل (المستدعي يقرر البديل)."""
    if not dpapi_available():
        return None
    try:
        return _DPAPI_TAG + base64.b64encode(_dpapi(data, True))
    except Exception:
        return None


def is_protected_blob(blob: bytes):
    return bool(blob) and blob.startswith(_DPAPI_TAG)


def unprotect(blob: bytes):
    """يفك تغليف DPAPI؛ يرفع IntegrityError إن كان من جهاز/حساب آخر."""
    if not is_protected_blob(blob):
        raise IntegrityError("not a protected blob")
    if not dpapi_available():
        raise IntegrityError("DPAPI unavailable on this platform")
    try:
        return _dpapi(base64.b64decode(blob[len(_DPAPI_TAG):]), False)
    except Exception as exc:
        raise IntegrityError("cannot unprotect (other machine/account?)") from exc


# ---------------------------------------------------------------------------
# بيانات الختم (أي الملفات وُقِّعت سابقاً) خارج مجلد البيانات
# ---------------------------------------------------------------------------
def _meta_path():
    return os.path.join(_data_dir(), META_FILE)


def _meta_get():
    if os.name == "nt":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _REG_PATH) as k:
                return set(filter(None, str(winreg.QueryValueEx(k, "files")[0]).split(",")))
        except Exception:
            return set()
    try:
        with open(_meta_path(), "r", encoding="utf-8") as f:
            return set(json.load(f))
    except Exception:
        return set()


def _meta_add(name):
    names = _meta_get()
    if name in names:
        return
    names.add(name)
    if os.name == "nt":
        try:
            import winreg
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, _REG_PATH) as k:
                winreg.SetValueEx(k, "files", 0, winreg.REG_SZ, ",".join(sorted(names)))
            return
        except Exception:
            pass
    try:
        os.makedirs(_data_dir(), exist_ok=True)
        with open(_meta_path(), "w", encoding="utf-8") as f:
            json.dump(sorted(names), f)
    except OSError:
        pass


def _meta_clear():
    if os.name == "nt":
        try:
            import winreg
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, _REG_PATH)
        except Exception:
            pass
    try:
        os.remove(_meta_path())
    except OSError:
        pass


def flag_get(name):
    return ("flag:" + name) in _meta_get()


def flag_set(name):
    _meta_add("flag:" + name)


# ---------------------------------------------------------------------------
# المفتاح الرئيسي
# ---------------------------------------------------------------------------
def _key_path():
    return os.path.join(_data_dir(), KEY_FILE)


def master_key():
    """يرجع المفتاح الرئيسي. إن وُجد ملف المفتاح ولم يُفك (جهاز/حساب آخر) يرفع IntegrityError
    ولا يولّد مفتاحاً جديداً، حتى لا يُستبدل الختم بصمت."""
    if _cache["key"]:
        return _cache["key"]
    path = _key_path()
    if os.path.exists(path):
        try:
            with open(path, "rb") as f:
                blob = f.read().strip()
            if blob.startswith(_PLAIN_TAG):
                key = base64.b64decode(blob[len(_PLAIN_TAG):])
            else:
                key = unprotect(blob)
        except IntegrityError:
            raise
        except Exception as exc:
            raise IntegrityError("master key unreadable") from exc
        if len(key) != 32:
            raise IntegrityError("master key corrupt")
        _cache["key"] = key
        return key
    if app_paths.data_mode() == "shared":
        # لا نولّد مفتاحاً عشوائياً محلياً أبداً في الوضع المشترك: المفتاح يُشتق من عبارة المرور فقط
        raise PassphraseRequired(shared_state())
    if _meta_get():
        # كان هناك ختم سابق لكن ملف المفتاح اختفى: حذف متعمَّد أو نقل غير سليم
        raise IntegrityError("master key missing while sealed")
    key = secrets.token_bytes(32)
    blob = protect(key)
    if blob is None:
        blob = _PLAIN_TAG + base64.b64encode(key)
    os.makedirs(_data_dir(), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(blob)
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    os.replace(tmp, path)
    _cache["key"] = key
    return key


def derived_key(purpose: str) -> bytes:
    """مفتاح فرعي لغرض معيّن (توقيع الملفات، سلسلة التدقيق، حالة الترخيص...)."""
    return hmac.new(master_key(), ("purpose|" + purpose).encode("utf-8"), hashlib.sha256).digest()


# ---------------------------------------------------------------------------
# التوقيع والتحقق
# ---------------------------------------------------------------------------
def _sig_path(path):
    return path + ".sig"


def _mac(name, data: bytes) -> str:
    return hmac.new(derived_key("file"), name.encode("utf-8") + b"\0" + data, hashlib.sha256).hexdigest()


def note_tamper(reason):
    _tamper["flag"] = True
    if reason not in _tamper["reasons"]:
        _tamper["reasons"].append(reason)
    try:
        import security_manager
        security_manager.audit("TAMPER_DETECTED", "", "blocked", {"reason": reason})
    except Exception:
        pass


def tamper_detected():
    return _tamper["flag"]


def tamper_reasons():
    return list(_tamper["reasons"])


def clear_tamper_state():
    _tamper["flag"] = False
    _tamper["reasons"] = []


def sign_file(path):
    """يوقّع محتوى الملف الحالي ويختمه. يُستدعى بعد كل كتابة مشروعة."""
    name = os.path.basename(path)
    with open(path, "rb") as f:
        data = f.read()
    sig = _mac(name, data)
    tmp = _sig_path(path) + ".tmp"
    with open(tmp, "w", encoding="ascii") as f:
        f.write(sig)
    os.replace(tmp, _sig_path(path))
    _meta_add(name)


def read_verified(path):
    """يقرأ بايتات ملف محمي بعد التحقق من توقيعه.

    يرجع None إن لم يكن الملف موجوداً وكان وجوده غير مُلزِم (تشغيل أول).
    يرفع IntegrityError عند التعديل أو الحذف بعد الختم أو تعذّر فك المفتاح.
    """
    name = os.path.basename(path)
    sealed = name in _meta_get()
    try:
        exists = os.path.exists(path)
        if not exists:
            if sealed:
                raise IntegrityError("%s missing after seal" % name)
            return None
        with open(path, "rb") as f:
            data = f.read()
        sp = _sig_path(path)
        if not os.path.exists(sp):
            if sealed:
                raise IntegrityError("%s signature missing" % name)
            # ترقية من نسخة قديمة بلا توقيع: نتبنّى المحتوى الحالي مرة واحدة ونختمه
            sign_file(path)
            return data
        with open(sp, "r", encoding="ascii", errors="ignore") as f:
            stored = f.read().strip()
        if not hmac.compare_digest(stored, _mac(name, data)):
            raise IntegrityError("%s modified" % name)
        if not sealed:
            _meta_add(name)          # جهاز جديد على بيانات مشتركة: من الآن حذف الملف يُعدّ عبثاً هنا أيضاً
        return data
    except IntegrityError as exc:
        note_tamper(str(exc))
        raise


# ---------------------------------------------------------------------------
# إعادة الختم (مسار استرداد صريح: نقل التطبيق لجهاز جديد، أو بعد تحقق المالك من الملفات)
# ---------------------------------------------------------------------------
def reseal_all(names=("users.json", "settings.json", "security.json")):
    """يحذف المفتاح والأختام القديمة ويتبنّى الملفات الحالية كما هي. استعمله فقط إن كنت
    واثقاً أن محتوى الملفات سليم (وإلا استرجع نسخة احتياطية أولاً)."""
    shared = app_paths.data_mode() == "shared"
    if not shared:
        # الوضع المشترك: المفتاح مشتق من عبارة المرور ولا يُستبدل بعشوائي (وإلا فقدت بقية الأجهزة القدرة على التحقق)
        _cache["key"] = None
        for fn in (KEY_FILE, KEY_FILE + ".tmp"):
            try:
                os.remove(os.path.join(_data_dir(), fn))
            except OSError:
                pass
    _meta_clear()
    clear_tamper_state()
    master_key()
    return _sign_existing(names)


def _sign_existing(names=("users.json", "settings.json", "security.json")):
    done = []
    for n in names:
        # security.json خاص بالجهاز (مجلد الجهاز)، والباقي في المجلد المشترك
        folder = _data_dir() if n == "security.json" else _shared_dir()
        p = os.path.join(folder, n)
        if os.path.exists(p):
            sign_file(p)
            done.append(n)
    return done



# ---------------------------------------------------------------------------
# وضع المجلد المشترك: مفتاح مشتق من عبارة مرور
# ---------------------------------------------------------------------------
# المفتاح الرئيسي في هذا الوضع = KDF(عبارة المرور، ملح). الملح و«شاهد تحقق» يُحفظان في المجلد المشترك
# (.es_shared.json) ولا يكشفان المفتاح. كل جهاز يُدخل العبارة مرة واحدة فيحفظ المفتاح محلياً محميّاً بـ DPAPI
# (الملف المعتاد .es_mk في مجلد الجهاز)، فلا تُطلب العبارة بعدها.
# لا استرجاع للعبارة: من نسيها يعيد بناء الفهرس، وتُعاد الأختام بـ reseal من نسخة احتياطية سليمة.
_KDF_SCRYPT = {"n": 2 ** 15, "r": 8, "p": 1}
_KDF_PBKDF2_ITER = 600000
_CHECK_LABEL = b"es-shared-passphrase-check-v1"
MIN_PASSPHRASE = 12


def _shared_dir():
    if SHARED_DIR:
        return SHARED_DIR
    return _data_dir() if app_paths.data_mode() == "local" else app_paths.shared_app_data_dir()


def _descriptor_path():
    return os.path.join(_shared_dir(), SHARED_DESCRIPTOR)


def _kdf(passphrase, salt, kdf=None):
    pw = passphrase.encode("utf-8")
    kdf = kdf or ("scrypt" if getattr(hashlib, "scrypt", None) else "pbkdf2")
    if kdf == "scrypt":
        key = hashlib.scrypt(pw, salt=salt, n=_KDF_SCRYPT["n"], r=_KDF_SCRYPT["r"], p=_KDF_SCRYPT["p"],
                             maxmem=128 * 1024 * 1024, dklen=32)
    else:
        key = hashlib.pbkdf2_hmac("sha256", pw, salt, _KDF_PBKDF2_ITER, 32)
    return key, kdf


def _check_value(key):
    return hmac.new(key, _CHECK_LABEL, hashlib.sha256).hexdigest()


def shared_state():
    """'ready' (هذا الجهاز يملك المفتاح) | 'need_unlock' (توجد بيانات مشتركة ويلزم إدخال العبارة)
    | 'need_setup' (المجلد المشترك جديد: لم تُضبط عبارة بعد) | 'local' (الوضع المحلي)."""
    if app_paths.data_mode() != "shared":
        return "local"
    if os.path.exists(_key_path()):
        return "ready"
    return "need_unlock" if os.path.exists(_descriptor_path()) else "need_setup"


def passphrase_problem(passphrase):
    """سبب الرفض (نص) أو None إن كانت العبارة مقبولة."""
    if len(passphrase or "") < MIN_PASSPHRASE:
        return "عبارة المرور يجب ألا تقل عن %d حرفاً." % MIN_PASSPHRASE
    if len(set(passphrase)) < 6:
        return "عبارة المرور بسيطة جداً (أحرف متكررة)."
    return None


def _install_key(key):
    """يحفظ المفتاح محلياً (DPAPI) كما يفعل master_key() ويفعّله."""
    blob = protect(key)
    if blob is None:
        blob = _PLAIN_TAG + base64.b64encode(key)
    os.makedirs(_data_dir(), exist_ok=True)
    path = _key_path()
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(blob)
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    os.replace(tmp, path)
    _cache["key"] = key


def setup_shared(passphrase):
    """إنشاء مجلد مشترك جديد: يولّد الملح، يحفظ شاهد التحقق، ويثبّت المفتاح على هذا الجهاز.
    لا يُعيد توقيع الملفات (استدعِ reseal_shared_files() بعد نسخ البيانات)."""
    problem = passphrase_problem(passphrase)
    if problem:
        raise ValueError(problem)
    if os.path.exists(_descriptor_path()):
        raise ValueError("المجلد المشترك مهيّأ مسبقاً؛ استعمل unlock_shared.")
    salt = secrets.token_bytes(16)
    key, kdf = _kdf(passphrase, salt)
    desc = {"v": 1, "kdf": kdf, "salt": base64.b64encode(salt).decode("ascii"), "check": _check_value(key)}
    os.makedirs(os.path.dirname(_descriptor_path()), exist_ok=True)
    tmp = _descriptor_path() + ".tmp"
    with open(tmp, "w", encoding="ascii") as f:
        json.dump(desc, f)
    os.replace(tmp, _descriptor_path())
    _install_key(key)


def unlock_shared(passphrase):
    """جهاز جديد ينضم لمجلد مشترك قائم. يرفع ValueError عند عبارة خاطئة."""
    try:
        with open(_descriptor_path(), "r", encoding="ascii") as f:
            desc = json.load(f)
        salt = base64.b64decode(desc["salt"])
        key, _ = _kdf(passphrase, salt, desc.get("kdf"))
        good = hmac.compare_digest(desc["check"], _check_value(key))
    except (OSError, ValueError, KeyError):
        raise ValueError("تعذّرت قراءة إعداد المجلد المشترك.")
    if not good:
        raise ValueError("عبارة المرور غير صحيحة.")
    _install_key(key)


def reseal_shared_files(names=("users.json", "settings.json")):
    """بعد تثبيت مفتاح جديد على بيانات منسوخة: يتبنّى الملفات الموقَّعة الحالية بالتوقيع الجديد.
    مسار استرداد صريح للمالك (مثل --reseal-integrity)."""
    clear_tamper_state()
    return _sign_existing(names)
