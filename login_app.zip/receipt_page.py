from msgbox_ltr import show_info, show_warning, show_question
# receipt_page.py
"""
صفحة "وصل الإيداع" - تُصدر وصلاً رسمياً (PDF) عند كل عملية تسديد،
وتحتفظ بسجل كل الوصولات الصادرة لهذه السنة.

الربط بين الصفحات الثلاث (كشف الأتعاب / تسديد الأتعاب / وصل الإيداع):
- وصل "تسبيق" (advance) هو تسديد فعلي لأتعاب الخبرة، لذلك عند توليده يُضاف
  تلقائياً كسطر تسديد في صفحة "تسديد الأتعاب"، ويُحدَّث "المدفوع/الباقي/الحالة"
  في صفحة "كشف الأتعاب" لنفس القضية - تماماً كأنه أُدخل يدوياً من هناك.
- وصل "إيداع تقرير الخبرة" (report_deposit) هو رسم ثابت (1500 دج) يُدفع لأمانة
  الضبط، ومستقل تماماً عن أتعاب الخبرة، لذلك لا يمس كشف الأتعاب ولا التسديدات؛
  يبقى مُسجَّلاً في سجل الوصولات الخاص به فقط.
"""

import os
import platform
import subprocess
import datetime
from PyQt5.QtCore import QSize
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QLineEdit,
    QPushButton, QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox,
    QDateEdit, QSpinBox, QFileDialog, QDialog, QFormLayout
)
from PyQt5.QtCore import Qt, QDate
import qtawesome as qta

import storage
from modern_theme import show_toast
from table_actions import build_action_bar, AttachmentPicker

ATTACHMENTS_SUBFOLDER = "receipts_scans"
SCAN_ROLE = Qt.UserRole + 1  # يطابق نفس الثابت المستعمل في payments_page.py لعمود "المرفق"


class ReceiptPage(QWidget):
    def __init__(self, case_page, fees_status_page=None, payments_page=None):
        super().__init__()
        self.case_page = case_page
        self.fees_status_page = fees_status_page
        self.payments_page = payments_page
        self._pending_scan_path = ""   # مسار الملف المختار (قبل الحفظ)
        self._row_indexes = []         # فهرس كل صف في القائمة الكاملة المحفوظة (للتعديل/الحذف رغم الفلترة)
        self._row_records = []         # نسخ من سجلات الوصولات المعروضة حالياً في الجدول (بنفس ترتيب الصفوف)

        self.setStyleSheet("background-color:#f8f9ff;")
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(20, 20, 20, 20)
        self.layout.setSpacing(12)

        title = QLabel("وصل الإيداع")
        title.setFont(QFont("Segoe UI", 15, QFont.Bold))
        self.layout.addWidget(title)

        self.init_form()
        self.init_table()
        self.load_receipts_data()

    def showEvent(self, event):
        self.update_case_list()
        super().showEvent(event)

    def reload(self):
        self.update_case_list()
        self.load_receipts_data()

    def update_case_list(self):
        current = self.case_combo.currentText() if hasattr(self, "case_combo") else ""
        self.case_combo.clear()
        for row in range(self.case_page.table.rowCount()):
            self.case_combo.addItem(self.case_page.table.item(row, 0).text())
        if current:
            idx = self.case_combo.findText(current)
            if idx >= 0:
                self.case_combo.setCurrentIndex(idx)

    def init_form(self):
        # --- نوع الوصل: يمنع أي اختلاط بين التسبيق وإيداع التقرير ---
        type_row = QHBoxLayout()
        self.receipt_type_combo = QComboBox()
        self.receipt_type_combo.addItem("وصل إيداع مبلغ التسبيق", "advance")
        self.receipt_type_combo.addItem("وصل إيداع تقرير الخبرة (أمانة الضبط)", "report_deposit")
        self.receipt_type_combo.setMinimumWidth(280)
        self.receipt_type_combo.currentIndexChanged.connect(self.on_type_changed)
        type_row.addWidget(QLabel("نوع الوصل:"))
        type_row.addWidget(self.receipt_type_combo)
        self.layout.addLayout(type_row)

        row1 = QHBoxLayout()
        self.case_combo = QComboBox()
        self.case_combo.setMinimumWidth(150)
        row1.addWidget(QLabel("رقم القضية:"))
        row1.addWidget(self.case_combo)

        self.receipt_number_input = QLineEdit()
        self.receipt_number_input.setPlaceholderText("رقم الوصل")
        row1.addWidget(QLabel("رقم الوصل:"))
        row1.addWidget(self.receipt_number_input)

        self.date_edit = QDateEdit(calendarPopup=True)
        self.date_edit.setDate(QDate.currentDate())
        row1.addWidget(QLabel("التاريخ:"))
        row1.addWidget(self.date_edit)

        self.layout.addLayout(row1)

        row2 = QHBoxLayout()
        self.payer_input = QLineEdit()
        self.payer_input.setPlaceholderText("اسم المودع")
        row2.addWidget(QLabel("اسم المودع:"))
        row2.addWidget(self.payer_input)

        self.amount_input = QLineEdit()
        self.amount_input.setPlaceholderText("المبلغ المستلم")
        row2.addWidget(QLabel("المبلغ:"))
        row2.addWidget(self.amount_input)

        self.font_size_spin = QSpinBox()
        self.font_size_spin.setRange(12, 30)
        self.font_size_spin.setValue(17)
        self.font_size_spin.setSuffix(" px")
        row2.addWidget(QLabel("حجم الخط:"))
        row2.addWidget(self.font_size_spin)

        self.layout.addLayout(row2)

        # --- إرفاق مسح ضوئي (صورة أو PDF) للوصل الفعلي الذي بحوزة المستعمل ---
        scan_row = QHBoxLayout()
        self.scan_label = QLabel("لا يوجد مرفق")
        self.scan_label.setStyleSheet("color:#5b6485;")
        scan_btn = QPushButton("إرفاق سكان / صورة / PDF")
        scan_btn.setIcon(qta.icon("fa5s.paperclip", color="#4338ca"))
        from scan_utils import attach_menu_for_button
        self._attach_menu = attach_menu_for_button(
            scan_btn, self,
            on_scan=self.scan_new_document,
            on_pick_file=self.attach_scan,
        )
        clear_scan_btn = QPushButton("إزالة")
        clear_scan_btn.clicked.connect(self.clear_scan)
        scan_row.addWidget(self.scan_label)
        scan_row.addStretch()
        scan_row.addWidget(clear_scan_btn)
        scan_row.addWidget(scan_btn)
        self.layout.addLayout(scan_row)

        # --- فلتر عرض الجدول حسب النوع (لمنع الاختلاط في العرض أيضاً) ---
        filter_row = QHBoxLayout()
        self.type_filter_combo = QComboBox()
        self.type_filter_combo.addItem("عرض الكل", "")
        self.type_filter_combo.addItem("وصولات التسبيق فقط", "advance")
        self.type_filter_combo.addItem("وصولات إيداع التقرير فقط", "report_deposit")
        self.type_filter_combo.currentIndexChanged.connect(self.load_receipts_data)
        filter_row.addWidget(QLabel("عرض:"))
        filter_row.addWidget(self.type_filter_combo)
        filter_row.addStretch()
        self.layout.addLayout(filter_row)

        generate_btn = QPushButton("توليد وصل الإيداع")
        generate_btn.setIcon(qta.icon("fa5s.receipt", color="white"))
        generate_btn.setIconSize(QSize(18, 18))
        generate_btn.setStyleSheet("""
            QPushButton { background-color:#7c3aed; color:white; padding:10px; border-radius:6px; font-weight:bold; }
            QPushButton:hover { background-color:#6d28d9; }
        """)
        generate_btn.clicked.connect(self.generate_receipt_clicked)
        self.layout.addWidget(generate_btn)

        self.on_type_changed()  # ضبط الحالة الابتدائية للحقول حسب النوع المختار

    def on_type_changed(self):
        """عند اختيار (وصل إيداع تقرير الخبرة): المبلغ ثابت 1500 دج ومقفل تلقائياً."""
        if self.receipt_type_combo.currentData() == "report_deposit":
            self.amount_input.setText("1500")
            self.amount_input.setReadOnly(True)
            self.amount_input.setStyleSheet("background-color:#f1f2ff;")
        else:
            self.amount_input.setReadOnly(False)
            self.amount_input.setStyleSheet("")
            if self.amount_input.text() == "1500":
                self.amount_input.clear()

        # اقتراح رقم الوصل التالي تلقائياً لهذا النوع (فقط إن كان الحقل فارغاً)
        if not self.receipt_number_input.text().strip():
            try:
                suggested = storage.next_receipt_number(self.receipt_type_combo.currentData())
                if suggested:
                    self.receipt_number_input.setText(suggested)
            except RuntimeError:
                pass

    def attach_scan(self):
        from scan_utils import pick_existing_file
        file_path = pick_existing_file(self, "اختر صورة أو PDF للوصل")
        if not file_path:
            return
        self._set_pending_scan(file_path)

    def scan_new_document(self):
        from scan_utils import scan_document
        file_path = scan_document(self, suggested_name="وصل_الإيداع")
        if not file_path:
            return
        self._set_pending_scan(file_path)

    def _set_pending_scan(self, file_path):
        self._pending_scan_path = file_path
        self.scan_label.setText(f"مرفق: {os.path.basename(file_path)}")
        self.scan_label.setStyleSheet("color:#128456; font-weight:bold;")

    def clear_scan(self):
        self._pending_scan_path = ""
        self.scan_label.setText("لا يوجد مرفق")
        self.scan_label.setStyleSheet("color:#5b6485;")

    def init_table(self):
        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(
            ["رقم الوصل", "رقم القضية", "التاريخ", "اسم المودع", "المبلغ", "النوع", "المرفق"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.cellDoubleClicked.connect(self.open_attachment)
        self.layout.addWidget(self.table)

        # شريط الأزرار: حفظ | تعديل | حذف | إضافة مرفق (للسطر المحدد)
        action_bar, self._action_buttons = build_action_bar(
            on_save=self.save_clicked,
            on_edit=self.edit_selected_receipt,
            on_delete=self.delete_selected_receipt,
            on_attach_scan=self.attach_scan_to_selected,
            on_attach_file=self.attach_file_to_selected,
            parent=self,
        )
        self.layout.addLayout(action_bar)

    def load_receipts_data(self):
        records = storage.load_receipts()
        type_filter = self.type_filter_combo.currentData() if hasattr(self, "type_filter_combo") else ""
        type_labels = {"advance": "تسبيق", "report_deposit": "إيداع تقرير"}

        self.table.setRowCount(0)
        self._row_records = []
        self._row_indexes = []
        for idx, rec in enumerate(records):
            rec_type = rec.get("type", "advance")
            if type_filter and rec_type != type_filter:
                continue
            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(rec.get("receipt_number", "")))
            self.table.setItem(row, 1, QTableWidgetItem(rec.get("case_number", "")))
            self.table.setItem(row, 2, QTableWidgetItem(rec.get("date", "")))
            self.table.setItem(row, 3, QTableWidgetItem(rec.get("payer", "")))
            self.table.setItem(row, 4, QTableWidgetItem(rec.get("amount", "")))
            self.table.setItem(row, 5, QTableWidgetItem(type_labels.get(rec_type, rec_type)))
            has_scan = bool(rec.get("scan_path")) and os.path.isfile(rec.get("scan_path", ""))
            attach_item = QTableWidgetItem("📎 عرض" if has_scan else "—")
            self.table.setItem(row, 6, attach_item)
            self._row_records.append(rec)
            self._row_indexes.append(idx)

    def open_attachment(self, row, column):
        if column != 6:
            return
        if row < 0 or row >= len(self._row_records):
            return
        scan_path = self._row_records[row].get("scan_path", "")
        if not scan_path or not os.path.isfile(scan_path):
            show_info(self, "لا يوجد مرفق",
                      "لا يوجد مسح ضوئي مرفق بهذا الوصل.\nلإضافة مرفق: حدّد السطر ثم اضغط «إضافة مرفق» أسفل الجدول.")
            return
        try:
            import safe_open
            safe_open.open_path(scan_path)
        except Exception as e:
            show_warning(self, "خطأ", f"تعذر فتح المرفق:\n{e}")

    def save_receipt_record(self, record):
        records = storage.load_receipts()
        records.append(record)
        storage.save_receipts(records)

    def generate_receipt_clicked(self):
        receipt_type = self.receipt_type_combo.currentData()
        case_number = self.case_combo.currentText().strip()
        receipt_number = self.receipt_number_input.text().strip()
        date = self.date_edit.date().toString("dd/MM/yyyy")
        payer = self.payer_input.text().strip()
        amount = self.amount_input.text().strip()

        if not case_number or not receipt_number or not amount:
            show_warning(self, "تنبيه", "يرجى إدخال رقم القضية ورقم الوصل والمبلغ على الأقل.")
            return

        # تتبّع أرقام الوصولات: تحذير عند تكرار نفس الرقم لنفس نوع الوصل
        if storage.receipt_number_exists(receipt_type, receipt_number):
            reply = show_question(
                self, "رقم وصل مكرر",
                f"رقم الوصل «{receipt_number}» مستعمل من قبل لنفس نوع الوصل.\nهل تريد المتابعة رغم ذلك؟",
            )
            if reply != QMessageBox.Yes:
                return

        # جلب المجموع الكلي والمتبقي من صفحة كشف الأتعاب إن توفرت
        # ملاحظة مهمة: هذا مجرد عرض إعلامي على الوصل، ولا علاقة له بوصل
        # إيداع التقرير (1500 دج) الذي هو رسم منفصل تمامًا عن أتعاب الخبرة.
        total, remaining = "", ""
        if self.fees_status_page is not None:
            fees_table = self.fees_status_page.table
            for r in range(fees_table.rowCount()):
                item = fees_table.item(r, 0)
                if item and item.text().strip() == case_number:
                    total = fees_table.item(r, 1).text() if fees_table.item(r, 1) else ""
                    remaining = fees_table.item(r, 3).text() if fees_table.item(r, 3) else ""
                    break

        expert_info = storage.load_expert_info()
        type_titles = {
            "advance": "وصل إيداع مبلغ التسبيق",
            "report_deposit": "وصل إيداع تقرير الخبرة لدى أمانة الضبط",
        }
        data = {
            "expert_name": expert_info.get("name", ""),
            "expert_address": expert_info.get("address", ""),
            "expert_phone": expert_info.get("phone", ""),
            "receipt_type": receipt_type,
            "receipt_title": type_titles.get(receipt_type, "وصل إيداع"),
            "receipt_number": receipt_number,
            "date": date,
            "case_number": case_number,
            "payer": payer,
            "amount": amount,
            "total": total,
            "remaining": remaining,
            "font_size": self.font_size_spin.value(),
        }

        try:
            from generate_receipt import generate_receipt
            html_file, pdf_file = generate_receipt(data)
        except Exception as e:
            show_warning(self, "خطأ", f"تعذر توليد الوصل:\n{e}")
            return

        # حفظ نسخة من المرفق (إن وُجد) داخل بيانات السنة الحالية
        scan_path = ""
        if self._pending_scan_path:
            try:
                desired_name = f"{receipt_type}_{receipt_number}_{case_number}"
                scan_path = storage.save_attachment_file(
                    self._pending_scan_path, ATTACHMENTS_SUBFOLDER, desired_name
                )
            except Exception as e:
                show_warning(self, "تنبيه", f"تم توليد الوصل لكن تعذر حفظ المرفق:\n{e}")

        record = {
            "receipt_number": receipt_number,
            "case_number": case_number,
            "date": date,
            "payer": payer,
            "amount": amount,
            "type": receipt_type,
            "scan_path": scan_path,
        }
        self.save_receipt_record(record)
        self.load_receipts_data()

        # --- الربط التلقائي: وصل "تسبيق" = تسديد فعلي لأتعاب الخبرة ---
        # يُضاف تلقائياً في صفحة التسديد ويُحدَّث المدفوع/الباقي في كشف الأتعاب،
        # حتى لا يبقى مجرد سطر معزول في صفحة وصل الإيداع.
        if receipt_type == "advance":
            self._sync_payment_from_receipt(case_number, date, receipt_number, amount, scan_path)
        elif receipt_type == "report_deposit":
            self._mark_case_report_deposited(case_number, date)

        from report_viewer import ReportViewer
        self.viewer = ReportViewer(html_file, pdf_file=pdf_file, title="معاينة الوصل")
        self.viewer.show()

        show_info(self, "تم", f"تم إنشاء وصل الإيداع بنجاح:\n{pdf_file}")

        # تفريغ الحقول (باستثناء المبلغ إن كان نوع الوصل "إيداع تقرير" ثابتاً على 1500)
        self.receipt_number_input.clear()
        self.payer_input.clear()
        if receipt_type != "report_deposit":
            self.amount_input.clear()
        self.clear_scan()
        # اقتراح رقم الوصل التالي مباشرة لتسريع إدخال الوصل الموالي
        try:
            suggested = storage.next_receipt_number(receipt_type)
            if suggested:
                self.receipt_number_input.setText(suggested)
        except RuntimeError:
            pass

    def _mark_case_report_deposited(self, case_number, date):
        """عند إصدار وصل إيداع تقرير الخبرة يُعاد حساب عمود "تاريخ الإيداع" في جدول القضايا:
        الحالة تُشتق من وجود الوصل نفسه (case_status)، فتتحوّل القضية إلى "تم الإيداع"
        وتخرج من التنبيه (متأخرة/قريبة) تلقائياً."""
        if self.case_page is None:
            return
        if hasattr(self.case_page, "refresh_deposit_column"):
            self.case_page.refresh_deposit_column()

    def _sync_payment_from_receipt(self, case_number, date, receipt_number, amount, scan_path=""):
        """يُضيف وصل "التسبيق" كسطر تسديد في صفحة تسديد الأتعاب، ويُحدِّث
        المدفوع/الباقي/الحالة في صفحة كشف الأتعاب لنفس القضية - بنفس منطق
        "إضافة تسديد يدوي" الموجود في صفحة التسديد، حتى تبقى الصفحات الثلاث متطابقة.
        كما يُنقَل مرفق الوصل (إن وُجد) إلى نفس سطر التسديد."""
        if self.payments_page is not None:
            p_table = self.payments_page.table
            p_table.blockSignals(True)
            row = p_table.rowCount()
            p_table.insertRow(row)
            p_table.setItem(row, 0, QTableWidgetItem(case_number))
            p_table.setItem(row, 1, QTableWidgetItem(date))
            p_table.setItem(row, 2, QTableWidgetItem(receipt_number))
            p_table.setItem(row, 3, QTableWidgetItem(amount))
            attach_item = QTableWidgetItem("📎 عرض" if scan_path else "—")
            attach_item.setData(SCAN_ROLE, scan_path or "")
            p_table.setItem(row, 4, attach_item)
            p_table.blockSignals(False)
            self.payments_page.save_payments_to_json()

        if self.fees_status_page is not None:
            f_table = self.fees_status_page.table
            for r in range(f_table.rowCount()):
                item = f_table.item(r, 0)
                if item and item.text().strip() == case_number:
                    try:
                        total_amount = float(f_table.item(r, 1).text() or 0) if f_table.item(r, 1) else 0.0
                        prev_paid = float(f_table.item(r, 2).text() or 0) if f_table.item(r, 2) else 0.0
                        new_paid = prev_paid + float(amount or 0)
                        remaining = total_amount - new_paid
                        status = "مدفوع بالكامل" if remaining <= 0 else ("مدفوع جزئي" if new_paid > 0 else "غير مدفوع")

                        f_table.blockSignals(True)
                        f_table.setItem(r, 2, QTableWidgetItem(str(new_paid)))
                        f_table.setItem(r, 3, QTableWidgetItem(str(remaining)))
                        f_table.setItem(r, 4, QTableWidgetItem(status))
                        if self.payments_page is not None:
                            f_table.setItem(r, 5, QTableWidgetItem(self.payments_page.notes_for_case(case_number)))
                        f_table.blockSignals(False)
                        self.fees_status_page.save_fees_to_json()
                    except (ValueError, AttributeError):
                        pass
                    break

    # =====================================================================
    # حفظ / تعديل / حذف / إضافة مرفق للسطر المحدد
    # =====================================================================
    def _selected_index(self, purpose):
        """يُرجع (فهرس السجل في التخزين، السجل) للسطر المحدد، أو (-1, None)."""
        row = self.table.currentRow()
        if row < 0 or row >= len(self._row_indexes):
            show_warning(self, "تنبيه", f"اختر سطراً من الجدول أولاً {purpose}.")
            return -1, None
        return self._row_indexes[row], dict(self._row_records[row])

    def save_clicked(self):
        storage.save_receipts(storage.load_receipts())
        show_toast(self, "تم حفظ الوصولات ✓", "success")

    def _store_record(self, idx, rec):
        records = storage.load_receipts()
        if 0 <= idx < len(records):
            records[idx] = rec
            storage.save_receipts(records)

    def _after_change(self, *case_numbers):
        """يحدّث الجدول والأعمدة المرتبطة (حالة القضية في صفحة القضايا) بعد أي تغيير."""
        self.load_receipts_data()
        if self.case_page is not None and hasattr(self.case_page, "refresh_deposit_column"):
            self.case_page.refresh_deposit_column()

    # ---------- تعديل ----------
    def edit_selected_receipt(self):
        idx, old = self._selected_index("لتعديله")
        if idx < 0:
            return
        rec_type = old.get("type", "advance")

        dialog = QDialog(self)
        dialog.setWindowTitle("تعديل وصل الإيداع")
        dialog.resize(440, 340)
        form = QFormLayout(dialog)

        type_names = {"advance": "وصل إيداع مبلغ التسبيق", "report_deposit": "وصل إيداع تقرير الخبرة"}
        form.addRow("النوع:", QLabel(type_names.get(rec_type, rec_type)))

        receipt_input = QLineEdit(old.get("receipt_number", ""))
        case_input = QLineEdit(old.get("case_number", ""))
        date_input = QDateEdit(calendarPopup=True)
        date_input.setDisplayFormat("dd/MM/yyyy")
        qd = QDate.fromString(old.get("date", ""), "dd/MM/yyyy")
        date_input.setDate(qd if qd.isValid() else QDate.currentDate())
        payer_input = QLineEdit(old.get("payer", ""))
        amount_input = QLineEdit(old.get("amount", ""))
        if rec_type == "report_deposit":
            amount_input.setReadOnly(True)   # رسم ثابت لأمانة الضبط
            amount_input.setStyleSheet("background-color:#f1f2ff;")
        picker = AttachmentPicker(dialog, old.get("scan_path", ""), "وصل_الإيداع")

        form.addRow("رقم الوصل:", receipt_input)
        form.addRow("رقم القضية:", case_input)
        form.addRow("التاريخ:", date_input)
        form.addRow("اسم المودع:", payer_input)
        form.addRow("المبلغ:", amount_input)
        form.addRow("المرفق:", picker.build_row())

        btns = QHBoxLayout()
        save_btn = QPushButton("حفظ التعديلات")
        save_btn.setStyleSheet("background:#128456;color:white;padding:8px 16px;border-radius:6px;font-weight:bold;")
        save_btn.clicked.connect(dialog.accept)
        cancel_btn = QPushButton("إلغاء")
        cancel_btn.clicked.connect(dialog.reject)
        btns.addWidget(save_btn)
        btns.addWidget(cancel_btn)
        form.addRow(btns)

        if dialog.exec_() != QDialog.Accepted:
            return

        new_number = receipt_input.text().strip()
        new_case = case_input.text().strip()
        new_amount = amount_input.text().strip()
        if not new_case or not new_number or not new_amount:
            show_warning(self, "تنبيه", "يرجى إدخال رقم القضية ورقم الوصل والمبلغ على الأقل.")
            return

        if new_number != old.get("receipt_number", "") and storage.receipt_number_exists(rec_type, new_number):
            reply = show_question(
                self, "رقم وصل مكرر",
                f"رقم الوصل «{new_number}» مستعمل من قبل لنفس نوع الوصل.\nهل تريد المتابعة رغم ذلك؟")
            if reply != QMessageBox.Yes:
                return

        scan_path = old.get("scan_path", "")
        if picker.path != scan_path:
            if not picker.path:
                scan_path = ""
            elif picker.is_new:
                try:
                    scan_path = storage.save_attachment_file(
                        picker.path, ATTACHMENTS_SUBFOLDER,
                        f"{rec_type}_{new_number}_{new_case}") or ""
                except Exception as e:
                    show_warning(self, "تنبيه", f"تعذر حفظ المرفق:\n{e}")
                    scan_path = old.get("scan_path", "")

        new_rec = dict(old)
        new_rec.update({
            "receipt_number": new_number, "case_number": new_case,
            "date": date_input.date().toString("dd/MM/yyyy"),
            "payer": payer_input.text().strip(), "amount": new_amount,
            "scan_path": scan_path,
        })
        self._store_record(idx, new_rec)

        # وصل التسبيق = تسديد فعلي: نحدّث سطر التسديد المرتبط وكشف الأتعاب
        if rec_type == "advance" and self.payments_page is not None:
            self.payments_page.update_payment_by_key(
                old.get("case_number", ""), old.get("receipt_number", ""),
                case_number=new_case, receipt_number=new_number,
                date=new_rec["date"], amount=new_amount, scan_path=scan_path)

        self._after_change()
        show_toast(self, "تم حفظ التعديلات ✓", "success")

    # ---------- حذف ----------
    def delete_selected_receipt(self):
        idx, rec = self._selected_index("لحذفه")
        if idx < 0:
            return
        rec_type = rec.get("type", "advance")
        extra = ("\nسيُحذف أيضاً سطر التسديد المرتبط به في «تسديد الأتعاب» "
                 "ويُعاد حساب كشف الأتعاب." if rec_type == "advance" else "")
        reply = show_question(
            self, "تأكيد الحذف",
            f"هل أنت متأكد من حذف الوصل رقم «{rec.get('receipt_number', '')}»؟{extra}")
        if reply != QMessageBox.Yes:
            return

        records = storage.load_receipts()
        if 0 <= idx < len(records):
            records.pop(idx)
            storage.save_receipts(records)

        if rec_type == "advance" and self.payments_page is not None:
            self.payments_page.delete_payment_by_key(
                rec.get("case_number", ""), rec.get("receipt_number", ""))

        self._after_change()
        show_toast(self, "تم حذف الوصل", "success")

    # ---------- إضافة مرفق لسطر موجود ----------
    def attach_file_to_selected(self):
        idx, rec = self._selected_index("لإضافة مرفق إليه")
        if idx < 0:
            return
        from scan_utils import pick_existing_file
        path = pick_existing_file(self, "اختر صورة أو PDF للوصل")
        if path:
            self._set_record_attachment(idx, rec, path)

    def attach_scan_to_selected(self):
        idx, rec = self._selected_index("لإضافة مرفق إليه")
        if idx < 0:
            return
        from scan_utils import scan_document
        path = scan_document(self, suggested_name="وصل_الإيداع")
        if path:
            self._set_record_attachment(idx, rec, path)

    def _set_record_attachment(self, idx, rec, source_path):
        rec_type = rec.get("type", "advance")
        try:
            new_path = storage.save_attachment_file(
                source_path, ATTACHMENTS_SUBFOLDER,
                f"{rec_type}_{rec.get('receipt_number', '')}_{rec.get('case_number', '')}")
        except Exception as e:
            show_warning(self, "خطأ", f"تعذر حفظ المرفق:\n{e}")
            return
        if not new_path:
            show_warning(self, "خطأ", "الملف المختار غير موجود.")
            return
        rec["scan_path"] = new_path
        self._store_record(idx, rec)

        # نقل المرفق إلى سطر التسديد المرتبط أيضاً (وصل التسبيق فقط)
        if rec_type == "advance" and self.payments_page is not None:
            self.payments_page.update_payment_by_key(
                rec.get("case_number", ""), rec.get("receipt_number", ""), scan_path=new_path)

        self.load_receipts_data()
        show_toast(self, "تمت إضافة المرفق ✓", "success")
