# -*- coding: utf-8 -*-
"""فتح المرفقات بأمان: يمنع تشغيل ملفات تنفيذية/سكربتات لو تلاعب أحد بمسار محفوظ في JSON."""
import os
import platform
import subprocess

BLOCKED_EXT = {
    ".exe", ".bat", ".cmd", ".com", ".scr", ".pif", ".msi", ".msp", ".lnk", ".url",
    ".ps1", ".psm1", ".vbs", ".vbe", ".js", ".jse", ".wsf", ".wsh", ".hta", ".reg",
    ".dll", ".jar", ".cpl", ".py", ".pyw", ".sh", ".appref-ms", ".gadget",
}


def open_path(path):
    """يفتح ملفاً بالبرنامج الافتراضي. يرفع استثناءً واضحاً عند المنع (تلتقطه الصفحات كالمعتاد)."""
    if not path or not isinstance(path, str):
        raise IOError("مسار غير صالح")
    real = os.path.realpath(path)
    if not os.path.isfile(real):
        raise IOError("الملف غير موجود")
    ext = os.path.splitext(real)[1].lower()
    if ext in BLOCKED_EXT:
        raise IOError("نوع الملف غير مسموح بفتحه من داخل البرنامج (%s)" % ext)
    if platform.system() == "Windows":
        os.startfile(real)
    elif platform.system() == "Darwin":
        subprocess.call(["open", real])
    else:
        subprocess.call(["xdg-open", real])
