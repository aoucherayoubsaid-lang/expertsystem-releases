# -*- coding: utf-8 -*-
"""التحديث التلقائي: يفحص ملف إصدار موقَّع، ينزّل المثبّت، يتحقق من بصمته، ثم يشغّله.

الأمان (مهم): الرابط وحده لا يُوثَق. ملف latest.json موقَّع بمفتاح Ed25519 خاص بالتحديثات
(غير مفتاح الترخيص)، والمفتاح العام فقط داخل البرنامج. التوقيع يغطي رقم الإصدار ورابط
التنزيل وبصمة SHA-256 للمثبّت، فلا يستطيع أحد (حتى لو اخترق الاستضافة) دسّ مثبّت مزوّر.
كذلك يُرفض أي إصدار أقدم من الحالي (منع هجوم الرجوع لنسخة قديمة بها ثغرة).

متوافق مع Python 3.8 (ويندوز 7): بلا مكتبات خارجية للتحقق (ed25519_verify بايثون صرف).
"""
import base64
import hashlib
import json
import os
import re
import subprocess
import sys
import urllib.request
import uuid

import ed25519_verify
import trial_online
from app_info import APP_VERSION
from app_paths import temp_dir

# ---- أعدّها مرة واحدة (انظر tools/release_tool.py keygen) ----
# مثال GitHub Releases:  https://github.com/OWNER/REPO/releases/latest/download/latest.json
UPDATE_MANIFEST_URL = "https://github.com/aoucherayoubsaid-lang/expertsystem-releases/releases/latest/download/latest.json"
UPDATE_PUBLIC_B64 = "SIlXPMbvQXL9y9zr2RuuE7cPyppaJcH+gD9eokrhcUk="

MAX_MANIFEST_BYTES = 64 * 1024
MAX_INSTALLER_BYTES = 400 * 1024 * 1024
_VER_RE = re.compile(r"^\d{1,4}(\.\d{1,4}){1,3}$")


def is_configured():
    return "YOUR-UPDATE-HOST" not in UPDATE_MANIFEST_URL and not UPDATE_PUBLIC_B64.startswith("PASTE")


def parse_version(text):
    text = str(text or "").strip()
    if not _VER_RE.match(text):
        return None
    return tuple(int(x) for x in text.split("."))


def _read_limited(resp, limit):
    data = resp.read(limit + 1)
    if len(data) > limit:
        raise ValueError("response too large")
    return data


def _open(url, timeout):
    if not str(url).lower().startswith("https://"):
        raise ValueError("https required")
    req = urllib.request.Request(url, headers={"User-Agent": "ExpertSystem/" + APP_VERSION})
    return urllib.request.urlopen(req, timeout=timeout, context=trial_online._ssl_context())


def verify_manifest(envelope, public_b64=None, current_version=None):
    """يتحقق من التوقيع والحقول. يرجع dict نظيف أو None. لا يرفع استثناءات."""
    try:
        pub = base64.b64decode(public_b64 or UPDATE_PUBLIC_B64)
        data = envelope["data"]
        if not isinstance(data, str):
            return None
        if not ed25519_verify.verify(pub, data.encode("utf-8"), base64.b64decode(envelope["sig"])):
            return None
        m = json.loads(data)
        if m.get("product") != "expert-system":
            return None
        newv = parse_version(m.get("version"))
        if newv is None:
            return None
        url = str(m.get("url") or "")
        sha = str(m.get("sha256") or "").lower()
        size = int(m.get("size") or 0)
        if not url.lower().startswith("https://") or not re.fullmatch(r"[0-9a-f]{64}", sha):
            return None
        if not (0 < size <= MAX_INSTALLER_BYTES):
            return None
        cur = parse_version(current_version or APP_VERSION) or (0,)
        out = {"version": m["version"], "version_t": newv, "url": url, "sha256": sha, "size": size,
               "notes": str(m.get("notes") or "")[:2000], "mandatory": bool(m.get("mandatory")),
               "min_version": str(m.get("min_version") or "")}
        out["is_newer"] = newv > cur
        # إصدار إلزامي إذا كانت النسخة الحالية أقدم من الحد الأدنى المسموح
        mv = parse_version(out["min_version"])
        if mv and cur < mv:
            out["mandatory"] = True
        return out
    except Exception:
        return None


def check_for_update(timeout=8):
    """يرجع معلومات التحديث إن وُجد إصدار أحدث وصحيح التوقيع، وإلا None (بصمت عند فشل الشبكة)."""
    if not is_configured():
        return None
    try:
        with _open(UPDATE_MANIFEST_URL, timeout) as r:
            envelope = json.loads(_read_limited(r, MAX_MANIFEST_BYTES).decode("utf-8"))
    except Exception:
        return None
    info = verify_manifest(envelope)
    return info if info and info["is_newer"] else None


def download_installer(info, progress=None, timeout=30):
    """ينزّل المثبّت إلى المجلد المؤقت ويتحقق من الحجم والبصمة. يرفع استثناءً عند أي خلل."""
    path = os.path.join(temp_dir(), "ExpertSystem_Update_%s.exe" % uuid.uuid4().hex[:8])
    h = hashlib.sha256()
    total = 0
    try:
        with _open(info["url"], timeout) as r, open(path, "wb") as f:
            while True:
                chunk = r.read(256 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > info["size"] or total > MAX_INSTALLER_BYTES:
                    raise ValueError("حجم الملف أكبر من المعلن")
                h.update(chunk)
                f.write(chunk)
                if progress:
                    progress(total, info["size"])
        if total != info["size"] or h.hexdigest() != info["sha256"]:
            raise ValueError("فشل التحقق من سلامة ملف التحديث")
        return path
    except Exception:
        try:
            os.remove(path)
        except OSError:
            pass
        raise


def launch_installer(path):
    """يشغّل مثبّت Inno Setup بصمت: يغلق البرنامج ويحدّثه ويعيد تشغيله. البيانات لا تُمَس."""
    args = [path, "/SILENT", "/SUPPRESSMSGBOXES", "/CLOSEAPPLICATIONS", "/RESTARTAPPLICATIONS", "/NORESTART"]
    subprocess.Popen(args, close_fds=True)


# ------------------------------- واجهة PyQt -------------------------------
def start_background_check(parent):
    """يستدعى مرة بعد فتح النافذة الرئيسية: فحص في خيط خلفي ثم نافذة سؤال إن وُجد تحديث."""
    if not is_configured() or not getattr(sys, "frozen", False):
        return None          # أثناء التطوير (تشغيل .py) لا نفحص
    from PyQt5.QtCore import QThread, pyqtSignal

    class _Check(QThread):
        found = pyqtSignal(object)

        def run(self):
            info = check_for_update()
            if info:
                self.found.emit(info)

    t = _Check(parent)
    t.found.connect(lambda info: _prompt(parent, info))
    t.start()
    parent._update_thread = t          # لمنع حذفه قبل انتهائه
    return t


def _prompt(parent, info):
    from PyQt5.QtCore import Qt, QThread, pyqtSignal
    from PyQt5.QtWidgets import QProgressDialog, QApplication
    from msgbox_ltr import show_confirm, show_warning

    notes = ("\n\n" + info["notes"]) if info["notes"] else ""
    text = "يتوفر إصدار جديد %s (الحالي %s).%s\n\nبياناتك لن تتأثر. هل تريد التحديث الآن؟" % (
        info["version"], APP_VERSION, notes)
    if not show_confirm(parent, "تحديث البرنامج", text, yes_text="تحديث الآن",
                        no_text="إغلاق" if info["mandatory"] else "لاحقًا"):
        if info["mandatory"]:
            QApplication.quit()
        return

    dlg = QProgressDialog("جارٍ تنزيل التحديث...", None, 0, 100, parent)
    dlg.setWindowModality(Qt.WindowModal)
    dlg.setAutoClose(False)
    dlg.show()

    class _Down(QThread):
        prog = pyqtSignal(int)
        done = pyqtSignal(str, str)           # (path, error)

        def run(self):
            try:
                p = download_installer(info, lambda a, b: self.prog.emit(int(a * 100 / max(b, 1))))
                self.done.emit(p, "")
            except Exception as e:
                self.done.emit("", str(e))

    def finished(path, err):
        dlg.close()
        if err:
            show_warning(parent, "التحديث", "تعذّر تنزيل التحديث:\n" + err)
            return
        launch_installer(path)
        QApplication.quit()

    d = _Down(parent)
    d.prog.connect(dlg.setValue)
    d.done.connect(finished)
    d.start()
    parent._download_thread = d
