# -*- coding: utf-8 -*-
"""بصمة الجهاز متعددة المكوّنات (تُهَشّ كل مكوّنة على حدة قبل إرسالها، لا تُرسل أي قيمة خام).

لماذا عدة مكوّنات؟ MachineGuid وحده يتغيّر بإعادة تثبيت ويندوز أو بتعديل السجل. الخادم يقارن
المكوّنات بوزن لكل منها: إن تغيّر بعضها وبقي بعضها (لوحة أم، UUID لـ BIOS، قرص، MAC...) يعرف
أنه الجهاز نفسه. تتوافق مع ويندوز 7..11 (بدون الاعتماد على wmic وحده، فهو محذوف في ويندوز 11 الحديث).
"""
import hashlib
import os
import platform
import subprocess
import uuid

_JUNK = {
    "", "none", "null", "n/a", "na", "unknown", "default string", "default", "not specified",
    "not applicable", "to be filled by o.e.m.", "to be filled by oem", "o.e.m.", "oem",
    "system serial number", "system product name", "123456789", "0123456789", "serial number",
    "00000000-0000-0000-0000-000000000000", "ffffffff-ffff-ffff-ffff-ffffffffffff",
}
_CACHE = {}


def _clean(value):
    """يُسقط القيم الوهمية التي تتشابه بين أجهزة مختلفة (وإلا حُظر مستخدمون أبرياء)."""
    v = (str(value) if value is not None else "").strip()
    low = v.lower()
    if len(v) < 4 or low in _JUNK or len(set(low.replace("-", ""))) <= 1:
        return ""
    return v


def _run(cmd, timeout=15):
    kw = {}
    if os.name == "nt":
        kw["creationflags"] = 0x08000000            # بدون نافذة سوداء
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.DEVNULL, timeout=timeout, **kw)
        return out.decode("utf-8", "ignore")
    except Exception:
        return ""


def _windows_wmi():
    """مكوّنات العتاد من WMI: PowerShell أولًا (يعمل في ويندوز 7..11) ثم wmic كاحتياط."""
    ps = ("$ErrorActionPreference='SilentlyContinue';"
          "'smbios='+(Get-WmiObject Win32_ComputerSystemProduct).UUID;"
          "'board='+(Get-WmiObject Win32_BaseBoard).SerialNumber;"
          "'bios='+(Get-WmiObject Win32_BIOS).SerialNumber;"
          "'cpu='+((Get-WmiObject Win32_Processor | Select-Object -First 1).ProcessorId);"
          "'disk='+((Get-WmiObject Win32_DiskDrive | Select-Object -First 1).SerialNumber)")
    out = _run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps])
    res = {}
    for line in out.splitlines():
        if "=" in line:
            k, _, v = line.partition("=")
            res[k.strip()] = v.strip()
    if res.get("smbios") or res.get("board") or res.get("disk"):
        return res
    for key, args in (("smbios", "csproduct get uuid"), ("board", "baseboard get serialnumber"),
                      ("bios", "bios get serialnumber"), ("cpu", "cpu get processorid"),
                      ("disk", "diskdrive get serialnumber")):
        lines = [l.strip() for l in _run(["wmic"] + args.split()).splitlines() if l.strip()]
        if len(lines) > 1:
            res[key] = lines[1]
    return res


def _windows_guid():
    try:
        import winreg
        access = winreg.KEY_READ | getattr(winreg, "KEY_WOW64_64KEY", 0)
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0, access) as k:
            return str(winreg.QueryValueEx(k, "MachineGuid")[0])
    except Exception:
        return ""


def _windows_volume_serial():
    try:
        import ctypes
        serial = ctypes.c_uint32(0)
        drive = os.environ.get("SystemDrive", "C:") + "\\"
        ok = ctypes.windll.kernel32.GetVolumeInformationW(ctypes.c_wchar_p(drive), None, 0,
                                                          ctypes.byref(serial), None, None, None, 0)
        return "%08X" % serial.value if ok else ""
    except Exception:
        return ""


def _read(path):
    try:
        with open(path, "r") as f:
            return f.read().strip()
    except Exception:
        return ""


def _mac():
    node = uuid.getnode()
    if (node >> 40) & 1:                              # بت "عشوائي": لم يُعثر على بطاقة شبكة حقيقية
        return ""
    return "%012x" % node


def _raw():
    """القيم الخام (تبقى في الذاكرة فقط). الاختبارات تستبدل هذه الدالة."""
    if os.name == "nt":
        w = _windows_wmi()
        return {"guid": _windows_guid(), "smbios": w.get("smbios", ""), "board": w.get("board", ""),
                "bios": w.get("bios", ""), "cpu": w.get("cpu", ""), "disk": w.get("disk", ""),
                "vol": _windows_volume_serial(), "mac": _mac()}
    return {"guid": _read("/etc/machine-id") or _read("/var/lib/dbus/machine-id"),
            "smbios": _read("/sys/class/dmi/id/product_uuid"), "board": _read("/sys/class/dmi/id/board_serial"),
            "bios": _read("/sys/class/dmi/id/chassis_serial"), "cpu": platform.processor(),
            "disk": "", "vol": "", "mac": _mac()}


def collect(refresh=False):
    """يرجع {اسم_المكوّنة: هاش 32 خانة}. تُحسب مرة واحدة لكل تشغيل."""
    if refresh or "c" not in _CACHE:
        out = {}
        for name, value in _raw().items():
            v = _clean(value)
            if v:
                out[name] = hashlib.sha256(("ES-FP|%s|%s" % (name, v.lower())).encode("utf-8")).hexdigest()[:32]
        _CACHE["c"] = out
    return dict(_CACHE["c"])
