# -*- coding: utf-8 -*-
"""توليد ملفات Word من نموذج جاهز بملء العلامات {{اسم_الحقل}} مع حفظ التنسيق.

- لا يحتاج ذكاءً اصطناعياً ولا اتصالاً بالإنترنت.
- يعمل على بايثون 3.8 مع مكتبة python-docx فقط:  pip install python-docx
- العلامات تُقرأ في: النص الأساسي، الجداول (حتى المتداخلة)، الترويسة والتذييل، مربعات النص.
- العلامات تعمل حتى لو قسّمها Word إلى عدة أجزاء داخل الفقرة.
"""
import re

from docx import Document
from docx.text.paragraph import Paragraph

_PLACEHOLDER = re.compile(r"\{\{\s*([^{}\s]+)\s*\}\}")
_W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"


# ---------------------------------------------------------------------------
# بناء بيانات القضية من storage
# ---------------------------------------------------------------------------
def build_case_context(case_number):
    """يجمع كل حقول القضية المختارة + المهام والنبذة + معلومات الخبير."""
    import storage

    case_number = str(case_number).strip()
    case = {}
    for c in storage.load_cases():
        if str(c.get("case_number", "")).strip() == case_number:
            case = dict(c)
            break
    if not case:
        raise ValueError("القضية غير موجودة: %s" % case_number)

    note = storage.get_case_note(case_number)
    ctx = {k: ("" if v is None else str(v)) for k, v in case.items()}
    ctx["tasks"] = note.get("tasks", "")
    ctx["summary"] = note.get("summary", "")
    ctx["dossier"] = storage.get_current_dossier_name() or ""
    ctx["year"] = str(storage.get_current_year() or "")

    expert = storage.load_expert_info() or {}
    if isinstance(expert, dict):
        for k, v in expert.items():
            ctx["expert_%s" % k] = "" if v is None else str(v)
    return ctx


# ---------------------------------------------------------------------------
# استبدال العلامات داخل فقرة مع حفظ تنسيق أول جزء من كل علامة
# ---------------------------------------------------------------------------
def _replace_in_paragraph(par, ctx, missing):
    runs = par.runs
    if not runs:
        return
    full = "".join(r.text for r in runs)
    if "{{" not in full:
        return

    # خريطة: موضع كل حرف -> رقم الجزء (run)
    owner = []
    for i, r in enumerate(runs):
        owner.extend([i] * len(r.text))

    new_texts = [list(r.text) for r in runs]
    # نعالج العلامات من الأخير للأول حتى لا تتغير المواضع
    for m in reversed(list(_PLACEHOLDER.finditer(full))):
        key = m.group(1)
        if key in ctx:
            value = ctx[key]
        else:
            missing.add(key)
            value = m.group(0)  # نترك العلامة كما هي ليراها المستخدم
        start, end = m.start(), m.end()
        first = owner[start]
        # احذف حروف العلامة من كل الأجزاء، وضع القيمة في الجزء الأول
        for pos in range(start, end):
            idx = owner[pos]
            offset = pos - sum(len(runs[j].text) for j in range(idx))
            new_texts[idx][offset] = ""
        offset_first = start - sum(len(runs[j].text) for j in range(first))
        new_texts[first][offset_first] = value
    for r, chars in zip(runs, new_texts):
        r.text = "".join(chars)


def _all_paragraphs(root_element, parent):
    """كل فقرات العنصر (تشمل الجداول ومربعات النص) عبر XML مباشرة."""
    for p in root_element.iter("{%s}p" % _W_NS):
        yield Paragraph(p, parent)


def fill_document(doc, ctx):
    """يملأ مستند Document مفتوحاً. يرجع مجموعة العلامات التي لم يجد لها قيمة."""
    missing = set()

    for par in _all_paragraphs(doc.element.body, doc):
        _replace_in_paragraph(par, ctx, missing)

    for section in doc.sections:
        for part in (section.header, section.footer,
                     section.first_page_header, section.first_page_footer,
                     section.even_page_header, section.even_page_footer):
            try:
                el = part._element
            except Exception:
                continue
            for par in _all_paragraphs(el, part):
                _replace_in_paragraph(par, ctx, missing)
    return missing


def fill_template(template_path, output_path, ctx):
    """يملأ النموذج ويحفظ النتيجة. يرجع مجموعة العلامات التي لم يجد لها قيمة."""
    doc = Document(template_path)
    missing = fill_document(doc, ctx)
    doc.save(output_path)
    return missing


def list_placeholders(template_path):
    """كل العلامات {{...}} الموجودة في النموذج (للتحقق من النموذج)."""
    doc = Document(template_path)
    found = set()
    roots = [(doc.element.body, doc)]
    for section in doc.sections:
        for part in (section.header, section.footer, section.first_page_header,
                     section.first_page_footer, section.even_page_header, section.even_page_footer):
            try:
                roots.append((part._element, part))
            except Exception:
                pass
    for el, parent in roots:
        for par in _all_paragraphs(el, parent):
            text = "".join(r.text for r in par.runs)
            found.update(m.group(1) for m in _PLACEHOLDER.finditer(text))
    return found


def known_keys():
    """أسماء العلامات المتاحة: حقول القضايا + المهام والنبذة + معلومات الخبير."""
    import storage
    keys = {"tasks", "summary", "dossier", "year"}
    for c in storage.load_cases():
        keys.update(c.keys())
    expert = storage.load_expert_info() or {}
    if isinstance(expert, dict):
        keys.update("expert_%s" % k for k in expert)
    return keys


def generate_cover(case_number, template_path, output_path):
    """الدالة التي تستدعيها من واجهة البرنامج."""
    ctx = build_case_context(case_number)
    return fill_template(template_path, output_path, ctx)
