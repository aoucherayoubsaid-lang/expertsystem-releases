"""
منطق موحّد لحالة إيداع الخبرة (يُستعمل في صفحة القضايا والصفحة الرئيسية والتنبيهات).

القاعدة:
  - "أُودعت"  ⇐ يوجد وصل "إيداع تقرير الخبرة" لهذه القضية في صفحة الإيداع (وصل الإيداع).
  - "متأخرة"  ⇐ لا وصل، وانقضى الأجل التقديري (تاريخ الاستلام + مدة الإنجاز).
  - "قريبة"   ⇐ لا وصل، وبقي على الأجل عدد أيام ≤ المدة المحددة في الإعدادات.
  - "عادية"   ⇐ لا وصل، والأجل بعيد.
لا يُعتمد على أي تاريخ يُكتب يدوياً، فلا يمكن أن تظهر قضية "مُودَعة" دون وصل.
"""
import datetime

import storage

DATE_FMT = "%d/%m/%Y"
REPORT_DEPOSIT = "report_deposit"


def near_days():
    """عدد الأيام المحدد في الإعدادات لتنبيه "قريبة الإيداع" (الافتراضي 30)."""
    try:
        from settings_page import AppSettings
        return max(0, int(float(AppSettings().get("near_deadline_days") or 30)))
    except Exception:
        return 30


def deposit_receipts():
    """{رقم القضية: آخر وصل إيداع تقرير خبرة}"""
    result = {}
    try:
        for rec in storage.load_receipts():
            if rec.get("type") == REPORT_DEPOSIT:
                number = str(rec.get("case_number", "") or "").strip()
                if number:
                    result[number] = rec
    except Exception:
        pass
    return result


def compute_deadline(case):
    """الأجل التقديري (date) أو None: تاريخ الاستلام + (مدة الإنجاز × 30 يوماً)."""
    receive = str(case.get("receive_date") or "").strip()
    months = str(case.get("duration_months") or "").strip()
    if not (receive and months):
        return None
    try:
        start = datetime.datetime.strptime(receive, DATE_FMT).date()
        return start + datetime.timedelta(days=int(float(months)) * 30)
    except Exception:
        return None


def case_status(case, receipts=None, near=None):
    receipts = deposit_receipts() if receipts is None else receipts
    near = near_days() if near is None else near
    number = str(case.get("case_number", "") or "").strip()
    receipt = receipts.get(number)
    deadline = compute_deadline(case)
    days_left = (deadline - datetime.date.today()).days if deadline else None

    if receipt:
        state = "deposited"
    elif deadline is None:
        state = "unknown"
    elif days_left < 0:
        state = "late"
    elif days_left <= near:
        state = "near"
    else:
        state = "ok"
    return {"state": state, "deadline": deadline, "days_left": days_left, "receipt": receipt}
