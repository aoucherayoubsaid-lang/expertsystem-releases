from msgbox_ltr import show_info, show_warning
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QComboBox, QDateEdit, QPushButton,
    QLineEdit, QTextEdit, QTableWidget, QTableWidgetItem, QHeaderView,
    QHBoxLayout, QFileDialog, QMessageBox, QSpinBox
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt, QDate, QSize
import os
import platform
import subprocess
import storage
import qtawesome as qta
from table_filter import TableFilterBar


class AttendanceReportPage(QWidget):
    def __init__(self, case_page, document_page, party_page, main_app=None):
        super().__init__()

        self.case_page = case_page
        self.document_page = document_page
        self.party_page = party_page
        self.main_app = main_app

        self.attendance_files = []

        self.setStyleSheet("background-color: #f8f9ff;")
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(20, 20, 20, 20)

        title = QLabel("محضر إثبات الحضور")
        title.setFont(QFont("Segoe UI", 16, QFont.Bold))
        self.layout.addWidget(title)

        self.init_form()
        self.init_table()
        self.load_attendance_data()

    def reload(self):
        """إعادة تحميل بيانات محاضر الحضور (تُستدعى عند تفعيل التبويب)."""
        self.update_case_list()
        self.load_attendance_data()

    def load_attendance_data(self):
        records = storage.load_attendance()
        self.table.setRowCount(0)
        self.attendance_files = []
        for rec in records:
            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(rec.get("case", "")))
            self.table.setItem(row, 1, QTableWidgetItem(rec.get("party", "")))
            self.table.setItem(row, 2, QTableWidgetItem(rec.get("date", "")))
            self.table.setItem(row, 3, QTableWidgetItem(rec.get("documents", "")))
            self.table.setItem(row, 4, QTableWidgetItem(rec.get("notes", "")))

            file_path = rec.get("file", "")
            label = "إرفاق ملف" if not file_path else os.path.basename(file_path)
            self.table.setCellWidget(row, 5, self._make_attach_button(row, label))
            self.attendance_files.append(file_path)
        if hasattr(self, "filter_bar"):
            self.filter_bar.refresh()

    def save_attendance_data(self):
        records = []
        for row in range(self.table.rowCount()):
            records.append({
                "case": self.table.item(row, 0).text() if self.table.item(row, 0) else "",
                "party": self.table.item(row, 1).text() if self.table.item(row, 1) else "",
                "date": self.table.item(row, 2).text() if self.table.item(row, 2) else "",
                "documents": self.table.item(row, 3).text() if self.table.item(row, 3) else "",
                "notes": self.table.item(row, 4).text() if self.table.item(row, 4) else "",
                "file": self.attendance_files[row] if row < len(self.attendance_files) else "",
            })
        storage.save_attendance(records)

    def init_form(self):
        form_layout = QHBoxLayout()

        self.case_combo = QComboBox()
        self.case_combo.currentTextChanged.connect(self.update_party_list)
        self.party_combo = QComboBox()
        self.date_edit = QDateEdit(calendarPopup=True)
        self.date_edit.setDate(QDate.currentDate())
        self.docs_input = QLineEdit()
        self.notes_input = QTextEdit()

        self.case_combo.setMinimumWidth(150)
        self.party_combo.setMinimumWidth(150)
        self.docs_input.setPlaceholderText("الوثائق المقدمة")
        self.notes_input.setPlaceholderText("ملاحظات")


        form_layout.addWidget(QLabel("الطرف :"))
        form_layout.addWidget(self.party_combo)

        form_layout.addWidget(QLabel("القضية :"))
        form_layout.addWidget(self.case_combo)

        form_layout.addWidget(QLabel("التاريخ :"))
        form_layout.addWidget(self.date_edit)

        self.layout.addLayout(form_layout)
        self.layout.addWidget(QLabel("الوثائق المقدمة:"))
        self.layout.addWidget(self.docs_input)
        self.layout.addWidget(QLabel("ملاحظات:"))
        self.layout.addWidget(self.notes_input)

        # التحكم في حجم خط المحضر عند الطباعة (لحل مشكلة ظهور كتابة صغيرة)
        font_row = QHBoxLayout()
        font_row.addWidget(QLabel("حجم خط المحضر عند الطباعة:"))
        self.font_size_spin = QSpinBox()
        self.font_size_spin.setRange(12, 36)
        self.font_size_spin.setValue(18)
        self.font_size_spin.setSuffix(" px")
        font_row.addWidget(self.font_size_spin)
        font_row.addStretch()
        self.layout.addLayout(font_row)

        btn_generate = QPushButton("إعداد محضر الحضور")
        btn_generate.setIcon(qta.icon("fa5s.file-signature", color="white"))
        btn_generate.setIconSize(QSize(18, 18))
        btn_generate.setStyleSheet("""
        QPushButton{
        background-color:#128456;
        color:white;
        padding:10px;
        font-size:14px;
        border-radius:6px;
        }
        QPushButton:hover{
        background-color:#0f7a52;
        }
        """)

        btn_generate.clicked.connect(self.generate_report_from_form)

        self.layout.addWidget(btn_generate)

        btn_save_only = QPushButton("حفظ البيانات في الجدول")
        btn_save_only.setIcon(qta.icon("fa5s.save", color="#4338ca"))
        btn_save_only.setIconSize(QSize(18, 18))
        btn_save_only.clicked.connect(self.save_only)
        self.layout.addWidget(btn_save_only)

    def init_table(self):
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["القضية", "الطرف", "تاريخ الحضور", "الوثائق", "ملاحظات", "ملف المحضر"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.cellDoubleClicked.connect(self.open_document)
        self.filter_bar = TableFilterBar(
            self.table, [(0, "كل القضايا"), (1, "كل الأطراف")],
            "ابحث في المحاضر...",
            extra_text=lambda r: os.path.basename(self.attendance_files[r]) if r < len(self.attendance_files) else "",
        )
        self.layout.addWidget(self.filter_bar)
        self.layout.addWidget(self.table)

    def showEvent(self, event):
        self.update_case_list()
        super().showEvent(event)

    def update_case_list(self):
        self.case_combo.clear()
        cases = set()
        for row in range(self.case_page.table.rowCount()):
            case_number = self.case_page.table.item(row, 0).text()
            cases.add(case_number)
        self.case_combo.addItems(sorted(cases))

    def update_party_list(self):
        self.party_combo.clear()
        selected_case = self.case_combo.currentText()
        parties = set()
        for row in range(self.case_page.table.rowCount()):
            if self.case_page.table.item(row, 0).text() == selected_case:
                p = self.case_page.table.item(row, 5).text()
                d = self.case_page.table.item(row, 6).text()
                if p:
                    parties.add(p)
                if d:
                    parties.add(d)
        self.party_combo.addItems(sorted(parties))

    def save_only(self):
        case = self.case_combo.currentText()
        party = self.party_combo.currentText()
        date = self.date_edit.date().toString("yyyy-MM-dd")
        documents = self.docs_input.text()
        notes = self.notes_input.toPlainText()

        if not case or not party:
            show_warning(self, "خطأ", "يرجى اختيار القضية والطرف.")
            return

        row = self.table.rowCount()
        self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(case))
        self.table.setItem(row, 1, QTableWidgetItem(party))
        self.table.setItem(row, 2, QTableWidgetItem(date))
        self.table.setItem(row, 3, QTableWidgetItem(documents))
        self.table.setItem(row, 4, QTableWidgetItem(notes))

        # زر اختيار/مسح ملف المحضر
        self.table.setCellWidget(row, 5, self._make_attach_button(row, "إرفاق ملف"))

        self.attendance_files.append("")  # مبدئياً بدون ملف

        # حفظ دائم في تخزين الملف (Dossier) الحالي
        self.save_attendance_data()

        self.filter_bar.clear()      # لتظهر الصفوف كلها بما فيها الجديد
        self.filter_bar.refresh()

        show_info(self, "تم", "تم حفظ البيانات في الجدول.")

    def _make_attach_button(self, row, label):
        from scan_utils import attach_menu_for_button
        btn = QPushButton(label)
        btn.setIcon(qta.icon("fa5s.paperclip", color="#4338ca"))
        btn.setIconSize(QSize(16, 16))
        btn._attach_menu = attach_menu_for_button(
            btn, self,
            on_scan=lambda r=row: self.scan_file(r),
            on_pick_file=lambda r=row: self.attach_file(r),
        )
        return btn

    def attach_file(self, row):
        file, _ = QFileDialog.getOpenFileName(self, "اختر ملف المحضر", "", "Documents (*.pdf *.docx *.doc);;All Files (*)")
        if file:
            self._set_attachment(row, file)

    def scan_file(self, row):
        from scan_utils import scan_document
        file = scan_document(self, suggested_name="محضر_حضور")
        if file:
            self._set_attachment(row, file)

    def _set_attachment(self, row, file):
        file_name = os.path.basename(file)
        self.table.setCellWidget(row, 5, self._make_attach_button(row, file_name))
        self.attendance_files[row] = file
        self.save_attendance_data()

    def open_document(self, row, column):
        if column != 5:
            return
        try:
            path = self.attendance_files[row]
            if path:
                import safe_open
                safe_open.open_path(path)
        except Exception as e:
            show_warning(self, "خطأ", f"تعذر فتح الملف:\n{e}")
    def generate_report_from_form(self):
        # بيانات الخبير: تُقرأ من التخزين المركزي (storage) لأنها صارت تُدار
        # من الصفحة الرئيسية للملف وليست حقولاً داخل MainApp.
        expert_info = storage.load_expert_info()
        expert_name = expert_info.get("name", "") or ""
        expert_title = expert_info.get("job", "") or ""
        expert_address = expert_info.get("address", "") or ""
        expert_phone = expert_info.get("phone", "") or ""

        # الطرف المختار من القائمة
        selected_party = self.party_combo.currentText()
        id_number = ""
        id_date = ""

        # البحث داخل جدول PartyPage
        for row in range(self.party_page.table.rowCount()):
            party_name_item = self.party_page.table.item(row, 0)
            if party_name_item and party_name_item.text() == selected_party:
                id_item = self.party_page.table.item(row, 2)
                date_item = self.party_page.table.item(row, 3)
                id_number = id_item.text() if id_item else ""
                id_date = date_item.text() if date_item else ""
                break  # وجدنا الطرف

        # البحث داخل CasePage بناءً على رقم القضية
        case_number = self.case_combo.currentText()
        index_number = ""
        session_date = ""
        plaintiff = ""
        defendant = ""

        for row in range(self.case_page.table.rowCount()):
         case_item = self.case_page.table.item(row, 0)  # رقم القضية
         if case_item and case_item.text() == case_number:
            index_number = self.case_page.table.item(row, 1).text()      # رقم الفهرس
            session_date = self.case_page.table.item(row, 3).text()      # تاريخ الجلسة
            plaintiff = self.case_page.table.item(row, 5).text()         # المدعي
            defendant = self.case_page.table.item(row, 6).text()         # المدعى عليه
            break  # وجدنا القضية

        # تجميع البيانات
        data = {
         "expert_name": expert_name,
         "expert_title": expert_title,
         "expert_address": expert_address,
         "expert_phone": expert_phone,

         "case_number": case_number,
         "party": selected_party,
         "date": self.date_edit.date().toString("yyyy-MM-dd"),
         "documents": self.docs_input.text(),
         "notes": self.notes_input.toPlainText(),

        # بيانات الطرف (قد تكون فارغة)
         "id_number": id_number,
         "id_date": id_date,

        # بيانات القضية (قد تكون فارغة)
         "index_number": index_number,
         "session_number": session_date,
         "between": plaintiff,
         "against": defendant,

        # حجم الخط المختار من المستخدم لضمان وضوح الطباعة
         "font_size": self.font_size_spin.value()
        }

        # 1⃣ إنشاء المحضر HTML + حفظه
        from generate_attendance import generate_attendance_report
        html_file, pdf_file = generate_attendance_report(data)  # تم تعديل generate_attendance_report لاستخدام pdfkit

        # 2⃣ فتح المحضر مباشرة في المتصفح الخارجي
        from report_viewer import ReportViewer

        self.viewer = ReportViewer(html_file, pdf_file=pdf_file, title="معاينة محضر الحضور")
        self.viewer.show()
        # 3⃣ إعلام المستخدم بمكان PDF
        from PyQt5.QtWidgets import QMessageBox
        show_info(self, "تم", f"تم إنشاء المحضر PDF في:\n{pdf_file}")