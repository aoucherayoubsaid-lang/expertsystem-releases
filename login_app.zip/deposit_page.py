# deposit_page.py
"""
تبويب "الإيداع" الموحّد: يجمع كشف الأتعاب، تسديد الأتعاب، ووصل الإيداع
في تبويبات فرعية (Menu Tabs) داخل تبويب علوي واحد.
"""

from PyQt5.QtWidgets import QWidget, QVBoxLayout, QTabWidget
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
import qtawesome as qta
import storage
from modern_theme import SUB_TAB_QSS

from fees_status_page import FeesStatusPage
from payments_page import PaymentsPage
from receipt_page import ReceiptPage


class DepositPage(QWidget):
    def __init__(self, case_page, main_app):
        super().__init__()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.sub_tabs = QTabWidget()
        # ضبط الخط عبر setFont (لا داخل stylesheet) حتى يحسب Qt عرض
        # التبويبات بشكل صحيح فلا تُقصّ أسماؤها.
        self.sub_tabs.tabBar().setFont(QFont("Segoe UI", 11, QFont.Bold))
        self.sub_tabs.tabBar().setElideMode(Qt.ElideNone)
        self.sub_tabs.tabBar().setExpanding(False)
        self.sub_tabs.tabBar().setUsesScrollButtons(True)
        self.sub_tabs.setStyleSheet(SUB_TAB_QSS)

        user = getattr(main_app, "current_user", None)

        # الصفحات تُنشأ دائماً (تعتمد عليها نافذة كشف الأتعاب في القضايا)،
        # لكن لا يُعرض منها إلا ما يملك الدور صلاحية الاطّلاع عليه.
        self.fees_status_page = FeesStatusPage(case_page)
        self.payments_page = PaymentsPage(main_app)
        self.receipt_page = ReceiptPage(case_page, self.fees_status_page, self.payments_page)

        sub_defs = [
            (self.fees_status_page, "fa5s.money-bill",  "كشف الأتعاب",  "view_fees"),
            (self.payments_page,    "fa5s.money-check", "تسديد الأتعاب", "view_payments"),
            (self.receipt_page,     "fa5s.receipt",     "وصل الإيداع",  "view_receipts"),
        ]
        for page, icon_name, title, perm in sub_defs:
            if storage.user_can(user, perm):
                self.sub_tabs.addTab(page, qta.icon(icon_name, color="#4338ca"), title)

        layout.addWidget(self.sub_tabs)

    def reload(self):
        for page in (self.fees_status_page, self.payments_page, self.receipt_page):
            if hasattr(page, "reload"):
                page.reload()