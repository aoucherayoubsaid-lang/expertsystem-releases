# -*- coding: utf-8 -*-
"""شغّله مرة واحدة فقط لتوليد زوج مفاتيح خاص بك لتوقيع الوثائق.
    python doc_signing_keygen.py

انسخ القيمتين الناتجتين:
- DOC_PRIVATE_HEX  -> إلى doc_signing.py  (يبقى سريًا داخل البرنامج فقط)
- DOC_PUBLIC_HEX   -> إلى doc_signing.py  وإلى verify_offline.html كليهما

لا تستعمل المفتاح المرفق في doc_signing.py كما هو في نسخة حقيقية —
ذاك مثال توضيحي فقط ومعروف لكل من رأى هذا الملف.
"""
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

priv = Ed25519PrivateKey.generate()
pub = priv.public_key()

priv_hex = priv.private_bytes(
    encoding=serialization.Encoding.Raw,
    format=serialization.PrivateFormat.Raw,
    encryption_algorithm=serialization.NoEncryption(),
).hex()
pub_hex = pub.public_bytes(
    encoding=serialization.Encoding.Raw,
    format=serialization.PublicFormat.Raw,
).hex()

print("DOC_PRIVATE_HEX =", priv_hex)
print("DOC_PUBLIC_HEX  =", pub_hex)
