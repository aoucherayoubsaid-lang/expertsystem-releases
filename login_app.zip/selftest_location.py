# -*- coding: utf-8 -*-
"""اختبار بلا واجهة لموقع البيانات: جهاز واحد، مجلد مشترك بجهازين، النقل، وقفل الكتابة.
التشغيل: python selftest_location.py   (كل «جهاز» عملية بايثون مستقلة بمجلد محلي خاص به)"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import textwrap

HERE = os.path.dirname(os.path.abspath(__file__))
fails = []


def check(name, cond):
    print(("PASS  " if cond else "FAIL  ") + name)
    if not cond:
        fails.append(name)


def run(env_extra, code, frozen_exe=None):
    env = dict(os.environ, PYTHONPATH=HERE, PYTHONIOENCODING="utf-8", **env_extra)
    env.pop("EXPERT_DATA_DIR", None) if "EXPERT_DATA_DIR" not in env_extra else None
    pre = "import sys\n"
    if frozen_exe:
        pre += "sys.frozen=True; sys.executable=%r\n" % frozen_exe
    p = subprocess.run([sys.executable, "-c", pre + textwrap.dedent(code)], cwd=HERE, env=env,
                       capture_output=True, text=True)
    if p.returncode != 0:
        print(p.stdout, p.stderr)
    return p.stdout.strip(), p.returncode


root = tempfile.mkdtemp(prefix="loc_")
try:
    # ------------------------------------------------------------------ 1) الجهاز الواحد: نقل من جوار الـ exe
    exe_dir = os.path.join(root, "Program Files", "ExpertSystem")
    os.makedirs(os.path.join(exe_dir, "app_data"))
    os.makedirs(os.path.join(exe_dir, "dossiers_data", "قضية_1"))
    with open(os.path.join(exe_dir, "app_data", "users.json"), "w", encoding="utf-8") as f:
        f.write('[{"u": "قديم"}]')
    with open(os.path.join(exe_dir, "dossiers_data", "قضية_1", "x.json"), "w", encoding="utf-8") as f:
        f.write('{"k": 1}')
    open(os.path.join(exe_dir, "docs_api.json"), "w").write('{"url": "https://x.example"}')
    A = os.path.join(root, "A_local")
    out, rc = run({"EXPERT_LOCAL_DIR": A}, "import app_paths;print(app_paths.app_base_dir())",
                  frozen_exe=os.path.join(exe_dir, "ExpertSystem.exe"))
    want = os.path.join(A, "data")
    check("exe: data base moves to LOCALAPPDATA/ExpertSystem/data", out == want)
    check("exe: files migrated intact", open(os.path.join(want, "app_data", "users.json"), encoding="utf-8").read() == '[{"u": "قديم"}]'
          and os.path.exists(os.path.join(want, "dossiers_data", "قضية_1", "x.json")))
    check("exe: legacy copy removed after verification", not os.path.exists(os.path.join(exe_dir, "app_data"))
          and not os.path.exists(os.path.join(exe_dir, "dossiers_data")))
    check("exe: shipped config next to exe untouched", os.path.exists(os.path.join(exe_dir, "docs_api.json")))

    # فشل التحقق أثناء النقل => يبقى الأصل ويُكمل العمل عليه
    exe2 = os.path.join(root, "pf2")
    os.makedirs(os.path.join(exe2, "app_data"))
    open(os.path.join(exe2, "app_data", "users.json"), "w").write("[]")
    out, rc = run({"EXPERT_LOCAL_DIR": os.path.join(root, "A2")}, """
        import shutil, app_paths
        def boom(*a, **k): raise OSError("disk full")
        shutil.copytree = boom
        print(app_paths.app_base_dir())
    """, frozen_exe=os.path.join(exe2, "x.exe"))
    check("migration failure: keeps working on legacy folder, nothing deleted",
          out == exe2 and os.path.exists(os.path.join(exe2, "app_data", "users.json")))

    # ------------------------------------------------------------------ 2) من جهاز واحد إلى مجلد مشترك (الجهاز A)
    shared = os.path.join(root, "share")
    os.makedirs(shared)
    out, rc = run({"EXPERT_LOCAL_DIR": A}, """
        import app_paths
        app_paths.write_location("local")
        import storage, local_protect, data_location, os
        storage._write_json(storage.USERS_FILE, [{"username": "ali"}])
        storage._write_json(storage.SETTINGS_FILE, {"lang": "ar"})
        open(os.path.join(app_paths.machine_dir(), ".es_dk"), "wb").write(b"DEVICEKEY")
        open(os.path.join(app_paths.machine_dir(), ".es_state"), "w").write("STATE")
        import security_manager
        try:
            data_location.switch_to_shared(%r, "short")
        except Exception as e:
            print("weak:", type(e).__name__)
        r = data_location.switch_to_shared(%r, "عبارة-مرور-طويلة-123")
        print("created", r["created"])
    """ % (shared, shared))
    check("weak passphrase rejected, strong accepted", "weak: SwitchError" in out and "created True" in out)
    sh_app = os.path.join(shared, "app_data")
    names = set(os.listdir(sh_app))
    check("shared folder holds users/settings + signatures + descriptor",
          {"users.json", "users.json.sig", "settings.json", "settings.json.sig", ".es_shared.json"} <= names)
    check("device-only files NEVER copied to shared folder",
          not ({".es_dk", ".es_state", ".es_mk", "security.json", "security_audit.jsonl", "rag_references.db"} & names))
    check("device files now live in local machine folder",
          os.path.exists(os.path.join(A, "machine", ".es_dk")) and os.path.exists(os.path.join(A, "machine", ".es_state"))
          and os.path.exists(os.path.join(A, "machine", ".es_mk")))
    check("old local data wiped after verified copy", not os.path.exists(os.path.join(A, "data", "app_data", "users.json")))
    check("descriptor does not contain the passphrase or key",
          "عبارة" not in open(os.path.join(sh_app, ".es_shared.json"), encoding="ascii").read())

    # ------------------------------------------------------------------ 3) جهاز ثانٍ B ينضم
    B = os.path.join(root, "B_local")
    out, rc = run({"EXPERT_LOCAL_DIR": B}, """
        import app_paths
        app_paths.write_location("shared", %r)
        import local_protect
        print(local_protect.shared_state())
        try:
            local_protect.unlock_shared("عبارة-خاطئة-طويلة-999")
        except ValueError as e:
            print("wrong")
        local_protect.unlock_shared("عبارة-مرور-طويلة-123")
        import storage
        users = storage.load_users()
        print(json.dumps(users, ensure_ascii=False) if False else users[0]["username"], local_protect.tamper_detected())
        print(local_protect.shared_state())
    """ % shared)
    lines = out.splitlines()
    check("B sees need_unlock, rejects wrong passphrase", lines[:2] == ["need_unlock", "wrong"])
    check("B reads A's signed users.json with no tamper flag", lines[2] == "ali False")
    check("B ready afterwards (passphrase asked once per machine)", lines[3] == "ready")

    # B بلا مفتاح: لا يولّد مفتاحاً عشوائياً ولا يعدّ ذلك عبثاً
    C = os.path.join(root, "C_local")
    out, rc = run({"EXPERT_LOCAL_DIR": C}, """
        import app_paths
        app_paths.write_location("shared", %r)
        import local_protect
        try:
            local_protect.master_key()
        except local_protect.PassphraseRequired:
            print("needs-passphrase")
        import os
        print(os.path.exists(os.path.join(app_paths.machine_dir(), ".es_mk")))
    """ % shared)
    check("shared mode never mints a random local key", out.splitlines() == ["needs-passphrase", "False"])

    # ------------------------------------------------------------------ 4) عبث بالملف المشترك يُكتشف من جهاز آخر
    with open(os.path.join(sh_app, "users.json"), "r+", encoding="utf-8") as f:
        orig = f.read()
        f.seek(0); f.write(orig.replace("ali", "evil")); f.truncate()
    out, rc = run({"EXPERT_LOCAL_DIR": B}, """
        import app_paths, storage, local_protect
        print(storage.load_users(), local_protect.tamper_detected())
    """)
    check("edited shared users.json detected on another machine", out == "[] True")
    with open(os.path.join(sh_app, "users.json"), "w", encoding="utf-8") as f:
        f.write(orig)

    # ------------------------------------------------------------------ 5) قفل الكتابة
    lock_code = """
        import app_paths, data_lock, storage, os, sys, json, time
        app_paths.write_location("shared", %r)
        import local_protect
        %s
        res = data_lock.acquire()
        print(res["role"], data_lock.is_read_only())
        %s
    """
    # الكاتب A: يحصل على العقد ويكتب ويبقي العقد (لا release) عبر عملية تنتظر
    holderA = subprocess.Popen([sys.executable, "-c", textwrap.dedent("""
        import app_paths, data_lock, local_protect, sys, time
        app_paths.write_location("shared", %r)
        print(data_lock.acquire()["role"], flush=True)
        time.sleep(25)
    """ % shared)], cwd=HERE, env=dict(os.environ, PYTHONPATH=HERE, EXPERT_LOCAL_DIR=A, PYTHONIOENCODING="utf-8"),
        stdout=subprocess.PIPE, text=True)
    first = holderA.stdout.readline().strip()
    check("A acquires writer lease", first == "writer")
    out, rc = run({"EXPERT_LOCAL_DIR": B}, lock_code % (shared, 'local_protect.unlock_shared("عبارة-مرور-طويلة-123")', """
        before = open(storage.SETTINGS_FILE, encoding="utf-8").read()
        storage._write_json(storage.SETTINGS_FILE, {"lang": "fr"})
        print(open(storage.SETTINGS_FILE, encoding="utf-8").read() == before)
        print(data_lock.holder_text() != "")
    """))
    l = out.splitlines()
    check("B becomes reader while A holds the lease", l[0] == "reader True")
    check("B's save is refused (file unchanged)", l[1] == "True")
    check("B is told who holds the lease", l[2] == "True")
    holderA.kill(); holderA.wait()

    # عقد A «ميت» (انهار البرنامج): بعد 90 ثانية على ساعة الخادم يستولي B
    lease = os.path.join(sh_app, ".writer.lease")
    check("crashed holder leaves a lease file", os.path.exists(lease))
    old = os.path.getmtime(lease) - 300
    os.utime(lease, (old, old))
    out, rc = run({"EXPERT_LOCAL_DIR": B}, lock_code % (shared, 'local_protect.unlock_shared("عبارة-مرور-طويلة-123")', """
        storage._write_json(storage.SETTINGS_FILE, {"lang": "fr"})
        print(storage.load_settings({}))
        data_lock.release()
        print(os.path.exists(os.path.join(app_paths.shared_app_data_dir(), ".writer.lease")))
    """))
    l = out.splitlines()
    check("stale lease is taken over; B writes; release removes lease",
          l[0] == "writer False" and l[1] == "{'lang': 'fr'}" and l[2] == "False")

    # ------------------------------------------------------------------ 6) فهارس الذكاء الاصطناعي تبقى محلية في الوضع المشترك
    out, rc = run({"EXPERT_LOCAL_DIR": B}, """
        import app_paths, local_protect, storage, rag_index, os
        app_paths.write_location("shared", %r)
        local_protect.unlock_shared("عبارة-مرور-طويلة-123")
        p = rag_index.reference_index().path if hasattr(rag_index.reference_index(), "path") else None
        print(p)
    """ % shared)
    check("reference index stays in the machine folder (not on the share)",
          out.startswith(os.path.join(B, "machine")) or (out and shared not in out))

    # ------------------------------------------------------------------ 7) العودة لجهاز واحد
    out, rc = run({"EXPERT_LOCAL_DIR": B}, """
        import app_paths
        app_paths.write_location("shared", %r)
        import local_protect, data_location
        local_protect.unlock_shared("عبارة-مرور-طويلة-123")
        data_location.switch_to_local()
        print("switched")
    """ % shared)
    check("switch_to_local completes", out.splitlines()[-1:] == ["switched"])
    out, rc = run({"EXPERT_LOCAL_DIR": B}, """
        import app_paths, storage, local_protect
        print(app_paths.data_mode(), storage.load_users()[0]["username"], local_protect.tamper_detected(),
              app_paths.app_base_dir().startswith(%r))
    """ % B)
    check("after switching back: data readable, signatures valid, data under this machine only", out == "local ali False True")
    check("shared folder untouched by switching one machine back", os.path.exists(os.path.join(sh_app, "users.json"))
          and os.path.exists(os.path.join(sh_app, ".es_shared.json")))
finally:
    shutil.rmtree(root, ignore_errors=True)

print("\n%d failure(s)" % len(fails))
sys.exit(1 if fails else 0)
