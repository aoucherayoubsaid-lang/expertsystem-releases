"""توليد كشف الأتعاب (Excel) من القالب الجديد fees_template.xlsx.

الخلايا التي يكتب فيها البرنامج:
  C8  = الجهة القضائية      C12 = رقم القضية
  C14 = رقم الفهرس          C16 = رقم الجلسة / التاريخ
  H20..H28 = البنود التسعة بالترتيب (دراسة، تنقل، بحث، مقابلة، تقرير، طبع، إيداع، طوابع، تبليغ)
  H29 = المجموع
تمت إزالة المدعي والمدعى عليه والرقم الجبائي ورقم المادة من القالب.
"""
import os
import shutil
from datetime import datetime

from openpyxl import load_workbook

import storage
from resource_path import resource_path

FEE_KEYS = ("study", "travel", "research", "interview", "report",
            "printing", "filing", "stamp", "notification")
FIRST_FEE_ROW = 20


def _num(data, key):
    txt = str(data.get(key) or "").strip().replace(" ", "").replace(",", ".")
    return float(txt) if txt else 0.0


def generate_fees_excel(data):
    template = resource_path("fees_template.xlsx")
    case = "".join("_" if ch in '\\/:*?"<>|' else ch
                   for ch in str(data.get("case", "")).strip()) or "قضية"
    out = os.path.join(storage.reports_dir("fees"),
                       f"fees_{case}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx")
    shutil.copy(template, out)

    wb = load_workbook(out)
    ws = wb.active
    ws["C8"] = data["court"]
    ws["C12"] = data["case"]
    ws["C14"] = data["index_number"]
    ws["C16"] = data["session_date"]

    for offset, key in enumerate(FEE_KEYS):
        ws[f"H{FIRST_FEE_ROW + offset}"] = _num(data, key)
    ws["H29"] = _num(data, "total")

    wb.save(out)
    return os.path.abspath(out)
