# -*- coding: utf-8 -*-
"""نافذة «المراجع» (قوانين وكتب): رفع وفهرسة وحذف.

الفهرسة تجري في خيط خلفي فلا تتجمد الواجهة. تحتاج ai_client + rag_index.

الاستعمال من أي صفحة (مثلاً زر في صفحة الإعدادات أو إعداد التقرير):
    from references_page import ReferencesDialog
    ReferencesDialog(self).exec_()
"""
import os

from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtWidgets import (
    QAbstractItemView, QComboBox, QDialog, QFileDialog, QHBoxLayout, QHeaderView,
    QLabel, QPushButton, QTreeWidget, QTreeWidgetItem, QVBoxLayout,
)

import rag_index
from msgbox_ltr import show_confirm, show_info, show_warning

_STATUS = {"ok": "مفهرس ✔", "no_text": "تعذّرت قراءة النص", "error": "خطأ"}


class _IndexWorker(QThread):
    progress = pyqtSignal(str)
    finished_all = pyqtSignal(list)   # [(اسم_الملف, حالة, تفاصيل)]

    def __init__(self, paths, category, parent=None):
        super().__init__(parent)
        self.paths, self.category = paths, category

    def run(self):
        results = []
        for i, p in enumerate(self.paths, 1):
            name = os.path.basename(p)
            self.progress.emit("جارٍ فهرسة (%d/%d): %s" % (i, len(self.paths), name))
            try:
                r = rag_index.add_reference(p, title=os.path.splitext(name)[0], category=self.category)
                results.append((name, r["status"], ""))
            except Exception as e:           # مثل: لا ترخيص مدفوع، لا إنترنت، ملف تالف
                results.append((name, "error", str(e)))
                if "ترخيص" in str(e) or "إنترنت" in str(e):
                    break                    # لا فائدة من متابعة بقية الملفات
        self.finished_all.emit(results)


class ReferencesDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("المراجع (قوانين وكتب)")
        self.setLayoutDirection(Qt.RightToLeft)
        self.resize(760, 520)
        self._worker = None

        lay = QVBoxLayout(self)
        lay.addWidget(QLabel(
            "ارفع القوانين والكتب التي يعتمد عليها التقرير. تُفهرس مرة واحدة، وتبقى متاحة لكل القضايا.\n"
            "اختر تصنيفاً (مثل: مدني، تجاري، محاسبي) قبل الرفع، فيبحث البرنامج في التصنيف المناسب فقط."))

        row = QHBoxLayout()
        row.addWidget(QLabel("التصنيف :"))
        self.category = QComboBox()
        self.category.setEditable(True)
        self.category.setMinimumWidth(220)
        row.addWidget(self.category)
        self.btn_add = QPushButton("رفع مراجع...")
        self.btn_add.clicked.connect(self._pick_files)
        row.addWidget(self.btn_add)
        self.btn_del = QPushButton("حذف المحدد")
        self.btn_del.clicked.connect(self._delete_selected)
        row.addWidget(self.btn_del)
        row.addStretch(1)
        lay.addLayout(row)

        self.tree = QTreeWidget()
        self.tree.setColumnCount(4)
        self.tree.setHeaderLabels(["المرجع", "التصنيف", "عدد القطع", "الحالة"])
        self.tree.setRootIsDecorated(False)
        self.tree.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tree.header().setSectionResizeMode(0, QHeaderView.Stretch)
        lay.addWidget(self.tree, 1)

        self.status = QLabel("")
        lay.addWidget(self.status)
        self._reload()

    # -- القائمة --------------------------------------------------------------
    def _reload(self):
        self.tree.clear()
        cats = set()
        try:
            rows = rag_index.reference_index().list_sources()
        except Exception as e:
            self.status.setText("تعذّر فتح فهرس المراجع: %s" % e)
            return
        for key, title, cat, n, ocr, st in rows:
            if cat:
                cats.add(cat)
            item = QTreeWidgetItem([title or "", cat or "", str(n), _STATUS.get(st, st)])
            item.setData(0, Qt.UserRole, key)
            self.tree.addTopLevelItem(item)
        current = self.category.currentText()
        self.category.clear()
        self.category.addItems(sorted(cats))
        self.category.setEditText(current)
        stats = rag_index.reference_index().stats()
        self.status.setText("المراجع: %d  |  القطع المفهرسة: %d" % (stats["sources"], stats["chunks"]))

    # -- الرفع ----------------------------------------------------------------
    def _pick_files(self):
        if self._worker is not None:
            return
        paths, _ = QFileDialog.getOpenFileNames(
            self, "اختر مراجع", "", "مراجع (*.pdf *.docx *.txt *.md *.jpg *.jpeg *.png)")
        if not paths:
            return
        cat = self.category.currentText().strip()
        if not cat and not show_confirm(
                self, "بدون تصنيف", "لم تحدد تصنيفاً. المراجع بلا تصنيف يصعب حصر البحث بها. أتابع؟"):
            return
        self.btn_add.setEnabled(False)
        self.btn_del.setEnabled(False)
        self._worker = _IndexWorker(paths, cat, self)
        self._worker.progress.connect(self.status.setText)
        self._worker.finished_all.connect(self._done)
        self._worker.start()

    def _done(self, results):
        self._worker = None
        self.btn_add.setEnabled(True)
        self.btn_del.setEnabled(True)
        self._reload()
        ok = [n for n, s, _ in results if s in ("ok", "unchanged")]
        scanned = [n for n, s, _ in results if s == "no_text"]
        errors = [(n, d) for n, s, d in results if s == "error"]
        msg = "تمت فهرسة %d ملف." % len(ok)
        if scanned:
            msg += "\n\nملفات ممسوحة ضوئياً لا تحتوي نصاً (تحتاج OCR لاحقاً):\n" + "\n".join(scanned)
        if errors:
            msg += "\n\nأخطاء:\n" + "\n".join("%s: %s" % e for e in errors)
            show_warning(self, "المراجع", msg)
        else:
            show_info(self, "المراجع", msg)

    # -- الحذف ----------------------------------------------------------------
    def _delete_selected(self):
        items = self.tree.selectedItems()
        if not items:
            return
        if not show_confirm(self, "حذف", "حذف %d مرجع من الفهرس؟ (الملف الأصلي على جهازك لا يُحذف)" % len(items), danger=True):
            return
        idx = rag_index.reference_index()
        for it in items:
            idx.remove_source(it.data(0, Qt.UserRole))
        self._reload()
