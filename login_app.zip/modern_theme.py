# modern_theme.py
"""
طبقة التصميم العصري للبرنامج (PyQt5) — تُفعَّل من مكان واحد دون تعديل الصفحات.

1) أزرار احترافية: تدرّج لوني، ظل يتوهّج ويرتفع عند المرور، هبوط عند الضغط،
   تأثير موجة (Ripple) عند النقر، مؤشر يد، وحالة معطّلة واضحة.
2) حركات: ظهور تدريجي + انزلاق خفيف للنوافذ والحوارات، وانتقال تدريجي بين
   التبويبات والصفحات، وإشعارات Toast منزلقة.
3) تنسيق موحّد: أشرطة تمرير رفيعة، حقول، قوائم منسدلة، Checkbox، جداول
   (صفوف متناوبة + تمييز عند المرور + رأس موحّد)، قوائم، رسائل.

الاستعمال (مرة واحدة بعد QApplication وقبل أي نافذة):
    from modern_theme import install_modern_theme
    install_modern_theme(app)
"""

import os
import re
import math
import tempfile

from PyQt5.QtCore import (
    QObject, QEvent, Qt, QPropertyAnimation, QVariantAnimation, QEasingCurve,
    QPoint, QPointF, QRectF, QTimer,
)
from PyQt5.QtGui import QColor, QPainter, QPainterPath
from PyQt5.QtWidgets import (
    QApplication, QPushButton, QGraphicsDropShadowEffect, QGraphicsOpacityEffect,
    QTabWidget, QStackedWidget, QAbstractItemView, QWidget, QDialog, QLabel,
    QTableView, QHeaderView,
)

# ---------------------------------------------------------------------------
# مفاتيح تشغيل/إيقاف. الوضع الخفيف مفعّل: الحركات والظلال معطّلة لأن الجهاز قديم
# (i3-2370M / 4GB) والظلال تسبب بطئاً وانهياراً أحياناً. غيّر إلى True لإعادتها.
# ---------------------------------------------------------------------------
ENABLE_WINDOW_FADE = False       # ظهور تدريجي للنوافذ
ENABLE_DIALOG_SLIDE = False      # انزلاق خفيف للحوارات
ENABLE_PAGE_FADE = False         # انتقال تدريجي بين التبويبات/الصفحات
ENABLE_BUTTON_EFFECTS = False    # ظل + حركة الأزرار
ENABLE_RIPPLE = False            # موجة عند النقر
ENABLE_TABLE_POLISH = True      # تحسين الجداول تلقائياً
ENABLE_GLOBAL_QSS = True        # التنسيق العام

WINDOW_FADE_MS = 220
PAGE_FADE_MS = 220
BUTTON_ANIM_MS = 160

import theme_tokens as T

NAVY = T.PRIMARY
ACCENT = T.ACCENT

BUTTON_KINDS = {
    "primary":   T.PRIMARY,
    "info":      T.ACCENT,
    "success":   T.SUCCESS,
    "danger":    T.DANGER,
    "warning":   T.WARNING,
    "purple":    T.PURPLE,
    "secondary": T.SECONDARY,
}

MAIN_TAB_QSS = f"""
    QTabWidget::pane {{ border: none; border-top: 1px solid {T.BORDER}; background: {T.BG}; }}
    QTabBar {{ background: {T.SURFACE}; }}
    QTabBar::tab {{
        background: {T.SURFACE}; color: {T.TEXT_MUTED}; padding: 11px 20px; min-width: 90px;
        margin: 0; border: none; border-bottom: 3px solid transparent;
    }}
    QTabBar::tab:selected {{ color: {T.PRIMARY_DARK}; border-bottom: 3px solid {T.ACCENT}; background: {T.BG}; }}
    QTabBar::tab:hover:!selected {{ background: {T.HOVER_BG}; color: {T.PRIMARY_DARK}; }}
"""

SUB_TAB_QSS = f"""
    QTabWidget::pane {{ border: none; border-top: 1px solid {T.BORDER}; background: {T.BG}; }}
    QTabBar {{ background: transparent; }}
    QTabBar::tab {{
        background: transparent; color: {T.TEXT_MUTED}; padding: 7px 18px; min-width: 96px;
        margin: 8px 3px; border: none; border-radius: 15px;
    }}
    QTabBar::tab:selected {{ background: {T.ACCENT}; color: white; font-weight: 600; }}
    QTabBar::tab:hover:!selected {{ background: {T.HOVER_BG}; color: {T.PRIMARY}; }}
"""

HEADER_QSS = (
    "QHeaderView { background: #4338ca; border: none; }"
    "QHeaderView::section { background: #4338ca; color: white; padding: 11px 8px;"
    " border: none; border-right: 1px solid #5b52d6; font-weight: bold; }"
)


# ---------------------------------------------------------------------------
# ألوان وأنماط الأزرار
# ---------------------------------------------------------------------------
def _gradient(color, light=112, dark=100):
    """متروكة للتوافق: نُرجع لوناً صلباً بدل التدرّج (أخف وأوضح)."""
    return QColor(color).lighter(light).name() if light != 100 else QColor(color).name()


def button_qss(color, radius=8, padding="9px 22px"):
    """زر مسطّح احترافي: تدرّج رأسي ناعم جداً (فاتح ← اللون الأصلي) بلا ظلال مكلفة."""
    c = QColor(color)
    r = min(max(radius, T.RADIUS_CTRL), 14)
    return f"""
        QPushButton {{
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 {c.lighter(110).name()}, stop:1 {c.name()});
            color: white; font-weight: bold; border: none;
            border-bottom: 2px solid {c.darker(122).name()};
            border-radius: {r}px; padding: {padding};
        }}
        QPushButton:hover {{
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 {c.lighter(122).name()}, stop:1 {c.lighter(108).name()});
        }}
        QPushButton:pressed {{ background: {c.darker(112).name()}; border-bottom: 2px solid {c.darker(112).name()}; }}
        QPushButton:disabled {{
            background: {T.HOVER_BG}; color: #9199b8; border-bottom: 2px solid {T.BORDER};
        }}
    """


def hero_button_qss(c1=None, c2=None, radius=12, padding="12px 22px", fg="white"):
    """زر رئيسي كبير بتدرّج أفقي بنفسجي (لأزرار الدخول/الفتح/الدخول إلى صفحة العمل)."""
    c1 = c1 or T.GRAD_A
    c2 = c2 or T.GRAD_B
    a, b = QColor(c1), QColor(c2)
    return f"""
        QPushButton {{
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {a.name()}, stop:1 {b.name()});
            color: {fg}; font-weight: bold; border: none;
            border-bottom: 3px solid {b.darker(130).name()};
            border-radius: {radius}px; padding: {padding};
        }}
        QPushButton:hover {{
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {a.lighter(115).name()}, stop:1 {b.lighter(115).name()});
        }}
        QPushButton:pressed {{
            background: {a.darker(110).name()}; border-bottom: 3px solid {a.darker(110).name()};
        }}
        QPushButton:disabled {{ background: {T.HOVER_BG}; color: #9199b8; border-bottom: 3px solid {T.BORDER}; }}
    """


def style_hero_button(btn, c1=None, c2=None, radius=12, padding="12px 22px"):
    """يطبّق hero_button_qss ويعلّم الزر كمُنسَّق (لا يعيد modern_theme تنسيقه)."""
    btn.setStyleSheet(hero_button_qss(c1, c2, radius, padding))
    btn.setProperty("_mt_styled", True)
    btn._mt_base = QColor(c1 or T.GRAD_A)
    btn._mt_dark = True
    btn.setCursor(Qt.PointingHandCursor)


def style_white_button(btn, fg=None, radius=12, padding="11px 22px"):
    """زر أبيض بنص ملوّن: للأزرار فوق لوحات التدرّج (بدون حدود ثقيلة)."""
    fg = fg or T.PRIMARY_DARK
    btn.setStyleSheet(f"""
        QPushButton {{ background: white; color: {fg}; font-weight: bold; border: none;
            border-bottom: 3px solid #cfcaf7; border-radius: {radius}px; padding: {padding}; }}
        QPushButton:hover {{ background: #f3f2ff; }}
        QPushButton:pressed {{ background: #e7e5ff; border-bottom: 3px solid #e7e5ff; }}
    """)
    btn.setProperty("_mt_styled", True)
    btn._mt_base = QColor("#ffffff")
    btn._mt_dark = False
    btn.setCursor(Qt.PointingHandCursor)


def style_button(btn, kind="primary", radius=8, padding="9px 22px"):
    """تصميم احترافي جاهز: kind = primary/info/success/danger/warning/purple/secondary أو لون #hex."""
    color = BUTTON_KINDS.get(kind, kind)
    btn.setStyleSheet(button_qss(color, radius, padding))
    btn.setProperty("_mt_styled", True)
    btn._mt_base = QColor(color)   # لون الظل والموجة
    btn._mt_dark = True            # خلفية داكنة -> موجة بيضاء
    btn.setCursor(Qt.PointingHandCursor)


def style_soft_button(btn, kind="info", radius=10, padding="6px 14px"):
    """زر ناعم (خلفية فاتحة بلون النوع + نص ملوّن) للأزرار داخل الجداول والأشرطة."""
    c = QColor(BUTTON_KINDS.get(kind, kind))
    btn.setStyleSheet(f"""
        QPushButton {{
            background: {c.lighter(190).name()}; color: {c.darker(115).name()};
            font-weight: bold; border: 1px solid {c.lighter(150).name()};
            border-radius: {radius}px; padding: {padding};
        }}
        QPushButton:hover {{ background: {c.lighter(170).name()}; border-color: {c.name()}; }}
        QPushButton:pressed {{ background: {c.lighter(140).name()}; }}
        QPushButton:disabled {{ background: #f8f9ff; color: #9199b8; border-color: #eef0ff; }}
    """)
    btn.setProperty("_mt_styled", True)
    btn._mt_base = QColor(c)
    btn._mt_dark = False           # خلفية فاتحة -> موجة داكنة
    btn.setCursor(Qt.PointingHandCursor)


_RULE_RE = re.compile(r"QPushButton\s*(?P<sel>(?::[a-zA-Z\-]+)*)\s*\{(?P<body>[^}]*)\}")
_BG_RE = re.compile(r"background(?:-color)?\s*:\s*(#[0-9a-fA-F]{6}|#[0-9a-fA-F]{3})\b")
_NAMED_BG_RE = re.compile(r"background(?:-color)?\s*:\s*(green|navy|red|orange|blue|purple|gray|grey)\b")
_RADIUS_RE = re.compile(r"border-radius\s*:\s*(\d+)px")


def _base_color(ss):
    if not ss:
        return None
    bodies = []
    if "{" not in ss:
        bodies = [ss]
    else:
        bodies = [r.group("body") for r in _RULE_RE.finditer(ss) if not r.group("sel")]
    for body in bodies:
        m = _BG_RE.search(body)
        if m:
            return QColor(m.group(1))
        m = _NAMED_BG_RE.search(body)
        if m:
            return QColor(m.group(1))
    return None


def _is_transparent_style(ss):
    s = (ss or "").replace(" ", "").lower()
    return "background:transparent" in s or "background-color:transparent" in s


def _in_item_view(w):
    p = w.parentWidget()
    while p is not None:
        if isinstance(p, QAbstractItemView):
            return True
        p = p.parentWidget()
    return False


def _contains_webengine(w):
    try:
        for c in w.findChildren(QWidget):
            if "WebEngine" in c.metaObject().className():
                return True
    except RuntimeError:
        pass
    return False


# ---------------------------------------------------------------------------
# موجة النقر (Ripple)
# ---------------------------------------------------------------------------
class _Ripple(QWidget):
    def __init__(self, btn, pos, dark_bg):
        super().__init__(btn)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WA_NoSystemBackground)
        self.setGeometry(btn.rect())
        self._center = QPointF(pos)
        self._t = 0.0
        w, h = btn.width(), btn.height()
        self._max = math.hypot(max(pos.x(), w - pos.x()), max(pos.y(), h - pos.y()))
        m = _RADIUS_RE.search(btn.styleSheet() or "")
        self._radius = int(m.group(1)) if m else 8
        self._color = QColor(255, 255, 255) if dark_bg else QColor(20, 48, 63)
        self._peak = 90 if dark_bg else 45
        anim = QVariantAnimation(self)
        anim.setDuration(520)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.valueChanged.connect(self._tick)
        anim.finished.connect(self.deleteLater)
        self._anim = anim
        self.show()
        self.raise_()
        anim.start()

    def _tick(self, v):
        self._t = float(v)
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        path = QPainterPath()
        path.addRoundedRect(QRectF(self.rect()), self._radius, self._radius)
        p.setClipPath(path)
        col = QColor(self._color)
        col.setAlpha(int(self._peak * (1.0 - self._t)))
        p.setPen(Qt.NoPen)
        p.setBrush(col)
        r = self._max * self._t
        p.drawEllipse(self._center, r, r)
        p.end()


# ---------------------------------------------------------------------------
# إعداد الأزرار
# ---------------------------------------------------------------------------
def _setup_button(btn):
    if btn.property("_mt_setup"):
        return
    btn.setProperty("_mt_setup", True)

    if btn.cursor().shape() == Qt.ArrowCursor:
        btn.setCursor(Qt.PointingHandCursor)

    ss = btn.styleSheet() or ""
    base = getattr(btn, "_mt_base", None) or _base_color(ss)
    if not hasattr(btn, "_mt_dark"):
        btn._mt_dark = (base.lightness() < 150) if base is not None else False

    if base is not None and not btn.property("_mt_styled"):
        wrapped = ss if "{" in ss else f"QPushButton {{ {ss} }}"
        extra = f"""
            QPushButton {{ background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 {base.lighter(110).name()}, stop:1 {base.name()}); border: none;
                border-bottom: 2px solid {base.darker(122).name()}; }}
            QPushButton:hover {{ background: {base.lighter(112).name()}; }}
            QPushButton:pressed {{ background: {base.darker(115).name()};
                border-bottom: 2px solid {base.darker(115).name()}; }}
            QPushButton:disabled {{ background: #eef0ff; color: #9199b8; }}
        """
        btn.setProperty("_mt_styled", True)
        btn.setStyleSheet(wrapped + extra)

    if (not ENABLE_BUTTON_EFFECTS or btn.isFlat() or _is_transparent_style(ss)
            or btn.graphicsEffect() is not None or _in_item_view(btn)):
        return

    glow = base if base is not None else QColor(NAVY)
    effect = QGraphicsDropShadowEffect(btn)
    effect.setColor(QColor(glow.red(), glow.green(), glow.blue(), 60))
    effect.setBlurRadius(6)
    effect.setOffset(0, 1)
    btn.setGraphicsEffect(effect)

    anim = QVariantAnimation(btn)
    anim.setDuration(BUTTON_ANIM_MS)
    anim.setEasingCurve(QEasingCurve.OutCubic)

    def apply(t):
        try:
            effect.setBlurRadius(6 + 14 * t)
            effect.setOffset(0, 1 + 3 * t)
            effect.setColor(QColor(glow.red(), glow.green(), glow.blue(), int(60 + 70 * t)))
        except RuntimeError:
            pass

    anim.valueChanged.connect(apply)
    btn._mt_anim = anim


def _animate_button(btn, target, ms=None):
    anim = getattr(btn, "_mt_anim", None)
    if anim is None:
        return
    anim.stop()
    anim.setDuration(ms or BUTTON_ANIM_MS)
    anim.setStartValue(float(anim.currentValue() or 0.0))
    anim.setEndValue(float(target))
    anim.start()


# ---------------------------------------------------------------------------
# حركات الظهور
# ---------------------------------------------------------------------------
def _fade_window(w):
    if w.testAttribute(Qt.WA_TranslucentBackground):
        return
    if w.windowType() in (Qt.Popup, Qt.ToolTip, Qt.SplashScreen):
        return
    if _contains_webengine(w):      # QWebEngineView + شفافية النافذة = شاشة سوداء أحياناً
        return
    w.setWindowOpacity(0.0)
    anim = QPropertyAnimation(w, b"windowOpacity", w)
    anim.setDuration(WINDOW_FADE_MS)
    anim.setStartValue(0.0)
    anim.setEndValue(1.0)
    anim.setEasingCurve(QEasingCurve.OutCubic)
    w._mt_fade = anim
    anim.start()


def _slide_dialog(w):
    if w.isMaximized() or w.isFullScreen() or _contains_webengine(w):
        return
    end = w.pos()
    anim = QPropertyAnimation(w, b"pos", w)
    anim.setDuration(WINDOW_FADE_MS + 80)
    anim.setStartValue(end + QPoint(0, 18))
    anim.setEndValue(end)
    anim.setEasingCurve(QEasingCurve.OutCubic)
    w._mt_slide = anim
    anim.start()


def fade_in(widget, ms=PAGE_FADE_MS):
    """ظهور تدريجي لأي ودجت (يُزال المؤثّر بعد الانتهاء)."""
    if widget is None or widget.graphicsEffect() is not None or _contains_webengine(widget):
        return
    eff = QGraphicsOpacityEffect(widget)
    eff.setOpacity(0.0)
    widget.setGraphicsEffect(eff)
    anim = QPropertyAnimation(eff, b"opacity", widget)
    anim.setDuration(ms)
    anim.setStartValue(0.0)
    anim.setEndValue(1.0)
    anim.setEasingCurve(QEasingCurve.OutCubic)

    def done():
        try:
            if widget.graphicsEffect() is eff:
                widget.setGraphicsEffect(None)
        except RuntimeError:
            pass

    anim.finished.connect(done)
    anim.start(QPropertyAnimation.DeleteWhenStopped)


def _hook_tabs(tw):
    if tw.property("_mt_hooked"):
        return
    tw.setProperty("_mt_hooked", True)
    tw.currentChanged.connect(lambda i, tw=tw: fade_in(tw.widget(i)) if tw.isVisible() else None)


def _hook_stack(sw):
    if sw.property("_mt_hooked") or isinstance(sw.parentWidget(), QTabWidget):
        return
    sw.setProperty("_mt_hooked", True)
    sw.currentChanged.connect(lambda i, sw=sw: fade_in(sw.widget(i)) if sw.isVisible() else None)


# ---------------------------------------------------------------------------
# الجداول
# ---------------------------------------------------------------------------
def _has_header_rule(w):
    while w is not None:
        if "QHeaderView" in (w.styleSheet() or ""):
            return True
        w = w.parentWidget()
    return False


def _polish_table(tv):
    if tv.property("_mt_table"):
        return
    tv.setProperty("_mt_table", True)
    # ضبط أعمدة/صفوف الجدول حسب الخط والمحتوى (حتى لا يُقطع النص عند تغيير الخط)
    try:
        from table_autofit import install_autofit
        install_autofit(tv)
    except Exception:
        pass
    if not tv.alternatingRowColors():
        tv.setAlternatingRowColors(True)
    try:
        vh = tv.verticalHeader()
        if vh.defaultSectionSize() < 40:
            vh.setDefaultSectionSize(40)
        hh = tv.horizontalHeader()
        if hh is not None and not _has_header_rule(tv):
            hh.setStyleSheet(HEADER_QSS)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# مرشّح الأحداث العام
# ---------------------------------------------------------------------------
class ModernThemeFilter(QObject):

    def eventFilter(self, obj, event):
        t = event.type()
        try:
            if t == QEvent.Show:
                if isinstance(obj, QPushButton):
                    _setup_button(obj)
                elif isinstance(obj, QTableView) and ENABLE_TABLE_POLISH:
                    _polish_table(obj)
                elif isinstance(obj, QTabWidget) and ENABLE_PAGE_FADE:
                    _hook_tabs(obj)
                elif isinstance(obj, QStackedWidget) and ENABLE_PAGE_FADE:
                    _hook_stack(obj)
                if isinstance(obj, QWidget) and obj.isWindow():
                    if ENABLE_WINDOW_FADE:
                        _fade_window(obj)
                    if ENABLE_DIALOG_SLIDE and isinstance(obj, QDialog) \
                            and obj.windowType() not in (Qt.Popup, Qt.ToolTip):
                        _slide_dialog(obj)
            elif isinstance(obj, QPushButton) and ENABLE_BUTTON_EFFECTS:
                if t == QEvent.Enter and obj.isEnabled():
                    _animate_button(obj, 1.0)
                elif t == QEvent.Leave:
                    _animate_button(obj, 0.0)
                elif t == QEvent.MouseButtonPress and obj.isEnabled():
                    _animate_button(obj, -0.35, 70)
                    if (ENABLE_RIPPLE and event.button() == Qt.LeftButton
                            and not obj.isFlat() and obj.width() > 0):
                        _Ripple(obj, event.pos(), getattr(obj, "_mt_dark", False))
                elif t == QEvent.MouseButtonRelease and obj.isEnabled():
                    _animate_button(obj, 1.0 if obj.underMouse() else 0.0, 120)
        except RuntimeError:
            pass
        return False


# ---------------------------------------------------------------------------
# Toast: إشعار منزلق غير معطِّل (بديل عن رسائل "تم" المزعجة)
# ---------------------------------------------------------------------------
_TOAST_COLORS = {"success": "#128456", "error": "#d03a50", "warning": "#b05c00", "info": "#5a4ee3"}


def show_toast(parent, text, kind="success", ms=2600):
    """إشعار بسيط غير معطِّل (بدون حركات/شفافية لتخفيف الحمل على الجهاز)."""
    win = parent.window() if parent is not None else QApplication.activeWindow()
    if win is None:
        return
    lbl = QLabel(text, win)
    lbl.setAttribute(Qt.WA_TransparentForMouseEvents)
    lbl.setAlignment(Qt.AlignCenter)
    lbl.setStyleSheet(
        f"background:{_TOAST_COLORS.get(kind, '#5a4ee3')}; color:white; font-weight:bold;"
        " border-radius:8px; padding:11px 26px;")
    lbl.adjustSize()
    lbl.move((win.width() - lbl.width()) // 2, win.height() - lbl.height() - 36)
    lbl.show()
    lbl.raise_()
    QTimer.singleShot(ms, lambda: lbl.deleteLater())


# ---------------------------------------------------------------------------
# التنسيق العام
# ---------------------------------------------------------------------------
_MARK_START = "/* __MODERN_THEME_START__ */"
_MARK_END = "/* __MODERN_THEME_END__ */"


def _asset(name, icon_name, color, size):
    try:
        import qtawesome as qta
        path = os.path.join(tempfile.gettempdir(), f"expertise_{name}.png")
        qta.icon(icon_name, color=color).pixmap(size, size).save(path, "PNG")
        return path.replace("\\", "/")
    except Exception:
        return None


def _global_qss():
    arrow = _asset("chevron_down", "fa5s.chevron-down", NAVY, 12)
    check = _asset("check_white", "fa5s.check", "white", 12)
    arrow_rule = (f"QComboBox::down-arrow, QDateEdit::down-arrow {{ image: url({arrow}); width: 12px; height: 12px; }}"
                  if arrow else "")
    check_rule = (f"QCheckBox::indicator:checked {{ image: url({check}); background: {NAVY}; border: 1px solid {NAVY}; }}"
                  if check else f"QCheckBox::indicator:checked {{ background: {NAVY}; border: 1px solid {NAVY}; }}")
    return f"""
    QToolTip {{ background: {NAVY}; color: white; border: none; padding: 6px 10px; border-radius: 6px; }}

    QScrollBar:vertical {{ background: transparent; width: 12px; margin: 2px; }}
    QScrollBar::handle:vertical {{ background: #c7cdea; border-radius: 4px; min-height: 32px; }}
    QScrollBar::handle:vertical:hover {{ background: #a9b0d0; }}
    QScrollBar:horizontal {{ background: transparent; height: 12px; margin: 2px; }}
    QScrollBar::handle:horizontal {{ background: #c7cdea; border-radius: 4px; min-width: 32px; }}
    QScrollBar::handle:horizontal:hover {{ background: #a9b0d0; }}
    QScrollBar::add-line, QScrollBar::sub-line {{ width: 0px; height: 0px; }}
    QScrollBar::add-page, QScrollBar::sub-page {{ background: transparent; }}

    QLineEdit, QTextEdit, QPlainTextEdit, QComboBox, QDateEdit {{
        border: 1px solid {T.BORDER_STRONG}; border-radius: {T.RADIUS_CTRL}px; padding: 6px 10px;
        background: white; selection-background-color: {ACCENT}; selection-color: white;
    }}
    QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus, QComboBox:focus, QDateEdit:focus {{
        border: 1px solid {ACCENT};
    }}
    QLineEdit:disabled, QTextEdit:disabled, QPlainTextEdit:disabled, QComboBox:disabled, QDateEdit:disabled {{
        background: #f8f9ff; color: #6b7399;
    }}
    QLineEdit:read-only {{ background: #f1f2ff; }}
    QLineEdit, QComboBox, QDateEdit {{ min-height: {T.CONTROL_HEIGHT - 14}px; }}
    QComboBox::drop-down, QDateEdit::drop-down {{ border: none; width: 26px; }}
    {arrow_rule}
    QComboBox QLineEdit {{ border: none; padding: 0; background: transparent; }}
    QComboBox QAbstractItemView {{
        border: 1px solid #cdd3ee; background: white; outline: 0;
        selection-background-color: {T.HOVER_BG}; selection-color: {NAVY};
    }}

    QCheckBox {{ spacing: 8px; }}
    QCheckBox::indicator {{ width: 18px; height: 18px; border: 1px solid #c7cdea; border-radius: 5px; background: white; }}
    QCheckBox::indicator:hover {{ border: 1px solid {ACCENT}; }}
    {check_rule}
    QRadioButton::indicator {{ width: 16px; height: 16px; }}

    QTableCornerButton::section {{ background: {NAVY}; border: none; }}
    QTableView {{
        gridline-color: #eef0ff; alternate-background-color: #f1f2ff;
        selection-background-color: #e2e0ff; selection-color: {NAVY};
    }}
    QTableView::item {{ padding: 0 6px; }}
    QTableView::item:selected {{ background: #e2e0ff; color: {NAVY}; }}

    QListWidget::item:hover {{ background: {T.HOVER_BG}; }}
    QListWidget::item:selected {{ background: #e2e0ff; color: {NAVY}; }}

    QProgressBar {{ border: none; border-radius: 6px; background: #eef0ff; text-align: center; height: 12px; }}
    QProgressBar::chunk {{ border-radius: 6px; background: #5a4ee3; }}

    QDialog {{ background: #f8f9ff; }}
    QGroupBox {{
        background: white; border: 1px solid #e4e7f7; border-radius: 12px;
        margin-top: 14px; padding: 14px 10px 10px 10px; font-weight: bold; color: {NAVY};
    }}
    QGroupBox::title {{ subcontrol-origin: margin; subcontrol-position: top right; padding: 0 10px; }}
    QTabBar::tab:focus, QPushButton:focus {{ outline: none; }}

    QMenu {{ background: white; border: 1px solid #e4e7f7; padding: 4px; }}
    QMenu::item {{ padding: 6px 26px; border-radius: 4px; }}
    QMenu::item:selected {{ background: {T.HOVER_BG}; color: {NAVY}; }}
    QMenu::separator {{ height: 1px; background: #eef0ff; margin: 4px 8px; }}

    QMessageBox {{ background: white; }}
    QMessageBox QLabel {{ min-width: 340px; font-size: 10.5pt; color: {T.TEXT}; }}
    QMessageBox QPushButton {{ min-width: 96px; min-height: 22px; }}

    QPushButton {{
        background: #ffffff; color: {NAVY}; border: 1px solid #cdd3ee;
        border-radius: {T.RADIUS_CTRL}px; padding: 8px 20px;
        font-weight: 600; min-height: 20px;
    }}
    QPushButton:hover {{ background: {T.HOVER_BG}; border-color: {ACCENT}; }}
    QPushButton:pressed {{ background: {T.SELECT_BG}; }}
    QPushButton:disabled {{ background: #f8f9ff; color: #9199b8; border-color: #eef0ff; }}
    """


def _install_dark_support(app):
    """الوضع الليلي: أسلوب Fusion + لوحة ألوان داكنة + ترجمة ألوان QSS اليدوية عند كل setStyleSheet.
    (أسلوب ويندوز الأصلي يتجاهل اللوحة جزئياً، لذلك نستعمل Fusion في الليلي فقط.)"""
    from PyQt5.QtGui import QPalette
    from PyQt5.QtWidgets import QWidget as _QW
    try:
        app.setStyle("Fusion")
    except Exception:
        pass
    pal = QPalette()
    c = QColor
    pal.setColor(QPalette.Window, c(T.BG))
    pal.setColor(QPalette.WindowText, c(T.TEXT))
    pal.setColor(QPalette.Base, c(T.SURFACE))
    pal.setColor(QPalette.AlternateBase, c(T.SURFACE_ALT))
    pal.setColor(QPalette.Text, c(T.TEXT))
    pal.setColor(QPalette.Button, c(T.SURFACE))
    pal.setColor(QPalette.ButtonText, c(T.TEXT))
    pal.setColor(QPalette.BrightText, c("#ffffff"))
    pal.setColor(QPalette.Highlight, c(T.ACCENT))
    pal.setColor(QPalette.HighlightedText, c("#ffffff"))
    pal.setColor(QPalette.ToolTipBase, c(T.SURFACE_ALT))
    pal.setColor(QPalette.ToolTipText, c(T.TEXT))
    pal.setColor(QPalette.Link, c("#9d93ff"))
    if hasattr(QPalette, "PlaceholderText"):
        pal.setColor(QPalette.PlaceholderText, c(T.TEXT_MUTED))
    for role in (QPalette.WindowText, QPalette.Text, QPalette.ButtonText):
        pal.setColor(QPalette.Disabled, role, c("#6c75a3"))
    app.setPalette(pal)

    if not getattr(_QW, "_mt_dark_patched", False):
        orig = _QW.setStyleSheet

        def patched(self, qss):
            orig(self, T.remap_qss(qss))

        _QW.setStyleSheet = patched
        _QW._mt_dark_patched = True


def install_modern_theme(app):
    """يُستدعى مرة واحدة بعد QApplication وقبل إنشاء أي نافذة."""
    if getattr(app, "_modern_theme_filter", None) is not None:
        return
    flt = ModernThemeFilter(app)
    app.installEventFilter(flt)
    app._modern_theme_filter = flt

    if T.IS_DARK:
        _install_dark_support(app)

    if ENABLE_GLOBAL_QSS:
        existing = app.styleSheet() or ""
        if _MARK_START in existing and _MARK_END in existing:
            existing = existing.split(_MARK_START)[0] + existing.split(_MARK_END)[-1]
        app.setStyleSheet(existing + f"\n{_MARK_START}\n{T.remap_qss(_global_qss())}\n{_MARK_END}\n")
