from msgbox_ltr import show_warning, show_question
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QHBoxLayout,
    QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView,
    QMessageBox, QDialog, QFrame, QTextEdit, QComboBox,
    QListWidget, QListWidgetItem, QGridLayout, QScrollArea, QApplication
)
from PyQt5.QtGui import QFont, QColor
from PyQt5.QtCore import Qt
import qtawesome as qta
import storage
from storage import load_parties, save_parties

# ---------------------------------------------------------------------------
# ترتيب الأعمدة المنطقية (لا يتغيّر: صفحات أخرى مثل محضر الحضور تقرأ الأعمدة 0 و2 و3).
# الأعمدة الجديدة أُضيفت في النهاية، وتُعرض بصرياً بعد "الصفة" مباشرة.
# ---------------------------------------------------------------------------
KEYS = ["name", "role", "id_number", "id_date", "address", "phone", "email",
        "linked_entity", "notes", "cases", "lawyer_name", "lawyer_phone"]
CASES_COL = KEYS.index("cases")
NO_CASE = "__none__"

# القيم المخزّنة للصفة عربية دائماً (ثابتة)، والعرض يُترجم حسب لغة البرنامج
ROLES_AR = ["مدعي", "مدعى عليه", "مدخل في الخصام", "متدخل في الخصام", "شاهد", "أخرى"]

TEXTS = {
    "ar": {
        "cols": ["الاسم الكامل", "الصفة", "رقم بطاقة التعريف الوطنية", "تاريخ صدور ب ت و",
                 "العنوان", "رقم الهاتف", "البريد الإلكتروني", "جهة مرتبطة", "ملاحظات",
                 "القضايا المرتبطة", "المحامي", "هاتف المحامي"],
        "roles": ROLES_AR,
        "title": "إدارة الأطراف",
        "search": "ابحث عن طرف بالاسم أو الصفة أو المحامي...",
        "case_lbl": "القضية", "all_cases": "كل القضايا", "no_case": "غير مرتبطة بأي قضية",
        "not_linked": "غير مرتبط", "count": "عدد الأطراف المعروضة: {n}",
        "add": "إضافة", "edit": "تعديل", "delete": "حذف",
        "error": "خطأ", "warn": "تنبيه",
        "select_edit": "الرجاء اختيار طرف للتعديل.", "select_delete": "يرجى اختيار صف للحذف.",
        "confirm_title": "تأكيد الحذف", "confirm_delete": "هل أنت متأكد من حذف هذا الطرف؟",
        "dlg_add": "إضافة طرف", "dlg_edit": "تعديل بيانات الطرف",
        "sec_info": "بيانات الطرف", "sec_cases": "القضايا المرتبطة",
        "sec_lawyer": "محامي الطرف", "sec_notes": "ملاحظات",
        "f_name": "الاسم الكامل", "f_role": "الصفة", "f_id": "رقم بطاقة التعريف الوطنية",
        "f_id_date": "تاريخ صدور ب ت و", "f_address": "العنوان", "f_phone": "رقم الهاتف",
        "f_email": "البريد الإلكتروني", "f_entity": "جهة مرتبطة",
        "f_lawyer": "اسم المحامي", "f_lawyer_phone": "هاتف المحامي",
        "hint_cases": "ضع علامة أمام كل قضية يكون هذا الطرف طرفاً فيها.",
        "empty_cases": "لا توجد قضايا في هذه السنة بعد. أضف القضية أولاً ثم اربط الطرف بها.",
        "year": "سنة {y}", "vs": "ضد",
        "save": "حفظ", "cancel": "إلغاء",
        "name_required": "الرجاء إدخال الاسم الكامل للطرف.",
    },
    "fr": {
        "cols": ["Nom complet", "Qualité", "N° carte d'identité nationale", "Date de délivrance",
                 "Adresse", "Téléphone", "E-mail", "Entité liée", "Notes",
                 "Affaires liées", "Avocat", "Tél. de l'avocat"],
        "roles": ["Demandeur", "Défendeur", "Partie appelée en cause", "Intervenant", "Témoin", "Autre"],
        "title": "Gestion des parties",
        "search": "Rechercher une partie par nom, qualité ou avocat...",
        "case_lbl": "Affaire", "all_cases": "Toutes les affaires", "no_case": "Non liées à une affaire",
        "not_linked": "Non liée", "count": "Parties affichées : {n}",
        "add": "Ajouter", "edit": "Modifier", "delete": "Supprimer",
        "error": "Erreur", "warn": "Attention",
        "select_edit": "Veuillez sélectionner une partie à modifier.",
        "select_delete": "Veuillez sélectionner une ligne à supprimer.",
        "confirm_title": "Confirmer la suppression",
        "confirm_delete": "Voulez-vous vraiment supprimer cette partie ?",
        "dlg_add": "Ajouter une partie", "dlg_edit": "Modifier la partie",
        "sec_info": "Informations de la partie", "sec_cases": "Affaires liées",
        "sec_lawyer": "Avocat de la partie", "sec_notes": "Notes",
        "f_name": "Nom complet", "f_role": "Qualité", "f_id": "N° carte d'identité nationale",
        "f_id_date": "Date de délivrance", "f_address": "Adresse", "f_phone": "Téléphone",
        "f_email": "E-mail", "f_entity": "Entité liée",
        "f_lawyer": "Nom de l'avocat", "f_lawyer_phone": "Téléphone de l'avocat",
        "hint_cases": "Cochez chaque affaire dans laquelle cette partie est impliquée.",
        "empty_cases": "Aucune affaire cette année. Ajoutez d'abord l'affaire, puis liez la partie.",
        "year": "année {y}", "vs": "contre",
        "save": "Enregistrer", "cancel": "Annuler",
        "name_required": "Veuillez saisir le nom complet de la partie.",
    },
    "en": {
        "cols": ["Full name", "Role", "National ID number", "ID issue date",
                 "Address", "Phone", "Email", "Linked entity", "Notes",
                 "Linked cases", "Lawyer", "Lawyer phone"],
        "roles": ["Plaintiff", "Defendant", "Third party", "Intervenor", "Witness", "Other"],
        "title": "Party management",
        "search": "Search a party by name, role or lawyer...",
        "case_lbl": "Case", "all_cases": "All cases", "no_case": "Not linked to any case",
        "not_linked": "Not linked", "count": "Parties shown: {n}",
        "add": "Add", "edit": "Edit", "delete": "Delete",
        "error": "Error", "warn": "Warning",
        "select_edit": "Please select a party to edit.",
        "select_delete": "Please select a row to delete.",
        "confirm_title": "Confirm deletion",
        "confirm_delete": "Are you sure you want to delete this party?",
        "dlg_add": "Add party", "dlg_edit": "Edit party details",
        "sec_info": "Party details", "sec_cases": "Linked cases",
        "sec_lawyer": "Party's lawyer", "sec_notes": "Notes",
        "f_name": "Full name", "f_role": "Role", "f_id": "National ID number",
        "f_id_date": "ID issue date", "f_address": "Address", "f_phone": "Phone",
        "f_email": "Email", "f_entity": "Linked entity",
        "f_lawyer": "Lawyer's name", "f_lawyer_phone": "Lawyer's phone",
        "hint_cases": "Tick each case this party is involved in.",
        "empty_cases": "No cases this year yet. Add the case first, then link the party.",
        "year": "year {y}", "vs": "vs",
        "save": "Save", "cancel": "Cancel",
        "name_required": "Please enter the party's full name.",
    },
}


def _tx(lang, key):
    return TEXTS.get(lang, TEXTS["ar"]).get(key, TEXTS["ar"][key])


def _saved_language():
    try:
        from settings_page import AppSettings
        return AppSettings().get_language_code()
    except Exception:
        return "ar"


def _role_display(role, lang):
    """الصفة المخزّنة (عربية) ← نص العرض بلغة الواجهة؛ النص الحر يبقى كما كتبه المستخدم."""
    if role in ROLES_AR:
        return TEXTS.get(lang, TEXTS["ar"])["roles"][ROLES_AR.index(role)]
    return role


def _role_canonical(text, lang):
    roles = TEXTS.get(lang, TEXTS["ar"])["roles"]
    return ROLES_AR[roles.index(text)] if text in roles else text


# ---------------------------------------------------------------------------
# أدوات مساعدة: القضايا مخزّنة حسب السنة، والأطراف مشتركة بين السنوات.
# لذلك يُحفظ الربط على شكل {"year": "2026", "number": "123/26"}.
# ---------------------------------------------------------------------------
def _current_year():
    try:
        return str(storage.get_current_year() or "")
    except Exception:
        return ""


def _year_cases():
    """قضايا السنة الحالية: [{number, plaintiff, defendant}]"""
    try:
        cases = storage.load_cases()
    except Exception:
        return []
    result = []
    for c in cases:
        number = str(c.get("case_number", "") or "").strip()
        if number:
            result.append({
                "number": number,
                "plaintiff": str(c.get("plaintiff", "") or ""),
                "defendant": str(c.get("defendant", "") or ""),
            })
    return result


def _links(party):
    links = party.get("cases", [])
    return links if isinstance(links, list) else []


def _numbers_for_year(party, year):
    return [l.get("number", "") for l in _links(party)
            if isinstance(l, dict) and str(l.get("year", "")) == year]


class AddEditPartyDialog(QDialog):
    def __init__(self, parent=None, data=None, lang="ar"):
        super().__init__(parent)
        self.lang = lang if lang in TEXTS else "ar"
        t = lambda k: _tx(self.lang, k)
        self.setLayoutDirection(Qt.RightToLeft if self.lang == "ar" else Qt.LeftToRight)
        self.setWindowTitle(t("dlg_edit") if data else t("dlg_add"))
        self.setStyleSheet("""
            QDialog { background-color: #f1f2ff; }
            QLabel { background: transparent; color: #1f2347; font-size: 10pt; }
            QScrollArea, QScrollArea > QWidget > QWidget { background: transparent; border: none; }
            QFrame#card { background: white; border: 1px solid #eef0ff; border-radius: 10px; }
            QLineEdit, QTextEdit, QComboBox {
                padding: 6px 8px; border: 1px solid #cdd3ee; border-radius: 6px;
                background: white; font-size: 10.5pt; min-height: 22px;
            }
            QLineEdit:focus, QTextEdit:focus, QComboBox:focus { border: 1px solid #5a4ee3; }
            QListWidget { border: 1px solid #cdd3ee; border-radius: 6px; background: white;
                          font-size: 10.5pt; }
            QListWidget::item { padding: 5px; }
        """)

        # حجم يتكيّف مع الشاشة حتى لا تُقصّ النافذة، والمحتوى قابل للتمرير
        screen = QApplication.primaryScreen().availableGeometry()
        self.resize(min(760, int(screen.width() * 0.92)), min(700, int(screen.height() * 0.88)))
        self.setMinimumSize(520, 420)

        self._data = dict(data) if data else {}
        self._year = _current_year()
        self.fields = {}

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ---- الشريط العلوي ----
        header = QFrame()
        header.setFixedHeight(62)
        header.setStyleSheet("QFrame{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,"
                             "stop:0 #4338ca, stop:1 #3730a3);}")
        hl = QHBoxLayout(header)
        hl.setContentsMargins(20, 0, 20, 0)
        icon = QLabel()
        icon.setPixmap(qta.icon("fa5s.user-edit" if data else "fa5s.user-plus",
                                color="white").pixmap(24, 24))
        hl.addWidget(icon)
        title = QLabel(t("dlg_edit") if data else t("dlg_add"))
        title.setStyleSheet("color:white; font-size:15pt; font-weight:bold;")
        hl.addWidget(title)
        hl.addStretch()
        root.addWidget(header)

        # ---- المحتوى القابل للتمرير ----
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        body = QWidget()
        body_l = QVBoxLayout(body)
        body_l.setContentsMargins(18, 16, 18, 16)
        body_l.setSpacing(14)
        scroll.setWidget(body)
        root.addWidget(scroll, stretch=1)

        # بيانات الطرف
        card, grid = self._card(t("sec_info"), "fa5s.id-card")
        role_combo = QComboBox()
        role_combo.setEditable(True)
        role_combo.addItem("")
        role_combo.addItems(TEXTS[self.lang]["roles"])
        self.fields["role"] = role_combo
        for key in ("name", "id_number", "id_date", "address", "phone", "email", "linked_entity"):
            self.fields[key] = QLineEdit()
        layout_map = [
            ("f_name", "name", 0, 0, 1, 2), ("f_role", "role", 1, 0, 1, 1), ("f_id", "id_number", 1, 1, 1, 1),
            ("f_id_date", "id_date", 2, 0, 1, 1), ("f_phone", "phone", 2, 1, 1, 1),
            ("f_email", "email", 3, 0, 1, 1), ("f_entity", "linked_entity", 3, 1, 1, 1),
            ("f_address", "address", 4, 0, 1, 2),
        ]
        for label_key, key, r, c, rs, cs in layout_map:
            grid.addWidget(self._labeled(t(label_key), self.fields[key]), r, c, rs, cs)
        body_l.addWidget(card)

        # القضايا المرتبطة
        title_txt = t("sec_cases") + (f"  ({t('year').format(y=self._year)})" if self._year else "")
        card, cl = self._card(title_txt, "fa5s.balance-scale", vbox=True)
        self.cases_list = QListWidget()
        selected = set(_numbers_for_year(self._data, self._year))
        year_cases = _year_cases()
        vs = t("vs")
        for c in year_cases:
            text = c["number"]
            if c["plaintiff"] or c["defendant"]:
                text += f"\n{c['plaintiff'] or '؟'}  {vs}  {c['defendant'] or '؟'}"
            item = QListWidgetItem(text)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if c["number"] in selected else Qt.Unchecked)
            item.setData(Qt.UserRole, c["number"])
            self.cases_list.addItem(item)
        if year_cases:
            hint = QLabel(t("hint_cases"))
            hint.setStyleSheet("color:#5b6485; font-size:9.5pt;")
            cl.addWidget(hint)
            self.cases_list.setMinimumHeight(140)
            cl.addWidget(self.cases_list)
        else:
            empty = QLabel(t("empty_cases"))
            empty.setStyleSheet("color:#5b6485;")
            empty.setWordWrap(True)
            cl.addWidget(empty)
        body_l.addWidget(card)

        # المحامي
        card, grid = self._card(t("sec_lawyer"), "fa5s.user-tie")
        self.fields["lawyer_name"] = QLineEdit()
        self.fields["lawyer_phone"] = QLineEdit()
        grid.addWidget(self._labeled(t("f_lawyer"), self.fields["lawyer_name"]), 0, 0)
        grid.addWidget(self._labeled(t("f_lawyer_phone"), self.fields["lawyer_phone"]), 0, 1)
        body_l.addWidget(card)

        # ملاحظات
        card, nl = self._card(t("sec_notes"), "fa5s.sticky-note", vbox=True)
        notes = QTextEdit()
        notes.setFixedHeight(84)
        self.fields["notes"] = notes
        nl.addWidget(notes)
        body_l.addWidget(card)
        body_l.addStretch()

        # ---- الشريط السفلي (ثابت، لا يُقصّ) ----
        footer = QFrame()
        footer.setStyleSheet("QFrame{background:white; border-top:1px solid #eef0ff;}")
        fl = QHBoxLayout(footer)
        fl.setContentsMargins(18, 10, 18, 10)
        save_btn = QPushButton(t("save"))
        save_btn.setIcon(qta.icon("fa5s.check", color="white"))
        save_btn.setDefault(True)
        save_btn.setStyleSheet(
            "QPushButton{background:#4338ca;color:white;padding:9px 30px;border-radius:6px;"
            "font-weight:bold;font-size:10.5pt;} QPushButton:hover{background:#4338ca;}")
        save_btn.clicked.connect(self._on_save)
        cancel_btn = QPushButton(t("cancel"))
        cancel_btn.setStyleSheet(
            "QPushButton{background:#f1f2ff;color:#1f2347;padding:9px 24px;border-radius:6px;"
            "font-size:10.5pt;} QPushButton:hover{background:#eef0ff;}")
        cancel_btn.clicked.connect(self.reject)
        fl.addWidget(save_btn)
        fl.addWidget(cancel_btn)
        fl.addStretch()
        root.addWidget(footer)

        # تعبئة القيم الحالية
        for key, field in self.fields.items():
            value = str(self._data.get(key, "") or "")
            if isinstance(field, QLineEdit):
                field.setText(value)
            elif isinstance(field, QComboBox):
                field.setCurrentText(_role_display(value, self.lang))
            else:
                field.setPlainText(value)

    # ---------------- عناصر مساعدة للتصميم ----------------
    def _card(self, title_text, icon_name, vbox=False):
        card = QFrame()
        card.setObjectName("card")
        outer = QVBoxLayout(card)
        outer.setContentsMargins(16, 12, 16, 14)
        outer.setSpacing(10)
        head = QHBoxLayout()
        ic = QLabel()
        ic.setPixmap(qta.icon(icon_name, color="#4338ca").pixmap(16, 16))
        head.addWidget(ic)
        lbl = QLabel(title_text)
        lbl.setStyleSheet("color:#4338ca; font-size:11.5pt; font-weight:bold;")
        head.addWidget(lbl)
        head.addStretch()
        outer.addLayout(head)
        line = QFrame()
        line.setFixedHeight(1)
        line.setStyleSheet("background:#eef0ff; border:none;")
        outer.addWidget(line)
        if vbox:
            return card, outer
        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(10)
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1)
        outer.addLayout(grid)
        return card, grid

    @staticmethod
    def _labeled(text, widget):
        box = QWidget()
        lay = QVBoxLayout(box)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(4)
        lbl = QLabel(text)
        lbl.setStyleSheet("color:#5b6485; font-weight:bold;")
        lay.addWidget(lbl)
        lay.addWidget(widget)
        return box

    def _on_save(self):
        if not self.fields["name"].text().strip():
            show_warning(self, _tx(self.lang, "warn"), _tx(self.lang, "name_required"))
            return
        self.accept()

    def get_data(self):
        data = dict(self._data)  # يحافظ على أي مفاتيح أخرى
        for key, field in self.fields.items():
            if isinstance(field, QLineEdit):
                data[key] = field.text().strip()
            elif isinstance(field, QComboBox):
                data[key] = _role_canonical(field.currentText().strip(), self.lang)
            else:
                data[key] = field.toPlainText().strip()

        # نُبقي ارتباطات السنوات الأخرى كما هي، ونستبدل ارتباطات السنة الحالية
        links = [l for l in _links(self._data)
                 if isinstance(l, dict) and str(l.get("year", "")) != self._year]
        for i in range(self.cases_list.count()):
            item = self.cases_list.item(i)
            if item.checkState() == Qt.Checked:
                links.append({"year": self._year, "number": item.data(Qt.UserRole)})
        data["cases"] = links
        return data


class PartyPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setStyleSheet("background-color: #f8f9ff;")
        self.parties = []
        self.lang = _saved_language()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(10)

        self.title_lbl = QLabel()
        self.title_lbl.setFont(QFont("Segoe UI", 16, QFont.Bold))
        layout.addWidget(self.title_lbl)

        # ---- البحث + التصفية حسب القضية ----
        tools = QHBoxLayout()
        self.search_bar = QLineEdit()
        self.search_bar.setMinimumHeight(34)
        self.search_bar.textChanged.connect(self.apply_filters)
        tools.addWidget(self.search_bar, stretch=1)

        self.case_lbl = QLabel()
        self.case_lbl.setFont(QFont("Segoe UI", 11, QFont.Bold))
        self.case_lbl.setStyleSheet("color:#1f2347; background:transparent;")
        tools.addWidget(self.case_lbl)

        self.case_filter = QComboBox()
        self.case_filter.setMinimumWidth(230)
        self.case_filter.setMinimumHeight(34)
        self.case_filter.currentIndexChanged.connect(self.apply_filters)
        tools.addWidget(self.case_filter)
        layout.addLayout(tools)

        # ---- الجدول ----
        self.table = QTableWidget(0, len(KEYS))
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.setStyleSheet("""
            QTableWidget { background: white; alternate-background-color: #f1f2ff;
                           gridline-color: #eef0ff; border: 1px solid #e4e7f7; }
            QTableWidget::item:selected { background-color: #5a4ee3; color: white; }
            QHeaderView::section { background-color: #4338ca; color: white; padding: 6px;
                                   border: none; border-left: 1px solid #3730a3; font-weight: bold; }
        """)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Interactive)
        header.setStretchLastSection(False)
        widths = [170, 100, 150, 110, 180, 110, 170, 130, 160, 150, 140, 120]
        for col, w in enumerate(widths):
            self.table.setColumnWidth(col, w)
        # عرضياً: الصفة ← القضايا المرتبطة ← المحامي ← هاتف المحامي (بعد الاسم مباشرة)
        for target, key in enumerate(["role", "cases", "lawyer_name", "lawyer_phone"], start=1):
            header.moveSection(header.visualIndex(KEYS.index(key)), target)
        self.table.doubleClicked.connect(lambda _idx: self.edit_party())
        layout.addWidget(self.table)

        # ---- الأزرار ----
        btn_layout = QHBoxLayout()
        self.add_btn = add_btn = QPushButton()
        add_btn.setIcon(qta.icon("fa5s.plus", color="white"))
        add_btn.setStyleSheet(self.button_style("#128456"))
        add_btn.clicked.connect(self.add_party)

        self.edit_btn = edit_btn = QPushButton()
        edit_btn.setIcon(qta.icon("fa5s.edit", color="white"))
        edit_btn.setStyleSheet(self.button_style("#5a4ee3"))
        edit_btn.clicked.connect(self.edit_party)

        self.delete_btn = delete_btn = QPushButton()
        delete_btn.setIcon(qta.icon("fa5s.trash", color="white"))
        delete_btn.setStyleSheet(self.button_style("#d03a50"))
        delete_btn.clicked.connect(self.delete_party)

        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(edit_btn)
        btn_layout.addWidget(delete_btn)
        btn_layout.addStretch()

        self.count_lbl = QLabel()
        self.count_lbl.setStyleSheet("color:#5b6485; background:transparent;")
        btn_layout.addWidget(self.count_lbl)
        layout.addLayout(btn_layout)

        self.apply_language(self.lang)
        self.load_data()  # تحميل بيانات الأطراف عند فتح الصفحة

    def _t(self, key, **kw):
        text = _tx(self.lang, key)
        return text.format(**kw) if kw else text

    def apply_language(self, lang_code):
        """يُستدعى عند تغيير لغة البرنامج: يبدّل كل نصوص الصفحة."""
        self.lang = lang_code if lang_code in TEXTS else "ar"
        self.title_lbl.setText(self._t("title"))
        self.search_bar.setPlaceholderText(self._t("search"))
        self.case_lbl.setText(self._t("case_lbl") + " :")
        self.table.setHorizontalHeaderLabels(TEXTS[self.lang]["cols"])
        self.add_btn.setText(self._t("add"))
        self.edit_btn.setText(self._t("edit"))
        self.delete_btn.setText(self._t("delete"))
        if hasattr(self, "case_filter"):
            self.refresh_case_filter()
            self.render_table()
            self.apply_filters()

    # ------------------------------------------------------------------
    def reload(self):
        """إعادة تحميل بيانات الأطراف (تُستدعى عند تفعيل التبويب أو تبديل الملف)."""
        self.load_data()

    def load_data(self):
        self.parties = load_parties()
        self.refresh_case_filter()
        self.render_table()
        self.apply_filters()

    def refresh_case_filter(self):
        previous = self.case_filter.currentData()
        self.case_filter.blockSignals(True)
        self.case_filter.clear()
        self.case_filter.addItem(self._t("all_cases"), None)
        self.case_filter.addItem(self._t("no_case"), NO_CASE)
        for c in _year_cases():
            self.case_filter.addItem(c["number"], c["number"])
        index = self.case_filter.findData(previous)
        self.case_filter.setCurrentIndex(index if index >= 0 else 0)
        self.case_filter.blockSignals(False)

    def render_table(self):
        year = _current_year()
        self.table.setRowCount(0)
        for party in self.parties:
            row = self.table.rowCount()
            self.table.insertRow(row)
            for col, key in enumerate(KEYS):
                if key == "cases":
                    numbers = _numbers_for_year(party, year)
                    item = QTableWidgetItem("  ،  ".join(numbers) if numbers else self._t("not_linked"))
                    if not numbers:
                        item.setForeground(QColor("#9aa3c7"))
                elif key == "role":
                    item = QTableWidgetItem(_role_display(str(party.get(key, "") or ""), self.lang))
                else:
                    item = QTableWidgetItem(str(party.get(key, "") or ""))
                item.setToolTip(item.text())
                self.table.setItem(row, col, item)

    def button_style(self, color):
        return f"""
            QPushButton {{
                background-color: {color};
                color: white;
                padding: 8px 14px;
                border-radius: 6px;
            }}
            QPushButton:hover {{
                background-color: #1f2347;
            }}
        """

    # ------------------------------------------------------------------
    def add_party(self):
        dialog = AddEditPartyDialog(self, lang=self.lang)
        if dialog.exec_() == QDialog.Accepted:
            self.parties.append(dialog.get_data())
            save_parties(self.parties)
            self.render_table()
            self.apply_filters()

    def edit_party(self):
        row = self.table.currentRow()
        if row < 0 or row >= len(self.parties):
            show_warning(self, self._t("error"), self._t("select_edit"))
            return
        dialog = AddEditPartyDialog(self, self.parties[row], lang=self.lang)
        if dialog.exec_() == QDialog.Accepted:
            self.parties[row] = dialog.get_data()
            save_parties(self.parties)
            self.render_table()
            self.apply_filters()
            self.table.selectRow(row)

    def delete_party(self):
        row = self.table.currentRow()
        if row < 0 or row >= len(self.parties):
            show_warning(self, self._t("error"), self._t("select_delete"))
            return
        confirm = show_question(self, self._t("confirm_title"), self._t("confirm_delete"))
        if confirm == QMessageBox.Yes:
            del self.parties[row]
            save_parties(self.parties)
            self.render_table()
            self.apply_filters()

    # ------------------------------------------------------------------
    def apply_filters(self, *_):
        query = self.search_bar.text().strip().lower()
        case_filter = self.case_filter.currentData()
        year = _current_year()
        visible_count = 0
        for row in range(self.table.rowCount()):
            visible = True
            if query:
                visible = any(
                    (self.table.item(row, col) is not None
                     and query in self.table.item(row, col).text().lower())
                    for col in range(self.table.columnCount())
                )
            if visible and row < len(self.parties) and case_filter is not None:
                numbers = _numbers_for_year(self.parties[row], year)
                if case_filter == NO_CASE:
                    visible = not numbers
                else:
                    visible = case_filter in numbers
            self.table.setRowHidden(row, not visible)
            if visible:
                visible_count += 1
        self.count_lbl.setText(self._t("count", n=visible_count))

    # للتوافق مع أي استدعاء قديم
    def filter_table(self):
        self.apply_filters()

    def save_current_data(self):
        save_parties(self.parties)
